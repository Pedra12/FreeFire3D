package d3;

public final class a implements r7.a
{
    private static final Object c;
    private volatile r7.a a;
    private volatile Object b;
    
    static {
        c = new Object();
    }
    
    private a(final r7.a a) {
        this.b = d3.a.c;
        this.a = a;
    }
    
    public static r7.a a(final r7.a a) {
        d.b(a);
        if (a instanceof a) {
            return a;
        }
        return (r7.a)new a(a);
    }
    
    private static Object b(final Object o, final Object o2) {
        if (o == a.c) {
            return o2;
        }
        if (o == o2) {
            return o2;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Scoped provider was invoked recursively returning different results: ");
        sb.append(o);
        sb.append(" & ");
        sb.append(o2);
        sb.append(". This is likely due to a circular dependency.");
        throw new IllegalStateException(sb.toString());
    }
    
    public Object get() {
        final Object b = this.b;
        final Object c = d3.a.c;
        if (b == c) {
            monitorenter(this);
            Label_0065: {
                try {
                    Object o;
                    if ((o = this.b) == c) {
                        o = this.a.get();
                        this.b = b(this.b, o);
                        this.a = null;
                    }
                    break Label_0065;
                }
                finally {
                    monitorexit(this);
                    monitorexit(this);
                    return;
                }
            }
        }
        return b;
    }
}
