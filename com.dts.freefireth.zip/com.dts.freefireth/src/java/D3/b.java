package d3;

import r7.a;

public interface b extends a
{
}
