package d3;

public final class c implements b
{
    private static final c b;
    private final Object a;
    
    static {
        b = new c(null);
    }
    
    private c(final Object a) {
        this.a = a;
    }
    
    public static b a(final Object o) {
        return (b)new c(d.c(o, "instance cannot be null"));
    }
    
    public Object get() {
        return this.a;
    }
}
