package d2;

import org.json.JSONException;
import java.util.Map$Entry;
import n2.w;
import n2.W;
import java.util.Map;
import java.util.HashMap;
import org.json.JSONObject;
import n2.A;
import com.facebook.e;
import java.util.Iterator;
import android.util.Log;
import kotlin.jvm.internal.Intrinsics;
import java.util.Collection;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;

public final class a
{
    public static final a a;
    private static boolean b;
    private static final String c;
    private static final List d;
    private static final Set e;
    
    static {
        a = new a();
        c = a.class.getCanonicalName();
        d = (List)new ArrayList();
        e = (Set)new CopyOnWriteArraySet();
    }
    
    private a() {
    }
    
    public static final void a() {
        d2.a.b = true;
        d2.a.a.c();
    }
    
    private final String b(String s, final String s2) {
        try {
            final ArrayList list = new ArrayList((Collection)d2.a.d);
            final int size = list.size();
            int i = 0;
        Label_0022:
            while (i < size) {
                final Object value = list.get(i);
                final int n = i + 1;
                final a a = (a)value;
                if (a == null) {
                    i = n;
                }
                else {
                    i = n;
                    if (Intrinsics.a((Object)s, (Object)a.a())) {
                        final Iterator iterator = a.b().keySet().iterator();
                        String s3;
                        do {
                            i = n;
                            if (!iterator.hasNext()) {
                                continue Label_0022;
                            }
                            s3 = (String)iterator.next();
                        } while (!Intrinsics.a((Object)s2, (Object)s3));
                        return (String)a.b().get((Object)s3);
                    }
                    continue;
                }
            }
            return null;
            a a = null;
            String s3 = null;
            s = (String)a.b().get((Object)s3);
            return s;
        }
        catch (final Exception ex) {
            Log.w(d2.a.c, "getMatchedRuleType failed", (Throwable)ex);
        }
        return null;
    }
    
    private final void c() {
        try {
            final w o = A.o(com.facebook.e.m(), false);
            if (o != null) {
                final String j = o.j();
                if (j != null) {
                    if (((CharSequence)j).length() == 0) {
                        return;
                    }
                    final JSONObject jsonObject = new JSONObject(j);
                    d2.a.d.clear();
                    d2.a.e.clear();
                    final Iterator keys = jsonObject.keys();
                    while (keys.hasNext()) {
                        final String s = (String)keys.next();
                        final JSONObject jsonObject2 = jsonObject.getJSONObject(s);
                        if (jsonObject2 != null) {
                            final JSONObject optJSONObject = jsonObject2.optJSONObject("restrictive_param");
                            Intrinsics.c((Object)s);
                            final a a = new a(s, (Map)new HashMap());
                            if (optJSONObject != null) {
                                a.c(W.o(optJSONObject));
                                d2.a.d.add((Object)a);
                            }
                            if (!jsonObject2.has("process_event_name")) {
                                continue;
                            }
                            d2.a.e.add((Object)a.a());
                        }
                    }
                }
            }
        }
        catch (final Exception ex) {}
    }
    
    private final boolean d(final String s) {
        return d2.a.e.contains((Object)s);
    }
    
    public static final String e(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "eventName");
        String s2 = s;
        if (d2.a.b) {
            s2 = s;
            if (d2.a.a.d(s)) {
                s2 = "_removed_";
            }
        }
        return s2;
    }
    
    public static final void f(final Map map, final String s) {
        Intrinsics.checkNotNullParameter((Object)map, "parameters");
        Intrinsics.checkNotNullParameter((Object)s, "eventName");
        if (!d2.a.b) {
            return;
        }
        final HashMap hashMap = new HashMap();
        final ArrayList list = new ArrayList((Collection)map.keySet());
        int n;
        for (int size = list.size(), i = 0; i < size; i = n) {
            final Object value = list.get(i);
            n = i + 1;
            final String s2 = (String)value;
            final String b = d2.a.a.b(s, s2);
            i = n;
            if (b != null) {
                ((Map)hashMap).put((Object)s2, (Object)b);
                map.remove((Object)s2);
            }
        }
        if (((Map)hashMap).isEmpty()) {
            return;
        }
        try {
            final JSONObject jsonObject = new JSONObject();
            for (final Map$Entry map$Entry : ((Map)hashMap).entrySet()) {
                jsonObject.put((String)map$Entry.getKey(), (Object)map$Entry.getValue());
            }
            map.put((Object)"_restrictedParams", (Object)jsonObject.toString());
        }
        catch (final JSONException ex) {}
    }
    
    public static final class a
    {
        private String a;
        private Map b;
        
        public a(final String a, final Map b) {
            Intrinsics.checkNotNullParameter((Object)a, "eventName");
            Intrinsics.checkNotNullParameter((Object)b, "restrictiveParams");
            this.a = a;
            this.b = b;
        }
        
        public final String a() {
            return this.a;
        }
        
        public final Map b() {
            return this.b;
        }
        
        public final void c(final Map b) {
            Intrinsics.checkNotNullParameter((Object)b, "<set-?>");
            this.b = b;
        }
    }
}
