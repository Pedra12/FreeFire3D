package b0;

import android.util.Log;
import W.X;
import java.util.Arrays;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.content.Context;
import android.view.ViewGroup;
import android.view.View;
import android.widget.OverScroller;
import android.view.VelocityTracker;
import android.view.animation.Interpolator;

public class c
{
    private static final Interpolator x;
    private int a;
    private int b;
    private int c;
    private float[] d;
    private float[] e;
    private float[] f;
    private float[] g;
    private int[] h;
    private int[] i;
    private int[] j;
    private int k;
    private VelocityTracker l;
    private float m;
    private float n;
    private int o;
    private final int p;
    private int q;
    private OverScroller r;
    private final c s;
    private View t;
    private boolean u;
    private final ViewGroup v;
    private final Runnable w;
    
    static {
        x = (Interpolator)new Interpolator() {
            public float getInterpolation(float n) {
                --n;
                return n * n * n * n * n + 1.0f;
            }
        };
    }
    
    private c(final Context context, final ViewGroup v, final c s) {
        this.c = -1;
        this.w = (Runnable)new Runnable() {
            final c a;
            
            public void run() {
                this.a.E(0);
            }
        };
        if (v == null) {
            throw new IllegalArgumentException("Parent view may not be null");
        }
        if (s != null) {
            this.v = v;
            this.s = s;
            final ViewConfiguration value = ViewConfiguration.get(context);
            final int n = (int)(context.getResources().getDisplayMetrics().density * 20.0f + 0.5f);
            this.p = n;
            this.o = n;
            this.b = value.getScaledTouchSlop();
            this.m = (float)value.getScaledMaximumFlingVelocity();
            this.n = (float)value.getScaledMinimumFlingVelocity();
            this.r = new OverScroller(context, b0.c.x);
            return;
        }
        throw new IllegalArgumentException("Callback may not be null");
    }
    
    private void A() {
        this.l.computeCurrentVelocity(1000, this.m);
        this.n(this.e(this.l.getXVelocity(this.c), this.n, this.m), this.e(this.l.getYVelocity(this.c), this.n, this.m));
    }
    
    private void B(final float n, final float n2, final int n3) {
        int c;
        final boolean b = (c = (this.c(n, n2, n3, 1) ? 1 : 0)) != 0;
        if (this.c(n2, n, n3, 4)) {
            c = ((b ? 1 : 0) | 0x4);
        }
        int n4 = c;
        if (this.c(n, n2, n3, 2)) {
            n4 = (c | 0x2);
        }
        int n5 = n4;
        if (this.c(n2, n, n3, 8)) {
            n5 = (n4 | 0x8);
        }
        if (n5 != 0) {
            final int[] i = this.i;
            i[n3] |= n5;
            this.s.f(n5, n3);
        }
    }
    
    private void C(final float n, final float n2, final int n3) {
        this.q(n3);
        this.d[n3] = (this.f[n3] = n);
        this.e[n3] = (this.g[n3] = n2);
        this.h[n3] = this.t((int)n, (int)n2);
        this.k |= 1 << n3;
    }
    
    private void D(final MotionEvent motionEvent) {
        for (int pointerCount = motionEvent.getPointerCount(), i = 0; i < pointerCount; ++i) {
            final int pointerId = motionEvent.getPointerId(i);
            if (this.x(pointerId)) {
                final float x = motionEvent.getX(i);
                final float y = motionEvent.getY(i);
                this.f[pointerId] = x;
                this.g[pointerId] = y;
            }
        }
    }
    
    private boolean c(float abs, float abs2, final int n, final int n2) {
        abs = Math.abs(abs);
        abs2 = Math.abs(abs2);
        if ((this.h[n] & n2) == n2 && (this.q & n2) != 0x0 && (this.j[n] & n2) != n2 && (this.i[n] & n2) != n2) {
            final int b = this.b;
            if (abs > b || abs2 > b) {
                if (abs < abs2 * 0.5f && this.s.g(n2)) {
                    final int[] j = this.j;
                    j[n] |= n2;
                    return false;
                }
                if ((this.i[n] & n2) == 0x0 && abs > this.b) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean d(final View view, final float n, final float n2) {
        if (view == null) {
            return false;
        }
        final boolean b = this.s.d(view) > 0;
        final boolean b2 = this.s.e(view) > 0;
        if (b && b2) {
            final int b3 = this.b;
            return n * n + n2 * n2 > b3 * b3;
        }
        if (b) {
            return Math.abs(n) > this.b;
        }
        return b2 && Math.abs(n2) > this.b;
    }
    
    private float e(final float n, float n2, final float n3) {
        final float abs = Math.abs(n);
        if (abs < n2) {
            return 0.0f;
        }
        n2 = n;
        if (abs > n3) {
            if (n > 0.0f) {
                return n3;
            }
            n2 = -n3;
        }
        return n2;
    }
    
    private int f(final int n, int n2, final int n3) {
        final int abs = Math.abs(n);
        if (abs < n2) {
            return 0;
        }
        n2 = n;
        if (abs > n3) {
            if (n > 0) {
                return n3;
            }
            n2 = -n3;
        }
        return n2;
    }
    
    private void g() {
        final float[] d = this.d;
        if (d == null) {
            return;
        }
        Arrays.fill(d, 0.0f);
        Arrays.fill(this.e, 0.0f);
        Arrays.fill(this.f, 0.0f);
        Arrays.fill(this.g, 0.0f);
        Arrays.fill(this.h, 0);
        Arrays.fill(this.i, 0);
        Arrays.fill(this.j, 0);
        this.k = 0;
    }
    
    private void h(final int n) {
        if (this.d != null) {
            if (this.w(n)) {
                this.d[n] = 0.0f;
                this.e[n] = 0.0f;
                this.f[n] = 0.0f;
                this.g[n] = 0.0f;
                this.h[n] = 0;
                this.i[n] = 0;
                this.j[n] = 0;
                this.k &= ~(1 << n);
            }
        }
    }
    
    private int i(int n, int abs, final int n2) {
        if (n == 0) {
            return 0;
        }
        final int width = ((View)this.v).getWidth();
        final int n3 = width / 2;
        final float min = Math.min(1.0f, Math.abs(n) / (float)width);
        final float n4 = (float)n3;
        final float o = this.o(min);
        abs = Math.abs(abs);
        if (abs > 0) {
            n = Math.round(Math.abs((n4 + o * n4) / abs) * 1000.0f) * 4;
        }
        else {
            n = (int)((Math.abs(n) / (float)n2 + 1.0f) * 256.0f);
        }
        return Math.min(n, 600);
    }
    
    private int j(final View view, int i, int j, int f, int n) {
        final int f2 = this.f(f, (int)this.n, (int)this.m);
        f = this.f(n, (int)this.n, (int)this.m);
        final int abs = Math.abs(i);
        final int abs2 = Math.abs(j);
        final int abs3 = Math.abs(f2);
        final int abs4 = Math.abs(f);
        final int n2 = abs3 + abs4;
        n = abs + abs2;
        float n3;
        float n4;
        if (f2 != 0) {
            n3 = (float)abs3;
            n4 = (float)n2;
        }
        else {
            n3 = (float)abs;
            n4 = (float)n;
        }
        final float n5 = n3 / n4;
        float n6;
        float n7;
        if (f != 0) {
            n6 = (float)abs4;
            n7 = (float)n2;
        }
        else {
            n6 = (float)abs2;
            n7 = (float)n;
        }
        final float n8 = n6 / n7;
        i = this.i(i, f2, this.s.d(view));
        j = this.i(j, f, this.s.e(view));
        return (int)(i * n5 + j * n8);
    }
    
    public static c l(final ViewGroup viewGroup, final float n, final c c) {
        final c m = m(viewGroup, c);
        m.b *= (int)(1.0f / n);
        return m;
    }
    
    public static c m(final ViewGroup viewGroup, final c c) {
        return new c(((View)viewGroup).getContext(), viewGroup, c);
    }
    
    private void n(final float n, final float n2) {
        this.u = true;
        this.s.l(this.t, n, n2);
        this.u = false;
        if (this.a == 1) {
            this.E(0);
        }
    }
    
    private float o(final float n) {
        return (float)Math.sin((double)((n - 0.5f) * 0.47123894f));
    }
    
    private void p(int b, final int n, final int n2, final int n3) {
        final int left = this.t.getLeft();
        final int top = this.t.getTop();
        int a = b;
        if (n2 != 0) {
            a = this.s.a(this.t, b, n2);
            X.Y(this.t, a - left);
        }
        b = n;
        if (n3 != 0) {
            b = this.s.b(this.t, n, n3);
            X.Z(this.t, b - top);
        }
        if (n2 == 0 && n3 == 0) {
            return;
        }
        this.s.k(this.t, a, b, a - left, b - top);
    }
    
    private void q(int n) {
        final float[] d = this.d;
        if (d != null && d.length > n) {
            return;
        }
        final float[] d2 = new float[++n];
        final float[] e = new float[n];
        final float[] f = new float[n];
        final float[] g = new float[n];
        final int[] h = new int[n];
        final int[] i = new int[n];
        final int[] j = new int[n];
        if (d != null) {
            System.arraycopy((Object)d, 0, (Object)d2, 0, d.length);
            final float[] e2 = this.e;
            System.arraycopy((Object)e2, 0, (Object)e, 0, e2.length);
            final float[] f2 = this.f;
            System.arraycopy((Object)f2, 0, (Object)f, 0, f2.length);
            final float[] g2 = this.g;
            System.arraycopy((Object)g2, 0, (Object)g, 0, g2.length);
            final int[] h2 = this.h;
            System.arraycopy((Object)h2, 0, (Object)h, 0, h2.length);
            final int[] k = this.i;
            System.arraycopy((Object)k, 0, (Object)i, 0, k.length);
            final int[] l = this.j;
            System.arraycopy((Object)l, 0, (Object)j, 0, l.length);
        }
        this.d = d2;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
        this.j = j;
    }
    
    private boolean s(int n, int n2, int j, final int n3) {
        final int left = this.t.getLeft();
        final int top = this.t.getTop();
        n -= left;
        n2 -= top;
        if (n == 0 && n2 == 0) {
            this.r.abortAnimation();
            this.E(0);
            return false;
        }
        j = this.j(this.t, n, n2, j, n3);
        this.r.startScroll(left, top, n, n2, j);
        this.E(2);
        return true;
    }
    
    private int t(final int n, final int n2) {
        int n3;
        final boolean b = (n3 = ((n < ((View)this.v).getLeft() + this.o) ? 1 : 0)) != 0;
        if (n2 < ((View)this.v).getTop() + this.o) {
            n3 = ((b ? 1 : 0) | 0x4);
        }
        int n4 = n3;
        if (n > ((View)this.v).getRight() - this.o) {
            n4 = (n3 | 0x2);
        }
        if (n2 > ((View)this.v).getBottom() - this.o) {
            return n4 | 0x8;
        }
        return n4;
    }
    
    private boolean x(final int n) {
        if (!this.w(n)) {
            final StringBuilder sb = new StringBuilder();
            sb.append("Ignoring pointerId=");
            sb.append(n);
            sb.append(" because ACTION_DOWN was not received for this pointer before ACTION_MOVE. It likely happened because  ViewDragHelper did not receive all the events in the event stream.");
            Log.e("ViewDragHelper", sb.toString());
            return false;
        }
        return true;
    }
    
    void E(final int a) {
        ((View)this.v).removeCallbacks(this.w);
        if (this.a != a) {
            this.a = a;
            this.s.j(a);
            if (this.a == 0) {
                this.t = null;
            }
        }
    }
    
    public boolean F(final int n, final int n2) {
        if (this.u) {
            return this.s(n, n2, (int)this.l.getXVelocity(this.c), (int)this.l.getYVelocity(this.c));
        }
        throw new IllegalStateException("Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased");
    }
    
    public boolean G(final MotionEvent motionEvent) {
        final int actionMasked = motionEvent.getActionMasked();
        final int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            this.a();
        }
        if (this.l == null) {
            this.l = VelocityTracker.obtain();
        }
        this.l.addMovement(motionEvent);
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked != 2) {
                    if (actionMasked != 3) {
                        if (actionMasked != 5) {
                            if (actionMasked != 6) {
                                return this.a == 1;
                            }
                            this.h(motionEvent.getPointerId(actionIndex));
                            return this.a == 1;
                        }
                        else {
                            final int pointerId = motionEvent.getPointerId(actionIndex);
                            final float x = motionEvent.getX(actionIndex);
                            final float y = motionEvent.getY(actionIndex);
                            this.C(x, y, pointerId);
                            final int a = this.a;
                            if (a == 0) {
                                final int n = this.h[pointerId];
                                final int q = this.q;
                                if ((n & q) != 0x0) {
                                    this.s.h(n & q, pointerId);
                                    return this.a == 1;
                                }
                                return this.a == 1;
                            }
                            else {
                                if (a != 2) {
                                    return this.a == 1;
                                }
                                final View r = this.r((int)x, (int)y);
                                if (r == this.t) {
                                    this.I(r, pointerId);
                                    return this.a == 1;
                                }
                                return this.a == 1;
                            }
                        }
                    }
                }
                else {
                    if (this.d == null) {
                        return this.a == 1;
                    }
                    if (this.e == null) {
                        return this.a == 1;
                    }
                    for (int pointerCount = motionEvent.getPointerCount(), i = 0; i < pointerCount; ++i) {
                        final int pointerId2 = motionEvent.getPointerId(i);
                        if (this.x(pointerId2)) {
                            final float x2 = motionEvent.getX(i);
                            final float y2 = motionEvent.getY(i);
                            final float n2 = x2 - this.d[pointerId2];
                            final float n3 = y2 - this.e[pointerId2];
                            final View r2 = this.r((int)x2, (int)y2);
                            final boolean b = r2 != null && this.d(r2, n2, n3);
                            if (b) {
                                final int left = r2.getLeft();
                                final int n4 = (int)n2;
                                final int a2 = this.s.a(r2, left + n4, n4);
                                final int top = r2.getTop();
                                final int n5 = (int)n3;
                                final int b2 = this.s.b(r2, top + n5, n5);
                                final int d = this.s.d(r2);
                                final int e = this.s.e(r2);
                                if (d == 0 || (d > 0 && a2 == left)) {
                                    if (e == 0) {
                                        break;
                                    }
                                    if (e > 0 && b2 == top) {
                                        break;
                                    }
                                }
                            }
                            this.B(n2, n3, pointerId2);
                            if (this.a == 1) {
                                break;
                            }
                            if (b && this.I(r2, pointerId2)) {
                                break;
                            }
                        }
                    }
                    this.D(motionEvent);
                    return this.a == 1;
                }
            }
            this.a();
        }
        else {
            final float x3 = motionEvent.getX();
            final float y3 = motionEvent.getY();
            final int pointerId3 = motionEvent.getPointerId(0);
            this.C(x3, y3, pointerId3);
            final View r3 = this.r((int)x3, (int)y3);
            if (r3 == this.t && this.a == 2) {
                this.I(r3, pointerId3);
            }
            final int n6 = this.h[pointerId3];
            final int q2 = this.q;
            if ((n6 & q2) != 0x0) {
                this.s.h(n6 & q2, pointerId3);
            }
        }
        return this.a == 1;
    }
    
    public boolean H(final View t, final int n, final int n2) {
        this.t = t;
        this.c = -1;
        final boolean s = this.s(n, n2, 0, 0);
        if (!s && this.a == 0 && this.t != null) {
            this.t = null;
        }
        return s;
    }
    
    boolean I(final View view, final int c) {
        if (view == this.t && this.c == c) {
            return true;
        }
        if (view != null && this.s.m(view, c)) {
            this.b(view, this.c = c);
            return true;
        }
        return false;
    }
    
    public void a() {
        this.c = -1;
        this.g();
        final VelocityTracker l = this.l;
        if (l != null) {
            l.recycle();
            this.l = null;
        }
    }
    
    public void b(final View t, final int c) {
        if (t.getParent() == this.v) {
            this.t = t;
            this.c = c;
            this.s.i(t, c);
            this.E(1);
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (");
        sb.append((Object)this.v);
        sb.append(")");
        throw new IllegalArgumentException(sb.toString());
    }
    
    public boolean k(final boolean b) {
        if (this.a == 2) {
            final boolean computeScrollOffset = this.r.computeScrollOffset();
            final int currX = this.r.getCurrX();
            final int currY = this.r.getCurrY();
            final int n = currX - this.t.getLeft();
            final int n2 = currY - this.t.getTop();
            if (n != 0) {
                X.Y(this.t, n);
            }
            if (n2 != 0) {
                X.Z(this.t, n2);
            }
            if (n != 0 || n2 != 0) {
                this.s.k(this.t, currX, currY, n, n2);
            }
            boolean b2 = computeScrollOffset;
            if (computeScrollOffset) {
                b2 = computeScrollOffset;
                if (currX == this.r.getFinalX()) {
                    b2 = computeScrollOffset;
                    if (currY == this.r.getFinalY()) {
                        this.r.abortAnimation();
                        b2 = false;
                    }
                }
            }
            if (!b2) {
                if (b) {
                    ((View)this.v).post(this.w);
                }
                else {
                    this.E(0);
                }
            }
        }
        return this.a == 2;
    }
    
    public View r(final int n, final int n2) {
        for (int i = this.v.getChildCount() - 1; i >= 0; --i) {
            final View child = this.v.getChildAt(this.s.c(i));
            if (n >= child.getLeft() && n < child.getRight() && n2 >= child.getTop() && n2 < child.getBottom()) {
                return child;
            }
        }
        return null;
    }
    
    public int u() {
        return this.b;
    }
    
    public boolean v(final int n, final int n2) {
        return this.y(this.t, n, n2);
    }
    
    public boolean w(final int n) {
        return (1 << n & this.k) != 0x0;
    }
    
    public boolean y(final View view, final int n, final int n2) {
        return view != null && (n >= view.getLeft() && n < view.getRight() && n2 >= view.getTop() && n2 < view.getBottom());
    }
    
    public void z(final MotionEvent motionEvent) {
        final int actionMasked = motionEvent.getActionMasked();
        final int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            this.a();
        }
        if (this.l == null) {
            this.l = VelocityTracker.obtain();
        }
        this.l.addMovement(motionEvent);
        final int n = 0;
        int i = 0;
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                if (this.a == 1) {
                    this.A();
                }
                this.a();
                return;
            }
            if (actionMasked != 2) {
                if (actionMasked == 3) {
                    if (this.a == 1) {
                        this.n(0.0f, 0.0f);
                    }
                    this.a();
                    return;
                }
                if (actionMasked != 5) {
                    if (actionMasked == 6) {
                        final int pointerId = motionEvent.getPointerId(actionIndex);
                        Label_0222: {
                            if (this.a == 1 && pointerId == this.c) {
                                while (true) {
                                    while (i < motionEvent.getPointerCount()) {
                                        final int pointerId2 = motionEvent.getPointerId(i);
                                        if (pointerId2 != this.c) {
                                            final View r = this.r((int)motionEvent.getX(i), (int)motionEvent.getY(i));
                                            final View t = this.t;
                                            if (r == t && this.I(t, pointerId2)) {
                                                final int c = this.c;
                                                if (c == -1) {
                                                    this.A();
                                                }
                                                break Label_0222;
                                            }
                                        }
                                        ++i;
                                    }
                                    final int c = -1;
                                    continue;
                                }
                            }
                        }
                        this.h(pointerId);
                    }
                }
                else {
                    final int pointerId3 = motionEvent.getPointerId(actionIndex);
                    final float x = motionEvent.getX(actionIndex);
                    final float y = motionEvent.getY(actionIndex);
                    this.C(x, y, pointerId3);
                    if (this.a == 0) {
                        this.I(this.r((int)x, (int)y), pointerId3);
                        final int n2 = this.h[pointerId3];
                        final int q = this.q;
                        if ((n2 & q) != 0x0) {
                            this.s.h(n2 & q, pointerId3);
                        }
                    }
                    else if (this.v((int)x, (int)y)) {
                        this.I(this.t, pointerId3);
                    }
                }
            }
            else {
                if (this.a != 1) {
                    for (int pointerCount = motionEvent.getPointerCount(), j = n; j < pointerCount; ++j) {
                        final int pointerId4 = motionEvent.getPointerId(j);
                        if (this.x(pointerId4)) {
                            final float x2 = motionEvent.getX(j);
                            final float y2 = motionEvent.getY(j);
                            final float n3 = x2 - this.d[pointerId4];
                            final float n4 = y2 - this.e[pointerId4];
                            this.B(n3, n4, pointerId4);
                            if (this.a == 1) {
                                break;
                            }
                            final View r2 = this.r((int)x2, (int)y2);
                            if (this.d(r2, n3, n4) && this.I(r2, pointerId4)) {
                                break;
                            }
                        }
                    }
                    this.D(motionEvent);
                    return;
                }
                if (this.x(this.c)) {
                    final int pointerIndex = motionEvent.findPointerIndex(this.c);
                    final float x3 = motionEvent.getX(pointerIndex);
                    final float y3 = motionEvent.getY(pointerIndex);
                    final float[] f = this.f;
                    final int c2 = this.c;
                    final int n5 = (int)(x3 - f[c2]);
                    final int n6 = (int)(y3 - this.g[c2]);
                    this.p(this.t.getLeft() + n5, this.t.getTop() + n6, n5, n6);
                    this.D(motionEvent);
                }
            }
        }
        else {
            final float x4 = motionEvent.getX();
            final float y4 = motionEvent.getY();
            final int pointerId5 = motionEvent.getPointerId(0);
            final View r3 = this.r((int)x4, (int)y4);
            this.C(x4, y4, pointerId5);
            this.I(r3, pointerId5);
            final int n7 = this.h[pointerId5];
            final int q2 = this.q;
            if ((n7 & q2) != 0x0) {
                this.s.h(n7 & q2, pointerId5);
            }
        }
    }
    
    public abstract static class c
    {
        public abstract int a(final View p0, final int p1, final int p2);
        
        public abstract int b(final View p0, final int p1, final int p2);
        
        public int c(final int n) {
            return n;
        }
        
        public int d(final View view) {
            return 0;
        }
        
        public int e(final View view) {
            return 0;
        }
        
        public void f(final int n, final int n2) {
        }
        
        public boolean g(final int n) {
            return false;
        }
        
        public void h(final int n, final int n2) {
        }
        
        public void i(final View view, final int n) {
        }
        
        public abstract void j(final int p0);
        
        public abstract void k(final View p0, final int p1, final int p2, final int p3, final int p4);
        
        public abstract void l(final View p0, final float p1, final float p2);
        
        public abstract boolean m(final View p0, final int p1);
    }
}
