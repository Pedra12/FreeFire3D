package b0;

import android.view.KeyEvent;
import android.view.MotionEvent;
import X.J;
import java.util.List;
import java.util.ArrayList;
import android.view.accessibility.AccessibilityRecord;
import X.K;
import android.view.accessibility.AccessibilityEvent;
import android.os.Bundle;
import android.view.ViewParent;
import W.X;
import y.j;
import X.I;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.graphics.Rect;

public abstract class a extends W.a
{
    private static final Rect n;
    private static final b.a o;
    private static final b.b p;
    private final Rect d;
    private final Rect e;
    private final Rect f;
    private final int[] g;
    private final AccessibilityManager h;
    private final View i;
    private c j;
    int k;
    int l;
    private int m;
    
    static {
        n = new Rect(Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE);
        o = new b.a() {
            public void b(final I i, final Rect rect) {
                i.l(rect);
            }
        };
        p = new b.b() {
            public I c(final j j, final int n) {
                return (I)j.p(n);
            }
            
            public int d(final j j) {
                return j.k();
            }
        };
    }
    
    public a(final View i) {
        this.d = new Rect();
        this.e = new Rect();
        this.f = new Rect();
        this.g = new int[2];
        this.k = Integer.MIN_VALUE;
        this.l = Integer.MIN_VALUE;
        this.m = Integer.MIN_VALUE;
        if (i != null) {
            this.i = i;
            this.h = (AccessibilityManager)i.getContext().getSystemService("accessibility");
            i.setFocusable(true);
            if (X.A(i) == 0) {
                X.x0(i, 1);
            }
            return;
        }
        throw new IllegalArgumentException("View may not be null");
    }
    
    private static Rect D(final View view, final int n, final Rect rect) {
        final int width = view.getWidth();
        final int height = view.getHeight();
        if (n == 17) {
            rect.set(width, 0, width, height);
            return rect;
        }
        if (n == 33) {
            rect.set(0, height, width, height);
            return rect;
        }
        if (n == 66) {
            rect.set(-1, 0, -1, height);
            return rect;
        }
        if (n == 130) {
            rect.set(0, -1, width, -1);
            return rect;
        }
        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
    }
    
    private boolean E(final Rect rect) {
        if (rect != null) {
            if (!rect.isEmpty()) {
                if (this.i.getWindowVisibility() != 0) {
                    return false;
                }
                ViewParent viewParent;
                View view;
                for (viewParent = this.i.getParent(); viewParent instanceof View; viewParent = view.getParent()) {
                    view = (View)viewParent;
                    if (view.getAlpha() <= 0.0f || view.getVisibility() != 0) {
                        return false;
                    }
                }
                if (viewParent != null) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private static int F(final int n) {
        if (n == 19) {
            return 33;
        }
        if (n == 21) {
            return 17;
        }
        if (n != 22) {
            return 130;
        }
        return 66;
    }
    
    private boolean G(int h, final Rect rect) {
        final j y = this.y();
        final int l = this.l;
        final int n = Integer.MIN_VALUE;
        Object o;
        if (l == Integer.MIN_VALUE) {
            o = null;
        }
        else {
            o = y.d(l);
        }
        I j;
        if (h != 1 && h != 2) {
            if (h != 17 && h != 33 && h != 66 && h != 130) {
                throw new IllegalArgumentException("direction must be one of {FOCUS_FORWARD, FOCUS_BACKWARD, FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
            }
            final Rect rect2 = new Rect();
            final int i = this.l;
            if (i != Integer.MIN_VALUE) {
                this.z(i, rect2);
            }
            else if (rect != null) {
                rect2.set(rect);
            }
            else {
                D(this.i, h, rect2);
            }
            j = (I)b.c(y, a.p, a.o, o, rect2, h);
        }
        else {
            j = (I)b.d(y, a.p, a.o, o, h, X.C(this.i) == 1, false);
        }
        if (j == null) {
            h = n;
        }
        else {
            h = y.h(y.g((Object)j));
        }
        return this.T(h);
    }
    
    private boolean Q(final int n, final int n2, final Bundle bundle) {
        if (n2 == 1) {
            return this.T(n);
        }
        if (n2 == 2) {
            return this.o(n);
        }
        if (n2 == 64) {
            return this.S(n);
        }
        if (n2 != 128) {
            return this.J(n, n2, bundle);
        }
        return this.n(n);
    }
    
    private boolean R(final int n, final Bundle bundle) {
        return X.d0(this.i, n, bundle);
    }
    
    private boolean S(final int k) {
        if (this.h.isEnabled()) {
            if (this.h.isTouchExplorationEnabled()) {
                final int i = this.k;
                if (i != k) {
                    if (i != Integer.MIN_VALUE) {
                        this.n(i);
                    }
                    this.k = k;
                    this.i.invalidate();
                    this.U(k, 32768);
                    return true;
                }
            }
        }
        return false;
    }
    
    private void V(final int m) {
        final int i = this.m;
        if (i == m) {
            return;
        }
        this.U(this.m = m, 128);
        this.U(i, 256);
    }
    
    private boolean n(final int n) {
        if (this.k == n) {
            this.k = Integer.MIN_VALUE;
            this.i.invalidate();
            this.U(n, 65536);
            return true;
        }
        return false;
    }
    
    private boolean p() {
        final int l = this.l;
        return l != Integer.MIN_VALUE && this.J(l, 16, null);
    }
    
    private AccessibilityEvent q(final int n, final int n2) {
        if (n != -1) {
            return this.r(n, n2);
        }
        return this.s(n2);
    }
    
    private AccessibilityEvent r(final int n, final int n2) {
        final AccessibilityEvent obtain = AccessibilityEvent.obtain(n2);
        final I h = this.H(n);
        ((AccessibilityRecord)obtain).getText().add((Object)h.A());
        ((AccessibilityRecord)obtain).setContentDescription(h.s());
        ((AccessibilityRecord)obtain).setScrollable(h.T());
        ((AccessibilityRecord)obtain).setPassword(h.S());
        ((AccessibilityRecord)obtain).setEnabled(h.L());
        ((AccessibilityRecord)obtain).setChecked(h.I());
        this.L(n, obtain);
        if (((AccessibilityRecord)obtain).getText().isEmpty() && ((AccessibilityRecord)obtain).getContentDescription() == null) {
            throw new RuntimeException("Callbacks must add text or a content description in populateEventForVirtualViewId()");
        }
        ((AccessibilityRecord)obtain).setClassName(h.p());
        K.c((AccessibilityRecord)obtain, this.i, n);
        obtain.setPackageName((CharSequence)this.i.getContext().getPackageName());
        return obtain;
    }
    
    private AccessibilityEvent s(final int n) {
        final AccessibilityEvent obtain = AccessibilityEvent.obtain(n);
        this.i.onInitializeAccessibilityEvent(obtain);
        return obtain;
    }
    
    private I t(int i) {
        final I y = I.Y();
        y.p0(true);
        y.r0(true);
        y.k0((CharSequence)"android.view.View");
        final Rect n = a.n;
        y.g0(n);
        y.h0(n);
        y.z0(this.i);
        this.N(i, y);
        if (y.A() == null && y.s() == null) {
            throw new RuntimeException("Callbacks must add text or a content description in populateNodeForVirtualViewId()");
        }
        y.l(this.e);
        if (this.e.equals((Object)n)) {
            throw new RuntimeException("Callbacks must set parent bounds in populateNodeForVirtualViewId()");
        }
        final int j = y.j();
        if ((j & 0x40) != 0x0) {
            throw new RuntimeException("Callbacks must not add ACTION_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
        }
        if ((j & 0x80) == 0x0) {
            y.x0((CharSequence)this.i.getContext().getPackageName());
            y.E0(this.i, i);
            if (this.k == i) {
                y.e0(true);
                y.a(128);
            }
            else {
                y.e0(false);
                y.a(64);
            }
            final boolean b = this.l == i;
            if (b) {
                y.a(2);
            }
            else if (y.N()) {
                y.a(1);
            }
            y.s0(b);
            this.i.getLocationOnScreen(this.g);
            y.m(this.d);
            if (this.d.equals((Object)n)) {
                y.l(this.d);
                if (y.b != -1) {
                    I y2;
                    Rect d;
                    Rect e;
                    for (y2 = I.Y(), i = y.b; i != -1; i = y2.b) {
                        y2.A0(this.i, -1);
                        y2.g0(a.n);
                        this.N(i, y2);
                        y2.l(this.e);
                        d = this.d;
                        e = this.e;
                        d.offset(e.left, e.top);
                    }
                    y2.c0();
                }
                this.d.offset(this.g[0] - this.i.getScrollX(), this.g[1] - this.i.getScrollY());
            }
            if (this.i.getLocalVisibleRect(this.f)) {
                this.f.offset(this.g[0] - this.i.getScrollX(), this.g[1] - this.i.getScrollY());
                if (this.d.intersect(this.f)) {
                    y.h0(this.d);
                    if (this.E(this.d)) {
                        y.I0(true);
                    }
                }
            }
            return y;
        }
        throw new RuntimeException("Callbacks must not add ACTION_CLEAR_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
    }
    
    private I u() {
        final I a0 = I.a0(this.i);
        X.b0(this.i, a0);
        final ArrayList list = new ArrayList();
        this.C((List)list);
        if (a0.o() > 0 && list.size() > 0) {
            throw new RuntimeException("Views cannot have both real and virtual children");
        }
        for (int size = list.size(), i = 0; i < size; ++i) {
            a0.c(this.i, (int)list.get(i));
        }
        return a0;
    }
    
    private j y() {
        final ArrayList list = new ArrayList();
        this.C((List)list);
        final j j = new j();
        for (int i = 0; i < ((List)list).size(); ++i) {
            j.j((int)((List)list).get(i), (Object)this.t((int)((List)list).get(i)));
        }
        return j;
    }
    
    private void z(final int n, final Rect rect) {
        this.H(n).l(rect);
    }
    
    public final int A() {
        return this.l;
    }
    
    protected abstract int B(final float p0, final float p1);
    
    protected abstract void C(final List p0);
    
    I H(final int n) {
        if (n == -1) {
            return this.u();
        }
        return this.t(n);
    }
    
    public final void I(final boolean b, final int n, final Rect rect) {
        final int l = this.l;
        if (l != Integer.MIN_VALUE) {
            this.o(l);
        }
        if (b) {
            this.G(n, rect);
        }
    }
    
    protected abstract boolean J(final int p0, final int p1, final Bundle p2);
    
    protected void K(final AccessibilityEvent accessibilityEvent) {
    }
    
    protected void L(final int n, final AccessibilityEvent accessibilityEvent) {
    }
    
    protected abstract void M(final I p0);
    
    protected abstract void N(final int p0, final I p1);
    
    protected abstract void O(final int p0, final boolean p1);
    
    boolean P(final int n, final int n2, final Bundle bundle) {
        if (n != -1) {
            return this.Q(n, n2, bundle);
        }
        return this.R(n2, bundle);
    }
    
    public final boolean T(final int l) {
        if (!this.i.isFocused() && !this.i.requestFocus()) {
            return false;
        }
        final int i = this.l;
        if (i == l) {
            return false;
        }
        if (i != Integer.MIN_VALUE) {
            this.o(i);
        }
        if (l == Integer.MIN_VALUE) {
            return false;
        }
        this.O(this.l = l, true);
        this.U(l, 8);
        return true;
    }
    
    public final boolean U(final int n, final int n2) {
        if (n != Integer.MIN_VALUE && this.h.isEnabled()) {
            final ViewParent parent = this.i.getParent();
            return parent != null && parent.requestSendAccessibilityEvent(this.i, this.q(n, n2));
        }
        return false;
    }
    
    public J b(final View view) {
        if (this.j == null) {
            this.j = new c();
        }
        return this.j;
    }
    
    public void f(final View view, final AccessibilityEvent accessibilityEvent) {
        super.f(view, accessibilityEvent);
        this.K(accessibilityEvent);
    }
    
    public void g(final View view, final I i) {
        super.g(view, i);
        this.M(i);
    }
    
    public final boolean o(final int n) {
        if (this.l != n) {
            return false;
        }
        this.l = Integer.MIN_VALUE;
        this.O(n, false);
        this.U(n, 8);
        return true;
    }
    
    public final boolean v(final MotionEvent motionEvent) {
        if (this.h.isEnabled()) {
            if (this.h.isTouchExplorationEnabled()) {
                final int action = motionEvent.getAction();
                if (action != 7 && action != 9) {
                    if (action != 10) {
                        return false;
                    }
                    if (this.m != Integer.MIN_VALUE) {
                        this.V(Integer.MIN_VALUE);
                        return true;
                    }
                    return false;
                }
                else {
                    final int b = this.B(motionEvent.getX(), motionEvent.getY());
                    this.V(b);
                    if (b != Integer.MIN_VALUE) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public final boolean w(final KeyEvent keyEvent) {
        final int action = keyEvent.getAction();
        int n = 0;
        if (action != 1) {
            final int keyCode = keyEvent.getKeyCode();
            if (keyCode != 61) {
                if (keyCode != 66) {
                    switch (keyCode) {
                        default: {
                            return false;
                        }
                        case 19:
                        case 20:
                        case 21:
                        case 22: {
                            if (keyEvent.hasNoModifiers()) {
                                final int f = F(keyCode);
                                final int repeatCount = keyEvent.getRepeatCount();
                                boolean b = false;
                                while (n < repeatCount + 1 && this.G(f, null)) {
                                    ++n;
                                    b = true;
                                }
                                return b;
                            }
                            return false;
                        }
                        case 23: {
                            break;
                        }
                    }
                }
                if (keyEvent.hasNoModifiers() && keyEvent.getRepeatCount() == 0) {
                    this.p();
                    return true;
                }
            }
            else {
                if (keyEvent.hasNoModifiers()) {
                    return this.G(2, null);
                }
                if (keyEvent.hasModifiers(1)) {
                    return this.G(1, null);
                }
            }
        }
        return false;
    }
    
    public final int x() {
        return this.k;
    }
    
    private class c extends J
    {
        final a b;
        
        c(final a b) {
            this.b = b;
        }
        
        @Override
        public I b(final int n) {
            return I.Z(this.b.H(n));
        }
        
        @Override
        public I d(int n) {
            if (n == 2) {
                n = this.b.k;
            }
            else {
                n = this.b.l;
            }
            if (n == Integer.MIN_VALUE) {
                return null;
            }
            return this.b(n);
        }
        
        @Override
        public boolean f(final int n, final int n2, final Bundle bundle) {
            return this.b.P(n, n2, bundle);
        }
    }
}
