package b0;

import java.util.Comparator;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;
import android.graphics.Rect;

abstract class b
{
    private static boolean a(final int n, final Rect rect, final Rect rect2, final Rect rect3) {
        final boolean b = b(n, rect, rect2);
        return !b(n, rect, rect3) && b && (!j(n, rect, rect3) || n == 17 || n == 66 || k(n, rect, rect2) < m(n, rect, rect3));
    }
    
    private static boolean b(final int n, final Rect rect, final Rect rect2) {
        if (n != 17) {
            if (n != 33) {
                if (n == 66) {
                    return rect2.bottom >= rect.top && rect2.top <= rect.bottom;
                }
                if (n != 130) {
                    throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                }
            }
            return rect2.right >= rect.left && rect2.left <= rect.right;
        }
        return rect2.bottom >= rect.top && rect2.top <= rect.bottom;
    }
    
    public static Object c(final Object o, final b b, final a a, final Object o2, final Rect rect, final int n) {
        final Rect rect2 = new Rect(rect);
        int i = 0;
        if (n != 17) {
            if (n != 33) {
                if (n != 66) {
                    if (n != 130) {
                        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                    }
                    rect2.offset(0, -(rect.height() + 1));
                }
                else {
                    rect2.offset(-(rect.width() + 1), 0);
                }
            }
            else {
                rect2.offset(0, rect.height() + 1);
            }
        }
        else {
            rect2.offset(rect.width() + 1, 0);
        }
        final int b2 = b.b(o);
        final Rect rect3 = new Rect();
        Object o3 = null;
        while (i < b2) {
            final Object a2 = b.a(o, i);
            if (a2 != o2) {
                a.a(a2, rect3);
                if (h(n, rect, rect3, rect2)) {
                    rect2.set(rect3);
                    o3 = a2;
                }
            }
            ++i;
        }
        return o3;
    }
    
    public static Object d(final Object o, final b b, final a a, final Object o2, final int n, final boolean b2, final boolean b3) {
        final int b4 = b.b(o);
        final ArrayList list = new ArrayList(b4);
        for (int i = 0; i < b4; ++i) {
            list.add(b.a(o, i));
        }
        Collections.sort((List)list, (Comparator)new c(b2, a));
        if (n == 1) {
            return f(o2, list, b3);
        }
        if (n == 2) {
            return e(o2, list, b3);
        }
        throw new IllegalArgumentException("direction must be one of {FOCUS_FORWARD, FOCUS_BACKWARD}.");
    }
    
    private static Object e(final Object o, final ArrayList list, final boolean b) {
        final int size = list.size();
        int lastIndex;
        if (o == null) {
            lastIndex = -1;
        }
        else {
            lastIndex = list.lastIndexOf(o);
        }
        if (++lastIndex < size) {
            return list.get(lastIndex);
        }
        if (b && size > 0) {
            return list.get(0);
        }
        return null;
    }
    
    private static Object f(final Object o, final ArrayList list, final boolean b) {
        final int size = list.size();
        int index;
        if (o == null) {
            index = size;
        }
        else {
            index = list.indexOf(o);
        }
        if (--index >= 0) {
            return list.get(index);
        }
        if (b && size > 0) {
            return list.get(size - 1);
        }
        return null;
    }
    
    private static int g(final int n, final int n2) {
        return n * 13 * n + n2 * n2;
    }
    
    private static boolean h(final int n, final Rect rect, final Rect rect2, final Rect rect3) {
        return i(rect, rect2, n) && (!i(rect, rect3, n) || a(n, rect, rect2, rect3) || (!a(n, rect, rect3, rect2) && g(k(n, rect, rect2), o(n, rect, rect2)) < g(k(n, rect, rect3), o(n, rect, rect3))));
    }
    
    private static boolean i(final Rect rect, final Rect rect2, int n) {
        if (n == 17) {
            final int right = rect.right;
            n = rect2.right;
            return (right > n || rect.left >= n) && rect.left > rect2.left;
        }
        if (n == 33) {
            final int bottom = rect.bottom;
            n = rect2.bottom;
            return (bottom > n || rect.top >= n) && rect.top > rect2.top;
        }
        if (n == 66) {
            final int left = rect.left;
            n = rect2.left;
            return (left < n || rect.right <= n) && rect.right < rect2.right;
        }
        if (n == 130) {
            final int top = rect.top;
            n = rect2.top;
            return (top < n || rect.bottom <= n) && rect.bottom < rect2.bottom;
        }
        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
    }
    
    private static boolean j(final int n, final Rect rect, final Rect rect2) {
        if (n == 17) {
            return rect.left >= rect2.right;
        }
        if (n == 33) {
            return rect.top >= rect2.bottom;
        }
        if (n == 66) {
            return rect.right <= rect2.left;
        }
        if (n == 130) {
            return rect.bottom <= rect2.top;
        }
        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
    }
    
    private static int k(final int n, final Rect rect, final Rect rect2) {
        return Math.max(0, l(n, rect, rect2));
    }
    
    private static int l(int n, final Rect rect, final Rect rect2) {
        int n2;
        if (n != 17) {
            if (n != 33) {
                if (n != 66) {
                    if (n != 130) {
                        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                    }
                    n = rect2.top;
                    n2 = rect.bottom;
                }
                else {
                    n = rect2.left;
                    n2 = rect.right;
                }
            }
            else {
                n = rect.top;
                n2 = rect2.bottom;
            }
        }
        else {
            n = rect.left;
            n2 = rect2.right;
        }
        return n - n2;
    }
    
    private static int m(final int n, final Rect rect, final Rect rect2) {
        return Math.max(1, n(n, rect, rect2));
    }
    
    private static int n(int n, final Rect rect, final Rect rect2) {
        int n2;
        if (n != 17) {
            if (n != 33) {
                if (n != 66) {
                    if (n != 130) {
                        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                    }
                    n = rect2.bottom;
                    n2 = rect.bottom;
                }
                else {
                    n = rect2.right;
                    n2 = rect.right;
                }
            }
            else {
                n = rect.top;
                n2 = rect2.top;
            }
        }
        else {
            n = rect.left;
            n2 = rect2.left;
        }
        return n - n2;
    }
    
    private static int o(final int n, final Rect rect, final Rect rect2) {
        if (n != 17) {
            if (n != 33) {
                if (n == 66) {
                    return Math.abs(rect.top + rect.height() / 2 - (rect2.top + rect2.height() / 2));
                }
                if (n != 130) {
                    throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                }
            }
            return Math.abs(rect.left + rect.width() / 2 - (rect2.left + rect2.width() / 2));
        }
        return Math.abs(rect.top + rect.height() / 2 - (rect2.top + rect2.height() / 2));
    }
    
    public interface a
    {
        void a(final Object p0, final Rect p1);
    }
    
    public interface b
    {
        Object a(final Object p0, final int p1);
        
        int b(final Object p0);
    }
    
    private static class c implements Comparator
    {
        private final Rect a;
        private final Rect b;
        private final boolean c;
        private final a d;
        
        c(final boolean c, final a d) {
            this.a = new Rect();
            this.b = new Rect();
            this.c = c;
            this.d = d;
        }
        
        public int compare(final Object o, final Object o2) {
            final Rect a = this.a;
            final Rect b = this.b;
            this.d.a(o, a);
            this.d.a(o2, b);
            final int top = a.top;
            final int top2 = b.top;
            if (top < top2) {
                return -1;
            }
            if (top > top2) {
                return 1;
            }
            final int left = a.left;
            final int left2 = b.left;
            if (left < left2) {
                if (this.c) {
                    return 1;
                }
                return -1;
            }
            else if (left > left2) {
                if (this.c) {
                    return -1;
                }
                return 1;
            }
            else {
                final int bottom = a.bottom;
                final int bottom2 = b.bottom;
                if (bottom < bottom2) {
                    return -1;
                }
                if (bottom > bottom2) {
                    return 1;
                }
                final int right = a.right;
                final int right2 = b.right;
                if (right < right2) {
                    if (this.c) {
                        return 1;
                    }
                    return -1;
                }
                else {
                    if (right <= right2) {
                        return 0;
                    }
                    if (this.c) {
                        return -1;
                    }
                    return 1;
                }
            }
        }
    }
}
