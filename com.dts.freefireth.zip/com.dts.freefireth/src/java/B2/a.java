package b2;

import java.util.Iterator;
import kotlin.ranges.c;
import kotlin.collections.E;
import kotlin.ranges.IntRange;
import kotlin.collections.j;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class a
{
    public static final a d;
    private int[] a;
    private int b;
    private float[] c;
    
    static {
        d = new a(null);
    }
    
    public a(final int[] a) {
        Intrinsics.checkNotNullParameter((Object)a, "shape");
        this.a = a;
        final int a2 = b2.a.d.b(a);
        this.b = a2;
        this.c = new float[a2];
    }
    
    public final float[] a() {
        return this.c;
    }
    
    public final int b(final int n) {
        return this.a[n];
    }
    
    public final int c() {
        return this.a.length;
    }
    
    public final void d(final int[] a) {
        Intrinsics.checkNotNullParameter((Object)a, "shape");
        this.a = a;
        final int a2 = a.d.b(a);
        final float[] c = new float[a2];
        System.arraycopy((Object)this.c, 0, (Object)c, 0, Math.min(this.b, a2));
        this.c = c;
        this.b = a2;
    }
    
    public static final class a
    {
        private a() {
        }
        
        private final int b(final int[] array) {
            if (array.length != 0) {
                int n = array[0];
                final E e = ((c)new IntRange(1, j.A(array))).e();
                while (((Iterator)e).hasNext()) {
                    n *= array[e.a()];
                }
                return n;
            }
            throw new UnsupportedOperationException("Empty array can't be reduced.");
        }
    }
}
