package b2;

import java.util.Map$Entry;
import java.io.File;
import kotlin.jvm.internal.Intrinsics;
import java.util.Iterator;
import kotlin.collections.L;
import java.util.HashMap;
import kotlin.collections.F;
import s7.u;
import kotlin.Pair;
import kotlin.jvm.internal.DefaultConstructorMarker;
import java.util.Map;

public final class b
{
    public static final a m;
    private static final Map n;
    private final b2.a a;
    private final b2.a b;
    private final b2.a c;
    private final b2.a d;
    private final b2.a e;
    private final b2.a f;
    private final b2.a g;
    private final b2.a h;
    private final b2.a i;
    private final b2.a j;
    private final b2.a k;
    private final Map l;
    
    static {
        m = new a(null);
        n = (Map)F.k(new Pair[] { u.a((Object)"embedding.weight", (Object)"embed.weight"), u.a((Object)"dense1.weight", (Object)"fc1.weight"), u.a((Object)"dense2.weight", (Object)"fc2.weight"), u.a((Object)"dense3.weight", (Object)"fc3.weight"), u.a((Object)"dense1.bias", (Object)"fc1.bias"), u.a((Object)"dense2.bias", (Object)"fc2.bias"), u.a((Object)"dense3.bias", (Object)"fc3.bias") });
    }
    
    private b(final Map map) {
        final Object value = map.get((Object)"embed.weight");
        if (value == null) {
            throw new IllegalStateException("Required value was null.");
        }
        this.a = (b2.a)value;
        final Object value2 = map.get((Object)"convs.0.weight");
        if (value2 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        this.b = b2.i.l((b2.a)value2);
        final Object value3 = map.get((Object)"convs.1.weight");
        if (value3 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        this.c = b2.i.l((b2.a)value3);
        final Object value4 = map.get((Object)"convs.2.weight");
        if (value4 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        this.d = b2.i.l((b2.a)value4);
        final Object value5 = map.get((Object)"convs.0.bias");
        if (value5 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        this.e = (b2.a)value5;
        final Object value6 = map.get((Object)"convs.1.bias");
        if (value6 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        this.f = (b2.a)value6;
        final Object value7 = map.get((Object)"convs.2.bias");
        if (value7 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        this.g = (b2.a)value7;
        final Object value8 = map.get((Object)"fc1.weight");
        if (value8 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        this.h = b2.i.k((b2.a)value8);
        final Object value9 = map.get((Object)"fc2.weight");
        if (value9 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        this.i = b2.i.k((b2.a)value9);
        final Object value10 = map.get((Object)"fc1.bias");
        if (value10 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        this.j = (b2.a)value10;
        final Object value11 = map.get((Object)"fc2.bias");
        if (value11 != null) {
            this.k = (b2.a)value11;
            this.l = (Map)new HashMap();
            for (final String s : L.i((Object[])new String[] { b2.f.a.a.b(), b2.f.a.b.b() })) {
                final StringBuilder sb = new StringBuilder();
                sb.append(s);
                sb.append(".weight");
                final String string = sb.toString();
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(s);
                sb2.append(".bias");
                final String string2 = sb2.toString();
                final b2.a a = (b2.a)map.get((Object)string);
                final b2.a a2 = (b2.a)map.get((Object)string2);
                if (a != null) {
                    this.l.put((Object)string, (Object)b2.i.k(a));
                }
                if (a2 != null) {
                    this.l.put((Object)string2, (Object)a2);
                }
            }
            return;
        }
        throw new IllegalStateException("Required value was null.");
    }
    
    public static final /* synthetic */ Map a() {
        return b.n;
    }
    
    public final b2.a b(b2.a a, final String[] array, final String s) {
        Intrinsics.checkNotNullParameter((Object)a, "dense");
        Intrinsics.checkNotNullParameter((Object)array, "texts");
        Intrinsics.checkNotNullParameter((Object)s, "task");
        final b2.a c = b2.i.c(b2.i.e(array, 128, this.a), this.b);
        b2.i.a(c, this.e);
        b2.i.i(c);
        final b2.a c2 = b2.i.c(c, this.c);
        b2.i.a(c2, this.f);
        b2.i.i(c2);
        final b2.a g = b2.i.g(c2, 2);
        final b2.a c3 = b2.i.c(g, this.d);
        b2.i.a(c3, this.g);
        b2.i.i(c3);
        final b2.a g2 = b2.i.g(c, c.b(1));
        final b2.a g3 = b2.i.g(g, g.b(1));
        final b2.a g4 = b2.i.g(c3, c3.b(1));
        b2.i.f(g2, 1);
        b2.i.f(g3, 1);
        b2.i.f(g4, 1);
        a = b2.i.d(b2.i.b(new b2.a[] { g2, g3, g4, a }), this.h, this.j);
        b2.i.i(a);
        a = b2.i.d(a, this.i, this.k);
        b2.i.i(a);
        final Map l = this.l;
        final StringBuilder sb = new StringBuilder();
        sb.append(s);
        sb.append(".weight");
        final b2.a a2 = (b2.a)l.get((Object)sb.toString());
        final Map i = this.l;
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(s);
        sb2.append(".bias");
        final b2.a a3 = (b2.a)i.get((Object)sb2.toString());
        if (a2 != null && a3 != null) {
            a = b2.i.d(a, a2, a3);
            b2.i.j(a);
            return a;
        }
        return null;
    }
    
    public static final class a
    {
        private a() {
        }
        
        private final Map b(final File file) {
            final Map c = b2.j.c(file);
            if (c != null) {
                final HashMap hashMap = new HashMap();
                final Map a = b2.b.a();
                for (final Map$Entry map$Entry : c.entrySet()) {
                    String s = (String)map$Entry.getKey();
                    if (a.containsKey(map$Entry.getKey()) && (s = (String)a.get(map$Entry.getKey())) == null) {
                        return null;
                    }
                    ((Map)hashMap).put((Object)s, map$Entry.getValue());
                }
                return (Map)hashMap;
            }
            return null;
        }
        
        public final b a(final File file) {
            Intrinsics.checkNotNullParameter((Object)file, "file");
            final Map b = this.b(file);
            if (b == null) {
                return null;
            }
            try {
                return new b(b, null);
            }
            catch (final Exception ex) {
                return null;
            }
        }
    }
}
