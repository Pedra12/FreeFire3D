package b2;

import kotlin.jvm.internal.Intrinsics;

public final class i
{
    public static final i a;
    
    static {
        a = new i();
    }
    
    private i() {
    }
    
    public static final void a(final a a, final a a2) {
        Intrinsics.checkNotNullParameter((Object)a, "x");
        Intrinsics.checkNotNullParameter((Object)a2, "b");
        final int b = a.b(0);
        final int b2 = a.b(1);
        final int b3 = a.b(2);
        final float[] a3 = a.a();
        final float[] a4 = a2.a();
        for (int i = 0; i < b; ++i) {
            for (int j = 0; j < b2; ++j) {
                for (int k = 0; k < b3; ++k) {
                    final int n = i * b2 * b3 + j * b3 + k;
                    a3[n] += a4[k];
                }
            }
        }
    }
    
    public static final a b(final a[] array) {
        Intrinsics.checkNotNullParameter((Object)array, "tensors");
        final int b = array[0].b(0);
        final int length = array.length;
        int i = 0;
        int n = 0;
        while (i < length) {
            n += array[i].b(1);
            ++i;
        }
        final a a = new a(new int[] { b, n });
        final float[] a2 = a.a();
        for (int j = 0; j < b; ++j) {
            int n2 = j * n;
            for (int length2 = array.length, k = 0; k < length2; ++k) {
                final float[] a3 = array[k].a();
                final int b2 = array[k].b(1);
                System.arraycopy((Object)a3, j * b2, (Object)a2, n2, b2);
                n2 += b2;
            }
        }
        return a;
    }
    
    public static final a c(final a a, final a a2) {
        Intrinsics.checkNotNullParameter((Object)a, "x");
        Intrinsics.checkNotNullParameter((Object)a2, "w");
        final int b = a.b(0);
        final int b2 = a.b(1);
        final int b3 = a.b(2);
        final int b4 = a2.b(0);
        final int n = b2 - b4 + 1;
        final int b5 = a2.b(2);
        final a a3 = new a(new int[] { b, n, b5 });
        final float[] a4 = a.a();
        final float[] a5 = a3.a();
        final float[] a6 = a2.a();
        for (int i = 0; i < b; ++i) {
            for (int j = 0; j < b5; ++j) {
                for (int k = 0; k < n; ++k) {
                    float n2 = 0.0f;
                    int n3 = 0;
                    while (true) {
                        int l = 0;
                        if (n3 >= b4) {
                            break;
                        }
                        while (l < b3) {
                            n2 += a4[b2 * b3 * i + (n3 + k) * b3 + l] * a6[(n3 * b3 + l) * b5 + j];
                            ++l;
                        }
                        ++n3;
                    }
                    a5[n * b5 * i + k * b5 + j] = n2;
                }
            }
        }
        return a3;
    }
    
    public static final a d(a h, final a a, final a a2) {
        Intrinsics.checkNotNullParameter((Object)h, "x");
        Intrinsics.checkNotNullParameter((Object)a, "w");
        Intrinsics.checkNotNullParameter((Object)a2, "b");
        final int b = h.b(0);
        final int b2 = a2.b(0);
        h = h(h, a);
        final float[] a3 = a2.a();
        final float[] a4 = h.a();
        for (int i = 0; i < b; ++i) {
            for (int j = 0; j < b2; ++j) {
                final int n = i * b2 + j;
                a4[n] += a3[j];
            }
        }
        return h;
    }
    
    public static final a e(final String[] array, final int n, final a a) {
        Intrinsics.checkNotNullParameter((Object)array, "texts");
        Intrinsics.checkNotNullParameter((Object)a, "w");
        final int length = array.length;
        final int b = a.b(1);
        final a a2 = new a(new int[] { length, n, b });
        final float[] a3 = a2.a();
        final float[] a4 = a.a();
        for (int i = 0; i < length; ++i) {
            final int[] d = j.a.d(array[i], n);
            for (int j = 0; j < n; ++j) {
                System.arraycopy((Object)a4, d[j] * b, (Object)a3, b * n * i + b * j, b);
            }
        }
        return a2;
    }
    
    public static final void f(final a a, final int n) {
        Intrinsics.checkNotNullParameter((Object)a, "x");
        if (n >= a.c()) {
            return;
        }
        final int c = a.c();
        int n2 = 1;
        for (int i = n; i < c; ++i) {
            n2 *= a.b(i);
        }
        final int[] array = new int[n + 1];
        for (int j = 0; j < n; ++j) {
            array[j] = a.b(j);
        }
        array[n] = n2;
        a.d(array);
    }
    
    public static final a g(final a a, final int n) {
        Intrinsics.checkNotNullParameter((Object)a, "x");
        final int b = a.b(0);
        final int b2 = a.b(1);
        final int b3 = a.b(2);
        final int n2 = b2 - n + 1;
        final a a2 = new a(new int[] { b, n2, b3 });
        final float[] a3 = a.a();
        final float[] a4 = a2.a();
        for (int i = 0; i < b; ++i) {
            for (int j = 0; j < b3; ++j) {
                for (int k = 0; k < n2; ++k) {
                    final int n3 = k * b3;
                    final int n4 = i * n2 * b3 + n3 + j;
                    a4[n4] = Float.MIN_VALUE;
                    for (int l = 0; l < n; ++l) {
                        a4[n4] = Math.max(a4[n4], a3[i * b2 * b3 + n3 + j + l * b3]);
                    }
                }
            }
        }
        return a2;
    }
    
    public static final a h(final a a, final a a2) {
        Intrinsics.checkNotNullParameter((Object)a, "x");
        Intrinsics.checkNotNullParameter((Object)a2, "w");
        final int b = a.b(0);
        final int b2 = a2.b(0);
        final int b3 = a2.b(1);
        final a a3 = new a(new int[] { b, b3 });
        final float[] a4 = a.a();
        final float[] a5 = a2.a();
        final float[] a6 = a3.a();
        for (int i = 0; i < b; ++i) {
            for (int j = 0; j < b3; ++j) {
                final int n = i * b3 + j;
                a6[n] = 0.0f;
                for (int k = 0; k < b2; ++k) {
                    a6[n] += a4[i * b2 + k] * a5[k * b3 + j];
                }
            }
        }
        return a3;
    }
    
    public static final void i(final a a) {
        Intrinsics.checkNotNullParameter((Object)a, "x");
        final float[] a2 = a.a();
        for (int length = a2.length, i = 0; i < length; ++i) {
            if (a2[i] < 0.0f) {
                a2[i] = 0.0f;
            }
        }
    }
    
    public static final void j(final a a) {
        Intrinsics.checkNotNullParameter((Object)a, "x");
        int i = 0;
        final int b = a.b(0);
        final int b2 = a.b(1);
        final float[] a2 = a.a();
        while (i < b) {
            final int n = i * b2;
            final int n2 = n + b2;
            float n3 = Float.MIN_VALUE;
            float n5;
            for (int j = n; j < n2; ++j, n3 = n5) {
                final float n4 = a2[j];
                n5 = n3;
                if (n4 > n3) {
                    n5 = n4;
                }
            }
            float n6 = 0.0f;
            int n7 = n;
            int k;
            while (true) {
                k = n;
                if (n7 >= n2) {
                    break;
                }
                final float n8 = (float)Math.exp((double)(a2[n7] - n3));
                a2[n7] = n8;
                n6 += n8;
                ++n7;
            }
            while (k < n2) {
                a2[k] /= n6;
                ++k;
            }
            ++i;
        }
    }
    
    public static final a k(final a a) {
        Intrinsics.checkNotNullParameter((Object)a, "x");
        final int b = a.b(0);
        final int b2 = a.b(1);
        final a a2 = new a(new int[] { b2, b });
        final float[] a3 = a.a();
        final float[] a4 = a2.a();
        for (int i = 0; i < b; ++i) {
            for (int j = 0; j < b2; ++j) {
                a4[j * b + i] = a3[i * b2 + j];
            }
        }
        return a2;
    }
    
    public static final a l(final a a) {
        Intrinsics.checkNotNullParameter((Object)a, "x");
        final int b = a.b(0);
        final int b2 = a.b(1);
        final int b3 = a.b(2);
        final a a2 = new a(new int[] { b3, b2, b });
        final float[] a3 = a.a();
        final float[] a4 = a2.a();
        for (int i = 0; i < b; ++i) {
            for (int j = 0; j < b2; ++j) {
                for (int k = 0; k < b3; ++k) {
                    a4[k * b * b2 + j * b + i] = a3[i * b2 * b3 + j * b3 + k];
                }
            }
        }
        return a2;
    }
}
