package b2;

import java.util.Collection;
import java.nio.charset.Charset;
import android.text.TextUtils;
import kotlin.text.Regex;
import org.json.JSONArray;
import java.util.HashMap;
import org.json.JSONObject;
import kotlin.text.Charsets;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import java.io.InputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import kotlin.jvm.internal.Intrinsics;
import java.util.Map;
import com.facebook.e;
import java.io.File;

public final class j
{
    public static final j a;
    
    static {
        a = new j();
    }
    
    private j() {
    }
    
    public static final File a() {
        File file2;
        final File file = file2 = new File(e.l().getFilesDir(), "facebook_ml/");
        if (!file.exists()) {
            if (file.mkdirs()) {
                file2 = file;
            }
            else {
                file2 = null;
            }
        }
        return file2;
    }
    
    public static final Map c(final File file) {
        Intrinsics.checkNotNullParameter((Object)file, "file");
        try {
            final FileInputStream fileInputStream = new FileInputStream(file);
            final int available = ((InputStream)fileInputStream).available();
            final DataInputStream dataInputStream = new DataInputStream((InputStream)fileInputStream);
            final byte[] array = new byte[available];
            dataInputStream.readFully(array);
            ((InputStream)dataInputStream).close();
            if (available < 4) {
                return null;
            }
            final ByteBuffer wrap = ByteBuffer.wrap(array, 0, 4);
            wrap.order(ByteOrder.LITTLE_ENDIAN);
            final int int1 = wrap.getInt();
            int n = int1 + 4;
            if (available < n) {
                return null;
            }
            final JSONObject jsonObject = new JSONObject(new String(array, 4, int1, Charsets.UTF_8));
            final JSONArray names = jsonObject.names();
            final int length = names.length();
            final String[] array2 = new String[length];
            for (int i = 0; i < length; ++i) {
                array2[i] = names.getString(i);
            }
            kotlin.collections.j.r((Object[])array2);
            final HashMap hashMap = new HashMap();
            for (final String s : array2) {
                if (s != null) {
                    final JSONArray jsonArray = jsonObject.getJSONArray(s);
                    final int length2 = jsonArray.length();
                    final int[] array3 = new int[length2];
                    int n2 = 1;
                    for (int k = 0; k < length2; ++k) {
                        final int int2 = jsonArray.getInt(k);
                        array3[k] = int2;
                        n2 *= int2;
                    }
                    final int n3 = n2 * 4;
                    final int n4 = n + n3;
                    if (n4 > available) {
                        return null;
                    }
                    final ByteBuffer wrap2 = ByteBuffer.wrap(array, n, n3);
                    wrap2.order(ByteOrder.LITTLE_ENDIAN);
                    final a a = new a(array3);
                    wrap2.asFloatBuffer().get(a.a(), 0, n2);
                    ((Map)hashMap).put((Object)s, (Object)a);
                    n = n4;
                }
            }
            return (Map)hashMap;
        }
        catch (final Exception ex) {
            return null;
        }
    }
    
    public final String b(String s) {
        Intrinsics.checkNotNullParameter((Object)s, "str");
        int n = ((CharSequence)s).length() - 1;
        int i = 0;
        int n2 = 0;
        while (i <= n) {
            int n3;
            if (n2 == 0) {
                n3 = i;
            }
            else {
                n3 = n;
            }
            final boolean b = Intrinsics.f((int)((CharSequence)s).charAt(n3), 32) <= 0;
            if (n2 == 0) {
                if (!b) {
                    n2 = 1;
                }
                else {
                    ++i;
                }
            }
            else {
                if (!b) {
                    break;
                }
                --n;
            }
        }
        s = ((CharSequence)s).subSequence(i, n + 1).toString();
        s = TextUtils.join((CharSequence)" ", (Object[])((Collection)new Regex("\\s+").j((CharSequence)s, 0)).toArray((Object[])new String[0]));
        Intrinsics.checkNotNullExpressionValue((Object)s, "join(...)");
        return s;
    }
    
    public final int[] d(final String s, final int n) {
        Intrinsics.checkNotNullParameter((Object)s, "texts");
        final int[] array = new int[n];
        final String b = this.b(s);
        final Charset forName = Charset.forName("UTF-8");
        Intrinsics.checkNotNullExpressionValue((Object)forName, "forName(...)");
        final byte[] bytes = b.getBytes(forName);
        Intrinsics.checkNotNullExpressionValue((Object)bytes, "this as java.lang.String).getBytes(charset)");
        for (int i = 0; i < n; ++i) {
            if (i < bytes.length) {
                array[i] = (bytes[i] & 0xFF);
            }
            else {
                array[i] = 0;
            }
        }
        return array;
    }
}
