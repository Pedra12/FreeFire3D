package b2;

import android.os.AsyncTask;
import java.util.Collection;
import android.os.BaseBundle;
import a2.k;
import a2.k$a;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.ranges.IntRange;
import kotlin.collections.E;
import s7.n;
import java.util.Locale;
import kotlin.text.StringsKt;
import java.io.File;
import com.facebook.GraphRequest$b;
import com.facebook.AccessToken;
import com.facebook.GraphRequest;
import android.text.TextUtils;
import android.os.Bundle;
import Z1.a;
import kotlin.jvm.internal.Intrinsics;
import java.util.Map$Entry;
import java.util.ArrayList;
import android.content.SharedPreferences;
import n2.s;
import n2.s$b;
import com.facebook.e;
import n2.W;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;
import kotlin.collections.CollectionsKt;
import j$.util.concurrent.ConcurrentHashMap;
import java.util.List;
import java.util.Map;

public final class f
{
    public static final f a;
    private static final Map b;
    private static final List c;
    private static final List d;
    
    static {
        a = new f();
        b = (Map)new ConcurrentHashMap();
        c = CollectionsKt.n((Object[])new String[] { "other", "fb_mobile_complete_registration", "fb_mobile_add_to_cart", "fb_mobile_purchase", "fb_mobile_initiated_checkout" });
        d = CollectionsKt.n((Object[])new String[] { "none", "address", "health" });
    }
    
    private f() {
    }
    
    private final void e(final JSONObject jsonObject) {
        final Iterator keys = jsonObject.keys();
        try {
            while (keys.hasNext()) {
                final b c = f.b.i.c(jsonObject.getJSONObject((String)keys.next()));
                if (c == null) {
                    continue;
                }
                f.b.put((Object)c.g(), (Object)c);
            }
        }
        catch (final JSONException ex) {}
    }
    
    public static final void f() {
        W.E0((Runnable)new b2.c());
    }
    
    private static final void g() {
        try {
            final SharedPreferences sharedPreferences = e.l().getSharedPreferences("com.facebook.internal.MODEL_STORE", 0);
            final String string = sharedPreferences.getString("models", (String)null);
            JSONObject k;
            if (string != null && ((CharSequence)string).length() != 0) {
                k = new JSONObject(string);
            }
            else {
                k = new JSONObject();
            }
            final long long1 = sharedPreferences.getLong("model_request_timestamp", 0L);
            if (!s.g(s$b.v) || k.length() == 0 || !f.a.n(long1)) {
                k = f.a.k();
                if (k == null) {
                    return;
                }
                sharedPreferences.edit().putString("models", k.toString()).putLong("model_request_timestamp", System.currentTimeMillis()).apply();
            }
            final f a = f.a;
            a.e(k);
            a.h();
        }
        catch (final Exception ex) {}
    }
    
    private final void h() {
        final ArrayList list = new ArrayList();
        final Iterator iterator = f.b.entrySet().iterator();
        String b = null;
        int n = 0;
        while (iterator.hasNext()) {
            final Map$Entry map$Entry = (Map$Entry)iterator.next();
            final String s = (String)map$Entry.getKey();
            final b b2 = (b)map$Entry.getValue();
            int max = n;
            if (Intrinsics.a((Object)s, (Object)f.a.b.c())) {
                b = b2.b();
                max = Math.max(n, b2.h());
                if (n2.s.g(s$b.k) && this.m()) {
                    ((List)list).add((Object)b2.j((Runnable)new d()));
                }
            }
            n = max;
            if (Intrinsics.a((Object)s, (Object)f.a.a.c())) {
                final String b3 = b2.b();
                final int max2 = Math.max(max, b2.h());
                b = b3;
                n = max2;
                if (!n2.s.g(s$b.l)) {
                    continue;
                }
                ((List)list).add((Object)b2.j((Runnable)new b2.e()));
                b = b3;
                n = max2;
            }
        }
        if (b != null && n > 0 && !((List)list).isEmpty()) {
            f.b.i.f(new b("MTML", b, null, n, null), (List)list);
        }
    }
    
    private static final void i() {
        e2.e.b();
    }
    
    private static final void j() {
        Z1.a.a();
    }
    
    private final JSONObject k() {
        final Bundle bundle = new Bundle();
        ((BaseBundle)bundle).putString("fields", TextUtils.join((CharSequence)",", (Object[])new String[] { "use_case", "version_id", "asset_uri", "rules_uri", "thresholds" }));
        final GraphRequest x = GraphRequest.n.x((AccessToken)null, "app/model_asset", (GraphRequest$b)null);
        x.H(bundle);
        final JSONObject c = x.k().c();
        if (c == null) {
            return null;
        }
        return this.p(c);
    }
    
    public static final File l(final a a) {
        Intrinsics.checkNotNullParameter((Object)a, "task");
        final b b = (b)f.b.get((Object)a.c());
        if (b == null) {
            return null;
        }
        return b.d();
    }
    
    private final boolean m() {
        final Locale n = W.N();
        if (n != null) {
            final String language = n.getLanguage();
            Intrinsics.checkNotNullExpressionValue((Object)language, "getLanguage(...)");
            if (!StringsKt.P((CharSequence)language, (CharSequence)"en", false, 2, (Object)null)) {
                return false;
            }
        }
        return true;
    }
    
    private final boolean n(final long n) {
        return n != 0L && System.currentTimeMillis() - n < 259200000L;
    }
    
    private final float[] o(final JSONArray jsonArray) {
        if (jsonArray == null) {
            return null;
        }
        final float[] array = new float[jsonArray.length()];
        final int length = jsonArray.length();
        int n = 0;
    Label_0050_Outer:
        while (true) {
            if (n >= length) {
                return array;
            }
            while (true) {
                try {
                    final String string = jsonArray.getString(n);
                    Intrinsics.checkNotNullExpressionValue((Object)string, "getString(...)");
                    array[n] = Float.parseFloat(string);
                    ++n;
                    continue Label_0050_Outer;
                }
                catch (final JSONException ex) {
                    continue;
                }
                break;
            }
        }
    }
    
    private final JSONObject p(JSONObject jsonObject) {
        final JSONObject jsonObject2 = new JSONObject();
        try {
            final JSONArray jsonArray = jsonObject.getJSONArray("data");
            for (int length = jsonArray.length(), i = 0; i < length; ++i) {
                jsonObject = jsonArray.getJSONObject(i);
                final JSONObject jsonObject3 = new JSONObject();
                jsonObject3.put("version_id", (Object)jsonObject.getString("version_id"));
                jsonObject3.put("use_case", (Object)jsonObject.getString("use_case"));
                jsonObject3.put("thresholds", (Object)jsonObject.getJSONArray("thresholds"));
                jsonObject3.put("asset_uri", (Object)jsonObject.getString("asset_uri"));
                if (jsonObject.has("rules_uri")) {
                    jsonObject3.put("rules_uri", (Object)jsonObject.getString("rules_uri"));
                }
                jsonObject2.put(jsonObject.getString("use_case"), (Object)jsonObject3);
            }
            return jsonObject2;
        }
        catch (final JSONException ex) {
            return new JSONObject();
        }
    }
    
    public static final String[] q(final a a, final float[][] array, final String[] array2) {
        Intrinsics.checkNotNullParameter((Object)a, "task");
        Intrinsics.checkNotNullParameter((Object)array, "denses");
        Intrinsics.checkNotNullParameter((Object)array2, "texts");
        final b b = (b)f.b.get((Object)a.c());
        if (b != null) {
            final b2.b c = b.c();
            if (c != null) {
                final float[] f = b.f();
                final int length = array2.length;
                final int length2 = array[0].length;
                final b2.a a2 = new b2.a(new int[] { length, length2 });
                for (int i = 0; i < length; ++i) {
                    System.arraycopy((Object)array[i], 0, (Object)a2.a(), i * length2, length2);
                }
                final b2.a b2 = c.b(a2, array2, a.b());
                if (b2 != null && f != null) {
                    if (b2.a().length != 0) {
                        if (f.length != 0) {
                            final int n = b2.f.c.a[a.ordinal()];
                            if (n == 1) {
                                return b2.f.a.s(b2, f);
                            }
                            if (n == 2) {
                                return b2.f.a.r(b2, f);
                            }
                            throw new n();
                        }
                    }
                }
            }
        }
        return null;
    }
    
    private final String[] r(final b2.a a, final float[] array) {
        final int b = a.b(0);
        final int b2 = a.b(1);
        final float[] a2 = a.a();
        if (b2 != array.length) {
            return null;
        }
        final IntRange k = kotlin.ranges.d.k(0, b);
        final ArrayList list = new ArrayList(CollectionsKt.v((Iterable)k, 10));
        final Iterator iterator = ((Iterable)k).iterator();
        while (iterator.hasNext()) {
            final int a3 = ((E)iterator).a();
            final int length = array.length;
            Object value = "none";
            for (int i = 0, n = 0; i < length; ++i, ++n) {
                if (a2[a3 * b2 + n] >= array[i]) {
                    value = f.d.get(n);
                }
            }
            ((Collection)list).add((Object)value);
        }
        return (String[])((Collection)list).toArray((Object[])new String[0]);
    }
    
    private final String[] s(final b2.a a, final float[] array) {
        final int b = a.b(0);
        final int b2 = a.b(1);
        final float[] a2 = a.a();
        if (b2 != array.length) {
            return null;
        }
        final IntRange k = kotlin.ranges.d.k(0, b);
        final ArrayList list = new ArrayList(CollectionsKt.v((Iterable)k, 10));
        final Iterator iterator = ((Iterable)k).iterator();
        while (iterator.hasNext()) {
            final int a3 = ((E)iterator).a();
            final int length = array.length;
            Object value = "other";
            for (int i = 0, n = 0; i < length; ++i, ++n) {
                if (a2[a3 * b2 + n] >= array[i]) {
                    value = f.c.get(n);
                }
            }
            ((Collection)list).add((Object)value);
        }
        return (String[])((Collection)list).toArray((Object[])new String[0]);
    }
    
    public enum a
    {
        a("MTML_INTEGRITY_DETECT", 0), 
        b("MTML_APP_EVENT_PREDICTION", 1);
        
        private static final f.a[] c;
        private static final y7.a d;
        
        static {
            d = y7.b.a((Enum[])(c = a()));
        }
        
        private a(final String s, final int n) {
        }
        
        private static final /* synthetic */ f.a[] a() {
            return new f.a[] { f.a.a, f.a.b };
        }
        
        public final String b() {
            final int n = f.a.a.a[this.ordinal()];
            if (n == 1) {
                return "integrity_detect";
            }
            if (n == 2) {
                return "app_event_pred";
            }
            throw new n();
        }
        
        public final String c() {
            final int n = f.a.a.a[this.ordinal()];
            if (n == 1) {
                return "MTML_INTEGRITY_DETECT";
            }
            if (n == 2) {
                return "MTML_APP_EVENT_PRED";
            }
            throw new n();
        }
    }
    
    public static final class b
    {
        public static final a i;
        private String a;
        private String b;
        private String c;
        private int d;
        private float[] e;
        private File f;
        private b2.b g;
        private Runnable h;
        
        static {
            i = new a(null);
        }
        
        public b(final String a, final String b, final String c, final int d, final float[] e) {
            Intrinsics.checkNotNullParameter((Object)a, "useCase");
            Intrinsics.checkNotNullParameter((Object)b, "assetUri");
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.e = e;
        }
        
        public static final /* synthetic */ Runnable a(final b b) {
            return b.h;
        }
        
        public final String b() {
            return this.b;
        }
        
        public final b2.b c() {
            return this.g;
        }
        
        public final File d() {
            return this.f;
        }
        
        public final String e() {
            return this.c;
        }
        
        public final float[] f() {
            return this.e;
        }
        
        public final String g() {
            return this.a;
        }
        
        public final int h() {
            return this.d;
        }
        
        public final void i(final b2.b g) {
            this.g = g;
        }
        
        public final b j(final Runnable h) {
            this.h = h;
            return this;
        }
        
        public final void k(final File f) {
            this.f = f;
        }
        
        public static final class a
        {
            private a() {
            }
            
            private final void d(final String s, int i) {
                final File a = j.a();
                if (a != null) {
                    final File[] listFiles = a.listFiles();
                    if (listFiles != null) {
                        if (listFiles.length == 0) {
                            return;
                        }
                        final StringBuilder sb = new StringBuilder();
                        sb.append(s);
                        sb.append("_");
                        sb.append(i);
                        final String string = sb.toString();
                        int length;
                        File file;
                        String name;
                        for (length = listFiles.length, i = 0; i < length; ++i) {
                            file = listFiles[i];
                            name = file.getName();
                            Intrinsics.c((Object)name);
                            if (StringsKt.J(name, s, false, 2, (Object)null) && !StringsKt.J(name, string, false, 2, (Object)null)) {
                                file.delete();
                            }
                        }
                    }
                }
            }
            
            private final void e(final String s, final String s2, final k$a k$a) {
                final File file = new File(j.a(), s2);
                if (s != null && !file.exists()) {
                    ((AsyncTask)new k(s, file, k$a)).execute((Object[])new String[0]);
                    return;
                }
                k$a.a(file);
            }
            
            private static final void g(final List list, final File file) {
                Intrinsics.checkNotNullParameter((Object)list, "$slaves");
                Intrinsics.checkNotNullParameter((Object)file, "file");
                final b2.b a = b2.b.m.a(file);
                if (a != null) {
                    for (final b b : list) {
                        final String g = b.g();
                        final int h = b.h();
                        final StringBuilder sb = new StringBuilder();
                        sb.append(g);
                        sb.append("_");
                        sb.append(h);
                        sb.append("_rule");
                        b.i.e(b.e(), sb.toString(), (k$a)new h(b, a));
                    }
                }
            }
            
            private static final void h(final b b, final b2.b b2, final File file) {
                Intrinsics.checkNotNullParameter((Object)b, "$slave");
                Intrinsics.checkNotNullParameter((Object)file, "file");
                b.i(b2);
                b.k(file);
                final Runnable a = f.b.a(b);
                if (a != null) {
                    a.run();
                }
            }
            
            public final b c(final JSONObject jsonObject) {
                final b b = null;
                if (jsonObject == null) {
                    return null;
                }
                try {
                    final String string = jsonObject.getString("use_case");
                    final String string2 = jsonObject.getString("asset_uri");
                    final String optString = jsonObject.optString("rules_uri", (String)null);
                    final int int1 = jsonObject.getInt("version_id");
                    final float[] d = b2.f.a.o(jsonObject.getJSONArray("thresholds"));
                    Intrinsics.c((Object)string);
                    Intrinsics.c((Object)string2);
                    return new b(string, string2, optString, int1, d);
                }
                catch (final Exception ex) {
                    return b;
                }
            }
            
            public final void f(final b b, final List list) {
                Intrinsics.checkNotNullParameter((Object)b, "master");
                Intrinsics.checkNotNullParameter((Object)list, "slaves");
                this.d(b.g(), b.h());
                final String g = b.g();
                final int h = b.h();
                final StringBuilder sb = new StringBuilder();
                sb.append(g);
                sb.append("_");
                sb.append(h);
                this.e(b.b(), sb.toString(), (k$a)new g(list));
            }
        }
    }
}
