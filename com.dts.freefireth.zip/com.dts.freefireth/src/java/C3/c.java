package c3;

import l3.a;
import android.content.Context;

final class c extends h
{
    private final Context a;
    private final a b;
    private final a c;
    private final String d;
    
    c(final Context a, final a b, final a c, final String d) {
        if (a == null) {
            throw new NullPointerException("Null applicationContext");
        }
        this.a = a;
        if (b == null) {
            throw new NullPointerException("Null wallClock");
        }
        this.b = b;
        if (c == null) {
            throw new NullPointerException("Null monotonicClock");
        }
        this.c = c;
        if (d != null) {
            this.d = d;
            return;
        }
        throw new NullPointerException("Null backendName");
    }
    
    @Override
    public Context b() {
        return this.a;
    }
    
    @Override
    public String c() {
        return this.d;
    }
    
    @Override
    public a d() {
        return this.c;
    }
    
    @Override
    public a e() {
        return this.b;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof h) {
            final h h = (h)o;
            if (this.a.equals(h.b()) && this.b.equals(h.e()) && this.c.equals(h.d()) && this.d.equals((Object)h.c())) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return (((this.a.hashCode() ^ 0xF4243) * 1000003 ^ this.b.hashCode()) * 1000003 ^ this.c.hashCode()) * 1000003 ^ this.d.hashCode();
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("CreationContext{applicationContext=");
        sb.append((Object)this.a);
        sb.append(", wallClock=");
        sb.append((Object)this.b);
        sb.append(", monotonicClock=");
        sb.append((Object)this.c);
        sb.append(", backendName=");
        sb.append(this.d);
        sb.append("}");
        return sb.toString();
    }
}
