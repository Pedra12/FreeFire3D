package c3;

import android.os.BaseBundle;
import java.lang.reflect.InvocationTargetException;
import android.content.pm.ServiceInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager$NameNotFoundException;
import android.content.ComponentName;
import com.google.android.datatransport.runtime.backends.TransportBackendDiscovery;
import java.util.Iterator;
import android.os.Bundle;
import java.util.Collections;
import android.util.Log;
import java.util.HashMap;
import android.content.Context;
import java.util.Map;

class k implements e
{
    private final a a;
    private final i b;
    private final Map c;
    
    k(final Context context, final i i) {
        this(new a(context), i);
    }
    
    k(final a a, final i b) {
        this.c = (Map)new HashMap();
        this.a = a;
        this.b = b;
    }
    
    @Override
    public m a(final String s) {
        monitorenter(this);
        Label_0039: {
            try {
                if (this.c.containsKey((Object)s)) {
                    final m m = (m)this.c.get((Object)s);
                    monitorexit(this);
                    return m;
                }
                break Label_0039;
            }
            finally {
                monitorexit(this);
                final d b = this.a.b(s);
                iftrue(Label_0056:)(b != null);
                Block_5: {
                    break Block_5;
                    final m create;
                    Label_0056: {
                        create = b.create(this.b.a(s));
                    }
                    this.c.put((Object)s, (Object)create);
                    monitorexit(this);
                    return create;
                }
                monitorexit(this);
                return null;
            }
        }
    }
    
    static class a
    {
        private final Context a;
        private Map b;
        
        a(final Context a) {
            this.b = null;
            this.a = a;
        }
        
        private Map a(final Context context) {
            final Bundle d = d(context);
            if (d == null) {
                Log.w("BackendRegistry", "Could not retrieve metadata, returning empty list of transport backends.");
                return Collections.EMPTY_MAP;
            }
            final HashMap hashMap = new HashMap();
            for (final String s : ((BaseBundle)d).keySet()) {
                final Object value = ((BaseBundle)d).get(s);
                if (value instanceof String && s.startsWith("backend:")) {
                    final String[] split = ((String)value).split(",", -1);
                    for (int length = split.length, i = 0; i < length; ++i) {
                        final String trim = split[i].trim();
                        if (!trim.isEmpty()) {
                            ((Map)hashMap).put((Object)trim, (Object)s.substring(8));
                        }
                    }
                }
            }
            return (Map)hashMap;
        }
        
        private Map c() {
            if (this.b == null) {
                this.b = this.a(this.a);
            }
            return this.b;
        }
        
        private static Bundle d(final Context context) {
            try {
                final PackageManager packageManager = context.getPackageManager();
                if (packageManager == null) {
                    Log.w("BackendRegistry", "Context has no PackageManager.");
                    return null;
                }
                final ServiceInfo serviceInfo = packageManager.getServiceInfo(new ComponentName(context, (Class)TransportBackendDiscovery.class), 128);
                if (serviceInfo == null) {
                    Log.w("BackendRegistry", "TransportBackendDiscovery has no service info.");
                    return null;
                }
                return serviceInfo.metaData;
            }
            catch (final PackageManager$NameNotFoundException ex) {
                Log.w("BackendRegistry", "Application info not found.");
                return null;
            }
        }
        
        d b(String className) {
            className = (String)this.c().get((Object)className);
            if (className == null) {
                return null;
            }
            Label_0155: {
                Label_0132: {
                    Label_0109: {
                        Label_0086: {
                            try {
                                return (d)Class.forName(className).asSubclass(d.class).getDeclaredConstructor((Class<?>[])null).newInstance((Object[])null);
                            }
                            catch (final InvocationTargetException ex) {}
                            catch (final NoSuchMethodException ex2) {
                                break Label_0086;
                            }
                            catch (final InstantiationException ex3) {
                                break Label_0109;
                            }
                            catch (final IllegalAccessException ex4) {
                                break Label_0132;
                            }
                            catch (final ClassNotFoundException ex5) {
                                break Label_0155;
                            }
                            final InvocationTargetException ex;
                            Log.w("BackendRegistry", String.format("Could not instantiate %s", new Object[] { className }), (Throwable)ex);
                            return null;
                        }
                        final NoSuchMethodException ex2;
                        Log.w("BackendRegistry", String.format("Could not instantiate %s", new Object[] { className }), (Throwable)ex2);
                        return null;
                    }
                    final InstantiationException ex3;
                    Log.w("BackendRegistry", String.format("Could not instantiate %s.", new Object[] { className }), (Throwable)ex3);
                    return null;
                }
                final IllegalAccessException ex4;
                Log.w("BackendRegistry", String.format("Could not instantiate %s.", new Object[] { className }), (Throwable)ex4);
                return null;
            }
            final ClassNotFoundException ex5;
            Log.w("BackendRegistry", String.format("Class %s is not found.", new Object[] { className }), (Throwable)ex5);
            return null;
        }
    }
}
