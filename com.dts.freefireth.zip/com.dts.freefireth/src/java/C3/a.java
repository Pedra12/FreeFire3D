package c3;

import java.util.Arrays;

final class a extends f
{
    private final Iterable a;
    private final byte[] b;
    
    private a(final Iterable a, final byte[] b) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public Iterable b() {
        return this.a;
    }
    
    @Override
    public byte[] c() {
        return this.b;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof f) {
            final f f = (f)o;
            if (this.a.equals(f.b())) {
                final byte[] b = this.b;
                byte[] array;
                if (f instanceof a) {
                    array = ((a)f).b;
                }
                else {
                    array = f.c();
                }
                if (Arrays.equals(b, array)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return (this.a.hashCode() ^ 0xF4243) * 1000003 ^ Arrays.hashCode(this.b);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("BackendRequest{events=");
        sb.append((Object)this.a);
        sb.append(", extras=");
        sb.append(Arrays.toString(this.b));
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends f.a
    {
        private Iterable a;
        private byte[] b;
        
        @Override
        public f a() {
            final Iterable a = this.a;
            String string = "";
            if (a == null) {
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(" events");
                string = sb.toString();
            }
            if (string.isEmpty()) {
                return new a(this.a, this.b, null);
            }
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("Missing required properties:");
            sb2.append(string);
            throw new IllegalStateException(sb2.toString());
        }
        
        @Override
        public f.a b(final Iterable a) {
            if (a != null) {
                this.a = a;
                return this;
            }
            throw new NullPointerException("Null events");
        }
        
        @Override
        public f.a c(final byte[] b) {
            this.b = b;
            return this;
        }
    }
}
