package c3;

import b3.i;

public interface m
{
    g a(final f p0);
    
    i b(final i p0);
}
