package c3;

import android.content.Context;
import r7.a;
import d3.b;

public final class j implements b
{
    private final a a;
    private final a b;
    private final a c;
    
    public j(final a a, final a b, final a c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public static j a(final a a, final a a2, final a a3) {
        return new j(a, a2, a3);
    }
    
    public static i c(final Context context, final l3.a a, final l3.a a2) {
        return new i(context, a, a2);
    }
    
    public i b() {
        return c((Context)this.a.get(), (l3.a)this.b.get(), (l3.a)this.c.get());
    }
}
