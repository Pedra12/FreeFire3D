package c3;

public interface d
{
    m create(final h p0);
}
