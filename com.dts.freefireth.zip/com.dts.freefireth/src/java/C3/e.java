package c3;

public interface e
{
    m a(final String p0);
}
