package c3;

public abstract class g
{
    public static g a() {
        return new b(a.c, -1L);
    }
    
    public static g d() {
        return new b(a.d, -1L);
    }
    
    public static g e(final long n) {
        return new b(a.a, n);
    }
    
    public static g f() {
        return new b(a.b, -1L);
    }
    
    public abstract long b();
    
    public abstract a c();
    
    public enum a
    {
        a("OK", 0), 
        b("TRANSIENT_ERROR", 1), 
        c("FATAL_ERROR", 2), 
        d("INVALID_PAYLOAD", 3);
        
        private static final a[] e;
        
        private a(final String s, final int n) {
        }
    }
}
