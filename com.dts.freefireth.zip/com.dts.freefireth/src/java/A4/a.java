package a4;

import android.os.Parcel;
import android.os.IBinder;
import android.os.IInterface;

public abstract class a implements IInterface
{
    private final IBinder g;
    private final String h;
    
    protected a(final IBinder g, final String s) {
        this.g = g;
        this.h = "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService";
    }
    
    public final IBinder asBinder() {
        return this.g;
    }
    
    protected final Parcel f() {
        final Parcel obtain = Parcel.obtain();
        obtain.writeInterfaceToken(this.h);
        return obtain;
    }
    
    protected final Parcel g(final int n, final Parcel parcel) {
        final Parcel obtain = Parcel.obtain();
        try {
            try {
                this.g.transact(n, parcel, obtain, 0);
                obtain.readException();
                parcel.recycle();
                return obtain;
            }
            finally {}
        }
        catch (final RuntimeException ex) {
            obtain.recycle();
            throw ex;
        }
        parcel.recycle();
    }
}
