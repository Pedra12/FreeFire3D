package a4;

import android.os.Parcel;
import android.os.IBinder;

public final class d extends a implements f
{
    d(final IBinder binder) {
        super(binder, "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
    }
    
    @Override
    public final boolean I(final boolean b) {
        final Parcel f = this.f();
        c.a(f, true);
        final Parcel g = this.g(2, f);
        final boolean b2 = c.b(g);
        g.recycle();
        return b2;
    }
    
    @Override
    public final String a() {
        final Parcel g = this.g(1, this.f());
        final String string = g.readString();
        g.recycle();
        return string;
    }
}
