package a4;

import android.os.IInterface;

public interface f extends IInterface
{
    boolean I(final boolean p0);
    
    String a();
}
