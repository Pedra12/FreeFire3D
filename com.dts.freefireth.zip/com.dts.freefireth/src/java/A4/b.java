package a4;

import android.os.IInterface;
import android.os.Binder;

public abstract class b extends Binder implements IInterface
{
}
