package a4;

public interface h
{
}
