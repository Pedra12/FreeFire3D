package a4;

final class g implements h
{
    public g() {
    }
}
