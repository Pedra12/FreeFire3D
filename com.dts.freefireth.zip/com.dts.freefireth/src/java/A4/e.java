package a4;

import android.os.IInterface;
import android.os.IBinder;

public abstract class e extends b implements f
{
    public static f f(final IBinder binder) {
        if (binder == null) {
            return null;
        }
        final IInterface queryLocalInterface = binder.queryLocalInterface("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
        if (queryLocalInterface instanceof f) {
            return (f)queryLocalInterface;
        }
        return new d(binder);
    }
}
