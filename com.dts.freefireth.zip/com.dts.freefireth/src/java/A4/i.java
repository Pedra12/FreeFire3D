package a4;

public abstract class i
{
    private static volatile h a;
    
    static {
        i.a = new g();
    }
    
    public static void a() {
    }
    
    public static void b(final int n) {
    }
}
