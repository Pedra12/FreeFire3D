package d4;

import com.google.android.gms.common.Feature;

public abstract class h
{
    public static final Feature a;
    public static final Feature[] b;
    
    static {
        b = new Feature[] { a = new Feature("moduleinstall", 7L) };
    }
}
