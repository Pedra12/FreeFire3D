package d4;

import android.os.Handler$Callback;
import android.os.Looper;
import android.os.Handler;

public class g extends Handler
{
    private final Looper a;
    
    public g(final Looper looper) {
        super(looper);
        this.a = Looper.getMainLooper();
    }
    
    public g(final Looper looper, final Handler$Callback handler$Callback) {
        super(looper, handler$Callback);
        this.a = Looper.getMainLooper();
    }
}
