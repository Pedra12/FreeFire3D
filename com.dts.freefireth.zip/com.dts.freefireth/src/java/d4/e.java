package d4;

import y.h;

public abstract class e extends h
{
}
