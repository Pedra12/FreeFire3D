package d4;

import com.google.android.gms.common.Feature;

public abstract class d
{
    public static final Feature a;
    public static final Feature[] b;
    
    static {
        b = new Feature[] { a = new Feature("CLIENT_TELEMETRY", 1L) };
    }
}
