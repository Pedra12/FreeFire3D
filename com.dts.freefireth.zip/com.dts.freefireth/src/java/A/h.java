package A;

import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.CoroutineContext$Element;
import kotlin.coroutines.CoroutineContext$b;
import kotlin.jvm.functions.Function2;

final class h implements e
{
    public static final h a;
    
    static {
        a = new h();
    }
    
    private h() {
    }
    
    public Object G(final Object o, final Function2 function2) {
        return e.a.a(this, o, function2);
    }
    
    public CoroutineContext$Element b(final CoroutineContext$b coroutineContext$b) {
        return e.a.b(this, coroutineContext$b);
    }
    
    public CoroutineContext h(final CoroutineContext coroutineContext) {
        return e.a.d(this, coroutineContext);
    }
    
    public CoroutineContext r(final CoroutineContext$b coroutineContext$b) {
        return e.a.c(this, coroutineContext$b);
    }
}
