package A;

final class g implements i
{
    public static final g a;
    
    static {
        a = new g();
    }
    
    private g() {
    }
    
    @Override
    public String toString() {
        return "ReferentialEqualityPolicy";
    }
}
