package a;

import java.util.Locale;
import android.os.Parcel;
import c.j0;
import com.google.gson.annotations.SerializedName;
import android.os.Parcelable$Creator;
import android.os.Parcelable;

public final class b1 implements Parcelable
{
    public static final Parcelable$Creator<b1> CREATOR;
    @SerializedName("failingUrl")
    public String failingUrl;
    @SerializedName("isMainFrame")
    public boolean isMainFrame;
    @SerializedName("reasonPhrase")
    public String reasonPhrase;
    @SerializedName("statusCode")
    public int statusCode;
    @SerializedName("timestamp")
    public long timestamp;
    @SerializedName("webViewId")
    public int webViewId;
    
    static {
        CREATOR = (Parcelable$Creator)new j0();
    }
    
    public b1(final int webViewId, final int statusCode, String reasonPhrase, String failingUrl, final boolean isMainFrame) {
        this.webViewId = webViewId;
        this.statusCode = statusCode;
        if (reasonPhrase == null) {
            reasonPhrase = "";
        }
        this.reasonPhrase = reasonPhrase;
        if (failingUrl == null) {
            failingUrl = "";
        }
        this.failingUrl = failingUrl;
        this.isMainFrame = isMainFrame;
        this.timestamp = System.currentTimeMillis();
    }
    
    public b1(final Parcel parcel) {
        this.webViewId = parcel.readInt();
        this.statusCode = parcel.readInt();
        this.reasonPhrase = parcel.readString();
        this.failingUrl = parcel.readString();
        this.isMainFrame = (parcel.readByte() != 0);
        this.timestamp = parcel.readLong();
    }
    
    public final int describeContents() {
        return 0;
    }
    
    @Override
    public final String toString() {
        return String.format(Locale.getDefault(), "WebViewClientHttpError{webViewId=%d, statusCode=%d, reasonPhrase='%s', failingUrl='%s', isMainFrame=%s, timestamp=%d}", new Object[] { this.webViewId, this.statusCode, this.reasonPhrase, this.failingUrl, this.isMainFrame, this.timestamp });
    }
    
    public final void writeToParcel(final Parcel parcel, final int n) {
        parcel.writeInt(this.webViewId);
        parcel.writeInt(this.statusCode);
        parcel.writeString(this.reasonPhrase);
        parcel.writeString(this.failingUrl);
        parcel.writeByte((byte)(byte)(this.isMainFrame ? 1 : 0));
        parcel.writeLong(this.timestamp);
    }
}
