package A;

import android.os.Looper;
import kotlin.jvm.functions.Function0;
import s7.j;
import s7.i;

public abstract class a
{
    private static final i a;
    private static final long b;
    
    static {
        a = j.a((Function0)a$a.b);
        long id;
        try {
            id = Looper.getMainLooper().getThread().getId();
        }
        catch (final Exception ex) {
            id = -1L;
        }
        b = id;
    }
    
    public static final long a() {
        return A.a.b;
    }
}
