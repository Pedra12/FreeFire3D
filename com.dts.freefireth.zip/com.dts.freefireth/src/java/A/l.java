package A;

import B.b;
import java.util.concurrent.atomic.AtomicReference;

public final class l
{
    private final AtomicReference a;
    private final Object b;
    private Object c;
    
    public l() {
        this.a = new AtomicReference((Object)B.b.a());
        this.b = new Object();
    }
    
    public final Object a() {
        final long id = Thread.currentThread().getId();
        if (id == A.a.a()) {
            return this.c;
        }
        return ((B.a)this.a.get()).b(id);
    }
}
