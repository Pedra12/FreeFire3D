package a;

import android.os.Parcel;
import c.q0;
import c.D0;
import java.util.LinkedList;
import android.os.Parcelable$Creator;
import android.os.Parcelable;

public final class e1 implements Parcelable
{
    public static final Parcelable$Creator<e1> CREATOR;
    public float X;
    public float Y;
    public float Z;
    public String a;
    public boolean b;
    public boolean c;
    public boolean d;
    public boolean e;
    public boolean f;
    public double g;
    public String h;
    public final LinkedList i;
    public boolean j;
    public boolean k;
    public boolean l;
    public boolean v;
    public boolean w;
    public D0 x;
    public float y;
    
    static {
        CREATOR = (Parcelable$Creator)new q0();
    }
    
    public e1() {
        this.b = false;
        this.c = false;
        this.d = false;
        this.e = false;
        this.f = false;
        this.g = 0.0;
        this.i = new LinkedList();
        this.k = true;
        this.l = true;
        this.v = false;
        this.w = false;
    }
    
    public e1(final Parcel parcel) {
        final boolean b = false;
        this.b = false;
        this.c = false;
        this.d = false;
        this.e = false;
        this.f = false;
        this.g = 0.0;
        this.i = new LinkedList();
        this.k = true;
        this.l = true;
        this.v = false;
        this.w = false;
        this.a = parcel.readString();
        this.b = (parcel.readByte() != 0);
        this.c = (parcel.readByte() != 0);
        this.d = (parcel.readByte() != 0);
        this.e = (parcel.readByte() != 0);
        this.f = (parcel.readByte() != 0);
        this.g = parcel.readDouble();
        this.h = parcel.readString();
        this.j = (parcel.readByte() != 0);
        this.k = (parcel.readByte() != 0);
        this.l = (parcel.readByte() != 0);
        this.v = (parcel.readByte() != 0);
        boolean w = b;
        if (parcel.readByte() != 0) {
            w = true;
        }
        this.w = w;
        this.y = parcel.readFloat();
        this.X = parcel.readFloat();
        this.Y = parcel.readFloat();
        this.Z = parcel.readFloat();
    }
    
    public final int describeContents() {
        return 0;
    }
    
    public final void writeToParcel(final Parcel parcel, final int n) {
        parcel.writeString(this.a);
        parcel.writeByte((byte)(byte)(this.b ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.c ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.d ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.e ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.f ? 1 : 0));
        parcel.writeDouble(this.g);
        parcel.writeString(this.h);
        parcel.writeByte((byte)(byte)(this.j ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.k ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.l ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.v ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.w ? 1 : 0));
        parcel.writeFloat(this.y);
        parcel.writeFloat(this.X);
        parcel.writeFloat(this.Y);
        parcel.writeFloat(this.Z);
    }
}
