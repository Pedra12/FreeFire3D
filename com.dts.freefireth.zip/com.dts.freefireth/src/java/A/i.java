package A;

public interface i
{
}
