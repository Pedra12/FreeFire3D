package a;

import java.util.Locale;
import android.os.Parcel;
import c.f0;
import com.google.gson.annotations.SerializedName;
import android.os.Parcelable$Creator;
import android.os.Parcelable;

public final class Z0 implements Parcelable
{
    public static final Parcelable$Creator<Z0> CREATOR;
    @SerializedName("errorCode")
    public int errorCode;
    @SerializedName("errorMessage")
    public String errorMessage;
    @SerializedName("failingUrl")
    public String failingUrl;
    @SerializedName("isMainFrame")
    public boolean isMainFrame;
    @SerializedName("timestamp")
    public long timestamp;
    @SerializedName("webViewId")
    public int webViewId;
    
    static {
        CREATOR = (Parcelable$Creator)new f0();
    }
    
    public Z0(final int webViewId, final int errorCode, String errorMessage, String failingUrl, final boolean isMainFrame) {
        this.webViewId = webViewId;
        this.errorCode = errorCode;
        if (errorMessage == null) {
            errorMessage = "";
        }
        this.errorMessage = errorMessage;
        if (failingUrl == null) {
            failingUrl = "";
        }
        this.failingUrl = failingUrl;
        this.isMainFrame = isMainFrame;
        this.timestamp = System.currentTimeMillis();
    }
    
    public Z0(final Parcel parcel) {
        this.webViewId = parcel.readInt();
        this.errorCode = parcel.readInt();
        this.errorMessage = parcel.readString();
        this.failingUrl = parcel.readString();
        this.isMainFrame = (parcel.readByte() != 0);
        this.timestamp = parcel.readLong();
    }
    
    public final int describeContents() {
        return 0;
    }
    
    @Override
    public final String toString() {
        return String.format(Locale.getDefault(), "WebViewClientError{webViewId=%d, errorCode=%d, errorMessage='%s', failingUrl='%s', isMainFrame=%s, timestamp=%d}", new Object[] { this.webViewId, this.errorCode, this.errorMessage, this.failingUrl, this.isMainFrame, this.timestamp });
    }
    
    public final void writeToParcel(final Parcel parcel, final int n) {
        parcel.writeInt(this.webViewId);
        parcel.writeInt(this.errorCode);
        parcel.writeString(this.errorMessage);
        parcel.writeString(this.failingUrl);
        parcel.writeByte((byte)(byte)(this.isMainFrame ? 1 : 0));
        parcel.writeLong(this.timestamp);
    }
}
