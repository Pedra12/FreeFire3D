package A;

final class m implements i
{
    public static final m a;
    
    static {
        a = new m();
    }
    
    private m() {
    }
    
    @Override
    public String toString() {
        return "StructuralEqualityPolicy";
    }
}
