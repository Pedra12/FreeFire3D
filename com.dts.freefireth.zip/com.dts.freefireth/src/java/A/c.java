package a;

import android.os.Parcel;
import c.m0;
import com.google.gson.annotations.SerializedName;
import android.os.Parcelable$Creator;
import android.os.Parcelable;

public final class c implements Parcelable
{
    public static final Parcelable$Creator<c> CREATOR;
    @SerializedName("callback")
    public String callback;
    @SerializedName("code")
    public String code;
    @SerializedName("id")
    public String id;
    @SerializedName("webViewId")
    public int webViewId;
    
    static {
        CREATOR = (Parcelable$Creator)new m0();
    }
    
    public c() {
    }
    
    public c(final Parcel parcel) {
        this.webViewId = parcel.readInt();
        this.code = parcel.readString();
        this.callback = parcel.readString();
        this.id = parcel.readString();
    }
    
    public final int describeContents() {
        return 0;
    }
    
    public final void writeToParcel(final Parcel parcel, final int n) {
        parcel.writeInt(this.webViewId);
        parcel.writeString(this.code);
        parcel.writeString(this.callback);
        parcel.writeString(this.id);
    }
}
