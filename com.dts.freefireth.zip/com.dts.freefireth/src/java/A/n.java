package A;

import java.lang.ref.WeakReference;

public abstract class n extends WeakReference
{
}
