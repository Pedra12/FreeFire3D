package a;

import android.os.Parcel;
import c.c0;
import android.os.Parcelable$Creator;
import android.os.Parcelable;

public final class X0 implements Parcelable
{
    public static final Parcelable$Creator<X0> CREATOR;
    public String X;
    public String Y;
    public int a;
    public String b;
    public float c;
    public float d;
    public float e;
    public float f;
    public boolean g;
    public boolean h;
    public boolean i;
    public boolean j;
    public boolean k;
    public boolean l;
    public boolean v;
    public boolean w;
    public boolean x;
    public boolean y;
    
    static {
        CREATOR = (Parcelable$Creator)new c0();
    }
    
    public X0(final int a) {
        this.g = false;
        this.h = true;
        this.i = false;
        this.j = false;
        this.k = true;
        this.l = true;
        this.v = true;
        this.w = true;
        this.x = false;
        this.y = false;
        this.a = a;
    }
    
    public X0(final Parcel parcel) {
        final boolean b = false;
        this.g = false;
        this.h = true;
        this.i = false;
        this.j = false;
        this.k = true;
        this.l = true;
        this.v = true;
        this.w = true;
        this.x = false;
        this.y = false;
        this.a = parcel.readInt();
        this.b = parcel.readString();
        this.c = parcel.readFloat();
        this.d = parcel.readFloat();
        this.e = parcel.readFloat();
        this.f = parcel.readFloat();
        this.g = (parcel.readByte() != 0);
        this.h = (parcel.readByte() != 0);
        this.i = (parcel.readByte() != 0);
        this.j = (parcel.readByte() != 0);
        this.k = (parcel.readByte() != 0);
        this.l = (parcel.readByte() != 0);
        this.v = (parcel.readByte() != 0);
        this.w = (parcel.readByte() != 0);
        this.x = (parcel.readByte() != 0);
        boolean y = b;
        if (parcel.readByte() != 0) {
            y = true;
        }
        this.y = y;
        this.X = parcel.readString();
        this.Y = parcel.readString();
    }
    
    public final int describeContents() {
        return 0;
    }
    
    public final void writeToParcel(final Parcel parcel, final int n) {
        parcel.writeInt(this.a);
        parcel.writeString(this.b);
        parcel.writeFloat(this.c);
        parcel.writeFloat(this.d);
        parcel.writeFloat(this.e);
        parcel.writeFloat(this.f);
        parcel.writeByte((byte)(byte)(this.g ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.h ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.i ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.j ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.k ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.l ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.v ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.w ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.x ? 1 : 0));
        parcel.writeByte((byte)(byte)(this.y ? 1 : 0));
        parcel.writeString(this.X);
        parcel.writeString(this.Y);
    }
}
