package A;

final class f implements i
{
    public static final f a;
    
    static {
        a = new f();
    }
    
    private f() {
    }
    
    @Override
    public String toString() {
        return "NeverEqualPolicy";
    }
}
