package a;

import android.os.Parcel;
import c.r0;
import com.google.gson.annotations.SerializedName;
import android.os.Parcelable$Creator;
import android.os.Parcelable;

public final class e implements Parcelable
{
    public static final Parcelable$Creator<e> CREATOR;
    @SerializedName("callback")
    public String callback;
    @SerializedName("error")
    public String error;
    @SerializedName("id")
    public String id;
    @SerializedName("value")
    public String value;
    
    static {
        CREATOR = (Parcelable$Creator)new r0();
    }
    
    public e() {
    }
    
    public e(final Parcel parcel) {
        this.id = parcel.readString();
        this.callback = parcel.readString();
        this.error = parcel.readString();
        this.value = parcel.readString();
    }
    
    public final int describeContents() {
        return 0;
    }
    
    public final void writeToParcel(final Parcel parcel, final int n) {
        parcel.writeString(this.id);
        parcel.writeString(this.callback);
        parcel.writeString(this.error);
        parcel.writeString(this.value);
    }
}
