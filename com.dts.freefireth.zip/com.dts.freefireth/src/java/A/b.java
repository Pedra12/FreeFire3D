package A;

import java.util.concurrent.atomic.AtomicInteger;

public final class b extends AtomicInteger
{
    public b(final int n) {
        super(n);
    }
    
    public byte a() {
        return (byte)this.intValue();
    }
    
    public /* bridge */ double b() {
        return super.doubleValue();
    }
    
    public final /* bridge */ byte byteValue() {
        return this.a();
    }
    
    public /* bridge */ float c() {
        return super.floatValue();
    }
    
    public /* bridge */ int d() {
        return super.intValue();
    }
    
    public final /* bridge */ double doubleValue() {
        return this.b();
    }
    
    public /* bridge */ long e() {
        return super.longValue();
    }
    
    public short f() {
        return (short)this.intValue();
    }
    
    public final /* bridge */ float floatValue() {
        return this.c();
    }
    
    public final /* bridge */ int intValue() {
        return this.d();
    }
    
    public final /* bridge */ long longValue() {
        return this.e();
    }
    
    public final /* bridge */ short shortValue() {
        return this.f();
    }
}
