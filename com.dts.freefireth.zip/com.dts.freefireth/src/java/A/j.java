package A;

public abstract class j
{
    public static final i a() {
        return k.a();
    }
    
    public static final i b() {
        return k.b();
    }
    
    public static final i c() {
        return k.c();
    }
}
