package d1;

public final class a
{
    public static final String a = "8.0.0";
}
