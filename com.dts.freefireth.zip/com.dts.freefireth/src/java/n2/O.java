package n2;

import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import java.util.HashSet;
import java.util.HashMap;
import org.json.JSONObject;
import kotlin.collections.F;
import s7.u;
import kotlin.Pair;
import java.util.Set;
import com.facebook.FacebookRequestError$a;
import kotlin.jvm.internal.DefaultConstructorMarker;
import java.util.Map;

public final class o
{
    public static final a g;
    private static o h;
    private final Map a;
    private final Map b;
    private final Map c;
    private final String d;
    private final String e;
    private final String f;
    
    static {
        g = new a(null);
    }
    
    public o(final Map a, final Map b, final Map c, final String d, final String e, final String f) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    public static final /* synthetic */ o a() {
        return o.h;
    }
    
    public static final /* synthetic */ void b(final o h) {
        o.h = h;
    }
    
    public final FacebookRequestError$a c(final int n, final int n2, final boolean b) {
        if (b) {
            return FacebookRequestError$a.c;
        }
        final Map a = this.a;
        if (a != null && a.containsKey((Object)n)) {
            final Set set = (Set)this.a.get((Object)n);
            if (set == null || set.contains((Object)n2)) {
                return FacebookRequestError$a.b;
            }
        }
        final Map c = this.c;
        if (c != null && c.containsKey((Object)n)) {
            final Set set2 = (Set)this.c.get((Object)n);
            if (set2 == null || set2.contains((Object)n2)) {
                return FacebookRequestError$a.a;
            }
        }
        final Map b2 = this.b;
        if (b2 != null && b2.containsKey((Object)n)) {
            final Set set3 = (Set)this.b.get((Object)n);
            if (set3 == null || set3.contains((Object)n2)) {
                return FacebookRequestError$a.c;
            }
        }
        return FacebookRequestError$a.b;
    }
    
    public final String d(final FacebookRequestError$a facebookRequestError$a) {
        int n;
        if (facebookRequestError$a == null) {
            n = -1;
        }
        else {
            n = o.b.a[((Enum)facebookRequestError$a).ordinal()];
        }
        if (n == 1) {
            return this.d;
        }
        if (n == 2) {
            return this.f;
        }
        if (n != 3) {
            return null;
        }
        return this.e;
    }
    
    public static final class a
    {
        private a() {
        }
        
        private final o c() {
            return new o(null, (Map)F.k(new Pair[] { u.a((Object)2, (Object)null), u.a((Object)4, (Object)null), u.a((Object)9, (Object)null), u.a((Object)17, (Object)null), u.a((Object)341, (Object)null) }), (Map)F.k(new Pair[] { u.a((Object)102, (Object)null), u.a((Object)190, (Object)null), u.a((Object)412, (Object)null) }), null, null, null);
        }
        
        private final Map d(JSONObject optJSONObject) {
            final JSONArray optJSONArray = optJSONObject.optJSONArray("items");
            if (optJSONArray != null && optJSONArray.length() != 0) {
                final HashMap hashMap = new HashMap();
                for (int length = optJSONArray.length(), i = 0; i < length; ++i) {
                    optJSONObject = optJSONArray.optJSONObject(i);
                    if (optJSONObject != null) {
                        final int optInt = optJSONObject.optInt("code");
                        if (optInt != 0) {
                            final JSONArray optJSONArray2 = optJSONObject.optJSONArray("subcodes");
                            Object o;
                            if (optJSONArray2 != null && optJSONArray2.length() > 0) {
                                final HashSet set = new HashSet();
                                final int length2 = optJSONArray2.length();
                                int n = 0;
                                while (true) {
                                    o = set;
                                    if (n >= length2) {
                                        break;
                                    }
                                    final int optInt2 = optJSONArray2.optInt(n);
                                    if (optInt2 != 0) {
                                        set.add((Object)optInt2);
                                    }
                                    ++n;
                                }
                            }
                            else {
                                o = null;
                            }
                            ((Map)hashMap).put((Object)optInt, o);
                        }
                    }
                }
                return (Map)hashMap;
            }
            return null;
        }
        
        public final o a(final JSONArray jsonArray) {
            if (jsonArray == null) {
                return null;
            }
            final int length = jsonArray.length();
            int i = 0;
            Map map = null;
            String s = null;
            String s2;
            Object d = s2 = s;
            String optString;
            String s3 = optString = s2;
            while (i < length) {
                final JSONObject optJSONObject = jsonArray.optJSONObject(i);
                Map d2;
                Object d3;
                String optString2;
                String optString3;
                if (optJSONObject == null) {
                    d2 = map;
                    d3 = s;
                    optString2 = s2;
                    optString3 = s3;
                }
                else {
                    final String optString4 = optJSONObject.optString("name");
                    if (optString4 == null) {
                        d2 = map;
                        d3 = s;
                        optString2 = s2;
                        optString3 = s3;
                    }
                    else if (StringsKt.y(optString4, "other", true)) {
                        optString2 = optJSONObject.optString("recovery_message", (String)null);
                        d2 = this.d(optJSONObject);
                        d3 = s;
                        optString3 = s3;
                    }
                    else if (StringsKt.y(optString4, "transient", true)) {
                        optString3 = optJSONObject.optString("recovery_message", (String)null);
                        d3 = this.d(optJSONObject);
                        d2 = map;
                        optString2 = s2;
                    }
                    else {
                        d2 = map;
                        d3 = s;
                        optString2 = s2;
                        optString3 = s3;
                        if (StringsKt.y(optString4, "login_recoverable", true)) {
                            optString = optJSONObject.optString("recovery_message", (String)null);
                            d = this.d(optJSONObject);
                            optString3 = s3;
                            optString2 = s2;
                            d3 = s;
                            d2 = map;
                        }
                    }
                }
                ++i;
                map = d2;
                s = (String)d3;
                s2 = optString2;
                s3 = optString3;
            }
            return new o(map, (Map)s, (Map)d, s2, s3, optString);
        }
        
        public final o b() {
            monitorenter(this);
            Label_0024: {
                try {
                    if (o.a() == null) {
                        o.b(this.c());
                    }
                    break Label_0024;
                }
                finally {
                    monitorexit(this);
                    final o a = o.a();
                    Intrinsics.d((Object)a, "null cannot be cast to non-null type com.facebook.internal.FacebookRequestErrorClassification");
                    monitorexit(this);
                    return a;
                }
            }
        }
    }
}
