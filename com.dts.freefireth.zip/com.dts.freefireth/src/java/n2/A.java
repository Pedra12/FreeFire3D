package n2;

import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.DefaultConstructorMarker;
import android.content.Intent;
import java.util.UUID;

public final class a
{
    public static final a d;
    private static a e;
    private int a;
    private final UUID b;
    private Intent c;
    
    static {
        d = new a(null);
    }
    
    public a(final int n) {
        this(n, null, 2, null);
    }
    
    public a(final int a, final UUID b) {
        Intrinsics.checkNotNullParameter((Object)b, "callId");
        this.a = a;
        this.b = b;
    }
    
    public static final /* synthetic */ a a() {
        return a.e;
    }
    
    public static final /* synthetic */ void b(final a e) {
        a.e = e;
    }
    
    public final UUID c() {
        return this.b;
    }
    
    public final int d() {
        return this.a;
    }
    
    public final Intent e() {
        return this.c;
    }
    
    public final boolean f() {
        return n2.a.d.d(this);
    }
    
    public final void g(final Intent c) {
        this.c = c;
    }
    
    public static final class a
    {
        private a() {
        }
        
        private final boolean d(final n2.a a) {
            synchronized (this) {
                final n2.a c = this.c();
                a.b(a);
                return c != null;
            }
        }
        
        public final n2.a b(final UUID uuid, final int n) {
            monitorenter(this);
            Label_0057: {
                try {
                    Intrinsics.checkNotNullParameter((Object)uuid, "callId");
                    final n2.a c = this.c();
                    if (c != null && Intrinsics.a((Object)c.c(), (Object)uuid) && c.d() == n) {
                        this.d(null);
                        monitorexit(this);
                        return c;
                    }
                    break Label_0057;
                }
                finally {
                    monitorexit(this);
                    monitorexit(this);
                    return null;
                }
            }
        }
        
        public final n2.a c() {
            return n2.a.a();
        }
    }
}
