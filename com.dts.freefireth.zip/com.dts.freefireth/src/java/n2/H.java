package n2;

public interface h
{
    int a();
    
    String b();
    
    String name();
}
