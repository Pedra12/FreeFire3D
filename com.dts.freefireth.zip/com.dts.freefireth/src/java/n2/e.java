package n2;

import y7.b;
import y7.a;
import kotlin.jvm.internal.Intrinsics;
import android.content.Intent;
import java.util.HashMap;
import kotlin.jvm.internal.DefaultConstructorMarker;
import java.util.Map;

public final class e implements R1.e
{
    public static final b b;
    private static final Map c;
    private final Map a;
    
    static {
        b = new b(null);
        c = (Map)new HashMap();
    }
    
    public e() {
        this.a = (Map)new HashMap();
    }
    
    public static final /* synthetic */ Map b() {
        return e.c;
    }
    
    public boolean a(final int n, final int n2, final Intent intent) {
        final e$a e$a = (e$a)this.a.get((Object)n);
        if (e$a != null) {
            return e$a.a(n2, intent);
        }
        return e.b.d(n, n2, intent);
    }
    
    public final void c(final int n, final e$a e$a) {
        Intrinsics.checkNotNullParameter((Object)e$a, "callback");
        this.a.put((Object)n, (Object)e$a);
    }
    
    public static final class b
    {
        private b() {
        }
        
        private final e$a b(final int n) {
            synchronized (this) {
                return (e$a)e.b().get((Object)n);
            }
        }
        
        private final boolean d(final int n, final int n2, final Intent intent) {
            final e$a b = this.b(n);
            return b != null && b.a(n2, intent);
        }
        
        public final void c(final int n, final e$a e$a) {
            synchronized (this) {
                Intrinsics.checkNotNullParameter((Object)e$a, "callback");
                if (e.b().containsKey((Object)n)) {
                    return;
                }
                e.b().put((Object)n, (Object)e$a);
            }
        }
    }
    
    public enum c
    {
        private static final a W0;
        
        X("TournamentShareDialog", 15, 15), 
        Y("TournamentJoinDialog", 16, 16);
        
        private static final c[] Z;
        
        b("Login", 0, 0), 
        c("Share", 1, 1), 
        d("Message", 2, 2), 
        e("Like", 3, 3), 
        f("GameRequest", 4, 4), 
        g("AppGroupCreate", 5, 5), 
        h("AppGroupJoin", 6, 6), 
        i("AppInvite", 7, 7), 
        j("DeviceShare", 8, 8), 
        k("GamingFriendFinder", 9, 9), 
        l("GamingGroupIntegration", 10, 10), 
        v("Referral", 11, 11), 
        w("GamingContextCreate", 12, 12), 
        x("GamingContextSwitch", 13, 13), 
        y("GamingContextChoose", 14, 14);
        
        private final int a;
        
        static {
            W0 = y7.b.a((Enum[])(Z = a()));
        }
        
        private c(final String s, final int n, final int a) {
            this.a = a;
        }
        
        private static final /* synthetic */ c[] a() {
            return new c[] { c.b, c.c, c.d, c.e, c.f, c.g, c.h, c.i, c.j, c.k, c.l, c.v, c.w, c.x, c.y, c.X, c.Y };
        }
        
        public final int b() {
            return com.facebook.e.q() + this.a;
        }
    }
}
