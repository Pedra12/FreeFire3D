package n2;

import kotlin.jvm.internal.DefaultConstructorMarker;
import y7.b;
import y7.a;
import java.util.Iterator;
import kotlin.text.StringsKt;
import java.util.Map$Entry;
import com.facebook.e;
import kotlin.jvm.internal.Intrinsics;
import java.util.HashMap;
import java.util.Map;

public final class s
{
    public static final s a;
    private static final Map b;
    
    static {
        a = new s();
        b = (Map)new HashMap();
    }
    
    private s() {
    }
    
    public static final void a(final b b, final s$a s$a) {
        Intrinsics.checkNotNullParameter((Object)b, "feature");
        Intrinsics.checkNotNullParameter((Object)s$a, "callback");
        v.h((v.a)new v.a(s$a, b) {
            final s$a a;
            final s.b b;
            
            @Override
            public void a() {
                this.a.a(s.g(this.b));
            }
        });
    }
    
    private final boolean b(final b b) {
        switch (c.a[b.ordinal()]) {
            default: {
                return true;
            }
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
            case 23:
            case 24: {
                return false;
            }
        }
    }
    
    public static final void c(final b b) {
        Intrinsics.checkNotNullParameter((Object)b, "feature");
        e.l().getSharedPreferences("com.facebook.internal.FEATURE_MANAGER", 0).edit().putString(b.d(), e.B()).apply();
    }
    
    public static final b d(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "className");
        s.a.f();
        for (final Map$Entry map$Entry : s.b.entrySet()) {
            final b b = (b)map$Entry.getKey();
            final String[] array = (String[])map$Entry.getValue();
            for (int length = array.length, i = 0; i < length; ++i) {
                if (StringsKt.J(s, array[i], false, 2, (Object)null)) {
                    return b;
                }
            }
        }
        return n2.s.b.c;
    }
    
    private final boolean e(final b b) {
        return v.d(b.d(), e.m(), this.b(b));
    }
    
    private final void f() {
        synchronized (this) {
            final Map b = s.b;
            if (!b.isEmpty()) {
                return;
            }
            b.put((Object)s.b.i, (Object)new String[] { "com.facebook.appevents.aam." });
            b.put((Object)s.b.f, (Object)new String[] { "com.facebook.appevents.codeless." });
            b.put((Object)s.b.g, (Object)new String[] { "com.facebook.appevents.cloudbridge." });
            b.put((Object)s.b.b1, (Object)new String[] { "com.facebook.internal.instrument.errorreport." });
            b.put((Object)s.b.c1, (Object)new String[] { "com.facebook.internal.instrument.anrreport." });
            b.put((Object)s.b.j, (Object)new String[] { "com.facebook.appevents.ml." });
            b.put((Object)s.b.k, (Object)new String[] { "com.facebook.appevents.suggestedevents." });
            b.put((Object)s.b.h, (Object)new String[] { "com.facebook.appevents.restrictivedatafilter.RestrictiveDataManager" });
            b.put((Object)s.b.l, (Object)new String[] { "com.facebook.appevents.integrity.IntegrityManager" });
            b.put((Object)s.b.w, (Object)new String[] { "com.facebook.appevents.integrity.ProtectedModeManager" });
            b.put((Object)s.b.x, (Object)new String[] { "com.facebook.appevents.integrity.MACARuleMatchingManager" });
            b.put((Object)s.b.y, (Object)new String[] { "com.facebook.appevents.eventdeactivation." });
            b.put((Object)s.b.X, (Object)new String[] { "com.facebook.appevents.ondeviceprocessing." });
            b.put((Object)s.b.Z, (Object)new String[] { "com.facebook.appevents.iap." });
            b.put((Object)s.b.d1, (Object)new String[] { "com.facebook.internal.logging.monitor" });
        }
    }
    
    public static final boolean g(final b b) {
        Intrinsics.checkNotNullParameter((Object)b, "feature");
        if (s.b.c == b) {
            return false;
        }
        if (s.b.d == b) {
            return true;
        }
        final String string = e.l().getSharedPreferences("com.facebook.internal.FEATURE_MANAGER", 0).getString(b.d(), (String)null);
        if (string != null && Intrinsics.a((Object)string, (Object)e.B())) {
            return false;
        }
        final b c = b.c();
        if (c == b) {
            return s.a.e(b);
        }
        return g(c) && s.a.e(b);
    }
    
    public enum b
    {
        W0("IapLoggingLib2", 17, 67329), 
        X("OnDeviceEventProcessing", 14, 67072), 
        X0("Instrument", 18, 131072), 
        Y("OnDevicePostInstallEventProcessing", 15, 67073), 
        Y0("CrashReport", 19, 131328), 
        Z("IapLogging", 16, 67328), 
        Z0("CrashShield", 20, 131329), 
        a1("ThreadCheck", 21, 131330);
        
        public static final a b;
        
        b1("ErrorReport", 22, 131584), 
        c("Unknown", 0, -1), 
        c1("AnrReport", 23, 131840), 
        d("Core", 1, 0), 
        d1("Monitoring", 24, 196608), 
        e("AppEvents", 2, 65536), 
        e1("ServiceUpdateCompliance", 25, 196864), 
        f("CodelessEvents", 3, 65792), 
        f1("Megatron", 26, 262144), 
        g("CloudBridge", 4, 67584), 
        g1("Elora", 27, 327680), 
        h("RestrictiveDataFiltering", 5, 66048), 
        h1("Login", 28, 16777216), 
        i("AAM", 6, 66304), 
        i1("ChromeCustomTabsPrefetching", 29, 16842752), 
        j("PrivacyProtection", 7, 66560), 
        j1("IgnoreAppSwitchToLoggedOut", 30, 16908288), 
        k("SuggestedEvents", 8, 66561), 
        k1("BypassAppSwitch", 31, 16973824), 
        l("IntelligentIntegrity", 9, 66562), 
        l1("Share", 32, 33554432);
        
        private static final s.b[] m1;
        private static final y7.a n1;
        
        v("ModelRequest", 10, 66563), 
        w("ProtectedMode", 11, 66564), 
        x("MACARuleMatching", 12, 66565), 
        y("EventDeactivation", 13, 66816);
        
        private final int a;
        
        static {
            n1 = y7.b.a((Enum[])(m1 = a()));
            b = new a(null);
        }
        
        private b(final String s, final int n, final int a) {
            this.a = a;
        }
        
        private static final /* synthetic */ s.b[] a() {
            return new s.b[] { s.b.c, s.b.d, s.b.e, s.b.f, s.b.g, s.b.h, s.b.i, s.b.j, s.b.k, s.b.l, s.b.v, s.b.w, s.b.x, s.b.y, s.b.X, s.b.Y, s.b.Z, s.b.W0, s.b.X0, s.b.Y0, s.b.Z0, s.b.a1, s.b.b1, s.b.c1, s.b.d1, s.b.e1, s.b.f1, s.b.g1, s.b.h1, s.b.i1, s.b.j1, s.b.k1, s.b.l1 };
        }
        
        public static final /* synthetic */ int b(final s.b b) {
            return b.a;
        }
        
        public final s.b c() {
            final int a = this.a;
            if ((a & 0xFF) > 0) {
                return s.b.b.a(a & 0xFFFFFF00);
            }
            if ((0xFF00 & a) > 0) {
                return s.b.b.a(a & 0xFFFF0000);
            }
            if ((0xFF0000 & a) > 0) {
                return s.b.b.a(a & 0xFF000000);
            }
            return s.b.b.a(0);
        }
        
        public final String d() {
            final StringBuilder sb = new StringBuilder();
            sb.append("FBSDKFeature");
            sb.append((Object)this);
            return sb.toString();
        }
        
        public String toString() {
            switch (s.b.b.a[this.ordinal()]) {
                default: {
                    return "unknown";
                }
                case 32: {
                    return "ShareKit";
                }
                case 31: {
                    return "BypassAppSwitch";
                }
                case 30: {
                    return "IgnoreAppSwitchToLoggedOut";
                }
                case 29: {
                    return "ChromeCustomTabsPrefetching";
                }
                case 28: {
                    return "LoginKit";
                }
                case 27: {
                    return "ServiceUpdateCompliance";
                }
                case 26: {
                    return "Elora";
                }
                case 25: {
                    return "Megatron";
                }
                case 24: {
                    return "Monitoring";
                }
                case 23: {
                    return "IAPLoggingLib2";
                }
                case 22: {
                    return "IAPLogging";
                }
                case 21: {
                    return "OnDevicePostInstallEventProcessing";
                }
                case 20: {
                    return "OnDeviceEventProcessing";
                }
                case 19: {
                    return "EventDeactivation";
                }
                case 18: {
                    return "ModelRequest";
                }
                case 17: {
                    return "MACARuleMatching";
                }
                case 16: {
                    return "ProtectedMode";
                }
                case 15: {
                    return "IntelligentIntegrity";
                }
                case 14: {
                    return "SuggestedEvents";
                }
                case 13: {
                    return "PrivacyProtection";
                }
                case 12: {
                    return "AppEventsCloudbridge";
                }
                case 11: {
                    return "AAM";
                }
                case 10: {
                    return "AnrReport";
                }
                case 9: {
                    return "ErrorReport";
                }
                case 8: {
                    return "ThreadCheck";
                }
                case 7: {
                    return "CrashShield";
                }
                case 6: {
                    return "CrashReport";
                }
                case 5: {
                    return "Instrument";
                }
                case 4: {
                    return "RestrictiveDataFiltering";
                }
                case 3: {
                    return "CodelessEvents";
                }
                case 2: {
                    return "AppEvents";
                }
                case 1: {
                    return "CoreKit";
                }
            }
        }
        
        public static final class a
        {
            private a() {
            }
            
            public final s.b a(final int n) {
                for (final s.b b : s.b.values()) {
                    if (s.b.b(b) == n) {
                        return b;
                    }
                }
                return s.b.c;
            }
        }
    }
}
