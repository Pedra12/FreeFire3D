package n2;

import android.os.BaseBundle;
import java.util.Iterator;
import org.json.JSONObject;
import java.util.ArrayList;
import org.json.JSONArray;
import kotlin.jvm.internal.Intrinsics;
import android.os.Bundle;
import java.util.HashMap;
import java.util.Map;

public final class d
{
    public static final d a;
    private static final Map b;
    
    static {
        a = new d();
        final HashMap b2 = new HashMap();
        (b = (Map)b2).put((Object)Boolean.class, (Object)new h() {
            @Override
            public void a(final Bundle bundle, final String s, final Object o) {
                Intrinsics.checkNotNullParameter((Object)bundle, "bundle");
                Intrinsics.checkNotNullParameter((Object)s, "key");
                Intrinsics.checkNotNullParameter(o, "value");
                bundle.putBoolean(s, (boolean)o);
            }
        });
        ((Map)b2).put((Object)Integer.class, (Object)new h() {
            @Override
            public void a(final Bundle bundle, final String s, final Object o) {
                Intrinsics.checkNotNullParameter((Object)bundle, "bundle");
                Intrinsics.checkNotNullParameter((Object)s, "key");
                Intrinsics.checkNotNullParameter(o, "value");
                ((BaseBundle)bundle).putInt(s, (int)o);
            }
        });
        ((Map)b2).put((Object)Long.class, (Object)new h() {
            @Override
            public void a(final Bundle bundle, final String s, final Object o) {
                Intrinsics.checkNotNullParameter((Object)bundle, "bundle");
                Intrinsics.checkNotNullParameter((Object)s, "key");
                Intrinsics.checkNotNullParameter(o, "value");
                ((BaseBundle)bundle).putLong(s, (long)o);
            }
        });
        ((Map)b2).put((Object)Double.class, (Object)new h() {
            @Override
            public void a(final Bundle bundle, final String s, final Object o) {
                Intrinsics.checkNotNullParameter((Object)bundle, "bundle");
                Intrinsics.checkNotNullParameter((Object)s, "key");
                Intrinsics.checkNotNullParameter(o, "value");
                ((BaseBundle)bundle).putDouble(s, (double)o);
            }
        });
        ((Map)b2).put((Object)String.class, (Object)new h() {
            @Override
            public void a(final Bundle bundle, final String s, final Object o) {
                Intrinsics.checkNotNullParameter((Object)bundle, "bundle");
                Intrinsics.checkNotNullParameter((Object)s, "key");
                Intrinsics.checkNotNullParameter(o, "value");
                ((BaseBundle)bundle).putString(s, (String)o);
            }
        });
        ((Map)b2).put((Object)String[].class, (Object)new h() {
            @Override
            public void a(final Bundle bundle, final String s, final Object o) {
                Intrinsics.checkNotNullParameter((Object)bundle, "bundle");
                Intrinsics.checkNotNullParameter((Object)s, "key");
                Intrinsics.checkNotNullParameter(o, "value");
                throw new IllegalArgumentException("Unexpected type from JSON");
            }
        });
        ((Map)b2).put((Object)JSONArray.class, (Object)new h() {
            @Override
            public void a(final Bundle bundle, final String s, final Object o) {
                Intrinsics.checkNotNullParameter((Object)bundle, "bundle");
                Intrinsics.checkNotNullParameter((Object)s, "key");
                Intrinsics.checkNotNullParameter(o, "value");
                final JSONArray jsonArray = (JSONArray)o;
                final ArrayList list = new ArrayList();
                if (jsonArray.length() == 0) {
                    bundle.putStringArrayList(s, list);
                    return;
                }
                for (int length = jsonArray.length(), i = 0; i < length; ++i) {
                    final Object value = jsonArray.get(i);
                    if (!(value instanceof String)) {
                        final Class<?> class1 = value.getClass();
                        final StringBuilder sb = new StringBuilder();
                        sb.append("Unexpected type in an array: ");
                        sb.append((Object)class1);
                        throw new IllegalArgumentException(sb.toString());
                    }
                    list.add(value);
                }
                bundle.putStringArrayList(s, list);
            }
        });
    }
    
    private d() {
    }
    
    public static final Bundle a(final JSONObject jsonObject) {
        Intrinsics.checkNotNullParameter((Object)jsonObject, "jsonObject");
        final Bundle bundle = new Bundle();
        final Iterator keys = jsonObject.keys();
        while (keys.hasNext()) {
            final String s = (String)keys.next();
            final Object value = jsonObject.get(s);
            if (value == JSONObject.NULL) {
                continue;
            }
            if (value instanceof JSONObject) {
                bundle.putBundle(s, a((JSONObject)value));
            }
            else {
                final h h = (h)d.b.get((Object)((JSONObject)value).getClass());
                if (h == null) {
                    final Class<? extends JSONObject> class1 = ((JSONObject)value).getClass();
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Unsupported type: ");
                    sb.append((Object)class1);
                    throw new IllegalArgumentException(sb.toString());
                }
                Intrinsics.c((Object)s);
                Intrinsics.c(value);
                h.a(bundle, s, value);
            }
        }
        return bundle;
    }
    
    public interface h
    {
        void a(final Bundle p0, final String p1, final Object p2);
    }
}
