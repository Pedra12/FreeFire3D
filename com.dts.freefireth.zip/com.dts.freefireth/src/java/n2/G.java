package n2;

import java.util.Set;
import android.content.pm.ServiceInfo;
import java.util.Iterator;
import java.util.HashSet;
import java.util.List;
import android.content.pm.ResolveInfo;
import kotlin.collections.j;
import kotlin.jvm.internal.Intrinsics;
import android.content.Intent;
import com.facebook.e;

public final class g
{
    public static final g a;
    private static final String[] b;
    
    static {
        a = new g();
        b = new String[] { "com.android.chrome", "com.chrome.beta", "com.chrome.dev" };
    }
    
    private g() {
    }
    
    public static final String a() {
        final List queryIntentServices = e.l().getPackageManager().queryIntentServices(new Intent("android.support.customtabs.action.CustomTabsService"), 0);
        Intrinsics.checkNotNullExpressionValue((Object)queryIntentServices, "queryIntentServices(...)");
        final HashSet r = j.R((Object[])g.b);
        final Iterator iterator = queryIntentServices.iterator();
        while (iterator.hasNext()) {
            final ServiceInfo serviceInfo = ((ResolveInfo)iterator.next()).serviceInfo;
            if (serviceInfo != null && ((Set)r).contains((Object)serviceInfo.packageName)) {
                return serviceInfo.packageName;
            }
        }
        return null;
    }
    
    public static final String b() {
        final String packageName = e.l().getPackageName();
        final StringBuilder sb = new StringBuilder();
        sb.append("fbconnect://cct.");
        sb.append(packageName);
        return sb.toString();
    }
    
    public static final String c(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "developerDefinedRedirectURI");
        if (X.e(e.l(), s)) {
            return s;
        }
        if (X.e(e.l(), b())) {
            return b();
        }
        return "";
    }
}
