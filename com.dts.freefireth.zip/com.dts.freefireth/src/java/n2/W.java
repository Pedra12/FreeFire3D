package n2;

import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.text.StringsKt;
import org.json.JSONObject;
import android.net.Uri;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.json.JSONArray;
import java.util.Map;
import java.util.EnumSet;

public final class w
{
    public static final a v;
    private final boolean a;
    private final String b;
    private final boolean c;
    private final int d;
    private final EnumSet e;
    private final Map f;
    private final boolean g;
    private final o h;
    private final String i;
    private final String j;
    private final boolean k;
    private final boolean l;
    private final JSONArray m;
    private final String n;
    private final boolean o;
    private final boolean p;
    private final String q;
    private final String r;
    private final String s;
    private final JSONArray t;
    private final JSONArray u;
    
    static {
        v = new a(null);
    }
    
    public w(final boolean a, final String b, final boolean c, final int d, final EnumSet e, final Map f, final boolean g, final o h, final String i, final String j, final boolean k, final boolean l, final JSONArray m, final String n, final boolean o, final boolean p21, final String q, final String r, final String s, final JSONArray t, final JSONArray u) {
        Intrinsics.checkNotNullParameter((Object)b, "nuxContent");
        Intrinsics.checkNotNullParameter((Object)e, "smartLoginOptions");
        Intrinsics.checkNotNullParameter((Object)f, "dialogConfigurations");
        Intrinsics.checkNotNullParameter((Object)h, "errorClassification");
        Intrinsics.checkNotNullParameter((Object)i, "smartLoginBookmarkIconURL");
        Intrinsics.checkNotNullParameter((Object)j, "smartLoginMenuIconURL");
        Intrinsics.checkNotNullParameter((Object)n, "sdkUpdateMessage");
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
        this.j = j;
        this.k = k;
        this.l = l;
        this.m = m;
        this.n = n;
        this.o = o;
        this.p = p21;
        this.q = q;
        this.r = r;
        this.s = s;
        this.t = t;
        this.u = u;
    }
    
    public final boolean a() {
        return this.g;
    }
    
    public final boolean b() {
        return this.l;
    }
    
    public final Map c() {
        return this.f;
    }
    
    public final o d() {
        return this.h;
    }
    
    public final JSONArray e() {
        return this.m;
    }
    
    public final boolean f() {
        return this.k;
    }
    
    public final JSONArray g() {
        return this.u;
    }
    
    public final JSONArray h() {
        return this.t;
    }
    
    public final String i() {
        return this.q;
    }
    
    public final String j() {
        return this.s;
    }
    
    public final String k() {
        return this.n;
    }
    
    public final int l() {
        return this.d;
    }
    
    public final EnumSet m() {
        return this.e;
    }
    
    public final String n() {
        return this.r;
    }
    
    public final boolean o() {
        return this.a;
    }
    
    public static final class a
    {
        private a() {
        }
        
        public final b a(final String s, final String s2, final String s3) {
            Intrinsics.checkNotNullParameter((Object)s, "applicationId");
            Intrinsics.checkNotNullParameter((Object)s2, "actionName");
            Intrinsics.checkNotNullParameter((Object)s3, "featureName");
            if (((CharSequence)s2).length() != 0) {
                if (((CharSequence)s3).length() != 0) {
                    final w f = A.f(s);
                    Map map = null;
                    Label_0075: {
                        if (f != null) {
                            final Map c = f.c();
                            if (c != null) {
                                map = (Map)c.get((Object)s2);
                                break Label_0075;
                            }
                        }
                        map = null;
                    }
                    if (map != null) {
                        return (b)map.get((Object)s3);
                    }
                    return null;
                }
            }
            return null;
        }
    }
    
    public static final class b
    {
        public static final a e;
        private final String a;
        private final String b;
        private final Uri c;
        private final int[] d;
        
        static {
            e = new a(null);
        }
        
        private b(final String a, final String b, final Uri c, final int[] d) {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
        }
        
        public final String a() {
            return this.a;
        }
        
        public final String b() {
            return this.b;
        }
        
        public final int[] c() {
            return this.d;
        }
        
        public static final class a
        {
            private a() {
            }
            
            private final int[] b(final JSONArray jsonArray) {
                if (jsonArray != null) {
                    final int length = jsonArray.length();
                    final int[] array = new int[length];
                    for (int i = 0; i < length; ++i) {
                        final int n = -1;
                        final int optInt = jsonArray.optInt(i, -1);
                        int int1;
                        if ((int1 = optInt) == -1) {
                            final String optString = jsonArray.optString(i);
                            int1 = optInt;
                            if (!W.d0(optString)) {
                                try {
                                    Intrinsics.c((Object)optString);
                                    int1 = Integer.parseInt(optString);
                                }
                                catch (final NumberFormatException ex) {
                                    W.j0("FacebookSDK", (Exception)ex);
                                    int1 = n;
                                }
                            }
                        }
                        array[i] = int1;
                    }
                    return array;
                }
                return null;
            }
            
            public final b a(final JSONObject jsonObject) {
                Intrinsics.checkNotNullParameter((Object)jsonObject, "dialogConfigJSON");
                final String optString = jsonObject.optString("name");
                final boolean d0 = W.d0(optString);
                Uri parse = null;
                if (d0) {
                    return null;
                }
                Intrinsics.c((Object)optString);
                final List split$default = StringsKt.split$default((CharSequence)optString, new String[] { "|" }, false, 0, 6, (Object)null);
                if (split$default.size() != 2) {
                    return null;
                }
                final String s = (String)CollectionsKt.O(split$default);
                final String s2 = (String)CollectionsKt.X(split$default);
                if (!W.d0(s) && !W.d0(s2)) {
                    final String optString2 = jsonObject.optString("url");
                    if (!W.d0(optString2)) {
                        parse = Uri.parse(optString2);
                    }
                    return new b(s, s2, parse, this.b(jsonObject.optJSONArray("versions")), null);
                }
                return null;
            }
        }
    }
}
