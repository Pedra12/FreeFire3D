package n2;

import java.util.Collection;
import android.os.BaseBundle;
import java.util.Iterator;
import java.util.List;
import java.util.Map$Entry;
import java.util.ArrayList;
import o2.a;
import java.util.HashMap;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import android.content.SharedPreferences;
import java.util.concurrent.Executor;
import org.json.JSONException;
import com.facebook.GraphRequest$c;
import com.facebook.GraphRequest$b;
import com.facebook.AccessToken;
import kotlin.jvm.internal.Intrinsics;
import java.util.Arrays;
import G7.G;
import com.facebook.GraphRequest;
import com.facebook.e;
import android.os.Bundle;
import org.json.JSONObject;
import android.content.Context;
import j$.util.concurrent.ConcurrentHashMap;
import G7.D;
import o2.b;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;

public final class v
{
    public static final v a;
    private static final String b;
    private static final AtomicBoolean c;
    private static final ConcurrentLinkedQueue d;
    private static final Map e;
    private static Long f;
    private static b g;
    
    static {
        a = new v();
        b = D.b((Class)v.class).b();
        c = new AtomicBoolean(false);
        d = new ConcurrentLinkedQueue();
        e = (Map)new ConcurrentHashMap();
    }
    
    private v() {
    }
    
    private final JSONObject c(final String s) {
        final Bundle bundle = new Bundle();
        ((BaseBundle)bundle).putString("platform", "android");
        ((BaseBundle)bundle).putString("sdk_version", com.facebook.e.B());
        ((BaseBundle)bundle).putString("fields", "gatekeepers");
        final GraphRequest$c n = GraphRequest.n;
        final G a = G.a;
        final String format = String.format("app/%s", Arrays.copyOf(new Object[] { "mobile_sdk_gk" }, 1));
        Intrinsics.checkNotNullExpressionValue((Object)format, "format(format, *args)");
        final GraphRequest x = n.x((AccessToken)null, format, (GraphRequest$b)null);
        x.H(bundle);
        JSONObject d;
        if ((d = x.k().d()) == null) {
            d = new JSONObject();
        }
        return d;
    }
    
    public static final boolean d(final String s, final String s2, final boolean b) {
        Intrinsics.checkNotNullParameter((Object)s, "name");
        final Map e = v.a.e(s2);
        if (e.containsKey((Object)s)) {
            final Boolean b2 = (Boolean)e.get((Object)s);
            if (b2 != null) {
                return b2;
            }
        }
        return b;
    }
    
    private final boolean f(final Long n) {
        return n != null && System.currentTimeMillis() - n < 3600000L;
    }
    
    public static final void h(a a) {
        final Class<v> clazz;
        monitorenter(clazz = v.class);
        Label_0025: {
            if (a == null) {
                break Label_0025;
            }
            try {
                v.d.add((Object)a);
                break Label_0025;
            }
            finally {
                monitorexit(clazz);
                while (true) {
                    String string = null;
                    Block_7: {
                        Block_6: {
                            while (true) {
                                final String m;
                                j(m, (JSONObject)a);
                                final Executor t;
                                Label_0171: {
                                    t = com.facebook.e.t();
                                }
                                iftrue(Label_0183:)(t != null);
                                monitorexit(clazz);
                                return;
                                final Context l;
                                Label_0107:
                                final SharedPreferences sharedPreferences = l.getSharedPreferences("com.facebook.internal.preferences.APP_GATEKEEPERS", 0);
                                a = null;
                                final String format;
                                string = sharedPreferences.getString(format, (String)null);
                                iftrue(Label_0171:)(W.d0(string));
                                break Block_7;
                                Label_0063:
                                l = com.facebook.e.l();
                                final G a2 = G.a;
                                format = String.format("com.facebook.internal.APP_GATEKEEPERS.%s", Arrays.copyOf(new Object[] { m }, 1));
                                Intrinsics.checkNotNullExpressionValue((Object)format, "format(format, *args)");
                                iftrue(Label_0107:)(l != null);
                                break Block_6;
                                iftrue(Label_0171:)(a == null);
                                continue;
                            }
                            Label_0183: {
                                iftrue(Label_0200:)(v.c.compareAndSet(false, true));
                            }
                            monitorexit(clazz);
                            return;
                        }
                        monitorexit(clazz);
                        return;
                        Label_0200: {
                            final String m;
                            final Executor t;
                            final Context l;
                            final String format;
                            t.execute((Runnable)new t(m, l, format));
                        }
                        monitorexit(clazz);
                        return;
                        final String m = com.facebook.e.m();
                        final v a3 = v.a;
                        iftrue(Label_0063:)(!a3.f(v.f) || !v.e.containsKey((Object)m));
                        a3.k();
                        monitorexit(clazz);
                        return;
                    }
                    try {
                        a = (a)new JSONObject(string);
                    }
                    catch (final JSONException ex) {
                        W.j0("FacebookSDK", (Exception)ex);
                    }
                    continue;
                }
            }
        }
    }
    
    private static final void i(final String s, final Context context, final String s2) {
        Intrinsics.checkNotNullParameter((Object)s, "$applicationId");
        Intrinsics.checkNotNullParameter((Object)context, "$context");
        Intrinsics.checkNotNullParameter((Object)s2, "$gateKeepersKey");
        final v a = v.a;
        final JSONObject c = a.c(s);
        if (c.length() != 0) {
            j(s, c);
            context.getSharedPreferences("com.facebook.internal.preferences.APP_GATEKEEPERS", 0).edit().putString(s2, c.toString()).apply();
            v.f = System.currentTimeMillis();
        }
        a.k();
        v.c.set(false);
    }
    
    public static final JSONObject j(final String s, JSONObject o) {
        final Class<v> clazz;
        monitorenter(clazz = v.class);
        Label_0053: {
            try {
                Intrinsics.checkNotNullParameter((Object)s, "applicationId");
                JSONObject jsonObject;
                if ((jsonObject = (JSONObject)v.e.get((Object)s)) == null) {
                    jsonObject = new JSONObject();
                }
                break Label_0053;
            }
            finally {
                monitorexit(clazz);
                while (true) {
                    final JSONObject jsonObject;
                    int n = 0;
                Block_9:
                    while (true) {
                    Label_0129:
                        while (true) {
                        Label_0124_Outer:
                            while (true) {
                            Label_0082:
                                while (true) {
                                    Block_8: {
                                        while (true) {
                                            final Object o2;
                                            iftrue(Label_0124:)((o = ((JSONObject)o2).optJSONArray("gatekeepers")) != null);
                                            break Block_8;
                                            n = 0;
                                            iftrue(Label_0080:)(o == null);
                                            break Label_0129;
                                            o2 = new JSONObject();
                                            continue Label_0124_Outer;
                                        }
                                        final int length = ((JSONArray)o).length();
                                        break Label_0129;
                                        final JSONArray optJSONArray;
                                        o = optJSONArray.optJSONObject(0);
                                        break Label_0082;
                                        iftrue(Label_0181:)(n >= length);
                                        break Block_9;
                                        Label_0181: {
                                            v.e.put((Object)s, (Object)jsonObject);
                                        }
                                        monitorexit(clazz);
                                        return jsonObject;
                                        Label_0080:
                                        o = null;
                                        break Label_0082;
                                    }
                                    o = new JSONArray();
                                    continue;
                                }
                                Object o2 = o;
                                iftrue(Label_0099:)(o != null);
                                continue Label_0124_Outer;
                            }
                            ++n;
                            continue Label_0129;
                        }
                        final JSONArray optJSONArray = ((JSONObject)o).optJSONArray("data");
                        iftrue(Label_0080:)(optJSONArray == null);
                        continue;
                    }
                    try {
                        final JSONObject jsonObject2 = ((JSONArray)o).getJSONObject(n);
                        jsonObject.put(jsonObject2.getString("key"), jsonObject2.getBoolean("value"));
                    }
                    catch (final JSONException ex) {
                        W.j0("FacebookSDK", (Exception)ex);
                    }
                    continue;
                }
            }
        }
    }
    
    private final void k() {
        final Handler handler = new Handler(Looper.getMainLooper());
        while (true) {
            final ConcurrentLinkedQueue d = v.d;
            if (d.isEmpty()) {
                break;
            }
            final a a = (a)d.poll();
            if (a == null) {
                continue;
            }
            handler.post((Runnable)new u(a));
        }
    }
    
    private static final void l(final a a) {
        a.a();
    }
    
    public static final JSONObject m(final String s, final boolean b) {
        Intrinsics.checkNotNullParameter((Object)s, "applicationId");
        if (!b) {
            final Map e = v.e;
            if (e.containsKey((Object)s)) {
                JSONObject jsonObject;
                if ((jsonObject = (JSONObject)e.get((Object)s)) == null) {
                    jsonObject = new JSONObject();
                }
                return jsonObject;
            }
        }
        final JSONObject c = v.a.c(s);
        final Context l = com.facebook.e.l();
        final G a = G.a;
        final String format = String.format("com.facebook.internal.APP_GATEKEEPERS.%s", Arrays.copyOf(new Object[] { s }, 1));
        Intrinsics.checkNotNullExpressionValue((Object)format, "format(format, *args)");
        l.getSharedPreferences("com.facebook.internal.preferences.APP_GATEKEEPERS", 0).edit().putString(format, c.toString()).apply();
        return j(s, c);
    }
    
    public final Map e(final String s) {
        this.g();
        if (s != null) {
            final Map e = v.e;
            if (e.containsKey((Object)s)) {
                final b g = v.g;
                Object a;
                if (g != null) {
                    a = g.a(s);
                }
                else {
                    a = null;
                }
                if (a != null) {
                    final HashMap hashMap = new HashMap();
                    for (final o2.a a2 : a) {
                        ((Map)hashMap).put((Object)a2.a(), (Object)a2.b());
                    }
                    return (Map)hashMap;
                }
                final HashMap hashMap2 = new HashMap();
                JSONObject jsonObject;
                if ((jsonObject = (JSONObject)e.get((Object)s)) == null) {
                    jsonObject = new JSONObject();
                }
                final Iterator keys = jsonObject.keys();
                while (keys.hasNext()) {
                    final String s2 = (String)keys.next();
                    Intrinsics.c((Object)s2);
                    ((Map)hashMap2).put((Object)s2, (Object)jsonObject.optBoolean(s2));
                }
                b g2;
                if ((g2 = v.g) == null) {
                    g2 = new b();
                }
                final ArrayList list = new ArrayList(((Map)hashMap2).size());
                for (final Map$Entry map$Entry : ((Map)hashMap2).entrySet()) {
                    ((Collection)list).add((Object)new o2.a((String)map$Entry.getKey(), (boolean)map$Entry.getValue()));
                }
                g2.b(s, (List)list);
                v.g = g2;
                return (Map)hashMap2;
            }
        }
        return (Map)new HashMap();
    }
    
    public final void g() {
        h(null);
    }
    
    public interface a
    {
        void a();
    }
}
