package n2;

import android.os.BaseBundle;
import android.app.Activity;
import androidx.fragment.app.Fragment;
import android.os.Message;
import android.content.res.Configuration;
import java.util.Arrays;
import com.facebook.e;
import G7.G;
import android.content.Context;
import android.content.Intent;
import androidx.fragment.app.h;
import kotlin.jvm.internal.Intrinsics;
import R1.j;
import android.os.Bundle;
import kotlin.jvm.internal.DefaultConstructorMarker;
import android.app.Dialog;
import kotlin.Metadata;
import androidx.fragment.app.c;

@Metadata
public final class n extends c
{
    public static final a X1;
    private Dialog W1;
    
    static {
        X1 = new a(null);
    }
    
    private static final void b2(final n n, final Bundle bundle, final j j) {
        Intrinsics.checkNotNullParameter((Object)n, "this$0");
        n.d2(bundle, j);
    }
    
    private static final void c2(final n n, final Bundle bundle, final j j) {
        Intrinsics.checkNotNullParameter((Object)n, "this$0");
        n.e2(bundle);
    }
    
    private final void d2(final Bundle bundle, final j j) {
        final h n = ((Fragment)this).n();
        if (n == null) {
            return;
        }
        final Intent intent = ((Activity)n).getIntent();
        Intrinsics.checkNotNullExpressionValue((Object)intent, "getIntent(...)");
        final Intent n2 = K.n(intent, bundle, j);
        int n3;
        if (j == null) {
            n3 = -1;
        }
        else {
            n3 = 0;
        }
        ((Activity)n).setResult(n3, n2);
        ((Activity)n).finish();
    }
    
    private final void e2(final Bundle bundle) {
        final h n = ((Fragment)this).n();
        if (n == null) {
            return;
        }
        final Intent intent = new Intent();
        Bundle bundle2;
        if ((bundle2 = bundle) == null) {
            bundle2 = new Bundle();
        }
        intent.putExtras(bundle2);
        ((Activity)n).setResult(-1, intent);
        ((Activity)n).finish();
    }
    
    public void L0() {
        super.L0();
        final Dialog w1 = this.W1;
        if (w1 instanceof b0) {
            Intrinsics.d((Object)w1, "null cannot be cast to non-null type com.facebook.internal.WebDialog");
            ((b0)w1).x();
        }
    }
    
    public Dialog Q1(final Bundle bundle) {
        final Dialog w1 = this.W1;
        if (w1 == null) {
            this.d2(null, null);
            this.V1(false);
            final Dialog q1 = super.Q1(bundle);
            Intrinsics.checkNotNullExpressionValue((Object)q1, "onCreateDialog(...)");
            return q1;
        }
        Intrinsics.d((Object)w1, "null cannot be cast to non-null type android.app.Dialog");
        return w1;
    }
    
    public final void a2() {
        if (this.W1 == null) {
            final h n = ((Fragment)this).n();
            if (n != null) {
                final Intent intent = ((Activity)n).getIntent();
                Intrinsics.c((Object)intent);
                final Bundle y = K.y(intent);
                final boolean b = y != null && y.getBoolean("is_fallback", false);
                String string = null;
                Bundle bundle = null;
                b0 w1;
                if (!b) {
                    String string2;
                    if (y != null) {
                        string2 = ((BaseBundle)y).getString("action");
                    }
                    else {
                        string2 = null;
                    }
                    if (y != null) {
                        bundle = y.getBundle("params");
                    }
                    if (W.d0(string2)) {
                        W.k0("FacebookDialogFragment", "Cannot start a WebDialog with an empty/missing 'actionName'");
                        ((Activity)n).finish();
                        return;
                    }
                    Intrinsics.d((Object)string2, "null cannot be cast to non-null type kotlin.String");
                    w1 = new b0$a((Context)n, string2, bundle).h((b0$d)new l(this)).a();
                }
                else {
                    if (y != null) {
                        string = ((BaseBundle)y).getString("url");
                    }
                    if (W.d0(string)) {
                        W.k0("FacebookDialogFragment", "Cannot start a fallback WebDialog with an empty/missing 'url'");
                        ((Activity)n).finish();
                        return;
                    }
                    final G a = G.a;
                    final String format = String.format("fb%s://bridge/", Arrays.copyOf(new Object[] { e.m() }, 1));
                    Intrinsics.checkNotNullExpressionValue((Object)format, "format(format, *args)");
                    final r.a x = r.X;
                    Intrinsics.d((Object)string, "null cannot be cast to non-null type kotlin.String");
                    w1 = x.a((Context)n, string, format);
                    w1.B((b0.b0$d)new m(this));
                }
                this.W1 = w1;
            }
        }
    }
    
    public final void f2(final Dialog w1) {
        this.W1 = w1;
    }
    
    public void onConfigurationChanged(final Configuration configuration) {
        Intrinsics.checkNotNullParameter((Object)configuration, "newConfig");
        super.onConfigurationChanged(configuration);
        if (this.W1 instanceof b0 && ((Fragment)this).h0()) {
            final Dialog w1 = this.W1;
            Intrinsics.d((Object)w1, "null cannot be cast to non-null type com.facebook.internal.WebDialog");
            ((b0)w1).x();
        }
    }
    
    public void q0(final Bundle bundle) {
        super.q0(bundle);
        this.a2();
    }
    
    public void x0() {
        final Dialog o1 = this.O1();
        if (o1 != null && ((Fragment)this).O()) {
            o1.setDismissMessage((Message)null);
        }
        super.x0();
    }
    
    public static final class a
    {
        private a() {
        }
    }
}
