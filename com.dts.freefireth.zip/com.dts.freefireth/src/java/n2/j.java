package n2;

import android.os.BaseBundle;
import kotlin.Unit;
import androidx.activity.result.ActivityResultLauncher;
import android.content.Context;
import com.facebook.FacebookActivity;
import com.facebook.CustomTabMainActivity;
import android.os.Bundle;
import android.content.Intent;
import i.c;
import android.app.Activity;
import kotlin.jvm.internal.Intrinsics;
import android.util.Pair;
import G7.C;
import R1.e;

public final class j
{
    public static final j a;
    
    static {
        a = new j();
    }
    
    private j() {
    }
    
    public static final boolean b(final h h) {
        Intrinsics.checkNotNullParameter((Object)h, "feature");
        return c(h).d() != -1;
    }
    
    public static final K.f c(final h h) {
        Intrinsics.checkNotNullParameter((Object)h, "feature");
        final String m = com.facebook.e.m();
        final String b = h.b();
        return K.u(b, j.a.d(m, b, h));
    }
    
    private final int[] d(final String s, final String s2, final h h) {
        final w.b a = w.v.a(s, s2, h.name());
        if (a != null) {
            final int[] c = a.c();
            if (c != null) {
                return c;
            }
        }
        return new int[] { h.a() };
    }
    
    public static final void e(final a a, final Activity activity) {
        Intrinsics.checkNotNullParameter((Object)a, "appCall");
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        activity.startActivityForResult(a.e(), a.d());
        a.f();
    }
    
    public static final void f(final a a, final c c, final e e) {
        Intrinsics.checkNotNullParameter((Object)a, "appCall");
        Intrinsics.checkNotNullParameter((Object)c, "registry");
        final Intent e2 = a.e();
        if (e2 == null) {
            return;
        }
        m(c, e, e2, a.d());
        a.f();
    }
    
    public static final void g(final a a) {
        Intrinsics.checkNotNullParameter((Object)a, "appCall");
        k(a, new R1.j("Unable to show the provided content via the web or the installed version of the Facebook app. Some dialogs are only supported starting API 14."));
    }
    
    public static final void h(final a a, final String s, final Bundle bundle) {
        Intrinsics.checkNotNullParameter((Object)a, "appCall");
        X.e(com.facebook.e.l(), g.b());
        X.h(com.facebook.e.l());
        final Intent intent = new Intent(com.facebook.e.l(), (Class)CustomTabMainActivity.class);
        intent.putExtra(CustomTabMainActivity.d, s);
        intent.putExtra(CustomTabMainActivity.e, bundle);
        intent.putExtra(CustomTabMainActivity.f, g.a());
        K.D(intent, a.c().toString(), s, K.x(), null);
        a.g(intent);
    }
    
    public static final void i(final a a, final R1.j j) {
        Intrinsics.checkNotNullParameter((Object)a, "appCall");
        if (j == null) {
            return;
        }
        X.f(com.facebook.e.l());
        final Intent intent = new Intent();
        intent.setClass(com.facebook.e.l(), (Class)FacebookActivity.class);
        intent.setAction("PassThrough");
        K.D(intent, a.c().toString(), null, K.x(), K.i(j));
        a.g(intent);
    }
    
    public static final void j(final a a, final j.j$a j$a, final h h) {
        Intrinsics.checkNotNullParameter((Object)a, "appCall");
        Intrinsics.checkNotNullParameter((Object)j$a, "parameterProvider");
        Intrinsics.checkNotNullParameter((Object)h, "feature");
        final Context l = com.facebook.e.l();
        final String b = h.b();
        final K.f c = c(h);
        final int d = c.d();
        if (d == -1) {
            throw new R1.j("Cannot present this dialog. This likely means that the Facebook app is not installed.");
        }
        Bundle bundle;
        if (K.C(d)) {
            bundle = j$a.a();
        }
        else {
            bundle = j$a.b();
        }
        Bundle bundle2 = bundle;
        if (bundle == null) {
            bundle2 = new Bundle();
        }
        final Intent i = K.l(l, a.c().toString(), b, c, bundle2);
        if (i != null) {
            a.g(i);
            return;
        }
        throw new R1.j("Unable to create Intent; this likely means theFacebook app is not installed.");
    }
    
    public static final void k(final a a, final R1.j j) {
        Intrinsics.checkNotNullParameter((Object)a, "appCall");
        i(a, j);
    }
    
    public static final void l(final a a, final String s, final Bundle bundle) {
        Intrinsics.checkNotNullParameter((Object)a, "appCall");
        X.f(com.facebook.e.l());
        X.h(com.facebook.e.l());
        final Bundle bundle2 = new Bundle();
        ((BaseBundle)bundle2).putString("action", s);
        bundle2.putBundle("params", bundle);
        final Intent intent = new Intent();
        K.D(intent, a.c().toString(), s, K.x(), bundle2);
        intent.setClass(com.facebook.e.l(), (Class)FacebookActivity.class);
        intent.setAction("FacebookDialogFragment");
        a.g(intent);
    }
    
    public static final void m(final c c, final e e, final Intent intent, final int n) {
        Intrinsics.checkNotNullParameter((Object)c, "registry");
        Intrinsics.checkNotNullParameter((Object)intent, "intent");
        final C c2 = new C();
        final StringBuilder sb = new StringBuilder();
        sb.append("facebook-dialog-request-");
        sb.append(n);
        final ActivityResultLauncher m = c.m(sb.toString(), (j.a)new j.a() {
            public Intent d(final Context context, final Intent intent) {
                Intrinsics.checkNotNullParameter((Object)context, "context");
                Intrinsics.checkNotNullParameter((Object)intent, "input");
                return intent;
            }
            
            public Pair e(final int n, final Intent intent) {
                final Pair create = Pair.create((Object)n, (Object)intent);
                Intrinsics.checkNotNullExpressionValue((Object)create, "create(...)");
                return create;
            }
        }, (i.a)new i(e, n, c2));
        c2.a = m;
        if (m != null) {
            m.a((Object)intent);
        }
    }
    
    private static final void n(final e e, final int n, final C c, final Pair pair) {
        Intrinsics.checkNotNullParameter((Object)c, "$launcher");
        Object o = e;
        if (e == null) {
            o = new n2.e();
        }
        final Object first = pair.first;
        Intrinsics.checkNotNullExpressionValue(first, "first");
        ((e)o).a(n, ((Number)first).intValue(), (Intent)pair.second);
        final ActivityResultLauncher activityResultLauncher = (ActivityResultLauncher)c.a;
        if (activityResultLauncher != null) {
            synchronized (activityResultLauncher) {
                activityResultLauncher.c();
                c.a = null;
                final Unit a = Unit.a;
            }
        }
    }
}
