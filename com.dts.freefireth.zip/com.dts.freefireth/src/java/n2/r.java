package n2;

import android.os.BaseBundle;
import android.view.View;
import org.json.JSONException;
import org.json.JSONObject;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;
import android.os.Handler;
import android.os.Looper;
import kotlin.jvm.internal.Intrinsics;
import android.content.Context;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class r extends b0
{
    public static final a X;
    private static final String Y;
    private boolean y;
    
    static {
        X = new a(null);
        Y = r.class.getName();
    }
    
    private r(final Context context, final String s, final String s2) {
        super(context, s);
        this.A(s2);
    }
    
    private static final void F(final r r) {
        Intrinsics.checkNotNullParameter((Object)r, "this$0");
        r.cancel();
    }
    
    @Override
    public void cancel() {
        final WebView r = this.r();
        if (!this.u() || this.t() || r == null || !((View)r).isShown()) {
            super.cancel();
            return;
        }
        if (this.y) {
            return;
        }
        this.y = true;
        final StringBuilder sb = new StringBuilder();
        sb.append("javascript:");
        sb.append("(function() {  var event = document.createEvent('Event');  event.initEvent('fbPlatformDialogMustClose',true,true);  document.dispatchEvent(event);})();");
        r.loadUrl(sb.toString());
        new Handler(Looper.getMainLooper()).postDelayed((Runnable)new q(this), 1500L);
    }
    
    @Override
    public Bundle w(String p0) {
        p0 = (String)W.p0(Uri.parse(p0).getQuery());
        final String string = ((BaseBundle)p0).getString("bridge_args");
        ((Bundle)p0).remove("bridge_args");
        if (!W.d0(string)) {
            try {
                ((Bundle)p0).putBundle("com.facebook.platform.protocol.BRIDGE_ARGS", n2.d.a(new JSONObject(string)));
            }
            catch (final JSONException ex) {
                W.l0(r.Y, "Unable to parse bridge_args JSON", (Throwable)ex);
            }
        }
        final String string2 = ((BaseBundle)p0).getString("method_results");
        ((Bundle)p0).remove("method_results");
        if (!W.d0(string2)) {
            try {
                ((Bundle)p0).putBundle("com.facebook.platform.protocol.RESULT_ARGS", n2.d.a(new JSONObject(string2)));
            }
            catch (final JSONException ex2) {
                W.l0(r.Y, "Unable to parse bridge_args JSON", (Throwable)ex2);
            }
        }
        ((Bundle)p0).remove("version");
        ((BaseBundle)p0).putInt("com.facebook.platform.protocol.PROTOCOL_VERSION", K.x());
        return (Bundle)p0;
    }
    
    public static final class a
    {
        private a() {
        }
        
        public final r a(final Context context, final String s, final String s2) {
            Intrinsics.checkNotNullParameter((Object)context, "context");
            Intrinsics.checkNotNullParameter((Object)s, "url");
            Intrinsics.checkNotNullParameter((Object)s2, "expectedRedirectUrl");
            b0.s(context);
            return new r(context, s, s2, null);
        }
    }
}
