package n2;

import android.os.BaseBundle;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.text.StringsKt;
import android.content.pm.ProviderInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.content.ContentResolver;
import android.util.Log;
import java.util.UUID;
import android.text.TextUtils;
import com.facebook.login.z;
import com.facebook.login.d;
import R1.l;
import android.net.Uri;
import java.util.Collection;
import kotlin.collections.CollectionsKt;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeSet;
import android.content.pm.ResolveInfo;
import android.content.Context;
import java.util.Iterator;
import com.facebook.e;
import kotlin.collections.j;
import kotlin.jvm.internal.Intrinsics;
import android.os.Bundle;
import android.content.Intent;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.Map;
import java.util.List;

public final class K
{
    public static final K a;
    private static final String b;
    private static final List c;
    private static final List d;
    private static final Map e;
    private static final AtomicBoolean f;
    private static final Integer[] g;
    
    static {
        final K k = a = new K();
        b = K.class.getName();
        c = k.f();
        d = k.e();
        e = k.d();
        f = new AtomicBoolean(false);
        g = new Integer[] { 20210906, 20171115, 20170417, 20170411, 20170213, 20161017, 20160327, 20150702, 20150401, 20141218, 20141107, 20141028, 20141001, 20140701, 20140324, 20140313, 20140204, 20131107, 20131024, 20130618, 20130502, 20121101 };
    }
    
    private K() {
    }
    
    public static final Bundle A(final Intent intent) {
        Intrinsics.checkNotNullParameter((Object)intent, "resultIntent");
        final int z = z(intent);
        Bundle bundle2;
        final Bundle bundle = bundle2 = intent.getExtras();
        if (C(z)) {
            if (bundle == null) {
                bundle2 = bundle;
            }
            else {
                bundle2 = bundle.getBundle("com.facebook.platform.protocol.RESULT_ARGS");
            }
        }
        return bundle2;
    }
    
    public static final boolean B(final Intent intent) {
        Intrinsics.checkNotNullParameter((Object)intent, "resultIntent");
        final Bundle q = q(intent);
        if (q != null) {
            return ((BaseBundle)q).containsKey("error");
        }
        return intent.hasExtra("com.facebook.platform.status.ERROR_TYPE");
    }
    
    public static final boolean C(final int n) {
        return j.w((Object[])K.g, (Object)n) && n >= 20140701;
    }
    
    public static final void D(final Intent intent, final String s, final String s2, final int n, final Bundle bundle) {
        Intrinsics.checkNotNullParameter((Object)intent, "intent");
        final String m = com.facebook.e.m();
        final String n2 = com.facebook.e.n();
        intent.putExtra("com.facebook.platform.protocol.PROTOCOL_VERSION", n).putExtra("com.facebook.platform.protocol.PROTOCOL_ACTION", s2).putExtra("com.facebook.platform.extra.APPLICATION_ID", m);
        if (C(n)) {
            final Bundle bundle2 = new Bundle();
            ((BaseBundle)bundle2).putString("action_id", s);
            W.s0(bundle2, "app_name", n2);
            intent.putExtra("com.facebook.platform.protocol.BRIDGE_ARGS", bundle2);
            Bundle bundle3;
            if ((bundle3 = bundle) == null) {
                bundle3 = new Bundle();
            }
            intent.putExtra("com.facebook.platform.protocol.METHOD_ARGS", bundle3);
            return;
        }
        intent.putExtra("com.facebook.platform.protocol.CALL_ID", s);
        if (!W.d0(n2)) {
            intent.putExtra("com.facebook.platform.extra.APPLICATION_NAME", n2);
        }
        if (bundle != null) {
            intent.putExtras(bundle);
        }
    }
    
    public static final void E() {
        if (!K.f.compareAndSet(false, true)) {
            return;
        }
        com.facebook.e.t().execute((Runnable)new J());
    }
    
    private static final void F() {
        Label_0046: {
            try {
                final Iterator iterator = K.c.iterator();
                while (iterator.hasNext()) {
                    ((e)iterator.next()).a(true);
                }
            }
            finally {
                break Label_0046;
            }
            K.f.set(false);
            return;
        }
        K.f.set(false);
    }
    
    public static final Intent G(final Context context, final Intent intent, final e e) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        if (intent == null) {
            return null;
        }
        final ResolveInfo resolveActivity = context.getPackageManager().resolveActivity(intent, 0);
        if (resolveActivity == null) {
            return null;
        }
        final String packageName = resolveActivity.activityInfo.packageName;
        Intrinsics.checkNotNullExpressionValue((Object)packageName, "packageName");
        if (!p.a(context, packageName)) {
            return null;
        }
        return intent;
    }
    
    public static final Intent H(final Context context, final Intent intent, final e e) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        if (intent == null) {
            return null;
        }
        final ResolveInfo resolveService = context.getPackageManager().resolveService(intent, 0);
        if (resolveService == null) {
            return null;
        }
        final String packageName = resolveService.serviceInfo.packageName;
        Intrinsics.checkNotNullExpressionValue((Object)packageName, "packageName");
        if (!p.a(context, packageName)) {
            return null;
        }
        return intent;
    }
    
    public static final /* synthetic */ String c() {
        return K.b;
    }
    
    private final Map d() {
        final HashMap hashMap = new HashMap();
        final ArrayList list = new ArrayList();
        list.add((Object)new d());
        final List c = K.c;
        ((Map)hashMap).put((Object)"com.facebook.platform.action.request.OGACTIONPUBLISH_DIALOG", (Object)c);
        ((Map)hashMap).put((Object)"com.facebook.platform.action.request.FEED_DIALOG", (Object)c);
        ((Map)hashMap).put((Object)"com.facebook.platform.action.request.LIKE_DIALOG", (Object)c);
        ((Map)hashMap).put((Object)"com.facebook.platform.action.request.APPINVITES_DIALOG", (Object)c);
        ((Map)hashMap).put((Object)"com.facebook.platform.action.request.MESSAGE_DIALOG", (Object)list);
        ((Map)hashMap).put((Object)"com.facebook.platform.action.request.OGMESSAGEPUBLISH_DIALOG", (Object)list);
        ((Map)hashMap).put((Object)"com.facebook.platform.action.request.CAMERA_EFFECT", (Object)K.d);
        ((Map)hashMap).put((Object)"com.facebook.platform.action.request.SHARE_STORY", (Object)c);
        return (Map)hashMap;
    }
    
    private final List e() {
        final ArrayList g = CollectionsKt.g((Object[])new e[] { (e)new a() });
        g.addAll((Collection)this.f());
        return (List)g;
    }
    
    private final List f() {
        return (List)CollectionsKt.g((Object[])new e[] { (e)new c(), (e)new g() });
    }
    
    private final Uri g(final e e) {
        final String d = e.d();
        final StringBuilder sb = new StringBuilder();
        sb.append("content://");
        sb.append(d);
        sb.append(".provider.PlatformProvider/versions");
        final Uri parse = Uri.parse(sb.toString());
        Intrinsics.checkNotNullExpressionValue((Object)parse, "parse(...)");
        return parse;
    }
    
    public static final int h(final TreeSet set, final int n, final int[] array) {
        Intrinsics.checkNotNullParameter((Object)array, "versionSpec");
        if (set == null) {
            return -1;
        }
        int n2 = array.length - 1;
        final Iterator descendingIterator = set.descendingIterator();
        int n3 = -1;
        while (descendingIterator.hasNext()) {
            final Integer n4 = (Integer)descendingIterator.next();
            Intrinsics.c((Object)n4);
            final int max = Math.max(n3, (int)n4);
            int n5;
            for (n5 = n2; n5 >= 0 && array[n5] > n4; --n5) {}
            if (n5 < 0) {
                return -1;
            }
            n2 = n5;
            n3 = max;
            if (array[n5] != n4) {
                continue;
            }
            if (n5 % 2 == 0) {
                return Math.min(max, n);
            }
            break;
        }
        return -1;
    }
    
    public static final Bundle i(final R1.j j) {
        if (j == null) {
            return null;
        }
        final Bundle bundle = new Bundle();
        ((BaseBundle)bundle).putString("error_description", j.toString());
        if (j instanceof l) {
            ((BaseBundle)bundle).putString("error_type", "UserCanceled");
        }
        return bundle;
    }
    
    public static final Intent j(final Context context, final String s, final Collection collection, final String s2, final boolean b, final boolean b2, final com.facebook.login.d d, final String s3, final String s4, final String s5, final boolean b3, final boolean b4, final boolean b5) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        Intrinsics.checkNotNullParameter((Object)s, "applicationId");
        Intrinsics.checkNotNullParameter((Object)collection, "permissions");
        Intrinsics.checkNotNullParameter((Object)s2, "e2e");
        Intrinsics.checkNotNullParameter((Object)d, "defaultAudience");
        Intrinsics.checkNotNullParameter((Object)s3, "clientState");
        Intrinsics.checkNotNullParameter((Object)s4, "authType");
        final b b6 = new b();
        return G(context, K.a.k((e)b6, s, collection, s2, b2, d, s3, s4, false, s5, b3, z.d, b4, b5, "", null, null), (e)b6);
    }
    
    private final Intent k(final e e, final String s, final Collection collection, final String s2, final boolean b, final com.facebook.login.d d, final String s3, final String s4, final boolean b2, final String s5, final boolean b3, final z z, final boolean b4, final boolean b5, final String s6, String c, final String s7) {
        c = e.c();
        if (c == null) {
            return null;
        }
        final Intent putExtra = new Intent().setClassName(e.d(), c).putExtra("client_id", s);
        Intrinsics.checkNotNullExpressionValue((Object)putExtra, "putExtra(...)");
        putExtra.putExtra("facebook_sdk_version", e.B());
        if (!W.e0(collection)) {
            putExtra.putExtra("scope", TextUtils.join((CharSequence)",", (Iterable)collection));
        }
        if (!W.d0(s2)) {
            putExtra.putExtra("e2e", s2);
        }
        putExtra.putExtra("state", s3);
        putExtra.putExtra("response_type", e.e());
        putExtra.putExtra("nonce", s6);
        putExtra.putExtra("return_scopes", "true");
        if (b) {
            putExtra.putExtra("default_audience", d.b());
        }
        putExtra.putExtra("legacy_override", e.w());
        putExtra.putExtra("auth_type", s4);
        if (b2) {
            putExtra.putExtra("fail_on_logged_out", true);
        }
        putExtra.putExtra("messenger_page_id", s5);
        putExtra.putExtra("reset_messenger_state", b3);
        if (b4) {
            putExtra.putExtra("fx_app", z.toString());
        }
        if (b5) {
            putExtra.putExtra("skip_dedupe", true);
        }
        return putExtra;
    }
    
    public static final Intent l(final Context context, final String s, final String s2, final f f, final Bundle bundle) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        if (f == null) {
            return null;
        }
        final e c = f.c();
        if (c == null) {
            return null;
        }
        final Intent g = G(context, new Intent().setAction("com.facebook.platform.PLATFORM_ACTIVITY").setPackage(c.d()).addCategory("android.intent.category.DEFAULT"), c);
        if (g == null) {
            return null;
        }
        D(g, s, s2, f.d(), bundle);
        return g;
    }
    
    public static final Intent m(final Context context) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        for (final e e : K.c) {
            final Intent h = H(context, new Intent("com.facebook.platform.PLATFORM_SERVICE").setPackage(e.d()).addCategory("android.intent.category.DEFAULT"), e);
            if (h != null) {
                return h;
            }
        }
        return null;
    }
    
    public static final Intent n(final Intent intent, final Bundle bundle, final R1.j j) {
        Intrinsics.checkNotNullParameter((Object)intent, "requestIntent");
        final UUID r = r(intent);
        if (r == null) {
            return null;
        }
        final Intent intent2 = new Intent();
        intent2.putExtra("com.facebook.platform.protocol.PROTOCOL_VERSION", z(intent));
        final Bundle bundle2 = new Bundle();
        ((BaseBundle)bundle2).putString("action_id", r.toString());
        if (j != null) {
            bundle2.putBundle("error", i(j));
        }
        intent2.putExtra("com.facebook.platform.protocol.BRIDGE_ARGS", bundle2);
        if (bundle != null) {
            intent2.putExtra("com.facebook.platform.protocol.RESULT_ARGS", bundle);
        }
        return intent2;
    }
    
    public static final List o(final Context context, final String s, final Collection collection, final String s2, final boolean b, final boolean b2, final com.facebook.login.d d, final String s3, final String s4, final boolean b3, final String s5, final boolean b4, final boolean b5, final boolean b6, final String s6, final String s7, final String s8) {
        Intrinsics.checkNotNullParameter((Object)s, "applicationId");
        Intrinsics.checkNotNullParameter((Object)collection, "permissions");
        Intrinsics.checkNotNullParameter((Object)s2, "e2e");
        Intrinsics.checkNotNullParameter((Object)d, "defaultAudience");
        Intrinsics.checkNotNullParameter((Object)s3, "clientState");
        Intrinsics.checkNotNullParameter((Object)s4, "authType");
        final List c = K.c;
        final ArrayList list = new ArrayList();
        final Iterator iterator = ((Iterable)c).iterator();
        while (iterator.hasNext()) {
            final Intent k = K.a.k((e)iterator.next(), s, collection, s2, b2, d, s3, s4, b3, s5, b4, z.c, b5, b6, s6, s7, s8);
            if (k != null) {
                ((Collection)list).add((Object)k);
            }
        }
        return (List)list;
    }
    
    private final TreeSet p(final e e) {
        final TreeSet set = new TreeSet();
        final ContentResolver contentResolver = e.l().getContentResolver();
        final Uri g = this.g(e);
        final Cursor cursor = null;
        Cursor cursor2 = null;
        Cursor cursor4;
        final Cursor cursor3 = cursor4 = null;
    Block_6_Outer:
        while (true) {
            PackageManager packageManager;
            String string;
            try {
                packageManager = e.l().getPackageManager();
                cursor4 = cursor3;
                final String d = e.d();
                cursor4 = cursor3;
                cursor4 = cursor3;
                final StringBuilder sb = new StringBuilder();
                cursor4 = cursor3;
                sb.append(d);
                cursor4 = cursor3;
                sb.append(".provider.PlatformProvider");
                cursor4 = cursor3;
                string = sb.toString();
                cursor4 = cursor3;
                final PackageManager packageManager2 = packageManager;
                final String s = string;
                final int n = 0;
                final ProviderInfo providerInfo = packageManager2.resolveContentProvider(s, n);
                break Label_0133;
            }
            finally {
                if (cursor4 != null) {
                    cursor4.close();
                }
            Block_9_Outer:
                while (true) {
                    while (true) {
                        Cursor query = null;
                        set.add((Object)query.getInt(query.getColumnIndex("version")));
                        Label_0227: {
                            break Label_0227;
                            while (true) {
                                cursor2 = query;
                                iftrue(Label_0269:)(query == null);
                                break Label_0227;
                                Label_0279: {
                                    return set;
                                }
                                try {
                                    query = contentResolver.query(g, new String[] { "version" }, (String)null, (String[])null, (String)null);
                                }
                                catch (final IllegalArgumentException ex) {
                                    Log.e(K.b, "Failed to query content resolver.");
                                    query = cursor;
                                }
                                catch (final SecurityException ex2) {
                                    Log.e(K.b, "Failed to query content resolver.");
                                    query = cursor;
                                }
                                catch (final NullPointerException ex3) {
                                    Log.e(K.b, "Failed to query content resolver.");
                                    query = cursor;
                                }
                                continue Block_6_Outer;
                            }
                        }
                        cursor2 = query;
                        iftrue(Label_0269:)(!query.moveToNext());
                        continue Block_6_Outer;
                    }
                    while (true) {
                        cursor2.close();
                        return set;
                        Label_0269: {
                            iftrue(Label_0279:)(cursor2 == null);
                        }
                        continue;
                    }
                    final ProviderInfo providerInfo;
                    iftrue(Label_0269:)(providerInfo == null);
                    continue Block_9_Outer;
                }
            }
            try {
                final PackageManager packageManager2 = packageManager;
                final String s = string;
                final int n = 0;
                final ProviderInfo providerInfo = packageManager2.resolveContentProvider(s, n);
                continue;
            }
            catch (final RuntimeException ex4) {}
            break;
        }
    }
    
    public static final Bundle q(final Intent intent) {
        Intrinsics.checkNotNullParameter((Object)intent, "intent");
        if (!C(z(intent))) {
            return null;
        }
        return intent.getBundleExtra("com.facebook.platform.protocol.BRIDGE_ARGS");
    }
    
    public static final UUID r(final Intent intent) {
        if (intent == null) {
            return null;
        }
        String s;
        if (C(z(intent))) {
            final Bundle bundleExtra = intent.getBundleExtra("com.facebook.platform.protocol.BRIDGE_ARGS");
            if (bundleExtra != null) {
                s = ((BaseBundle)bundleExtra).getString("action_id");
            }
            else {
                s = null;
            }
        }
        else {
            s = intent.getStringExtra("com.facebook.platform.protocol.CALL_ID");
        }
        Label_0060: {
            if (s == null) {
                break Label_0060;
            }
            try {
                return UUID.fromString(s);
                return null;
            }
            catch (final IllegalArgumentException ex) {
                return null;
            }
        }
    }
    
    public static final Bundle s(final Intent intent) {
        Intrinsics.checkNotNullParameter((Object)intent, "resultIntent");
        if (!B(intent)) {
            return null;
        }
        final Bundle q = q(intent);
        if (q != null) {
            return q.getBundle("error");
        }
        return intent.getExtras();
    }
    
    public static final R1.j t(final Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        String s;
        if ((s = ((BaseBundle)bundle).getString("error_type")) == null) {
            s = ((BaseBundle)bundle).getString("com.facebook.platform.status.ERROR_TYPE");
        }
        String s2;
        if ((s2 = ((BaseBundle)bundle).getString("error_description")) == null) {
            s2 = ((BaseBundle)bundle).getString("com.facebook.platform.status.ERROR_DESCRIPTION");
        }
        if (s != null && StringsKt.y(s, "UserCanceled", true)) {
            return (R1.j)new l(s2);
        }
        return new R1.j(s2);
    }
    
    public static final f u(final String s, final int[] array) {
        Intrinsics.checkNotNullParameter((Object)s, "action");
        Intrinsics.checkNotNullParameter((Object)array, "versionSpec");
        List k;
        if ((k = (List)K.e.get((Object)s)) == null) {
            k = CollectionsKt.k();
        }
        return K.a.v(k, array);
    }
    
    private final f v(final List list, final int[] array) {
        E();
        if (list == null) {
            return K.f.c.b();
        }
        for (final e e : list) {
            final int h = h(e.b(), x(), array);
            if (h != -1) {
                return K.f.c.a(e, h);
            }
        }
        return K.f.c.b();
    }
    
    public static final int w(final int n) {
        return K.a.v(K.c, new int[] { n }).d();
    }
    
    public static final int x() {
        return K.g[0];
    }
    
    public static final Bundle y(final Intent intent) {
        Intrinsics.checkNotNullParameter((Object)intent, "intent");
        if (!C(z(intent))) {
            return intent.getExtras();
        }
        return intent.getBundleExtra("com.facebook.platform.protocol.METHOD_ARGS");
    }
    
    public static final int z(final Intent intent) {
        Intrinsics.checkNotNullParameter((Object)intent, "intent");
        return intent.getIntExtra("com.facebook.platform.protocol.PROTOCOL_VERSION", 0);
    }
    
    private static final class a extends e
    {
        public a() {
        }
        
        @Override
        public String d() {
            return "com.facebook.arstudio.player";
        }
        
        public Void g() {
            return null;
        }
    }
    
    private static final class b extends e
    {
        public b() {
        }
        
        @Override
        public String c() {
            return "com.instagram.platform.AppAuthorizeActivity";
        }
        
        @Override
        public String d() {
            return "com.instagram.android";
        }
        
        @Override
        public String e() {
            return "token,signed_request,graph_domain,granted_scopes";
        }
    }
    
    private static final class c extends e
    {
        public c() {
        }
        
        private final boolean g() {
            return e.l().getApplicationInfo().targetSdkVersion >= 30;
        }
        
        @Override
        public String c() {
            return "com.facebook.katana.ProxyAuth";
        }
        
        @Override
        public String d() {
            return "com.facebook.katana";
        }
        
        @Override
        public void f() {
            if (this.g()) {
                Log.w(K.c(), "Apps that target Android API 30+ (Android 11+) cannot call Facebook native apps unless the package visibility needs are declared. Please follow https://developers.facebook.com/docs/android/troubleshooting/#faq_267321845055988 to make the declaration.");
            }
        }
    }
    
    private static final class d extends e
    {
        public d() {
        }
        
        @Override
        public String d() {
            return "com.facebook.orca";
        }
        
        public Void g() {
            return null;
        }
    }
    
    public abstract static class e
    {
        private TreeSet a;
        
        public final void a(final boolean b) {
            monitorenter(this);
            Label_0035: {
                if (b) {
                    break Label_0035;
                }
            Label_0064_Outer:
                while (true) {
                    try {
                        final TreeSet a = this.a;
                        if (a != null && a != null && !a.isEmpty()) {
                            break Label_0046;
                        }
                        break Label_0035;
                    }
                    finally {
                        monitorexit(this);
                    Label_0068:
                        while (true) {
                            this.f();
                            break Label_0068;
                            final TreeSet a2 = this.a;
                            iftrue(Label_0068:)(a2 != null && !((Collection)a2).isEmpty());
                            continue;
                        }
                        monitorexit(this);
                        return;
                        this.a = K.a.p(this);
                        continue Label_0064_Outer;
                    }
                    break;
                }
            }
        }
        
        public final TreeSet b() {
            final TreeSet a = this.a;
            if (a == null || a == null || a.isEmpty()) {
                this.a(false);
            }
            return this.a;
        }
        
        public abstract String c();
        
        public abstract String d();
        
        public String e() {
            return "id_token,token,signed_request,graph_domain";
        }
        
        public void f() {
        }
    }
    
    public static final class f
    {
        public static final a c;
        private e a;
        private int b;
        
        static {
            c = new a(null);
        }
        
        private f() {
        }
        
        public static final /* synthetic */ void a(final f f, final e a) {
            f.a = a;
        }
        
        public static final /* synthetic */ void b(final f f, final int b) {
            f.b = b;
        }
        
        public final e c() {
            return this.a;
        }
        
        public final int d() {
            return this.b;
        }
        
        public static final class a
        {
            private a() {
            }
            
            public final f a(final e e, final int n) {
                final f f = new f(null);
                K.f.a(f, e);
                K.f.b(f, n);
                return f;
            }
            
            public final f b() {
                final f f = new f(null);
                K.f.b(f, -1);
                return f;
            }
        }
    }
    
    private static final class g extends e
    {
        public g() {
        }
        
        @Override
        public String c() {
            return "com.facebook.katana.ProxyAuth";
        }
        
        @Override
        public String d() {
            return "com.facebook.wakizashi";
        }
    }
}
