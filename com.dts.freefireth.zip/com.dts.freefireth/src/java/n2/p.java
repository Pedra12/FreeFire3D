package n2;

import android.content.pm.Signature;
import android.content.pm.PackageManager$NameNotFoundException;
import kotlin.collections.CollectionsKt;
import kotlin.text.StringsKt;
import android.os.Build;
import kotlin.jvm.internal.Intrinsics;
import android.content.Context;
import kotlin.collections.L;
import java.util.HashSet;

public final class p
{
    public static final p a;
    private static final HashSet b;
    
    static {
        a = new p();
        b = L.f((Object[])new String[] { "8a3c4b262d721acd49a4bf97d5213199c86fa2b9", "cc2751449a350f668590264ed76692694a80308a", "a4b7452e2ed8f5f191058ca7bbfd26b0d3214bfc", "df6b721c8b4d3b6eb44c861d4415007e5a35fc95", "9b8f518b086098de3d77736f9458a3d2f6f95a37", "2438bce1ddb7bd026d5ff89f598b3b5e5bb824b3", "c56fb7d591ba6704df047fd98f535372fea00211" });
    }
    
    private p() {
    }
    
    public static final boolean a(final Context context, final String s) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        Intrinsics.checkNotNullParameter((Object)s, "packageName");
        final String brand = Build.BRAND;
        final int flags = context.getApplicationInfo().flags;
        Intrinsics.c((Object)brand);
        if (StringsKt.J(brand, "generic", false, 2, (Object)null) && (flags & 0x2) != 0x0) {
            return true;
        }
        try {
            final Signature[] signatures = context.getPackageManager().getPackageInfo(s, 64).signatures;
            if (signatures == null) {
                return false;
            }
            if (signatures.length == 0) {
                return false;
            }
            for (final Signature signature : signatures) {
                final HashSet b = p.b;
                final byte[] byteArray = signature.toByteArray();
                Intrinsics.checkNotNullExpressionValue((Object)byteArray, "toByteArray(...)");
                if (!CollectionsKt.F((Iterable)b, (Object)W.H0(byteArray))) {
                    return false;
                }
            }
            return true;
        }
        catch (final PackageManager$NameNotFoundException ex) {
            return false;
        }
    }
}
