package n2;

import android.view.ViewGroup;
import android.os.BaseBundle;
import java.util.List;
import java.util.Collection;
import org.json.JSONArray;
import java.util.Iterator;
import com.facebook.GraphRequest$b;
import com.facebook.AccessToken;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.json.JSONObject;
import R1.k;
import java.util.concurrent.CountDownLatch;
import android.os.AsyncTask;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import R1.w;
import com.facebook.FacebookRequestError;
import kotlin.text.StringsKt;
import java.util.regex.Pattern;
import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import R1.h;
import android.graphics.Bitmap;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager$NameNotFoundException;
import R1.j;
import android.view.Display;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.os.AsyncTask$Status;
import android.view.KeyEvent;
import android.content.DialogInterface$OnCancelListener;
import android.view.Window;
import android.app.Activity;
import android.os.IBinder;
import R1.l;
import android.graphics.drawable.Drawable;
import h2.b;
import android.view.View$OnClickListener;
import android.content.DialogInterface;
import android.view.MotionEvent;
import android.webkit.WebSettings;
import android.view.View;
import android.view.View$OnTouchListener;
import android.view.ViewGroup$LayoutParams;
import android.widget.FrameLayout$LayoutParams;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.net.Uri;
import java.util.Arrays;
import java.util.Locale;
import G7.G;
import com.facebook.e;
import com.facebook.login.z;
import android.os.Bundle;
import kotlin.jvm.internal.Intrinsics;
import android.content.Context;
import h2.f;
import kotlin.jvm.internal.DefaultConstructorMarker;
import android.view.WindowManager$LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.app.ProgressDialog;
import android.webkit.WebView;
import android.app.Dialog;

public class b0 extends Dialog
{
    public static final b v;
    private static final int w;
    private static volatile int x;
    private String a;
    private String b;
    private b0$d c;
    private WebView d;
    private ProgressDialog e;
    private ImageView f;
    private FrameLayout g;
    private e h;
    private boolean i;
    private boolean j;
    private boolean k;
    private WindowManager$LayoutParams l;
    
    static {
        v = new b(null);
        w = h2.f.a;
    }
    
    protected b0(final Context context, final String s) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        Intrinsics.checkNotNullParameter((Object)s, "url");
        this(context, s, b0.v.a());
    }
    
    private b0(final Context context, final String a, final int n) {
        int a2 = n;
        if (n == 0) {
            a2 = b0.v.a();
        }
        super(context, a2);
        this.b = "fbconnect://success";
        this.a = a;
    }
    
    private b0(final Context context, final String s, final Bundle bundle, final int n, final z z, final b0$d c) {
        int a = n;
        if (n == 0) {
            a = b0.v.a();
        }
        super(context, a);
        final String s2 = "fbconnect://success";
        this.b = "fbconnect://success";
        Bundle bundle2;
        if ((bundle2 = bundle) == null) {
            bundle2 = new Bundle();
        }
        String b = s2;
        if (W.X(context)) {
            b = "fbconnect://chrome_os_success";
        }
        ((BaseBundle)bundle2).putString("redirect_uri", this.b = b);
        ((BaseBundle)bundle2).putString("display", "touch");
        ((BaseBundle)bundle2).putString("client_id", com.facebook.e.m());
        final G a2 = G.a;
        final String format = String.format(Locale.ROOT, "android-%s", Arrays.copyOf(new Object[] { com.facebook.e.B() }, 1));
        Intrinsics.checkNotNullExpressionValue((Object)format, "format(locale, format, *args)");
        ((BaseBundle)bundle2).putString("sdk", format);
        this.c = c;
        if (Intrinsics.a((Object)s, (Object)"share") && ((BaseBundle)bundle2).containsKey("media")) {
            this.h = new e(s, bundle2);
            return;
        }
        Uri uri;
        if (b0.f.a[((Enum)z).ordinal()] == 1) {
            uri = W.g(N.k(), "oauth/authorize", bundle2);
        }
        else {
            final String b2 = N.b();
            final String w = com.facebook.e.w();
            final StringBuilder sb = new StringBuilder();
            sb.append(w);
            sb.append("/dialog/");
            sb.append(s);
            uri = W.g(b2, sb.toString(), bundle2);
        }
        this.a = uri.toString();
    }
    
    private final void C(final int n) {
        try {
            final LinearLayout linearLayout = new LinearLayout(this.getContext());
            ((View)(this.d = new WebView(this.getContext()) {
                public void onWindowFocusChanged(final boolean b) {
                    try {
                        super.onWindowFocusChanged(b);
                    }
                    catch (final NullPointerException ex) {}
                }
            })).setVerticalScrollBarEnabled(false);
            final WebView d = this.d;
            if (d != null) {
                ((View)d).setHorizontalScrollBarEnabled(false);
            }
            final WebView d2 = this.d;
            if (d2 != null) {
                d2.setWebViewClient((WebViewClient)new c());
            }
            final WebView d3 = this.d;
            final WebSettings webSettings = null;
            WebSettings settings;
            if (d3 != null) {
                settings = d3.getSettings();
            }
            else {
                settings = null;
            }
            if (settings != null) {
                settings.setJavaScriptEnabled(true);
            }
            final WebView d4 = this.d;
            if (d4 != null) {
                final String a = this.a;
                if (a == null) {
                    throw new IllegalStateException("Required value was null.");
                }
                d4.loadUrl(a);
            }
            final WebView d5 = this.d;
            if (d5 != null) {
                d5.setLayoutParams((ViewGroup$LayoutParams)new FrameLayout$LayoutParams(-1, -1));
            }
            final WebView d6 = this.d;
            if (d6 != null) {
                ((View)d6).setVisibility(4);
            }
            final WebView d7 = this.d;
            WebSettings settings2;
            if (d7 != null) {
                settings2 = d7.getSettings();
            }
            else {
                settings2 = null;
            }
            if (settings2 != null) {
                settings2.setSavePassword(false);
            }
            final WebView d8 = this.d;
            WebSettings settings3 = webSettings;
            if (d8 != null) {
                settings3 = d8.getSettings();
            }
            if (settings3 != null) {
                settings3.setSaveFormData(false);
            }
            final WebView d9 = this.d;
            if (d9 != null) {
                ((View)d9).setFocusable(true);
            }
            final WebView d10 = this.d;
            if (d10 != null) {
                ((View)d10).setFocusableInTouchMode(true);
            }
            final WebView d11 = this.d;
            if (d11 != null) {
                ((View)d11).setOnTouchListener((View$OnTouchListener)new Z());
            }
            ((View)linearLayout).setPadding(n, n, n, n);
            ((ViewGroup)linearLayout).addView((View)this.d);
            ((View)linearLayout).setBackgroundColor(-872415232);
            final FrameLayout g = this.g;
            if (g != null) {
                ((ViewGroup)g).addView((View)linearLayout);
            }
        }
        finally {}
    }
    
    private static final boolean D(final View view, final MotionEvent motionEvent) {
        if (!view.hasFocus()) {
            view.requestFocus();
        }
        return false;
    }
    
    public static final /* synthetic */ FrameLayout d(final b0 b0) {
        return b0.g;
    }
    
    public static final /* synthetic */ ImageView e(final b0 b0) {
        return b0.f;
    }
    
    public static final /* synthetic */ int f() {
        return b0.w;
    }
    
    public static final /* synthetic */ String g(final b0 b0) {
        return b0.b;
    }
    
    public static final /* synthetic */ ProgressDialog h(final b0 b0) {
        return b0.e;
    }
    
    public static final /* synthetic */ int i() {
        return b0.x;
    }
    
    public static final /* synthetic */ boolean j(final b0 b0) {
        return b0.j;
    }
    
    public static final /* synthetic */ void k(final b0 b0, final boolean k) {
        b0.k = k;
    }
    
    public static final /* synthetic */ void m(final b0 b0, final String a) {
        b0.a = a;
    }
    
    public static final /* synthetic */ void n(final int x) {
        b0.x = x;
    }
    
    private final void o() {
        ((View)(this.f = new ImageView(this.getContext()))).setOnClickListener((View$OnClickListener)new a0(this));
        final Drawable drawable = this.getContext().getResources().getDrawable(h2.b.a);
        final ImageView f = this.f;
        if (f != null) {
            f.setImageDrawable(drawable);
        }
        final ImageView f2 = this.f;
        if (f2 == null) {
            return;
        }
        f2.setVisibility(4);
    }
    
    private static final void p(final b0 b0, final View view) {
        Intrinsics.checkNotNullParameter((Object)b0, "this$0");
        b0.cancel();
    }
    
    private final int q(final int n, final float n2, final int n3, final int n4) {
        final int n5 = (int)(n / n2);
        double n6;
        if (n5 <= n3) {
            n6 = 1.0;
        }
        else if (n5 >= n4) {
            n6 = 0.5;
        }
        else {
            n6 = (n4 - n5) / (double)(n4 - n3) * 0.5 + 0.5;
        }
        return (int)(n * n6);
    }
    
    protected static final void s(final Context context) {
        b0.v.b(context);
    }
    
    private static final void v(final b0 b0, final DialogInterface dialogInterface) {
        Intrinsics.checkNotNullParameter((Object)b0, "this$0");
        b0.cancel();
    }
    
    protected final void A(final String b) {
        Intrinsics.checkNotNullParameter((Object)b, "expectedRedirectUrl");
        this.b = b;
    }
    
    public final void B(final b0$d c) {
        this.c = c;
    }
    
    public void cancel() {
        if (this.c != null && !this.i) {
            this.y((Throwable)new l());
        }
    }
    
    public void dismiss() {
        final WebView d = this.d;
        if (d != null) {
            d.stopLoading();
        }
        if (!this.j) {
            final ProgressDialog e = this.e;
            if (e != null && ((Dialog)e).isShowing()) {
                ((Dialog)e).dismiss();
            }
        }
        super.dismiss();
    }
    
    public void onAttachedToWindow() {
        this.j = false;
        final Context context = this.getContext();
        Intrinsics.checkNotNullExpressionValue((Object)context, "getContext(...)");
        if (W.o0(context)) {
            final WindowManager$LayoutParams l = this.l;
            if (l != null) {
                final Object o = null;
                IBinder token;
                if (l != null) {
                    token = l.token;
                }
                else {
                    token = null;
                }
                if (token == null) {
                    if (l != null) {
                        final Activity ownerActivity = this.getOwnerActivity();
                        IBinder token2 = null;
                        Label_0097: {
                            if (ownerActivity != null) {
                                final Window window = ownerActivity.getWindow();
                                if (window != null) {
                                    final WindowManager$LayoutParams attributes = window.getAttributes();
                                    if (attributes != null) {
                                        token2 = attributes.token;
                                        break Label_0097;
                                    }
                                }
                            }
                            token2 = null;
                        }
                        l.token = token2;
                    }
                    final WindowManager$LayoutParams i = this.l;
                    Object token3 = o;
                    if (i != null) {
                        token3 = i.token;
                    }
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Set token on onAttachedToWindow(): ");
                    sb.append(token3);
                    W.k0("FacebookSDK.WebDialog", sb.toString());
                }
            }
        }
        super.onAttachedToWindow();
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        ((Dialog)(this.e = new ProgressDialog(this.getContext()))).requestWindowFeature(1);
        final ProgressDialog e = this.e;
        if (e != null) {
            e.setMessage((CharSequence)this.getContext().getString(h2.e.d));
        }
        final ProgressDialog e2 = this.e;
        if (e2 != null) {
            ((Dialog)e2).setCanceledOnTouchOutside(false);
        }
        final ProgressDialog e3 = this.e;
        if (e3 != null) {
            ((Dialog)e3).setOnCancelListener((DialogInterface$OnCancelListener)new Y(this));
        }
        this.requestWindowFeature(1);
        this.g = new FrameLayout(this.getContext());
        this.x();
        final Window window = this.getWindow();
        if (window != null) {
            window.setGravity(17);
        }
        final Window window2 = this.getWindow();
        if (window2 != null) {
            window2.setSoftInputMode(16);
        }
        this.o();
        if (this.a != null) {
            final ImageView f = this.f;
            if (f == null) {
                throw new IllegalStateException("Required value was null.");
            }
            this.C(f.getDrawable().getIntrinsicWidth() / 2 + 1);
        }
        final FrameLayout g = this.g;
        if (g != null) {
            ((ViewGroup)g).addView((View)this.f, new ViewGroup$LayoutParams(-2, -2));
        }
        final FrameLayout g2 = this.g;
        if (g2 != null) {
            this.setContentView((View)g2);
            return;
        }
        throw new IllegalStateException("Required value was null.");
    }
    
    public void onDetachedFromWindow() {
        this.j = true;
        super.onDetachedFromWindow();
    }
    
    public boolean onKeyDown(final int n, final KeyEvent keyEvent) {
        Intrinsics.checkNotNullParameter((Object)keyEvent, "event");
        if (n == 4) {
            final WebView d = this.d;
            if (d != null && d != null && d.canGoBack()) {
                final WebView d2 = this.d;
                if (d2 != null) {
                    d2.goBack();
                }
                return true;
            }
            this.cancel();
        }
        return super.onKeyDown(n, keyEvent);
    }
    
    protected void onStart() {
        super.onStart();
        final e h = this.h;
        if (h != null) {
            AsyncTask$Status status;
            if (h != null) {
                status = h.getStatus();
            }
            else {
                status = null;
            }
            if (status == AsyncTask$Status.PENDING) {
                final e h2 = this.h;
                if (h2 != null) {
                    h2.execute((Object[])new Void[0]);
                }
                final ProgressDialog e = this.e;
                if (e != null) {
                    ((Dialog)e).show();
                }
                return;
            }
        }
        this.x();
    }
    
    protected void onStop() {
        final e h = this.h;
        if (h != null) {
            h.cancel(true);
            final ProgressDialog e = this.e;
            if (e != null) {
                ((Dialog)e).dismiss();
            }
        }
        super.onStop();
    }
    
    public void onWindowAttributesChanged(final WindowManager$LayoutParams l) {
        Intrinsics.checkNotNullParameter((Object)l, "params");
        if (l.token == null) {
            this.l = l;
        }
        super.onWindowAttributesChanged(l);
    }
    
    protected final WebView r() {
        return this.d;
    }
    
    protected final boolean t() {
        return this.i;
    }
    
    protected final boolean u() {
        return this.k;
    }
    
    public Bundle w(final String s) {
        final Uri parse = Uri.parse(s);
        final Bundle p = W.p0(parse.getQuery());
        p.putAll(W.p0(parse.getFragment()));
        return p;
    }
    
    public final void x() {
        final Object systemService = this.getContext().getSystemService("window");
        Intrinsics.d(systemService, "null cannot be cast to non-null type android.view.WindowManager");
        final Display defaultDisplay = ((WindowManager)systemService).getDefaultDisplay();
        final DisplayMetrics displayMetrics = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics);
        final int widthPixels = displayMetrics.widthPixels;
        final int heightPixels = displayMetrics.heightPixels;
        int n;
        if (widthPixels < heightPixels) {
            n = widthPixels;
        }
        else {
            n = heightPixels;
        }
        int n2 = widthPixels;
        if (widthPixels < heightPixels) {
            n2 = heightPixels;
        }
        final int min = Math.min(this.q(n, displayMetrics.density, 480, 800), displayMetrics.widthPixels);
        final int min2 = Math.min(this.q(n2, displayMetrics.density, 800, 1280), displayMetrics.heightPixels);
        final Window window = this.getWindow();
        if (window != null) {
            window.setLayout(min, min2);
        }
    }
    
    protected final void y(final Throwable t) {
        if (this.c != null && !this.i) {
            this.i = true;
            j j;
            if (t instanceof j) {
                j = (j)t;
            }
            else {
                j = new j(t);
            }
            final b0$d c = this.c;
            if (c != null) {
                c.a((Bundle)null, j);
            }
            this.dismiss();
        }
    }
    
    protected final void z(final Bundle bundle) {
        final b0$d c = this.c;
        if (c != null && !this.i) {
            this.i = true;
            if (c != null) {
                c.a(bundle, (j)null);
            }
            this.dismiss();
        }
    }
    
    public static final class b
    {
        private b() {
        }
        
        public final int a() {
            X.o();
            return b0.i();
        }
        
        protected final void b(final Context context) {
            if (context == null) {
                return;
            }
            try {
                final ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
                Bundle metaData;
                if (applicationInfo != null) {
                    metaData = applicationInfo.metaData;
                }
                else {
                    metaData = null;
                }
                if (metaData != null) {
                    if (b0.i() == 0) {
                        this.e(((BaseBundle)applicationInfo.metaData).getInt("com.facebook.sdk.WebDialogTheme"));
                    }
                }
            }
            catch (final PackageManager$NameNotFoundException ex) {}
        }
        
        public final b0 c(final Context context, final String s, final Bundle bundle, final int n, final z z, final b0$d b0$d) {
            Intrinsics.checkNotNullParameter((Object)context, "context");
            Intrinsics.checkNotNullParameter((Object)z, "targetApp");
            b0.s(context);
            return new b0(context, s, bundle, n, z, b0$d, null);
        }
        
        public final b0 d(final Context context, final String s, final Bundle bundle, final int n, final b0$d b0$d) {
            Intrinsics.checkNotNullParameter((Object)context, "context");
            b0.s(context);
            return new b0(context, s, bundle, n, z.c, b0$d, null);
        }
        
        public final void e(int f) {
            if (f == 0) {
                f = b0.f();
            }
            b0.n(f);
        }
    }
    
    private final class c extends WebViewClient
    {
        final b0 a;
        
        public c(final b0 a) {
            this.a = a;
        }
        
        public void onPageFinished(WebView r, final String s) {
            Intrinsics.checkNotNullParameter((Object)r, "view");
            Intrinsics.checkNotNullParameter((Object)s, "url");
            super.onPageFinished(r, s);
            if (!b0.j(this.a)) {
                final ProgressDialog h = b0.h(this.a);
                if (h != null) {
                    ((Dialog)h).dismiss();
                }
            }
            final FrameLayout d = b0.d(this.a);
            if (d != null) {
                ((View)d).setBackgroundColor(0);
            }
            r = this.a.r();
            if (r != null) {
                ((View)r).setVisibility(0);
            }
            final ImageView e = b0.e(this.a);
            if (e != null) {
                e.setVisibility(0);
            }
            b0.k(this.a, true);
        }
        
        public void onPageStarted(final WebView webView, final String s, final Bitmap bitmap) {
            Intrinsics.checkNotNullParameter((Object)webView, "view");
            Intrinsics.checkNotNullParameter((Object)s, "url");
            final StringBuilder sb = new StringBuilder();
            sb.append("Webview loading URL: ");
            sb.append(s);
            W.k0("FacebookSDK.WebDialog", sb.toString());
            super.onPageStarted(webView, s, bitmap);
            if (!b0.j(this.a)) {
                final ProgressDialog h = b0.h(this.a);
                if (h != null) {
                    ((Dialog)h).show();
                }
            }
        }
        
        public void onReceivedError(final WebView webView, final int n, final String s, final String s2) {
            Intrinsics.checkNotNullParameter((Object)webView, "view");
            Intrinsics.checkNotNullParameter((Object)s, "description");
            Intrinsics.checkNotNullParameter((Object)s2, "failingUrl");
            super.onReceivedError(webView, n, s, s2);
            this.a.y((Throwable)new h(s, n, s2));
        }
        
        public void onReceivedSslError(final WebView webView, final SslErrorHandler sslErrorHandler, final SslError sslError) {
            Intrinsics.checkNotNullParameter((Object)webView, "view");
            Intrinsics.checkNotNullParameter((Object)sslErrorHandler, "handler");
            Intrinsics.checkNotNullParameter((Object)sslError, "error");
            super.onReceivedSslError(webView, sslErrorHandler, sslError);
            sslErrorHandler.cancel();
            this.a.y((Throwable)new h((String)null, -11, (String)null));
        }
        
        public boolean shouldOverrideUrlLoading(final WebView webView, String s) {
            Intrinsics.checkNotNullParameter((Object)webView, "view");
            Intrinsics.checkNotNullParameter((Object)s, "url");
            final StringBuilder sb = new StringBuilder();
            sb.append("Redirect URL: ");
            sb.append(s);
            W.k0("FacebookSDK.WebDialog", sb.toString());
            final Uri parse = Uri.parse(s);
            final boolean b = parse.getPath() != null && Pattern.matches("^/(v\\d+\\.\\d+/)??dialog/.*", (CharSequence)parse.getPath());
            if (StringsKt.J(s, b0.g(this.a), false, 2, (Object)null)) {
                final Bundle w = this.a.w(s);
                if ((s = ((BaseBundle)w).getString("error")) == null) {
                    s = ((BaseBundle)w).getString("error_type");
                }
                String s2;
                if ((s2 = ((BaseBundle)w).getString("error_msg")) == null) {
                    s2 = ((BaseBundle)w).getString("error_message");
                }
                String string;
                if ((string = s2) == null) {
                    string = ((BaseBundle)w).getString("error_description");
                }
                final String string2 = ((BaseBundle)w).getString("error_code");
                int int1 = 0;
                Label_0193: {
                    if (string2 != null && !W.d0(string2)) {
                        try {
                            int1 = Integer.parseInt(string2);
                            break Label_0193;
                        }
                        catch (final NumberFormatException ex) {}
                    }
                    int1 = -1;
                }
                if (W.d0(s) && W.d0(string) && int1 == -1) {
                    this.a.z(w);
                }
                else if (s != null && (Intrinsics.a((Object)s, (Object)"access_denied") || Intrinsics.a((Object)s, (Object)"OAuthAccessDeniedException"))) {
                    this.a.cancel();
                }
                else if (int1 == 4201) {
                    this.a.cancel();
                }
                else {
                    this.a.y((Throwable)new w(new FacebookRequestError(int1, s, string), string));
                }
                return true;
            }
            if (StringsKt.J(s, "fbconnect://cancel", false, 2, (Object)null)) {
                this.a.cancel();
                return true;
            }
            if (b) {
                return false;
            }
            if (StringsKt.P((CharSequence)s, (CharSequence)"touch", false, 2, (Object)null)) {
                return false;
            }
            try {
                this.a.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse(s)));
                return true;
            }
            catch (final ActivityNotFoundException ex2) {
                return false;
            }
        }
    }
    
    private final class e extends AsyncTask
    {
        private final String a;
        private final Bundle b;
        private Exception[] c;
        final b0 d;
        
        public e(final b0 d, final String a, final Bundle b) {
            Intrinsics.checkNotNullParameter((Object)a, "action");
            Intrinsics.checkNotNullParameter((Object)b, "parameters");
            this.d = d;
            this.a = a;
            this.b = b;
            this.c = new Exception[0];
        }
        
        private static final void c(final String[] array, final int n, final e e, final CountDownLatch countDownLatch, final com.facebook.h h) {
            Intrinsics.checkNotNullParameter((Object)array, "$results");
            Intrinsics.checkNotNullParameter((Object)e, "this$0");
            Intrinsics.checkNotNullParameter((Object)countDownLatch, "$latch");
            Intrinsics.checkNotNullParameter((Object)h, "response");
            Label_0142: {
                Label_0135: {
                    try {
                        final FacebookRequestError b = h.b();
                        final String s = "Error staging photo.";
                        if (b != null) {
                            String m = b.m();
                            if (m == null) {
                                m = s;
                            }
                            throw new k(h, m);
                        }
                    }
                    catch (final Exception ex) {
                        break Label_0135;
                    }
                    final JSONObject c = h.c();
                    if (c == null) {
                        throw new j("Error staging photo.");
                    }
                    final String optString = c.optString("uri");
                    if (optString != null) {
                        array[n] = optString;
                        break Label_0142;
                    }
                    throw new j("Error staging photo.");
                }
                final Exception ex;
                e.c[n] = ex;
            }
            countDownLatch.countDown();
        }
        
        protected String[] b(Void... array) {
            Intrinsics.checkNotNullParameter((Object)array, "p0");
            final String[] stringArray = ((BaseBundle)this.b).getStringArray("media");
            if (stringArray == null) {
                return null;
            }
            final String[] array2 = new String[stringArray.length];
            this.c = new Exception[stringArray.length];
            final CountDownLatch countDownLatch = new CountDownLatch(stringArray.length);
            array = (Void[])(Object)new ConcurrentLinkedQueue();
            final AccessToken e = AccessToken.l.e();
            try {
                for (int length = stringArray.length, i = 0; i < length; ++i) {
                    if (this.isCancelled()) {
                        final Iterator iterator = ((ConcurrentLinkedQueue)(Object)array).iterator();
                        while (iterator.hasNext()) {
                            ((AsyncTask)iterator.next()).cancel(true);
                        }
                        return null;
                    }
                    final Uri parse = Uri.parse(stringArray[i]);
                    if (W.f0(parse)) {
                        array2[i] = parse.toString();
                        countDownLatch.countDown();
                    }
                    else {
                        final c0 c0 = new c0(array2, i, this, countDownLatch);
                        Intrinsics.c((Object)parse);
                        ((ConcurrentLinkedQueue)(Object)array).add((Object)z2.l.u(e, parse, (GraphRequest$b)c0).l());
                    }
                }
                countDownLatch.await();
                return array2;
            }
            catch (final Exception ex) {
                final Iterator iterator2 = ((ConcurrentLinkedQueue)(Object)array).iterator();
                while (iterator2.hasNext()) {
                    ((AsyncTask)iterator2.next()).cancel(true);
                }
                return null;
            }
        }
        
        protected void d(final String[] array) {
            final ProgressDialog h = b0.h(this.d);
            if (h != null) {
                ((Dialog)h).dismiss();
            }
            for (final Exception ex : this.c) {
                if (ex != null) {
                    this.d.y((Throwable)ex);
                    return;
                }
            }
            if (array == null) {
                this.d.y((Throwable)new j("Failed to stage photos for web dialog"));
                return;
            }
            final List e = kotlin.collections.j.e((Object[])array);
            if (e.contains((Object)null)) {
                this.d.y((Throwable)new j("Failed to stage photos for web dialog"));
                return;
            }
            W.r0(this.b, "media", new JSONArray((Collection)e));
            final String b = N.b();
            final String w = com.facebook.e.w();
            final String a = this.a;
            final StringBuilder sb = new StringBuilder();
            sb.append(w);
            sb.append("/dialog/");
            sb.append(a);
            b0.m(this.d, W.g(b, sb.toString(), this.b).toString());
            final ImageView e2 = b0.e(this.d);
            if (e2 != null) {
                this.d.C(e2.getDrawable().getIntrinsicWidth() / 2 + 1);
                return;
            }
            throw new IllegalStateException("Required value was null.");
        }
    }
}
