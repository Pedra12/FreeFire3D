package n2;

import android.os.BaseBundle;
import java.util.Iterator;
import java.util.Set;
import kotlin.text.Regex;
import android.os.Bundle;
import S1.F;
import android.content.Intent;
import android.content.IntentFilter;
import w0.a;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.DefaultConstructorMarker;
import android.content.Context;
import android.content.BroadcastReceiver;

public final class c extends BroadcastReceiver
{
    public static final a b;
    private static c c;
    private static final String d;
    private final Context a;
    
    static {
        b = new a(null);
        d = "com.parse.bolts.measurement_event";
    }
    
    private c(Context applicationContext) {
        applicationContext = applicationContext.getApplicationContext();
        Intrinsics.checkNotNullExpressionValue((Object)applicationContext, "getApplicationContext(...)");
        this.a = applicationContext;
    }
    
    public static final /* synthetic */ c a() {
        return n2.c.c;
    }
    
    public static final /* synthetic */ void c(final c c) {
        c.c = c;
    }
    
    private final void d() {
        final w0.a b = w0.a.b(this.a);
        Intrinsics.checkNotNullExpressionValue((Object)b, "getInstance(...)");
        b.e((BroadcastReceiver)this);
    }
    
    private final void e() {
        final w0.a b = w0.a.b(this.a);
        Intrinsics.checkNotNullExpressionValue((Object)b, "getInstance(...)");
        b.c((BroadcastReceiver)this, new IntentFilter(n2.c.d));
    }
    
    public final void finalize() {
        this.d();
    }
    
    public void onReceive(final Context context, final Intent intent) {
        final F f = new F(context);
        final Set set = null;
        String stringExtra;
        if (intent != null) {
            stringExtra = intent.getStringExtra("event_name");
        }
        else {
            stringExtra = null;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("bf_");
        sb.append(stringExtra);
        final String string = sb.toString();
        Object bundleExtra;
        if (intent != null) {
            bundleExtra = intent.getBundleExtra("event_args");
        }
        else {
            bundleExtra = null;
        }
        final Bundle bundle = new Bundle();
        Set keySet = set;
        if (bundleExtra != null) {
            keySet = ((BaseBundle)bundleExtra).keySet();
        }
        if (keySet != null) {
            for (final String s : keySet) {
                Intrinsics.c((Object)s);
                ((BaseBundle)bundle).putString(new Regex("[ -]*$").replace((CharSequence)new Regex("^[ -]*").replace((CharSequence)new Regex("[^0-9a-zA-Z _-]").replace((CharSequence)s, "-"), ""), ""), (String)((BaseBundle)bundleExtra).get(s));
            }
        }
        f.d(string, bundle);
    }
    
    public static final class a
    {
        private a() {
        }
        
        public final c a(final Context context) {
            Intrinsics.checkNotNullParameter((Object)context, "context");
            if (n2.c.a() != null) {
                return n2.c.a();
            }
            final c c = new c(context, null);
            c.e();
            n2.c.c(c);
            return n2.c.a();
        }
    }
}
