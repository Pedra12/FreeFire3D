package n2;

import android.database.Cursor;
import android.content.ComponentName;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import android.os.Parcel;
import android.os.IBinder;
import android.os.IInterface;
import android.content.pm.ProviderInfo;
import android.net.Uri;
import R1.j;
import android.os.Looper;
import kotlin.jvm.internal.Intrinsics;
import android.content.pm.PackageManager;
import android.content.ServiceConnection;
import android.content.Intent;
import java.lang.reflect.Method;
import android.content.Context;
import com.facebook.e;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class b
{
    public static final a f;
    private static final String g;
    public static b h;
    private String a;
    private long b;
    private String c;
    private String d;
    private boolean e;
    
    static {
        f = new a(null);
        g = b.class.getCanonicalName();
    }
    
    public static final /* synthetic */ long a(final b b) {
        return b.b;
    }
    
    public static final /* synthetic */ String b() {
        return b.g;
    }
    
    public static final /* synthetic */ void c(final b b, final String a) {
        b.a = a;
    }
    
    public static final /* synthetic */ void d(final b b, final String d) {
        b.d = d;
    }
    
    public static final /* synthetic */ void e(final b b, final String c) {
        b.c = c;
    }
    
    public static final /* synthetic */ void f(final b b, final long b2) {
        b.b = b2;
    }
    
    public static final /* synthetic */ void g(final b b, final boolean e) {
        b.e = e;
    }
    
    public final String h() {
        if (com.facebook.e.F() && com.facebook.e.k()) {
            return this.a;
        }
        return null;
    }
    
    public final String i() {
        return this.d;
    }
    
    public final String j() {
        return this.c;
    }
    
    public final boolean k() {
        return this.e;
    }
    
    public static final class a
    {
        private a() {
        }
        
        private final b a(final b h) {
            n2.b.f(h, System.currentTimeMillis());
            return n2.b.h = h;
        }
        
        private final b b(final Context context) {
            final b c = this.c(context);
            if (c == null) {
                b d;
                if ((d = this.d(context)) == null) {
                    d = new b();
                }
                return d;
            }
            return c;
        }
        
        private final b c(final Context context) {
            boolean booleanValue = false;
            Label_0165: {
                b b;
                try {
                    if (!this.g(context)) {
                        return null;
                    }
                    final Method l = W.L("com.google.android.gms.ads.identifier.AdvertisingIdClient", "getAdvertisingIdInfo", Context.class);
                    if (l == null) {
                        return null;
                    }
                    final Object u = W.U(null, l, context);
                    if (u == null) {
                        return null;
                    }
                    final Method k = W.K(u.getClass(), "getId", new Class[0]);
                    final Method i = W.K(u.getClass(), "isLimitAdTrackingEnabled", new Class[0]);
                    if (k == null || i == null) {
                        return null;
                    }
                    b = new b();
                    n2.b.c(b, (String)W.U(u, k, new Object[0]));
                    final Boolean b2 = (Boolean)W.U(u, i, new Object[0]);
                    if (b2 != null) {
                        booleanValue = b2;
                    }
                }
                catch (final Exception ex) {
                    break Label_0165;
                }
                n2.b.g(b, booleanValue);
                return b;
            }
            final Exception ex;
            W.j0("android_id", ex);
            return null;
        }
        
        private final b d(final Context context) {
            if (!this.g(context)) {
                return null;
            }
            final c c = new c();
            final Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
            intent.setPackage("com.google.android.gms");
            try {
                if (context.bindService(intent, (ServiceConnection)c, 1)) {
                    try {
                        try {
                            final b b = new b(c.a());
                            final b b2 = new b();
                            n2.b.c(b2, b.f());
                            n2.b.g(b2, b.g());
                            context.unbindService((ServiceConnection)c);
                            return b2;
                        }
                        finally {}
                    }
                    catch (final Exception ex) {
                        W.j0("android_id", ex);
                        context.unbindService((ServiceConnection)c);
                        return null;
                    }
                    context.unbindService((ServiceConnection)c);
                }
                return null;
            }
            catch (final SecurityException ex2) {
                return null;
            }
        }
        
        private final String f(final Context context) {
            final PackageManager packageManager = context.getPackageManager();
            if (packageManager != null) {
                return packageManager.getInstallerPackageName(context.getPackageName());
            }
            return null;
        }
        
        private final boolean g(final Context context) {
            final Method l = W.L("com.google.android.gms.common.GooglePlayServicesUtil", "isGooglePlayServicesAvailable", Context.class);
            if (l == null) {
                return false;
            }
            final Object u = W.U(null, l, context);
            return u instanceof Integer && Intrinsics.a(u, (Object)0);
        }
        
        public final b e(Context query) {
            Intrinsics.checkNotNullParameter((Object)query, "context");
            final b b = this.b(query);
            final Context context = null;
            Throwable t2 = null;
            Context context3 = null;
            Label_0405: {
                try {
                    if (Intrinsics.a((Object)Looper.myLooper(), (Object)Looper.getMainLooper())) {
                        throw new j("getAttributionIdentifiers cannot be called on the main thread.");
                    }
                    final b h = n2.b.h;
                    if (h != null && System.currentTimeMillis() - n2.b.a(h) < 3600000L) {
                        return h;
                    }
                }
                catch (final Exception ex) {
                    break Label_0405;
                }
                finally {
                    query = context;
                }
                final ProviderInfo resolveContentProvider = query.getPackageManager().resolveContentProvider("com.facebook.katana.provider.AttributionIdProvider", 0);
                final ProviderInfo resolveContentProvider2 = query.getPackageManager().resolveContentProvider("com.facebook.wakizashi.provider.AttributionIdProvider", 0);
                Uri uri = null;
                Label_0181: {
                    while (true) {
                        Label_0140: {
                            if (resolveContentProvider == null) {
                                break Label_0140;
                            }
                            final String packageName = resolveContentProvider.packageName;
                            Intrinsics.checkNotNullExpressionValue((Object)packageName, "packageName");
                            if (!p.a(query, packageName)) {
                                break Label_0140;
                            }
                            uri = Uri.parse("content://com.facebook.katana.provider.AttributionIdProvider");
                            break Label_0181;
                        }
                        if (resolveContentProvider2 != null) {
                            final String packageName2 = resolveContentProvider2.packageName;
                            Intrinsics.checkNotNullExpressionValue((Object)packageName2, "packageName");
                            if (p.a(query, packageName2)) {
                                uri = Uri.parse("content://com.facebook.wakizashi.provider.AttributionIdProvider");
                                continue;
                            }
                        }
                        break;
                    }
                    uri = null;
                }
                final String f = this.f(query);
                if (f != null) {
                    n2.b.d(b, f);
                }
                if (uri == null) {
                    return this.a(b);
                }
                query = (Context)query.getContentResolver().query(uri, new String[] { "aid", "androidid", "limit_tracking" }, (String)null, (String[])null, (String)null);
                Label_0371: {
                    if (query != null) {
                        try {
                            if (!((Cursor)query).moveToFirst()) {
                                break Label_0371;
                            }
                            final int columnIndex = ((Cursor)query).getColumnIndex("aid");
                            final int columnIndex2 = ((Cursor)query).getColumnIndex("androidid");
                            final int columnIndex3 = ((Cursor)query).getColumnIndex("limit_tracking");
                            n2.b.e(b, ((Cursor)query).getString(columnIndex));
                            if (columnIndex2 > 0 && columnIndex3 > 0 && b.h() == null) {
                                n2.b.c(b, ((Cursor)query).getString(columnIndex2));
                                n2.b.g(b, Boolean.parseBoolean(((Cursor)query).getString(columnIndex3)));
                            }
                        }
                        catch (final Exception ex2) {
                            break Label_0405;
                        }
                        finally {
                            goto Label_0062;
                        }
                        ((Cursor)query).close();
                        return this.a(b);
                    }
                }
                final b a = this.a(b);
                if (query != null) {
                    ((Cursor)query).close();
                }
                return a;
                try {
                    final String b2 = n2.b.b();
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Caught unexpected exception in getAttributionId(): ");
                    final Throwable t;
                    sb.append((Object)t);
                    W.k0(b2, sb.toString());
                    if (query != null) {
                        ((Cursor)query).close();
                    }
                    return null;
                }
                finally {
                    final Context context2 = query;
                    final Throwable t3;
                    t2 = t3;
                    context3 = context2;
                }
            }
            if (context3 != null) {
                ((Cursor)context3).close();
            }
            throw t2;
        }
        
        public final boolean h(final Context context) {
            Intrinsics.checkNotNullParameter((Object)context, "context");
            final b e = this.e(context);
            return e != null && e.k();
        }
    }
    
    private static final class b implements IInterface
    {
        public static final a h;
        private final IBinder g;
        
        static {
            h = new a(null);
        }
        
        public b(final IBinder g) {
            Intrinsics.checkNotNullParameter((Object)g, "binder");
            this.g = g;
        }
        
        public IBinder asBinder() {
            return this.g;
        }
        
        public final String f() {
            final Parcel obtain = Parcel.obtain();
            Intrinsics.checkNotNullExpressionValue((Object)obtain, "obtain(...)");
            final Parcel obtain2 = Parcel.obtain();
            Intrinsics.checkNotNullExpressionValue((Object)obtain2, "obtain(...)");
            try {
                obtain.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                this.g.transact(1, obtain, obtain2, 0);
                obtain2.readException();
                return obtain2.readString();
            }
            finally {
                obtain2.recycle();
                obtain.recycle();
            }
        }
        
        public final boolean g() {
            final Parcel obtain = Parcel.obtain();
            Intrinsics.checkNotNullExpressionValue((Object)obtain, "obtain(...)");
            final Parcel obtain2 = Parcel.obtain();
            Intrinsics.checkNotNullExpressionValue((Object)obtain2, "obtain(...)");
            try {
                obtain.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                boolean b = true;
                obtain.writeInt(1);
                this.g.transact(2, obtain, obtain2, 0);
                obtain2.readException();
                if (obtain2.readInt() == 0) {
                    b = false;
                }
                return b;
            }
            finally {
                obtain2.recycle();
                obtain.recycle();
            }
        }
        
        public static final class a
        {
            private a() {
            }
        }
    }
    
    private static final class c implements ServiceConnection
    {
        private final AtomicBoolean a;
        private final BlockingQueue b;
        
        public c() {
            this.a = new AtomicBoolean(false);
            this.b = (BlockingQueue)new LinkedBlockingDeque();
        }
        
        public final IBinder a() {
            if (!this.a.compareAndSet(true, true)) {
                final Object take = this.b.take();
                Intrinsics.checkNotNullExpressionValue(take, "take(...)");
                return (IBinder)take;
            }
            throw new IllegalStateException("Binder already consumed");
        }
        
        public void onServiceConnected(final ComponentName componentName, final IBinder binder) {
            if (binder == null) {
                return;
            }
            try {
                this.b.put((Object)binder);
            }
            catch (final InterruptedException ex) {}
        }
        
        public void onServiceDisconnected(final ComponentName componentName) {
        }
    }
}
