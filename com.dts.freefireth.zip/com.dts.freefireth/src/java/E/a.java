package e;

import android.os.Parcelable;
import android.os.Parcel;
import android.os.IBinder;
import android.os.Binder;
import android.net.Uri;
import android.os.Bundle;
import android.os.IInterface;

public interface a extends IInterface
{
    public static final String d = "android$support$customtabs$ICustomTabsCallback".replace('$', '.');
    
    void D(final int p0, final int p1, final int p2, final int p3, final int p4, final Bundle p5);
    
    void E0(final int p0, final int p1, final Bundle p2);
    
    void M0(final String p0, final Bundle p1);
    
    void Q0(final Bundle p0);
    
    void T0(final int p0, final Bundle p1);
    
    Bundle X(final String p0, final Bundle p1);
    
    void m1(final String p0, final Bundle p1);
    
    void n0(final Bundle p0);
    
    void t0(final Bundle p0);
    
    void t1(final Bundle p0);
    
    void x1(final int p0, final Uri p1, final boolean p2, final Bundle p3);
    
    public abstract static class a extends Binder implements e.a
    {
        public a() {
            this.attachInterface((IInterface)this, e.a.d);
        }
        
        public IBinder asBinder() {
            return (IBinder)this;
        }
        
        public boolean onTransact(int int1, final Parcel parcel, final Parcel parcel2, final int n) {
            final String d = e.a.d;
            if (int1 >= 1 && int1 <= 16777215) {
                parcel.enforceInterface(d);
            }
            if (int1 == 1598968902) {
                parcel2.writeString(d);
                return true;
            }
            switch (int1) {
                default: {
                    return super.onTransact(int1, parcel, parcel2, n);
                }
                case 12: {
                    this.t0((Bundle)a$b.a(parcel, Bundle.CREATOR));
                    break;
                }
                case 11: {
                    this.n0((Bundle)a$b.a(parcel, Bundle.CREATOR));
                    break;
                }
                case 10: {
                    this.D(parcel.readInt(), parcel.readInt(), parcel.readInt(), parcel.readInt(), parcel.readInt(), (Bundle)a$b.a(parcel, Bundle.CREATOR));
                    break;
                }
                case 9: {
                    this.Q0((Bundle)a$b.a(parcel, Bundle.CREATOR));
                    break;
                }
                case 8: {
                    this.E0(parcel.readInt(), parcel.readInt(), (Bundle)a$b.a(parcel, Bundle.CREATOR));
                    break;
                }
                case 7: {
                    final Bundle x = this.X(parcel.readString(), (Bundle)a$b.a(parcel, Bundle.CREATOR));
                    parcel2.writeNoException();
                    a$b.b(parcel2, (Parcelable)x, 1);
                    break;
                }
                case 6: {
                    int1 = parcel.readInt();
                    this.x1(int1, (Uri)a$b.a(parcel, Uri.CREATOR), parcel.readInt() != 0, (Bundle)a$b.a(parcel, Bundle.CREATOR));
                    break;
                }
                case 5: {
                    this.m1(parcel.readString(), (Bundle)a$b.a(parcel, Bundle.CREATOR));
                    parcel2.writeNoException();
                    break;
                }
                case 4: {
                    this.t1((Bundle)a$b.a(parcel, Bundle.CREATOR));
                    parcel2.writeNoException();
                    break;
                }
                case 3: {
                    this.M0(parcel.readString(), (Bundle)a$b.a(parcel, Bundle.CREATOR));
                    break;
                }
                case 2: {
                    this.T0(parcel.readInt(), (Bundle)a$b.a(parcel, Bundle.CREATOR));
                    break;
                }
            }
            return true;
        }
    }
}
