package e;

import android.os.Parcelable;
import android.os.Parcel;
import android.os.IBinder;
import android.os.Binder;
import java.util.List;
import android.os.Bundle;
import android.net.Uri;
import android.os.IInterface;

public interface b extends IInterface
{
    public static final String e = "android$support$customtabs$ICustomTabsService".replace('$', '.');
    
    boolean Y(final e.a p0, final Uri p1, final Bundle p2, final List p3);
    
    boolean Z0(final e.a p0);
    
    boolean g1(final e.a p0, final Bundle p1);
    
    boolean l0(final long p0);
    
    public abstract static class a extends Binder implements b
    {
        public static b f(final IBinder binder) {
            if (binder == null) {
                return null;
            }
            final IInterface queryLocalInterface = binder.queryLocalInterface(b.e);
            if (queryLocalInterface != null && queryLocalInterface instanceof b) {
                return (b)queryLocalInterface;
            }
            return new a(binder);
        }
        
        private static class a implements b
        {
            private IBinder g;
            
            a(final IBinder g) {
                this.g = g;
            }
            
            @Override
            public boolean Y(final e.a a, final Uri uri, final Bundle bundle, final List list) {
                final Parcel obtain = Parcel.obtain();
                final Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.e);
                    obtain.writeStrongInterface((IInterface)a);
                    boolean b = false;
                    d(obtain, (Parcelable)uri, 0);
                    d(obtain, (Parcelable)bundle, 0);
                    c(obtain, list, 0);
                    this.g.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                    if (obtain2.readInt() != 0) {
                        b = true;
                    }
                    return b;
                }
                finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
            
            @Override
            public boolean Z0(final e.a a) {
                final Parcel obtain = Parcel.obtain();
                final Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.e);
                    obtain.writeStrongInterface((IInterface)a);
                    final IBinder g = this.g;
                    boolean b = false;
                    g.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                    if (obtain2.readInt() != 0) {
                        b = true;
                    }
                    return b;
                }
                finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
            
            public IBinder asBinder() {
                return this.g;
            }
            
            @Override
            public boolean g1(final e.a a, final Bundle bundle) {
                final Parcel obtain = Parcel.obtain();
                final Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.e);
                    obtain.writeStrongInterface((IInterface)a);
                    boolean b = false;
                    d(obtain, (Parcelable)bundle, 0);
                    this.g.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                    if (obtain2.readInt() != 0) {
                        b = true;
                    }
                    return b;
                }
                finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
            
            @Override
            public boolean l0(final long n) {
                final Parcel obtain = Parcel.obtain();
                final Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.e);
                    obtain.writeLong(n);
                    final IBinder g = this.g;
                    boolean b = false;
                    g.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                    if (obtain2.readInt() != 0) {
                        b = true;
                    }
                    return b;
                }
                finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }
    }
    
    public abstract static class b
    {
        private static void c(final Parcel parcel, final List list, final int n) {
            if (list == null) {
                parcel.writeInt(-1);
                return;
            }
            final int size = list.size();
            parcel.writeInt(size);
            for (int i = 0; i < size; ++i) {
                d(parcel, (Parcelable)list.get(i), n);
            }
        }
        
        private static void d(final Parcel parcel, final Parcelable parcelable, final int n) {
            if (parcelable != null) {
                parcel.writeInt(1);
                parcelable.writeToParcel(parcel, n);
                return;
            }
            parcel.writeInt(0);
        }
    }
}
