package c0;

import android.widget.CompoundButton;

public abstract class a
{
    public static void a(final CompoundButton compoundButton, final boolean checked) {
        if (compoundButton.isChecked() != checked) {
            compoundButton.setChecked(checked);
        }
    }
}
