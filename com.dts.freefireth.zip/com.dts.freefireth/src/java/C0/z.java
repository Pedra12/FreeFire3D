package C0;

import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import java.util.ArrayDeque;
import java.util.concurrent.Executor;

public final class z implements Executor
{
    private final Executor a;
    private final ArrayDeque b;
    private Runnable c;
    private final Object d;
    
    public z(final Executor a) {
        Intrinsics.checkNotNullParameter((Object)a, "executor");
        this.a = a;
        this.b = new ArrayDeque();
        this.d = new Object();
    }
    
    private static final void b(final Runnable runnable, final z z) {
        Intrinsics.checkNotNullParameter((Object)runnable, "$command");
        Intrinsics.checkNotNullParameter((Object)z, "this$0");
        try {
            runnable.run();
        }
        finally {
            z.c();
        }
    }
    
    public final void c() {
        final Object d;
        monitorenter(d = this.d);
        Label_0057: {
            try {
                final Object poll = this.b.poll();
                final Runnable c = (Runnable)poll;
                this.c = c;
                if (poll != null) {
                    this.a.execute(c);
                }
            }
            finally {
                break Label_0057;
            }
            final Unit a = Unit.a;
            monitorexit(d);
            return;
        }
        monitorexit(d);
    }
    
    public void execute(final Runnable runnable) {
        Intrinsics.checkNotNullParameter((Object)runnable, "command");
        final Object d;
        monitorenter(d = this.d);
        Label_0065: {
            try {
                this.b.offer((Object)new y(runnable, this));
                if (this.c == null) {
                    this.c();
                }
            }
            finally {
                break Label_0065;
            }
            final Unit a = Unit.a;
            monitorexit(d);
            return;
        }
        monitorexit(d);
    }
}
