package C0;

import kotlin.jvm.internal.Intrinsics;
import java.util.concurrent.Callable;
import java.io.File;
import java.util.Set;
import android.content.Intent;
import java.util.concurrent.Executor;
import java.util.List;
import G0.h;
import android.content.Context;

public class g
{
    public final Context a;
    public final String b;
    public final h.c c;
    public final r.e d;
    public final List e;
    public final boolean f;
    public final r.d g;
    public final Executor h;
    public final Executor i;
    public final Intent j;
    public final boolean k;
    public final boolean l;
    private final Set m;
    public final String n;
    public final File o;
    public final Callable p;
    public final List q;
    public final List r;
    public final boolean s;
    
    public g(final Context a, final String b, final h.c c, final r.e d, final List e, final boolean f, final r.d g, final Executor h, final Executor i, final Intent j, final boolean k, final boolean l, final Set m, final String n, final File o, final Callable p19, final r.f f2, final List q, final List r) {
        Intrinsics.checkNotNullParameter((Object)a, "context");
        Intrinsics.checkNotNullParameter((Object)c, "sqliteOpenHelperFactory");
        Intrinsics.checkNotNullParameter((Object)d, "migrationContainer");
        Intrinsics.checkNotNullParameter((Object)g, "journalMode");
        Intrinsics.checkNotNullParameter((Object)h, "queryExecutor");
        Intrinsics.checkNotNullParameter((Object)i, "transactionExecutor");
        Intrinsics.checkNotNullParameter((Object)q, "typeConverters");
        Intrinsics.checkNotNullParameter((Object)r, "autoMigrationSpecs");
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
        this.j = j;
        this.k = k;
        this.l = l;
        this.m = m;
        this.n = n;
        this.o = o;
        this.p = p19;
        this.q = q;
        this.r = r;
        this.s = (j != null);
    }
    
    public boolean a(final int n, final int n2) {
        if (n > n2 && this.l) {
            return false;
        }
        if (this.k) {
            final Set m = this.m;
            if (m == null || !m.contains((Object)n)) {
                return true;
            }
        }
        return false;
    }
}
