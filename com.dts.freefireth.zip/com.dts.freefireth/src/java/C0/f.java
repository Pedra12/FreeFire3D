package C0;

import java.util.Map;
import kotlin.jvm.internal.Intrinsics;
import O7.j0;
import O7.E;

public abstract class f
{
    public static final E a(final r r) {
        final Map k = r.k();
        Object o;
        if ((o = k.get((Object)"QueryDispatcher")) == null) {
            o = j0.b(r.o());
            k.put((Object)"QueryDispatcher", o);
        }
        Intrinsics.d(o, "null cannot be cast to non-null type kotlinx.coroutines.CoroutineDispatcher");
        return (E)o;
    }
    
    public static final E b(final r r) {
        final Map k = r.k();
        Object o;
        if ((o = k.get((Object)"TransactionDispatcher")) == null) {
            o = j0.b(r.r());
            k.put((Object)"TransactionDispatcher", o);
        }
        Intrinsics.d(o, "null cannot be cast to non-null type kotlinx.coroutines.CoroutineDispatcher");
        return (E)o;
    }
}
