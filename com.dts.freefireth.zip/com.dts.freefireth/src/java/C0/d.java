package C0;

import android.content.ContentResolver;
import G0.e;
import android.database.DataSetObserver;
import android.database.ContentObserver;
import G0.f;
import android.net.Uri;
import android.os.Bundle;
import android.database.CharArrayBuffer;
import kotlin.collections.CollectionsKt;
import java.util.ArrayList;
import android.os.CancellationSignal;
import G0.j;
import android.database.Cursor;
import G0.k;
import android.content.ContentValues;
import G7.n;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import java.util.List;
import G0.g;
import kotlin.jvm.internal.Intrinsics;

public final class d implements h, G0.h, AutoCloseable
{
    private final G0.h a;
    public final C0.c b;
    private final a c;
    
    public d(final G0.h a, final C0.c b) {
        Intrinsics.checkNotNullParameter((Object)a, "delegate");
        Intrinsics.checkNotNullParameter((Object)b, "autoCloser");
        this.a = a;
        (this.b = b).k(this.a());
        this.c = new a(b);
    }
    
    @Override
    public g R0() {
        this.c.a();
        return this.c;
    }
    
    @Override
    public G0.h a() {
        return this.a;
    }
    
    @Override
    public void close() {
        this.c.close();
    }
    
    @Override
    public String getDatabaseName() {
        return this.a.getDatabaseName();
    }
    
    @Override
    public void setWriteAheadLoggingEnabled(final boolean writeAheadLoggingEnabled) {
        this.a.setWriteAheadLoggingEnabled(writeAheadLoggingEnabled);
    }
    
    public static final class a implements g, AutoCloseable
    {
        private final C0.c a;
        
        public a(final C0.c a) {
            Intrinsics.checkNotNullParameter((Object)a, "autoCloser");
            this.a = a;
        }
        
        @Override
        public List D() {
            return (List)this.a.g((Function1)d$a$a.b);
        }
        
        @Override
        public void F0() {
            final g h = this.a.h();
            Unit a;
            if (h != null) {
                h.F0();
                a = Unit.a;
            }
            else {
                a = null;
            }
            if (a != null) {
                return;
            }
            throw new IllegalStateException("setTransactionSuccessful called but delegateDb is null");
        }
        
        @Override
        public void H0(final String s, final Object[] array) {
            Intrinsics.checkNotNullParameter((Object)s, "sql");
            Intrinsics.checkNotNullParameter((Object)array, "bindArgs");
            this.a.g((Function1)new Function1(s, array) {
                final String b;
                final Object[] c;
                
                public final Object a(final g g) {
                    Intrinsics.checkNotNullParameter((Object)g, "db");
                    g.H0(this.b, this.c);
                    return null;
                }
            });
        }
        
        @Override
        public void I0() {
            final g j = this.a.j();
            try {
                j.I0();
            }
            finally {
                this.a.e();
            }
        }
        
        @Override
        public boolean I1() {
            return this.a.h() != null && (boolean)this.a.g((Function1)d$a$d.a);
        }
        
        @Override
        public void J(final String s) {
            Intrinsics.checkNotNullParameter((Object)s, "sql");
            this.a.g((Function1)new Function1(s) {
                final String b;
                
                public final Object a(final g g) {
                    Intrinsics.checkNotNullParameter((Object)g, "db");
                    g.J(this.b);
                    return null;
                }
            });
        }
        
        @Override
        public int J0(final String s, final int n, final ContentValues contentValues, final String s2, final Object[] array) {
            Intrinsics.checkNotNullParameter((Object)s, "table");
            Intrinsics.checkNotNullParameter((Object)contentValues, "values");
            return ((Number)this.a.g((Function1)new Function1(s, n, contentValues, s2, array) {
                final String b;
                final int c;
                final ContentValues d;
                final String e;
                final Object[] f;
                
                public final Integer a(final g g) {
                    Intrinsics.checkNotNullParameter((Object)g, "db");
                    return g.J0(this.b, this.c, this.d, this.e, this.f);
                }
            })).intValue();
        }
        
        @Override
        public k T(final String s) {
            Intrinsics.checkNotNullParameter((Object)s, "sql");
            return new b(s, this.a);
        }
        
        @Override
        public Cursor U0(final String s) {
            Intrinsics.checkNotNullParameter((Object)s, "query");
            try {
                return (Cursor)new c(this.a.j().U0(s), this.a);
            }
            finally {
                this.a.e();
            }
        }
        
        public final void a() {
            this.a.g((Function1)d$a$g.b);
        }
        
        @Override
        public boolean a2() {
            return (boolean)this.a.g((Function1)d$a$e.b);
        }
        
        @Override
        public void b1() {
            if (this.a.h() != null) {
                try {
                    final g h = this.a.h();
                    Intrinsics.c((Object)h);
                    h.b1();
                    return;
                }
                finally {
                    this.a.e();
                }
            }
            throw new IllegalStateException("End transaction called but delegateDb is null");
        }
        
        public void close() {
            this.a.d();
        }
        
        @Override
        public Cursor f2(final j j, final CancellationSignal cancellationSignal) {
            Intrinsics.checkNotNullParameter((Object)j, "query");
            try {
                return (Cursor)new c(this.a.j().f2(j, cancellationSignal), this.a);
            }
            finally {
                this.a.e();
            }
        }
        
        @Override
        public String getPath() {
            return (String)this.a.g((Function1)d$a$f.b);
        }
        
        @Override
        public boolean isOpen() {
            final g h = this.a.h();
            return h != null && h.isOpen();
        }
        
        @Override
        public Cursor j0(final j j) {
            Intrinsics.checkNotNullParameter((Object)j, "query");
            try {
                return (Cursor)new c(this.a.j().j0(j), this.a);
            }
            finally {
                this.a.e();
            }
        }
        
        @Override
        public void v() {
            final g j = this.a.j();
            try {
                j.v();
            }
            finally {
                this.a.e();
            }
        }
    }
    
    private static final class b implements k, AutoCloseable
    {
        private final String a;
        private final C0.c b;
        private final ArrayList c;
        
        public b(final String a, final C0.c b) {
            Intrinsics.checkNotNullParameter((Object)a, "sql");
            Intrinsics.checkNotNullParameter((Object)b, "autoCloser");
            this.a = a;
            this.b = b;
            this.c = new ArrayList();
        }
        
        public static final /* synthetic */ String b(final b b) {
            return b.a;
        }
        
        private final void c(final k k) {
            final ArrayList c = this.c;
            final int size = c.size();
            int n = 0;
            int i = 0;
            while (i < size) {
                c.get(i);
                ++i;
                final int n2 = n + 1;
                if (n < 0) {
                    CollectionsKt.u();
                }
                final Object value = this.c.get(n);
                if (value == null) {
                    k.y1(n2);
                }
                else if (value instanceof Long) {
                    k.D0(n2, ((Number)value).longValue());
                }
                else if (value instanceof Double) {
                    k.g0(n2, ((Number)value).doubleValue());
                }
                else if (value instanceof String) {
                    k.K(n2, (String)value);
                }
                else if (value instanceof byte[]) {
                    k.K0(n2, (byte[])value);
                }
                n = n2;
            }
        }
        
        private final Object d(final Function1 function1) {
            return this.b.g((Function1)new Function1(this, function1) {
                final b b;
                final Function1 c;
                
                public final Object a(final g g) {
                    Intrinsics.checkNotNullParameter((Object)g, "db");
                    final k t = g.T(d.b.b(this.b));
                    this.b.c(t);
                    return this.c.invoke((Object)t);
                }
            });
        }
        
        private final void e(int size, final Object o) {
            final int n = size - 1;
            if (n >= this.c.size()) {
                size = this.c.size();
                if (size <= n) {
                    while (true) {
                        this.c.add((Object)null);
                        if (size == n) {
                            break;
                        }
                        ++size;
                    }
                }
            }
            this.c.set(n, o);
        }
        
        public void D0(final int n, final long n2) {
            this.e(n, n2);
        }
        
        public void K(final int n, final String s) {
            Intrinsics.checkNotNullParameter((Object)s, "value");
            this.e(n, s);
        }
        
        public void K0(final int n, final byte[] array) {
            Intrinsics.checkNotNullParameter((Object)array, "value");
            this.e(n, array);
        }
        
        @Override
        public int R() {
            return ((Number)this.d((Function1)d$b$c.b)).intValue();
        }
        
        public void close() {
        }
        
        public void g0(final int n, final double n2) {
            this.e(n, n2);
        }
        
        @Override
        public long x2() {
            return ((Number)this.d((Function1)d$b$a.b)).longValue();
        }
        
        public void y1(final int n) {
            this.e(n, null);
        }
    }
    
    private static final class c implements Cursor, AutoCloseable
    {
        private final Cursor a;
        private final C0.c b;
        
        public c(final Cursor a, final C0.c b) {
            Intrinsics.checkNotNullParameter((Object)a, "delegate");
            Intrinsics.checkNotNullParameter((Object)b, "autoCloser");
            this.a = a;
            this.b = b;
        }
        
        public void close() {
            this.a.close();
            this.b.e();
        }
        
        public void copyStringToBuffer(final int n, final CharArrayBuffer charArrayBuffer) {
            this.a.copyStringToBuffer(n, charArrayBuffer);
        }
        
        public void deactivate() {
            this.a.deactivate();
        }
        
        public byte[] getBlob(final int n) {
            return this.a.getBlob(n);
        }
        
        public int getColumnCount() {
            return this.a.getColumnCount();
        }
        
        public int getColumnIndex(final String s) {
            return this.a.getColumnIndex(s);
        }
        
        public int getColumnIndexOrThrow(final String s) {
            return this.a.getColumnIndexOrThrow(s);
        }
        
        public String getColumnName(final int n) {
            return this.a.getColumnName(n);
        }
        
        public String[] getColumnNames() {
            return this.a.getColumnNames();
        }
        
        public int getCount() {
            return this.a.getCount();
        }
        
        public double getDouble(final int n) {
            return this.a.getDouble(n);
        }
        
        public Bundle getExtras() {
            return this.a.getExtras();
        }
        
        public float getFloat(final int n) {
            return this.a.getFloat(n);
        }
        
        public int getInt(final int n) {
            return this.a.getInt(n);
        }
        
        public long getLong(final int n) {
            return this.a.getLong(n);
        }
        
        public Uri getNotificationUri() {
            return G0.c.a(this.a);
        }
        
        public List getNotificationUris() {
            return f.a(this.a);
        }
        
        public int getPosition() {
            return this.a.getPosition();
        }
        
        public short getShort(final int n) {
            return this.a.getShort(n);
        }
        
        public String getString(final int n) {
            return this.a.getString(n);
        }
        
        public int getType(final int n) {
            return this.a.getType(n);
        }
        
        public boolean getWantsAllOnMoveCalls() {
            return this.a.getWantsAllOnMoveCalls();
        }
        
        public boolean isAfterLast() {
            return this.a.isAfterLast();
        }
        
        public boolean isBeforeFirst() {
            return this.a.isBeforeFirst();
        }
        
        public boolean isClosed() {
            return this.a.isClosed();
        }
        
        public boolean isFirst() {
            return this.a.isFirst();
        }
        
        public boolean isLast() {
            return this.a.isLast();
        }
        
        public boolean isNull(final int n) {
            return this.a.isNull(n);
        }
        
        public boolean move(final int n) {
            return this.a.move(n);
        }
        
        public boolean moveToFirst() {
            return this.a.moveToFirst();
        }
        
        public boolean moveToLast() {
            return this.a.moveToLast();
        }
        
        public boolean moveToNext() {
            return this.a.moveToNext();
        }
        
        public boolean moveToPosition(final int n) {
            return this.a.moveToPosition(n);
        }
        
        public boolean moveToPrevious() {
            return this.a.moveToPrevious();
        }
        
        public void registerContentObserver(final ContentObserver contentObserver) {
            this.a.registerContentObserver(contentObserver);
        }
        
        public void registerDataSetObserver(final DataSetObserver dataSetObserver) {
            this.a.registerDataSetObserver(dataSetObserver);
        }
        
        public boolean requery() {
            return this.a.requery();
        }
        
        public Bundle respond(final Bundle bundle) {
            return this.a.respond(bundle);
        }
        
        public void setExtras(final Bundle bundle) {
            Intrinsics.checkNotNullParameter((Object)bundle, "extras");
            e.a(this.a, bundle);
        }
        
        public void setNotificationUri(final ContentResolver contentResolver, final Uri uri) {
            this.a.setNotificationUri(contentResolver, uri);
        }
        
        public void setNotificationUris(final ContentResolver contentResolver, final List list) {
            Intrinsics.checkNotNullParameter((Object)contentResolver, "cr");
            Intrinsics.checkNotNullParameter((Object)list, "uris");
            f.b(this.a, contentResolver, list);
        }
        
        public void unregisterContentObserver(final ContentObserver contentObserver) {
            this.a.unregisterContentObserver(contentObserver);
        }
        
        public void unregisterDataSetObserver(final DataSetObserver dataSetObserver) {
            this.a.unregisterDataSetObserver(dataSetObserver);
        }
    }
}
