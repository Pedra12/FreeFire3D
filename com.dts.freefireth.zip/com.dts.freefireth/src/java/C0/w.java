package C0;

import kotlin.jvm.internal.Intrinsics;
import java.util.concurrent.Callable;
import java.io.File;
import G0.h;

public final class w implements c
{
    private final String a;
    private final File b;
    private final Callable c;
    private final c d;
    
    public w(final String a, final File b, final Callable c, final c d) {
        Intrinsics.checkNotNullParameter((Object)d, "mDelegate");
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    @Override
    public h a(final h.b b) {
        Intrinsics.checkNotNullParameter((Object)b, "configuration");
        return new v(b.a, this.a, this.b, this.c, b.c.a, this.d.a(b));
    }
}
