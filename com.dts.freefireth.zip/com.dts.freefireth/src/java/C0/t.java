package C0;

import java.util.Iterator;
import java.util.List;
import android.database.Cursor;
import java.io.Closeable;
import C7.b;
import G0.j;
import G0.a;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.DefaultConstructorMarker;
import G0.h;

public class t extends h.a
{
    public static final a g;
    private g c;
    private final b d;
    private final String e;
    private final String f;
    
    static {
        g = new a(null);
    }
    
    public t(final g c, final b d, final String e, final String f) {
        Intrinsics.checkNotNullParameter((Object)c, "configuration");
        Intrinsics.checkNotNullParameter((Object)d, "delegate");
        Intrinsics.checkNotNullParameter((Object)e, "identityHash");
        Intrinsics.checkNotNullParameter((Object)f, "legacyHash");
        super(d.a);
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    private final void h(final G0.g g) {
        if (t.g.b(g)) {
            final Cursor j0 = g.j0(new G0.a("SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1"));
            while (true) {
                Label_0050: {
                    try {
                        if (j0.moveToFirst()) {
                            final String string = j0.getString(0);
                            break Label_0052;
                        }
                        break Label_0050;
                    }
                    finally {
                        try {}
                        finally {
                            C7.b.a((Closeable)j0, (Throwable)g);
                        }
                        C7.b.a((Closeable)j0, (Throwable)null);
                        final String string;
                        iftrue(Label_0131:)(Intrinsics.a((Object)this.e, (Object)string) || Intrinsics.a((Object)this.f, (Object)string));
                        Label_0082: {
                            break Label_0082;
                            string = null;
                            continue;
                            Label_0131: {
                                return;
                            }
                        }
                        final StringBuilder sb = new StringBuilder();
                        sb.append("Room cannot verify the data integrity. Looks like you've changed schema but forgot to update the version number. You can simply fix this by increasing the version number. Expected identity hash: ");
                        sb.append(this.e);
                        sb.append(", found: ");
                        sb.append(string);
                        throw new IllegalStateException(sb.toString());
                    }
                }
                break;
            }
        }
        final c g2 = this.d.g(g);
        if (g2.a) {
            this.d.e(g);
            this.j(g);
            return;
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("Pre-packaged database has an invalid schema: ");
        sb2.append(g2.b);
        throw new IllegalStateException(sb2.toString());
    }
    
    private final void i(final G0.g g) {
        g.J("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
    }
    
    private final void j(final G0.g g) {
        this.i(g);
        g.J(s.a(this.e));
    }
    
    @Override
    public void b(final G0.g g) {
        Intrinsics.checkNotNullParameter((Object)g, "db");
        super.b(g);
    }
    
    @Override
    public void d(final G0.g g) {
        Intrinsics.checkNotNullParameter((Object)g, "db");
        final boolean a = t.g.a(g);
        this.d.a(g);
        if (!a) {
            final c g2 = this.d.g(g);
            if (!g2.a) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Pre-packaged database has an invalid schema: ");
                sb.append(g2.b);
                throw new IllegalStateException(sb.toString());
            }
        }
        this.j(g);
        this.d.c(g);
    }
    
    @Override
    public void e(final G0.g g, final int n, final int n2) {
        Intrinsics.checkNotNullParameter((Object)g, "db");
        this.g(g, n, n2);
    }
    
    @Override
    public void f(final G0.g g) {
        Intrinsics.checkNotNullParameter((Object)g, "db");
        super.f(g);
        this.h(g);
        this.d.d(g);
        this.c = null;
    }
    
    @Override
    public void g(final G0.g g, final int n, final int n2) {
        Intrinsics.checkNotNullParameter((Object)g, "db");
        final g c = this.c;
        if (c != null) {
            final List d = c.d.d(n, n2);
            if (d != null) {
                this.d.f(g);
                final Iterator iterator = ((Iterable)d).iterator();
                while (iterator.hasNext()) {
                    ((D0.b)iterator.next()).a(g);
                }
                final c g2 = this.d.g(g);
                if (g2.a) {
                    this.d.e(g);
                    this.j(g);
                    return;
                }
                final StringBuilder sb = new StringBuilder();
                sb.append("Migration didn't properly handle: ");
                sb.append(g2.b);
                throw new IllegalStateException(sb.toString());
            }
        }
        final g c2 = this.c;
        if (c2 != null && !c2.a(n, n2)) {
            this.d.b(g);
            this.d.a(g);
            return;
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("A migration from ");
        sb2.append(n);
        sb2.append(" to ");
        sb2.append(n2);
        sb2.append(" was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(Migration ...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* methods.");
        throw new IllegalStateException(sb2.toString());
    }
    
    public static final class a
    {
        private a() {
        }
        
        public final boolean a(G0.g u0) {
            Intrinsics.checkNotNullParameter((Object)u0, "db");
            u0 = (G0.g)u0.U0("SELECT count(*) FROM sqlite_master WHERE name != 'android_metadata'");
            Label_0059: {
                try {
                    final boolean moveToFirst = ((Cursor)u0).moveToFirst();
                    boolean b = false;
                    if (!moveToFirst) {
                        break Label_0059;
                    }
                    final int int1 = ((Cursor)u0).getInt(0);
                    b = b;
                    if (int1 == 0) {
                        b = true;
                    }
                    break Label_0059;
                }
                finally {
                    try {}
                    finally {
                        final Throwable t;
                        C7.b.a((Closeable)u0, t);
                    }
                    C7.b.a((Closeable)u0, (Throwable)null);
                    return;
                }
            }
        }
        
        public final boolean b(G0.g u0) {
            Intrinsics.checkNotNullParameter((Object)u0, "db");
            u0 = (G0.g)u0.U0("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name='room_master_table'");
            Label_0059: {
                try {
                    final boolean moveToFirst = ((Cursor)u0).moveToFirst();
                    boolean b = false;
                    if (!moveToFirst) {
                        break Label_0059;
                    }
                    final int int1 = ((Cursor)u0).getInt(0);
                    b = b;
                    if (int1 != 0) {
                        b = true;
                    }
                    break Label_0059;
                }
                finally {
                    try {}
                    finally {
                        final Throwable t;
                        C7.b.a((Closeable)u0, t);
                    }
                    C7.b.a((Closeable)u0, (Throwable)null);
                    return;
                }
            }
        }
    }
    
    public abstract static class b
    {
        public final int a;
        
        public b(final int a) {
            this.a = a;
        }
        
        public abstract void a(final G0.g p0);
        
        public abstract void b(final G0.g p0);
        
        public abstract void c(final G0.g p0);
        
        public abstract void d(final G0.g p0);
        
        public abstract void e(final G0.g p0);
        
        public abstract void f(final G0.g p0);
        
        public abstract c g(final G0.g p0);
    }
    
    public static class c
    {
        public final boolean a;
        public final String b;
        
        public c(final boolean a, final String b) {
            this.a = a;
            this.b = b;
        }
    }
}
