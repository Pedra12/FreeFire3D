package C0;

import java.util.Map;
import java.util.Iterator;
import java.util.Map$Entry;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.DefaultConstructorMarker;
import java.util.TreeMap;
import G0.j;
import G0.i;

public final class u implements i, j, AutoCloseable
{
    public static final a i;
    public static final TreeMap j;
    private final int a;
    private volatile String b;
    public final long[] c;
    public final double[] d;
    public final String[] e;
    public final byte[][] f;
    private final int[] g;
    private int h;
    
    static {
        i = new a(null);
        j = new TreeMap();
    }
    
    private u(int a) {
        this.a = a;
        ++a;
        this.g = new int[a];
        this.c = new long[a];
        this.d = new double[a];
        this.e = new String[a];
        this.f = new byte[a][];
    }
    
    public static final u c(final String s, final int n) {
        return u.i.a(s, n);
    }
    
    @Override
    public void D0(final int n, final long n2) {
        this.g[n] = 2;
        this.c[n] = n2;
    }
    
    @Override
    public void K(final int n, final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "value");
        this.g[n] = 4;
        this.e[n] = s;
    }
    
    @Override
    public void K0(final int n, final byte[] array) {
        Intrinsics.checkNotNullParameter((Object)array, "value");
        this.g[n] = 5;
        this.f[n] = array;
    }
    
    @Override
    public String a() {
        final String b = this.b;
        if (b != null) {
            return b;
        }
        throw new IllegalStateException("Required value was null.");
    }
    
    @Override
    public void b(final i i) {
        Intrinsics.checkNotNullParameter((Object)i, "statement");
        final int d = this.d();
        if (1 <= d) {
            int n = 1;
            while (true) {
                final int n2 = this.g[n];
                if (n2 != 1) {
                    if (n2 != 2) {
                        if (n2 != 3) {
                            if (n2 != 4) {
                                if (n2 == 5) {
                                    final byte[] array = this.f[n];
                                    if (array == null) {
                                        throw new IllegalArgumentException("Required value was null.");
                                    }
                                    i.K0(n, array);
                                }
                            }
                            else {
                                final String s = this.e[n];
                                if (s == null) {
                                    throw new IllegalArgumentException("Required value was null.");
                                }
                                i.K(n, s);
                            }
                        }
                        else {
                            i.g0(n, this.d[n]);
                        }
                    }
                    else {
                        i.D0(n, this.c[n]);
                    }
                }
                else {
                    i.y1(n);
                }
                if (n == d) {
                    break;
                }
                ++n;
            }
        }
    }
    
    public void close() {
    }
    
    public int d() {
        return this.h;
    }
    
    public final void e(final String b, final int h) {
        Intrinsics.checkNotNullParameter((Object)b, "query");
        this.b = b;
        this.h = h;
    }
    
    public final void f() {
        final TreeMap j = u.j;
        synchronized (j) {
            ((Map)j).put((Object)this.a, (Object)this);
            u.i.b();
            final Unit a = Unit.a;
        }
    }
    
    @Override
    public void g0(final int n, final double n2) {
        this.g[n] = 3;
        this.d[n] = n2;
    }
    
    @Override
    public void y1(final int n) {
        this.g[n] = 1;
    }
    
    public static final class a
    {
        private a() {
        }
        
        public final u a(final String s, final int n) {
            Intrinsics.checkNotNullParameter((Object)s, "query");
            final TreeMap j = u.j;
            final TreeMap treeMap;
            monitorenter(treeMap = j);
            Label_0104: {
                try {
                    final Map$Entry ceilingEntry = j.ceilingEntry((Object)n);
                    if (ceilingEntry != null) {
                        j.remove(ceilingEntry.getKey());
                        final u u = (u)ceilingEntry.getValue();
                        u.e(s, n);
                        Intrinsics.checkNotNullExpressionValue((Object)u, "sqliteQuery");
                        monitorexit(treeMap);
                        return u;
                    }
                }
                finally {
                    break Label_0104;
                }
                final Unit a = Unit.a;
                monitorexit(treeMap);
                final u u2 = new u(n, null);
                final String s2;
                u2.e(s2, n);
                return u2;
            }
            monitorexit(treeMap);
        }
        
        public final void b() {
            final TreeMap j = u.j;
            if (j.size() > 15) {
                int i = j.size() - 10;
                final Iterator iterator = j.descendingKeySet().iterator();
                Intrinsics.checkNotNullExpressionValue((Object)iterator, "queryPool.descendingKeySet().iterator()");
                while (i > 0) {
                    iterator.next();
                    iterator.remove();
                    --i;
                }
            }
        }
    }
}
