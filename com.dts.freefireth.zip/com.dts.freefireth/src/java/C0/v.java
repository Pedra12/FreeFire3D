package C0;

import android.util.Log;
import E0.b;
import I0.a;
import java.nio.channels.FileChannel;
import java.io.IOException;
import java.nio.channels.ReadableByteChannel;
import E0.c;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.FileInputStream;
import java.nio.channels.Channels;
import kotlin.jvm.internal.Intrinsics;
import java.util.concurrent.Callable;
import java.io.File;
import android.content.Context;

public final class v implements h, G0.h, AutoCloseable
{
    private final Context a;
    private final String b;
    private final File c;
    private final Callable d;
    private final int e;
    private final G0.h f;
    private g g;
    private boolean h;
    
    public v(final Context a, final String b, final File c, final Callable d, final int e, final G0.h f) {
        Intrinsics.checkNotNullParameter((Object)a, "context");
        Intrinsics.checkNotNullParameter((Object)f, "delegate");
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    private final void b(final File file, final boolean b) {
        Label_0095: {
            if (this.b != null) {
                final Object o = Channels.newChannel(this.a.getAssets().open(this.b));
                Intrinsics.checkNotNullExpressionValue(o, "newChannel(context.assets.open(copyFromAssetPath))");
                break Label_0095;
            }
            if (this.c != null) {
                final Object o = new FileInputStream(this.c).getChannel();
                Intrinsics.checkNotNullExpressionValue(o, "FileInputStream(copyFromFile).channel");
                break Label_0095;
            }
            final Callable d = this.d;
            if (d == null) {
                throw new IllegalStateException("copyFromAssetPath, copyFromFile and copyFromInputStream are all null!");
            }
            try {
                final Object o = Channels.newChannel((InputStream)d.call());
                Intrinsics.checkNotNullExpressionValue(o, "newChannel(inputStream)");
                final File tempFile = File.createTempFile("room-copy-helper", ".tmp", this.a.getCacheDir());
                tempFile.deleteOnExit();
                final FileChannel channel = new FileOutputStream(tempFile).getChannel();
                Intrinsics.checkNotNullExpressionValue((Object)channel, "output");
                E0.c.a((ReadableByteChannel)o, channel);
                final File parentFile = file.getParentFile();
                if (parentFile != null && !parentFile.exists() && !parentFile.mkdirs()) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Failed to create directories for ");
                    sb.append(file.getAbsolutePath());
                    throw new IOException(sb.toString());
                }
                Intrinsics.checkNotNullExpressionValue((Object)tempFile, "intermediateFile");
                this.c(tempFile, b);
                if (tempFile.renameTo(file)) {
                    return;
                }
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("Failed to move intermediate file (");
                sb2.append(tempFile.getAbsolutePath());
                sb2.append(") to destination (");
                sb2.append(file.getAbsolutePath());
                sb2.append(").");
                throw new IOException(sb2.toString());
            }
            catch (final Exception ex) {
                throw new IOException("inputStreamCallable exception on call", (Throwable)ex);
            }
        }
        throw new IllegalStateException("copyFromAssetPath, copyFromFile and copyFromInputStream are all null!");
    }
    
    private final void c(final File file, final boolean b) {
        g g;
        if ((g = this.g) == null) {
            Intrinsics.q("databaseConfiguration");
            g = null;
        }
        g.getClass();
    }
    
    private final void e(final boolean b) {
        final String databaseName = this.getDatabaseName();
        if (databaseName == null) {
            throw new IllegalStateException("Required value was null.");
        }
        final File databasePath = this.a.getDatabasePath(databaseName);
        final g g = this.g;
        final g g2 = null;
        g g3;
        if ((g3 = g) == null) {
            Intrinsics.q("databaseConfiguration");
            g3 = null;
        }
        final a a = new a(databaseName, this.a.getFilesDir(), g3.s);
        Label_0139: {
            try {
                I0.a.c(a, false, 1, null);
                if (!databasePath.exists()) {
                    final File file = databasePath;
                    final String s = "databaseFile";
                    Intrinsics.checkNotNullExpressionValue((Object)file, s);
                    final v v = this;
                    final File file2 = databasePath;
                    final boolean b2 = b;
                    v.b(file2, b2);
                    final a a2 = a;
                    a2.d();
                    return;
                }
                break Label_0139;
            }
            finally {
                break Label_0139;
            }
            try {
                final File file = databasePath;
                final String s = "databaseFile";
                Intrinsics.checkNotNullExpressionValue((Object)file, s);
                final v v = this;
                final File file2 = databasePath;
                final boolean b2 = b;
                v.b(file2, b2);
                final a a2 = a;
                a2.d();
                return;
            }
            catch (final IOException ex) {
                throw new RuntimeException("Unable to copy database file.", (Throwable)ex);
            }
            try {
                Intrinsics.checkNotNullExpressionValue((Object)databasePath, "databaseFile");
                final int c = b.c(databasePath);
                if (c == this.e) {
                    a.d();
                    return;
                }
                g g4 = this.g;
                if (g4 == null) {
                    Intrinsics.q("databaseConfiguration");
                    g4 = g2;
                }
                if (g4.a(c, this.e)) {
                    a.d();
                    return;
                }
                if (this.a.deleteDatabase(databaseName)) {
                    try {
                        this.b(databasePath, b);
                    }
                    catch (final IOException ex2) {
                        Log.w("ROOM", "Unable to copy database file.", (Throwable)ex2);
                    }
                }
                else {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Failed to delete database file (");
                    sb.append(databaseName);
                    sb.append(") for a copy destructive migration.");
                    Log.w("ROOM", sb.toString());
                }
                a.d();
                return;
            }
            catch (final IOException ex3) {
                Log.w("ROOM", "Unable to read database version.", (Throwable)ex3);
                a.d();
                return;
            }
        }
        a.d();
    }
    
    @Override
    public G0.g R0() {
        if (!this.h) {
            this.e(true);
            this.h = true;
        }
        return this.a().R0();
    }
    
    @Override
    public G0.h a() {
        return this.f;
    }
    
    @Override
    public void close() {
        synchronized (this) {
            this.a().close();
            this.h = false;
        }
    }
    
    public final void d(final g g) {
        Intrinsics.checkNotNullParameter((Object)g, "databaseConfiguration");
        this.g = g;
    }
    
    @Override
    public String getDatabaseName() {
        return this.a().getDatabaseName();
    }
    
    @Override
    public void setWriteAheadLoggingEnabled(final boolean writeAheadLoggingEnabled) {
        this.a().setWriteAheadLoggingEnabled(writeAheadLoggingEnabled);
    }
}
