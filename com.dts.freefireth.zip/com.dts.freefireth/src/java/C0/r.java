package C0;

import android.util.Log;
import java.util.TreeMap;
import android.app.ActivityManager;
import H0.f;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.ArrayList;
import java.io.File;
import java.util.concurrent.TimeUnit;
import android.content.Intent;
import android.content.Context;
import android.os.Looper;
import java.util.Iterator;
import java.util.Map$Entry;
import D0.b;
import java.util.BitSet;
import kotlin.collections.F;
import kotlin.collections.L;
import java.util.Set;
import java.util.concurrent.locks.ReentrantReadWriteLock$ReadLock;
import java.util.concurrent.locks.Lock;
import kotlin.collections.CollectionsKt;
import G0.k;
import G7.n;
import kotlin.jvm.functions.Function1;
import java.util.concurrent.Callable;
import android.database.Cursor;
import android.os.CancellationSignal;
import G0.j;
import kotlin.jvm.internal.Intrinsics;
import j$.util.DesugarCollections;
import java.util.LinkedHashMap;
import kotlin.jvm.internal.DefaultConstructorMarker;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.Map;
import java.util.List;
import androidx.room.d;
import G0.h;
import java.util.concurrent.Executor;
import G0.g;

public abstract class r
{
    public static final c o;
    protected volatile g a;
    private Executor b;
    private Executor c;
    private h d;
    private final androidx.room.d e;
    private boolean f;
    private boolean g;
    protected List h;
    private Map i;
    private final ReentrantReadWriteLock j;
    private C0.c k;
    private final ThreadLocal l;
    private final Map m;
    private final Map n;
    
    static {
        o = new c(null);
    }
    
    public r() {
        this.e = this.g();
        this.i = (Map)new LinkedHashMap();
        this.j = new ReentrantReadWriteLock();
        this.l = new ThreadLocal();
        final Map synchronizedMap = DesugarCollections.synchronizedMap((Map)new LinkedHashMap());
        Intrinsics.checkNotNullExpressionValue((Object)synchronizedMap, "synchronizedMap(mutableMapOf())");
        this.m = synchronizedMap;
        this.n = (Map)new LinkedHashMap();
    }
    
    private final Object E(final Class clazz, final h obj) {
        if (clazz.isInstance(obj)) {
            return obj;
        }
        if (obj instanceof C0.h) {
            return this.E(clazz, ((C0.h)obj).a());
        }
        return null;
    }
    
    private final void u() {
        this.c();
        final g r0 = this.n().R0();
        this.m().u(r0);
        if (r0.a2()) {
            r0.I0();
            return;
        }
        r0.v();
    }
    
    private final void v() {
        this.n().R0().b1();
        if (!this.s()) {
            this.m().m();
        }
    }
    
    public Object B(final Callable callable) {
        Intrinsics.checkNotNullParameter((Object)callable, "body");
        this.e();
        try {
            final Object call = callable.call();
            this.D();
            return call;
        }
        finally {
            this.i();
        }
    }
    
    public void C(final Runnable runnable) {
        Intrinsics.checkNotNullParameter((Object)runnable, "body");
        this.e();
        try {
            runnable.run();
            this.D();
        }
        finally {
            this.i();
        }
    }
    
    public void D() {
        this.n().R0().F0();
    }
    
    public void c() {
        if (!this.f) {
            if (this.x()) {
                throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.");
            }
        }
    }
    
    public void d() {
        if (!this.s() && this.l.get() != null) {
            throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.");
        }
    }
    
    public void e() {
        this.c();
        final C0.c k = this.k;
        if (k == null) {
            this.u();
            return;
        }
        k.g((Function1)new Function1(this) {
            final r b;
            
            public final Object a(final g g) {
                Intrinsics.checkNotNullParameter((Object)g, "it");
                this.b.u();
                return null;
            }
        });
    }
    
    public k f(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "sql");
        this.c();
        this.d();
        return this.n().R0().T(s);
    }
    
    protected abstract androidx.room.d g();
    
    protected abstract h h(final C0.g p0);
    
    public void i() {
        final C0.c k = this.k;
        if (k == null) {
            this.v();
            return;
        }
        k.g((Function1)new Function1(this) {
            final r b;
            
            public final Object a(final g g) {
                Intrinsics.checkNotNullParameter((Object)g, "it");
                this.b.v();
                return null;
            }
        });
    }
    
    public List j(final Map map) {
        Intrinsics.checkNotNullParameter((Object)map, "autoMigrationSpecs");
        return CollectionsKt.k();
    }
    
    public final Map k() {
        return this.m;
    }
    
    public final Lock l() {
        final ReentrantReadWriteLock$ReadLock lock = this.j.readLock();
        Intrinsics.checkNotNullExpressionValue((Object)lock, "readWriteLock.readLock()");
        return (Lock)lock;
    }
    
    public androidx.room.d m() {
        return this.e;
    }
    
    public h n() {
        h d;
        if ((d = this.d) == null) {
            Intrinsics.q("internalOpenHelper");
            d = null;
        }
        return d;
    }
    
    public Executor o() {
        Executor b;
        if ((b = this.b) == null) {
            Intrinsics.q("internalQueryExecutor");
            b = null;
        }
        return b;
    }
    
    public Set p() {
        return L.e();
    }
    
    protected Map q() {
        return F.i();
    }
    
    public Executor r() {
        Executor c;
        if ((c = this.c) == null) {
            Intrinsics.q("internalTransactionExecutor");
            c = null;
        }
        return c;
    }
    
    public boolean s() {
        return this.n().R0().I1();
    }
    
    public void t(final C0.g g) {
        boolean b = false;
        Intrinsics.checkNotNullParameter((Object)g, "configuration");
        this.d = this.h(g);
        final Set p = this.p();
        final BitSet set = new BitSet();
        for (final Class clazz : p) {
            int n = g.r.size() - 1;
            Label_0129: {
                if (n >= 0) {
                    while (true) {
                        final int n2 = n - 1;
                        if (clazz.isAssignableFrom(g.r.get(n).getClass())) {
                            set.set(n);
                            break Label_0129;
                        }
                        if (n2 < 0) {
                            break;
                        }
                        n = n2;
                    }
                }
                n = -1;
            }
            if (n < 0) {
                final StringBuilder sb = new StringBuilder();
                sb.append("A required auto migration spec (");
                sb.append(clazz.getCanonicalName());
                sb.append(") is missing in the database configuration.");
                throw new IllegalArgumentException(sb.toString().toString());
            }
            this.i.put((Object)clazz, g.r.get(n));
        }
        int n3 = g.r.size() - 1;
        if (n3 >= 0) {
            while (true) {
                final int n4 = n3 - 1;
                if (!set.get(n3)) {
                    throw new IllegalArgumentException("Unexpected auto migration specs found. Annotate AutoMigrationSpec implementation with @ProvidedAutoMigrationSpec annotation or remove this spec from the builder.");
                }
                if (n4 < 0) {
                    break;
                }
                n3 = n4;
            }
        }
        for (final D0.b b2 : this.j(this.i)) {
            if (!g.d.c(b2.a, b2.b)) {
                g.d.b(b2);
            }
        }
        final v v = (v)this.E(v.class, this.n());
        if (v != null) {
            v.d(g);
        }
        final C0.d d = (C0.d)this.E(C0.d.class, this.n());
        if (d != null) {
            this.k = d.b;
            this.m().p(d.b);
        }
        if (g.g == r.d.c) {
            b = true;
        }
        this.n().setWriteAheadLoggingEnabled(b);
        this.h = g.e;
        this.b = g.h;
        this.c = (Executor)new z(g.i);
        this.f = g.f;
        this.g = b;
        if (g.j != null) {
            if (g.b == null) {
                throw new IllegalArgumentException("Required value was null.");
            }
            this.m().q(g.a, g.b, g.j);
        }
        final Map q = this.q();
        final BitSet set2 = new BitSet();
        for (final Map$Entry map$Entry : q.entrySet()) {
            final Class clazz2 = (Class)map$Entry.getKey();
            for (final Class clazz3 : (List)map$Entry.getValue()) {
                int n5 = g.q.size() - 1;
                Label_0686: {
                    if (n5 >= 0) {
                        while (true) {
                            final int n6 = n5 - 1;
                            if (clazz3.isAssignableFrom(g.q.get(n5).getClass())) {
                                set2.set(n5);
                                break Label_0686;
                            }
                            if (n6 < 0) {
                                break;
                            }
                            n5 = n6;
                        }
                    }
                    n5 = -1;
                }
                if (n5 < 0) {
                    final StringBuilder sb2 = new StringBuilder();
                    sb2.append("A required type converter (");
                    sb2.append((Object)clazz3);
                    sb2.append(") for ");
                    sb2.append(clazz2.getCanonicalName());
                    sb2.append(" is missing in the database configuration.");
                    throw new IllegalArgumentException(sb2.toString().toString());
                }
                this.n.put((Object)clazz3, g.q.get(n5));
            }
        }
        int n7 = g.q.size() - 1;
        if (n7 >= 0) {
            while (true) {
                final int n8 = n7 - 1;
                if (!set2.get(n7)) {
                    final Object value = g.q.get(n7);
                    final StringBuilder sb3 = new StringBuilder();
                    sb3.append("Unexpected type converter ");
                    sb3.append(value);
                    sb3.append(". Annotate TypeConverter class with @ProvidedTypeConverter annotation or remove this converter from the builder.");
                    throw new IllegalArgumentException(sb3.toString());
                }
                if (n8 < 0) {
                    break;
                }
                n7 = n8;
            }
        }
    }
    
    protected void w(final g g) {
        Intrinsics.checkNotNullParameter((Object)g, "db");
        this.m().j(g);
    }
    
    public final boolean x() {
        return Looper.getMainLooper().getThread() == Thread.currentThread();
    }
    
    public final boolean y() {
        final g a = this.a;
        return a != null && a.isOpen();
    }
    
    public Cursor z(final j j, final CancellationSignal cancellationSignal) {
        Intrinsics.checkNotNullParameter((Object)j, "query");
        this.c();
        this.d();
        if (cancellationSignal != null) {
            return this.n().R0().f2(j, cancellationSignal);
        }
        return this.n().R0().j0(j);
    }
    
    public static class a
    {
        private final Context a;
        private final Class b;
        private final String c;
        private final List d;
        private final List e;
        private List f;
        private Executor g;
        private Executor h;
        private h.c i;
        private boolean j;
        private d k;
        private Intent l;
        private boolean m;
        private boolean n;
        private long o;
        private TimeUnit p;
        private final e q;
        private Set r;
        private Set s;
        private String t;
        private File u;
        private Callable v;
        
        public a(final Context a, final Class b, final String c) {
            Intrinsics.checkNotNullParameter((Object)a, "context");
            Intrinsics.checkNotNullParameter((Object)b, "klass");
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = (List)new ArrayList();
            this.e = (List)new ArrayList();
            this.f = (List)new ArrayList();
            this.k = d.a;
            this.m = true;
            this.o = -1L;
            this.q = new e();
            this.r = (Set)new LinkedHashSet();
        }
        
        public a a(final b b) {
            Intrinsics.checkNotNullParameter((Object)b, "callback");
            this.d.add((Object)b);
            return this;
        }
        
        public a b(final D0.b... array) {
            Intrinsics.checkNotNullParameter((Object)array, "migrations");
            if (this.s == null) {
                this.s = (Set)new HashSet();
            }
            for (final D0.b b : array) {
                final Set s = this.s;
                Intrinsics.c((Object)s);
                s.add((Object)b.a);
                final Set s2 = this.s;
                Intrinsics.c((Object)s2);
                s2.add((Object)b.b);
            }
            this.q.b((D0.b[])Arrays.copyOf((Object[])array, array.length));
            return this;
        }
        
        public a c() {
            this.j = true;
            return this;
        }
        
        public r d() {
            final Executor g = this.g;
            if (g == null && this.h == null) {
                final Executor f = t.c.f();
                this.h = f;
                this.g = f;
            }
            else if (g != null && this.h == null) {
                this.h = g;
            }
            else if (g == null) {
                this.g = this.h;
            }
            final Set s = this.s;
            if (s != null) {
                Intrinsics.c((Object)s);
                final Iterator iterator = s.iterator();
                while (iterator.hasNext()) {
                    final int intValue = ((Number)iterator.next()).intValue();
                    if (!this.r.contains((Object)intValue)) {
                        continue;
                    }
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Inconsistency detected. A Migration was supplied to addMigration(Migration... migrations) that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(int... startVersions). Start version: ");
                    sb.append(intValue);
                    throw new IllegalArgumentException(sb.toString().toString());
                }
            }
            h.c i;
            if ((i = this.i) == null) {
                i = new H0.f();
            }
            h.c c2 = null;
            Label_0424: {
                if (i != null) {
                    h.c c = i;
                    if (this.o > 0L) {
                        if (this.c == null) {
                            throw new IllegalArgumentException("Cannot create auto-closing database for an in-memory database.");
                        }
                        final long o = this.o;
                        final TimeUnit p = this.p;
                        if (p == null) {
                            throw new IllegalArgumentException("Required value was null.");
                        }
                        final Executor g2 = this.g;
                        if (g2 == null) {
                            throw new IllegalArgumentException("Required value was null.");
                        }
                        c = new C0.e(i, new C0.c(o, p, g2));
                    }
                    final String t = this.t;
                    if (t == null && this.u == null) {
                        c2 = c;
                        if (this.v == null) {
                            break Label_0424;
                        }
                    }
                    if (this.c == null) {
                        throw new IllegalArgumentException("Cannot create from asset or file for an in-memory database.");
                    }
                    int n = 0;
                    int n2;
                    if (t == null) {
                        n2 = 0;
                    }
                    else {
                        n2 = 1;
                    }
                    final File u = this.u;
                    int n3;
                    if (u == null) {
                        n3 = 0;
                    }
                    else {
                        n3 = 1;
                    }
                    final Callable v = this.v;
                    if (v != null) {
                        n = 1;
                    }
                    if (n2 + n3 + n != 1) {
                        throw new IllegalArgumentException("More than one of createFromAsset(), createFromInputStream(), and createFromFile() were called on this Builder, but the database can only be created using one of the three configurations.");
                    }
                    c2 = new w(t, u, v, c);
                }
                else {
                    c2 = null;
                }
            }
            if (c2 == null) {
                throw new IllegalArgumentException("Required value was null.");
            }
            final Context a = this.a;
            final String c3 = this.c;
            final e q = this.q;
            final List d = this.d;
            final boolean j = this.j;
            final d c4 = this.k.c(a);
            final Executor g3 = this.g;
            if (g3 == null) {
                throw new IllegalArgumentException("Required value was null.");
            }
            final Executor h = this.h;
            if (h != null) {
                final C0.g g4 = new C0.g(a, c3, c2, q, d, j, c4, g3, h, this.l, this.m, this.n, this.r, this.t, this.u, this.v, null, this.e, this.f);
                final r r = (r)C0.q.b(this.b, "_Impl");
                r.t(g4);
                return r;
            }
            throw new IllegalArgumentException("Required value was null.");
        }
        
        public a e() {
            this.m = false;
            this.n = true;
            return this;
        }
        
        public a f(final h.c i) {
            this.i = i;
            return this;
        }
        
        public a g(final Executor g) {
            Intrinsics.checkNotNullParameter((Object)g, "executor");
            this.g = g;
            return this;
        }
    }
    
    public abstract static class b
    {
        public void a(final g g) {
            Intrinsics.checkNotNullParameter((Object)g, "db");
        }
        
        public void b(final g g) {
            Intrinsics.checkNotNullParameter((Object)g, "db");
        }
        
        public void c(final g g) {
            Intrinsics.checkNotNullParameter((Object)g, "db");
        }
    }
    
    public static final class c
    {
        private c() {
        }
    }
    
    public enum d
    {
        a("AUTOMATIC", 0), 
        b("TRUNCATE", 1), 
        c("WRITE_AHEAD_LOGGING", 2);
        
        private static final d[] d;
        
        static {
            d = a();
        }
        
        private d(final String s, final int n) {
        }
        
        private static final /* synthetic */ d[] a() {
            return new d[] { r.d.a, r.d.b, r.d.c };
        }
        
        private final boolean b(final ActivityManager activityManager) {
            return G0.c.b(activityManager);
        }
        
        public final d c(final Context context) {
            Intrinsics.checkNotNullParameter((Object)context, "context");
            if (this != r.d.a) {
                return this;
            }
            final Object systemService = context.getSystemService("activity");
            ActivityManager activityManager;
            if (systemService instanceof ActivityManager) {
                activityManager = (ActivityManager)systemService;
            }
            else {
                activityManager = null;
            }
            if (activityManager != null && !this.b(activityManager)) {
                return r.d.c;
            }
            return r.d.b;
        }
    }
    
    public static class e
    {
        private final Map a;
        
        public e() {
            this.a = (Map)new LinkedHashMap();
        }
        
        private final void a(final D0.b b) {
            final int a = b.a;
            final int b2 = b.b;
            final Map a2 = this.a;
            final Integer value = a;
            Object value2;
            if ((value2 = a2.get((Object)value)) == null) {
                value2 = new TreeMap();
                a2.put((Object)value, value2);
            }
            final TreeMap treeMap = (TreeMap)value2;
            if (((Map)treeMap).containsKey((Object)b2)) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Overriding migration ");
                sb.append(treeMap.get((Object)b2));
                sb.append(" with ");
                sb.append((Object)b);
                Log.w("ROOM", sb.toString());
            }
            ((Map)treeMap).put((Object)b2, (Object)b);
        }
        
        private final List e(final List list, final boolean b, int intValue, final int n) {
            boolean b2;
        Label_0199:
            do {
                if (b) {
                    if (intValue >= n) {
                        return list;
                    }
                }
                else if (intValue <= n) {
                    return list;
                }
                final TreeMap treeMap = (TreeMap)this.a.get((Object)intValue);
                if (treeMap == null) {
                    return null;
                }
                Object o;
                if (b) {
                    o = treeMap.descendingKeySet();
                }
                else {
                    o = treeMap.keySet();
                }
                for (final Integer n2 : o) {
                    if (b) {
                        Intrinsics.checkNotNullExpressionValue((Object)n2, "targetVersion");
                        final int intValue2 = n2;
                        if (intValue + 1 > intValue2 || intValue2 > n) {
                            continue;
                        }
                    }
                    else {
                        Intrinsics.checkNotNullExpressionValue((Object)n2, "targetVersion");
                        final int intValue3 = n2;
                        if (n > intValue3 || intValue3 >= intValue) {
                            continue;
                        }
                    }
                    final Object value = treeMap.get((Object)n2);
                    Intrinsics.c(value);
                    list.add(value);
                    intValue = n2;
                    b2 = true;
                    continue Label_0199;
                }
                b2 = false;
            } while (b2);
            return null;
        }
        
        public void b(final D0.b... array) {
            Intrinsics.checkNotNullParameter((Object)array, "migrations");
            for (int length = array.length, i = 0; i < length; ++i) {
                this.a(array[i]);
            }
        }
        
        public final boolean c(final int n, final int n2) {
            final Map f = this.f();
            if (f.containsKey((Object)n)) {
                Map i;
                if ((i = (Map)f.get((Object)n)) == null) {
                    i = F.i();
                }
                return i.containsKey((Object)n2);
            }
            return false;
        }
        
        public List d(final int n, final int n2) {
            if (n == n2) {
                return CollectionsKt.k();
            }
            return this.e((List)new ArrayList(), n2 > n, n, n2);
        }
        
        public Map f() {
            return this.a;
        }
    }
    
    public abstract static class f
    {
    }
}
