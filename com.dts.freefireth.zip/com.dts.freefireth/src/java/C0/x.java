package C0;

import s7.j;
import G0.k;
import G7.n;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import s7.i;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class x
{
    private final r a;
    private final AtomicBoolean b;
    private final i c;
    
    public x(final r a) {
        Intrinsics.checkNotNullParameter((Object)a, "database");
        this.a = a;
        this.b = new AtomicBoolean(false);
        this.c = j.a((Function0)new Function0(this) {
            final x b;
            
            public final k c() {
                return this.b.d();
            }
        });
    }
    
    private final k d() {
        return this.a.f(this.e());
    }
    
    private final k f() {
        return (k)this.c.getValue();
    }
    
    private final k g(final boolean b) {
        if (b) {
            return this.f();
        }
        return this.d();
    }
    
    public k b() {
        this.c();
        return this.g(this.b.compareAndSet(false, true));
    }
    
    protected void c() {
        this.a.c();
    }
    
    protected abstract String e();
    
    public void h(final k k) {
        Intrinsics.checkNotNullParameter((Object)k, "statement");
        if (k == this.f()) {
            this.b.set(false);
        }
    }
}
