package C0;

import kotlin.jvm.internal.Intrinsics;

public final class s
{
    public static final s a;
    
    static {
        a = new s();
    }
    
    private s() {
    }
    
    public static final String a(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "hash");
        final StringBuilder sb = new StringBuilder();
        sb.append("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '");
        sb.append(s);
        sb.append("')");
        return sb.toString();
    }
}
