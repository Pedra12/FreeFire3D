package C0;

import G0.k;
import kotlin.jvm.internal.Intrinsics;

public abstract class j extends x
{
    public j(final r r) {
        Intrinsics.checkNotNullParameter((Object)r, "database");
        super(r);
    }
    
    protected abstract void i(final k p0, final Object p1);
    
    public final void j(final Object o) {
        final k b = this.b();
        try {
            this.i(b, o);
            b.x2();
        }
        finally {
            this.h(b);
        }
    }
}
