package C0;

import java.util.Map;
import java.util.Collections;
import java.util.IdentityHashMap;
import kotlin.jvm.internal.Intrinsics;
import java.util.Set;

public final class l
{
    private final r a;
    private final Set b;
    
    public l(final r a) {
        Intrinsics.checkNotNullParameter((Object)a, "database");
        this.a = a;
        final Set setFromMap = Collections.newSetFromMap((Map)new IdentityHashMap());
        Intrinsics.checkNotNullExpressionValue((Object)setFromMap, "newSetFromMap(IdentityHashMap())");
        this.b = setFromMap;
    }
}
