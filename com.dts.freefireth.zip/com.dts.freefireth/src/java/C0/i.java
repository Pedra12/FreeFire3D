package C0;

import kotlin.jvm.internal.Intrinsics;

public abstract class i extends x
{
    public i(final r r) {
        Intrinsics.checkNotNullParameter((Object)r, "database");
        super(r);
    }
}
