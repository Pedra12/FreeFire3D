package C0;

public enum k
{
    a("ASC", 0), 
    b("DESC", 1);
    
    private static final k[] c;
    
    static {
        c = a();
    }
    
    private k(final String s, final int n) {
    }
    
    private static final /* synthetic */ k[] a() {
        return new k[] { k.a, k.b };
    }
}
