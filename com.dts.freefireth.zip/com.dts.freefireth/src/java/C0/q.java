package C0;

import kotlin.text.StringsKt;
import kotlin.jvm.internal.Intrinsics;
import android.content.Context;

public final class q
{
    public static final q a;
    
    static {
        a = new q();
    }
    
    private q() {
    }
    
    public static final r.a a(final Context context, final Class clazz, final String s) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        Intrinsics.checkNotNullParameter((Object)clazz, "klass");
        if (s != null && !StringsKt.b0((CharSequence)s)) {
            return new r.a(context, clazz, s);
        }
        throw new IllegalArgumentException("Cannot build a database with null or empty name. If you are trying to create an in memory database, use Room.inMemoryDatabaseBuilder");
    }
    
    public static final Object b(final Class clazz, String string) {
        Intrinsics.checkNotNullParameter((Object)clazz, "klass");
        Intrinsics.checkNotNullParameter((Object)string, "suffix");
        final Package package1 = clazz.getPackage();
        Intrinsics.c((Object)package1);
        final String name = package1.getName();
        String s = clazz.getCanonicalName();
        Intrinsics.c((Object)s);
        Intrinsics.checkNotNullExpressionValue((Object)name, "fullPackage");
        if (((CharSequence)name).length() != 0) {
            s = s.substring(name.length() + 1);
            Intrinsics.checkNotNullExpressionValue((Object)s, "this as java.lang.String).substring(startIndex)");
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(StringsKt.E(s, '.', '_', false, 4, (Object)null));
        sb.append(string);
        final String string2 = sb.toString();
        try {
            if (((CharSequence)name).length() == 0) {
                string = string2;
            }
            else {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(name);
                sb2.append('.');
                sb2.append(string2);
                string = sb2.toString();
            }
            final Class<?> forName = Class.forName(string, true, clazz.getClassLoader());
            Intrinsics.d((Object)forName, "null cannot be cast to non-null type java.lang.Class<T of androidx.room.Room.getGeneratedImplementation>");
            return forName.getDeclaredConstructor((Class<?>[])null).newInstance((Object[])null);
        }
        catch (final InstantiationException ex) {
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("Failed to create an instance of ");
            sb3.append(clazz.getCanonicalName());
            throw new RuntimeException(sb3.toString());
        }
        catch (final IllegalAccessException ex2) {
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("Cannot access the constructor ");
            sb4.append(clazz.getCanonicalName());
            throw new RuntimeException(sb4.toString());
        }
        catch (final ClassNotFoundException ex3) {
            final StringBuilder sb5 = new StringBuilder();
            sb5.append("Cannot find implementation for ");
            sb5.append(clazz.getCanonicalName());
            sb5.append(". ");
            sb5.append(string2);
            sb5.append(" does not exist");
            throw new RuntimeException(sb5.toString());
        }
    }
    
    public static final r.a c(final Context context, final Class clazz) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        Intrinsics.checkNotNullParameter((Object)clazz, "klass");
        return new r.a(context, clazz, null);
    }
}
