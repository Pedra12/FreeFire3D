package C0;

import kotlin.jvm.internal.Intrinsics;
import G0.h;

public final class e implements c
{
    private final c a;
    private final C0.c b;
    
    public e(final c a, final C0.c b) {
        Intrinsics.checkNotNullParameter((Object)a, "delegate");
        Intrinsics.checkNotNullParameter((Object)b, "autoCloser");
        this.a = a;
        this.b = b;
    }
    
    public d b(final h.b b) {
        Intrinsics.checkNotNullParameter((Object)b, "configuration");
        return new d(this.a.a(b), this.b);
    }
}
