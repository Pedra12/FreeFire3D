package C0;

import java.io.Closeable;
import kotlin.jvm.functions.Function1;
import kotlin.Unit;
import android.os.SystemClock;
import android.os.Looper;
import kotlin.jvm.internal.Intrinsics;
import java.util.concurrent.TimeUnit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import G0.g;
import java.util.concurrent.Executor;
import android.os.Handler;
import G0.h;

public final class c
{
    public static final a m;
    public h a;
    private final Handler b;
    private Runnable c;
    private final Object d;
    private long e;
    private final Executor f;
    private int g;
    private long h;
    private g i;
    private boolean j;
    private final Runnable k;
    private final Runnable l;
    
    static {
        m = new a(null);
    }
    
    public c(final long n, final TimeUnit timeUnit, final Executor f) {
        Intrinsics.checkNotNullParameter((Object)timeUnit, "autoCloseTimeUnit");
        Intrinsics.checkNotNullParameter((Object)f, "autoCloseExecutor");
        this.b = new Handler(Looper.getMainLooper());
        this.d = new Object();
        this.e = timeUnit.toMillis(n);
        this.f = f;
        this.h = SystemClock.uptimeMillis();
        this.k = (Runnable)new C0.a(this);
        this.l = (Runnable)new b(this);
    }
    
    private static final void c(final c c) {
        Intrinsics.checkNotNullParameter((Object)c, "this$0");
        final Object d;
        monitorenter(d = c.d);
        Label_0152: {
            Object o = null;
            Label_0094: {
                try {
                    if (SystemClock.uptimeMillis() - c.h < c.e) {
                        monitorexit(d);
                        return;
                    }
                    if (c.g != 0) {
                        monitorexit(d);
                        return;
                    }
                    o = c.c;
                    if (o != null) {
                        ((Runnable)o).run();
                        o = Unit.a;
                        break Label_0094;
                    }
                }
                finally {
                    break Label_0152;
                }
                o = null;
            }
            if (o != null) {
                final c c2;
                final g i = c2.i;
                if (i != null && i.isOpen()) {
                    ((Closeable)i).close();
                }
                c2.i = null;
                final Unit a = Unit.a;
                monitorexit(d);
                return;
            }
            throw new IllegalStateException("onAutoCloseCallback is null but it should have been set before use. Please file a bug against Room at: https://issuetracker.google.com/issues/new?component=413107&template=1096568");
        }
        monitorexit(d);
    }
    
    private static final void f(final c c) {
        Intrinsics.checkNotNullParameter((Object)c, "this$0");
        c.f.execute(c.l);
    }
    
    public final void d() {
        final Object d;
        monitorenter(d = this.d);
        Label_0048: {
            try {
                this.j = true;
                final g i = this.i;
                if (i != null) {
                    ((Closeable)i).close();
                }
            }
            finally {
                break Label_0048;
            }
            this.i = null;
            final Unit a = Unit.a;
            monitorexit(d);
            return;
        }
        monitorexit(d);
    }
    
    public final void e() {
        final Object d;
        monitorenter(d = this.d);
        Label_0087: {
            try {
                int g = this.g;
                if (g <= 0) {
                    throw new IllegalStateException("ref count is 0 or lower but we're supposed to decrement");
                }
                --g;
                if ((this.g = g) == 0) {
                    if (this.i == null) {
                        monitorexit(d);
                        return;
                    }
                    this.b.postDelayed(this.k, this.e);
                }
            }
            finally {
                break Label_0087;
            }
            final Unit a = Unit.a;
            monitorexit(d);
            return;
        }
        monitorexit(d);
    }
    
    public final Object g(final Function1 function1) {
        Intrinsics.checkNotNullParameter((Object)function1, "block");
        try {
            return function1.invoke((Object)this.j());
        }
        finally {
            this.e();
        }
    }
    
    public final g h() {
        return this.i;
    }
    
    public final h i() {
        final h a = this.a;
        if (a != null) {
            return a;
        }
        Intrinsics.q("delegateOpenHelper");
        return null;
    }
    
    public final g j() {
        final Object d;
        monitorenter(d = this.d);
        Label_0099: {
            try {
                this.b.removeCallbacks(this.k);
                ++this.g;
                if (this.j) {
                    throw new IllegalStateException("Attempting to open already closed database.");
                }
                final g i = this.i;
                if (i != null && i.isOpen()) {
                    monitorexit(d);
                    return i;
                }
            }
            finally {
                break Label_0099;
            }
            final g r0 = this.i().R0();
            this.i = r0;
            monitorexit(d);
            return r0;
        }
        monitorexit(d);
    }
    
    public final void k(final h h) {
        Intrinsics.checkNotNullParameter((Object)h, "delegateOpenHelper");
        this.m(h);
    }
    
    public final void l(final Runnable c) {
        Intrinsics.checkNotNullParameter((Object)c, "onAutoClose");
        this.c = c;
    }
    
    public final void m(final h a) {
        Intrinsics.checkNotNullParameter((Object)a, "<set-?>");
        this.a = a;
    }
    
    public static final class a
    {
        private a() {
        }
    }
}
