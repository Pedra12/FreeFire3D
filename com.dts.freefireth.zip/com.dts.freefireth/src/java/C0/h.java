package C0;

public interface h
{
    G0.h a();
}
