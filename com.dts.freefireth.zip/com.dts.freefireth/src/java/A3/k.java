package a3;

import java.util.List;

final class k extends u
{
    private final long a;
    private final long b;
    private final o c;
    private final Integer d;
    private final String e;
    private final List f;
    private final x g;
    
    private k(final long a, final long b, final o c, final Integer d, final String e, final List f, final x g) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
    }
    
    @Override
    public o b() {
        return this.c;
    }
    
    @Override
    public List c() {
        return this.f;
    }
    
    @Override
    public Integer d() {
        return this.d;
    }
    
    @Override
    public String e() {
        return this.e;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof u) {
            final u u = (u)o;
            if (this.a == u.g() && this.b == u.h()) {
                final o c = this.c;
                if (c == null) {
                    if (u.b() != null) {
                        return false;
                    }
                }
                else if (!c.equals(u.b())) {
                    return false;
                }
                final Integer d = this.d;
                if (d == null) {
                    if (u.d() != null) {
                        return false;
                    }
                }
                else if (!d.equals((Object)u.d())) {
                    return false;
                }
                final String e = this.e;
                if (e == null) {
                    if (u.e() != null) {
                        return false;
                    }
                }
                else if (!e.equals((Object)u.e())) {
                    return false;
                }
                final List f = this.f;
                if (f == null) {
                    if (u.c() != null) {
                        return false;
                    }
                }
                else if (!f.equals((Object)u.c())) {
                    return false;
                }
                final x g = this.g;
                if (g == null) {
                    if (u.f() != null) {
                        return false;
                    }
                }
                else if (!g.equals(u.f())) {
                    return false;
                }
                return true;
            }
        }
        return false;
    }
    
    @Override
    public x f() {
        return this.g;
    }
    
    @Override
    public long g() {
        return this.a;
    }
    
    @Override
    public long h() {
        return this.b;
    }
    
    @Override
    public int hashCode() {
        final long a = this.a;
        final int n = (int)(a ^ a >>> 32);
        final long b = this.b;
        final int n2 = (int)(b ^ b >>> 32);
        final o c = this.c;
        int hashCode = 0;
        int hashCode2;
        if (c == null) {
            hashCode2 = 0;
        }
        else {
            hashCode2 = c.hashCode();
        }
        final Integer d = this.d;
        int hashCode3;
        if (d == null) {
            hashCode3 = 0;
        }
        else {
            hashCode3 = d.hashCode();
        }
        final String e = this.e;
        int hashCode4;
        if (e == null) {
            hashCode4 = 0;
        }
        else {
            hashCode4 = e.hashCode();
        }
        final List f = this.f;
        int hashCode5;
        if (f == null) {
            hashCode5 = 0;
        }
        else {
            hashCode5 = f.hashCode();
        }
        final x g = this.g;
        if (g != null) {
            hashCode = g.hashCode();
        }
        return ((((((n ^ 0xF4243) * 1000003 ^ n2) * 1000003 ^ hashCode2) * 1000003 ^ hashCode3) * 1000003 ^ hashCode4) * 1000003 ^ hashCode5) * 1000003 ^ hashCode;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("LogRequest{requestTimeMs=");
        sb.append(this.a);
        sb.append(", requestUptimeMs=");
        sb.append(this.b);
        sb.append(", clientInfo=");
        sb.append((Object)this.c);
        sb.append(", logSource=");
        sb.append((Object)this.d);
        sb.append(", logSourceName=");
        sb.append(this.e);
        sb.append(", logEvents=");
        sb.append((Object)this.f);
        sb.append(", qosTier=");
        sb.append((Object)this.g);
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends a
    {
        private Long a;
        private Long b;
        private o c;
        private Integer d;
        private String e;
        private List f;
        private x g;
        
        @Override
        public u a() {
            final Long a = this.a;
            String string = "";
            if (a == null) {
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(" requestTimeMs");
                string = sb.toString();
            }
            String string2 = string;
            if (this.b == null) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(string);
                sb2.append(" requestUptimeMs");
                string2 = sb2.toString();
            }
            if (string2.isEmpty()) {
                return new k(this.a, this.b, this.c, this.d, this.e, this.f, this.g, null);
            }
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("Missing required properties:");
            sb3.append(string2);
            throw new IllegalStateException(sb3.toString());
        }
        
        @Override
        public a b(final o c) {
            this.c = c;
            return this;
        }
        
        @Override
        public a c(final List f) {
            this.f = f;
            return this;
        }
        
        @Override
        a d(final Integer d) {
            this.d = d;
            return this;
        }
        
        @Override
        a e(final String e) {
            this.e = e;
            return this;
        }
        
        @Override
        public a f(final x g) {
            this.g = g;
            return this;
        }
        
        @Override
        public a g(final long n) {
            this.a = n;
            return this;
        }
        
        @Override
        public a h(final long n) {
            this.b = n;
            return this;
        }
    }
}
