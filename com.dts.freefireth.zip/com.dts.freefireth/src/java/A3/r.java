package a3;

public abstract class r
{
    public static a a() {
        return (a)new h.b();
    }
    
    public abstract Integer b();
    
    public abstract static class a
    {
        public abstract r a();
        
        public abstract a b(final Integer p0);
    }
}
