package a3;

import java.util.Arrays;

final class j extends t
{
    private final long a;
    private final Integer b;
    private final p c;
    private final long d;
    private final byte[] e;
    private final String f;
    private final long g;
    private final w h;
    private final q i;
    
    private j(final long a, final Integer b, final p c, final long d, final byte[] e, final String f, final long g, final w h, final q i) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
    }
    
    @Override
    public p b() {
        return this.c;
    }
    
    @Override
    public Integer c() {
        return this.b;
    }
    
    @Override
    public long d() {
        return this.a;
    }
    
    @Override
    public long e() {
        return this.d;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof t) {
            final t t = (t)o;
            if (this.a == t.d()) {
                final Integer b = this.b;
                if (b == null) {
                    if (t.c() != null) {
                        return false;
                    }
                }
                else if (!b.equals((Object)t.c())) {
                    return false;
                }
                final p c = this.c;
                if (c == null) {
                    if (t.b() != null) {
                        return false;
                    }
                }
                else if (!c.equals(t.b())) {
                    return false;
                }
                if (this.d == t.e()) {
                    final byte[] e = this.e;
                    byte[] array;
                    if (t instanceof j) {
                        array = ((j)t).e;
                    }
                    else {
                        array = t.h();
                    }
                    if (Arrays.equals(e, array)) {
                        final String f = this.f;
                        if (f == null) {
                            if (t.i() != null) {
                                return false;
                            }
                        }
                        else if (!f.equals((Object)t.i())) {
                            return false;
                        }
                        if (this.g == t.j()) {
                            final w h = this.h;
                            if (h == null) {
                                if (t.g() != null) {
                                    return false;
                                }
                            }
                            else if (!h.equals(t.g())) {
                                return false;
                            }
                            final q i = this.i;
                            if (i == null) {
                                if (t.f() != null) {
                                    return false;
                                }
                            }
                            else if (!i.equals(t.f())) {
                                return false;
                            }
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    
    @Override
    public q f() {
        return this.i;
    }
    
    @Override
    public w g() {
        return this.h;
    }
    
    @Override
    public byte[] h() {
        return this.e;
    }
    
    @Override
    public int hashCode() {
        final long a = this.a;
        final int n = (int)(a ^ a >>> 32);
        final Integer b = this.b;
        int hashCode = 0;
        int hashCode2;
        if (b == null) {
            hashCode2 = 0;
        }
        else {
            hashCode2 = b.hashCode();
        }
        final p c = this.c;
        int hashCode3;
        if (c == null) {
            hashCode3 = 0;
        }
        else {
            hashCode3 = c.hashCode();
        }
        final long d = this.d;
        final int n2 = (int)(d ^ d >>> 32);
        final int hashCode4 = Arrays.hashCode(this.e);
        final String f = this.f;
        int hashCode5;
        if (f == null) {
            hashCode5 = 0;
        }
        else {
            hashCode5 = f.hashCode();
        }
        final long g = this.g;
        final int n3 = (int)(g >>> 32 ^ g);
        final w h = this.h;
        int hashCode6;
        if (h == null) {
            hashCode6 = 0;
        }
        else {
            hashCode6 = h.hashCode();
        }
        final q i = this.i;
        if (i != null) {
            hashCode = i.hashCode();
        }
        return ((((((((n ^ 0xF4243) * 1000003 ^ hashCode2) * 1000003 ^ hashCode3) * 1000003 ^ n2) * 1000003 ^ hashCode4) * 1000003 ^ hashCode5) * 1000003 ^ n3) * 1000003 ^ hashCode6) * 1000003 ^ hashCode;
    }
    
    @Override
    public String i() {
        return this.f;
    }
    
    @Override
    public long j() {
        return this.g;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("LogEvent{eventTimeMs=");
        sb.append(this.a);
        sb.append(", eventCode=");
        sb.append((Object)this.b);
        sb.append(", complianceData=");
        sb.append((Object)this.c);
        sb.append(", eventUptimeMs=");
        sb.append(this.d);
        sb.append(", sourceExtension=");
        sb.append(Arrays.toString(this.e));
        sb.append(", sourceExtensionJsonProto3=");
        sb.append(this.f);
        sb.append(", timezoneOffsetSeconds=");
        sb.append(this.g);
        sb.append(", networkConnectionInfo=");
        sb.append((Object)this.h);
        sb.append(", experimentIds=");
        sb.append((Object)this.i);
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends a
    {
        private Long a;
        private Integer b;
        private p c;
        private Long d;
        private byte[] e;
        private String f;
        private Long g;
        private w h;
        private q i;
        
        @Override
        public t a() {
            final Long a = this.a;
            String string = "";
            if (a == null) {
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(" eventTimeMs");
                string = sb.toString();
            }
            String string2 = string;
            if (this.d == null) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(string);
                sb2.append(" eventUptimeMs");
                string2 = sb2.toString();
            }
            String string3 = string2;
            if (this.g == null) {
                final StringBuilder sb3 = new StringBuilder();
                sb3.append(string2);
                sb3.append(" timezoneOffsetSeconds");
                string3 = sb3.toString();
            }
            if (string3.isEmpty()) {
                return new j(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, null);
            }
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("Missing required properties:");
            sb4.append(string3);
            throw new IllegalStateException(sb4.toString());
        }
        
        @Override
        public a b(final p c) {
            this.c = c;
            return this;
        }
        
        @Override
        public a c(final Integer b) {
            this.b = b;
            return this;
        }
        
        @Override
        public a d(final long n) {
            this.a = n;
            return this;
        }
        
        @Override
        public a e(final long n) {
            this.d = n;
            return this;
        }
        
        @Override
        public a f(final q i) {
            this.i = i;
            return this;
        }
        
        @Override
        public a g(final w h) {
            this.h = h;
            return this;
        }
        
        @Override
        a h(final byte[] e) {
            this.e = e;
            return this;
        }
        
        @Override
        a i(final String f) {
            this.f = f;
            return this;
        }
        
        @Override
        public a j(final long n) {
            this.g = n;
            return this;
        }
    }
}
