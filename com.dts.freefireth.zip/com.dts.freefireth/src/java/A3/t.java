package a3;

public abstract class t
{
    private static a a() {
        return (a)new j.b();
    }
    
    public static a k(final String s) {
        return a().i(s);
    }
    
    public static a l(final byte[] array) {
        return a().h(array);
    }
    
    public abstract p b();
    
    public abstract Integer c();
    
    public abstract long d();
    
    public abstract long e();
    
    public abstract q f();
    
    public abstract w g();
    
    public abstract byte[] h();
    
    public abstract String i();
    
    public abstract long j();
    
    public abstract static class a
    {
        public abstract t a();
        
        public abstract a b(final p p0);
        
        public abstract a c(final Integer p0);
        
        public abstract a d(final long p0);
        
        public abstract a e(final long p0);
        
        public abstract a f(final q p0);
        
        public abstract a g(final w p0);
        
        abstract a h(final byte[] p0);
        
        abstract a i(final String p0);
        
        public abstract a j(final long p0);
    }
}
