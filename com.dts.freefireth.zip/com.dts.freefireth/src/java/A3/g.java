package a3;

import java.util.Arrays;

final class g extends q
{
    private final byte[] a;
    private final byte[] b;
    
    private g(final byte[] a, final byte[] b) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public byte[] b() {
        return this.a;
    }
    
    @Override
    public byte[] c() {
        return this.b;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof q) {
            final q q = (q)o;
            final byte[] a = this.a;
            final boolean b = q instanceof g;
            byte[] array;
            if (b) {
                array = ((g)q).a;
            }
            else {
                array = q.b();
            }
            if (Arrays.equals(a, array)) {
                final byte[] b2 = this.b;
                byte[] array2;
                if (b) {
                    array2 = ((g)q).b;
                }
                else {
                    array2 = q.c();
                }
                if (Arrays.equals(b2, array2)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return (Arrays.hashCode(this.a) ^ 0xF4243) * 1000003 ^ Arrays.hashCode(this.b);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("ExperimentIds{clearBlob=");
        sb.append(Arrays.toString(this.a));
        sb.append(", encryptedBlob=");
        sb.append(Arrays.toString(this.b));
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends a
    {
        private byte[] a;
        private byte[] b;
        
        @Override
        public q a() {
            return new g(this.a, this.b, null);
        }
        
        @Override
        public a b(final byte[] a) {
            this.a = a;
            return this;
        }
        
        @Override
        public a c(final byte[] b) {
            this.b = b;
            return this;
        }
    }
}
