package a3;

final class i extends s
{
    private final r a;
    
    private i(final r a) {
        this.a = a;
    }
    
    @Override
    public r b() {
        return this.a;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof s)) {
            return false;
        }
        final s s = (s)o;
        final r a = this.a;
        final r b = s.b();
        if (a == null) {
            return b == null;
        }
        return a.equals(b);
    }
    
    @Override
    public int hashCode() {
        final r a = this.a;
        int hashCode;
        if (a == null) {
            hashCode = 0;
        }
        else {
            hashCode = a.hashCode();
        }
        return hashCode ^ 0xF4243;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("ExternalPrivacyContext{prequest=");
        sb.append((Object)this.a);
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends a
    {
        private r a;
        
        @Override
        public s a() {
            return new i(this.a, null);
        }
        
        @Override
        public a b(final r a) {
            this.a = a;
            return this;
        }
    }
}
