package a3;

final class e extends o
{
    private final o.b a;
    private final a3.a b;
    
    private e(final o.b a, final a3.a b) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public a3.a b() {
        return this.b;
    }
    
    @Override
    public o.b c() {
        return this.a;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof o) {
            final o o2 = (o)o;
            final o.b a = this.a;
            if (a == null) {
                if (o2.c() != null) {
                    return false;
                }
            }
            else if (!a.equals(o2.c())) {
                return false;
            }
            final a3.a b = this.b;
            if (b == null) {
                if (o2.b() != null) {
                    return false;
                }
            }
            else if (!b.equals(o2.b())) {
                return false;
            }
            return true;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        final o.b a = this.a;
        int hashCode = 0;
        int hashCode2;
        if (a == null) {
            hashCode2 = 0;
        }
        else {
            hashCode2 = a.hashCode();
        }
        final a3.a b = this.b;
        if (b != null) {
            hashCode = b.hashCode();
        }
        return (hashCode2 ^ 0xF4243) * 1000003 ^ hashCode;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("ClientInfo{clientType=");
        sb.append((Object)this.a);
        sb.append(", androidClientInfo=");
        sb.append((Object)this.b);
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends a
    {
        private o.b a;
        private a3.a b;
        
        @Override
        public o a() {
            return new e(this.a, this.b, null);
        }
        
        @Override
        public a b(final a3.a b) {
            this.b = b;
            return this;
        }
        
        @Override
        public a c(final o.b a) {
            this.a = a;
            return this;
        }
    }
}
