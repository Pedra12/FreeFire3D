package a3;

public abstract class o
{
    public static a a() {
        return (a)new e.b();
    }
    
    public abstract a3.a b();
    
    public abstract b c();
    
    public abstract static class a
    {
        public abstract o a();
        
        public abstract a b(final a3.a p0);
        
        public abstract a c(final b p0);
    }
    
    public enum b
    {
        b("UNKNOWN", 0, 0), 
        c("ANDROID_FIREBASE", 1, 23);
        
        private static final b[] d;
        private final int a;
        
        private b(final String s, final int n, final int a) {
            this.a = a;
        }
    }
}
