package a3;

final class l extends v
{
    private final long a;
    
    l(final long a) {
        this.a = a;
    }
    
    @Override
    public long c() {
        return this.a;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o == this || (o instanceof v && this.a == ((v)o).c());
    }
    
    @Override
    public int hashCode() {
        final long a = this.a;
        return 0xF4243 ^ (int)(a ^ a >>> 32);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("LogResponse{nextRequestWaitMillis=");
        sb.append(this.a);
        sb.append("}");
        return sb.toString();
    }
}
