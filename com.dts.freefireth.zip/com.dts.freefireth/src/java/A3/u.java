package a3;

import java.util.List;

public abstract class u
{
    public static a a() {
        return (a)new k.b();
    }
    
    public abstract o b();
    
    public abstract List c();
    
    public abstract Integer d();
    
    public abstract String e();
    
    public abstract x f();
    
    public abstract long g();
    
    public abstract long h();
    
    public abstract static class a
    {
        public abstract u a();
        
        public abstract a b(final o p0);
        
        public abstract a c(final List p0);
        
        abstract a d(final Integer p0);
        
        abstract a e(final String p0);
        
        public abstract a f(final x p0);
        
        public abstract a g(final long p0);
        
        public abstract a h(final long p0);
        
        public a i(final int n) {
            return this.d(n);
        }
        
        public a j(final String s) {
            return this.e(s);
        }
    }
}
