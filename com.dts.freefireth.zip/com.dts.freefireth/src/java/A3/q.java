package a3;

public abstract class q
{
    public static a a() {
        return (a)new g.b();
    }
    
    public abstract byte[] b();
    
    public abstract byte[] c();
    
    public abstract static class a
    {
        public abstract q a();
        
        public abstract a b(final byte[] p0);
        
        public abstract a c(final byte[] p0);
    }
}
