package a3;

import android.util.SparseArray;

public abstract class w
{
    public static a a() {
        return (a)new m.b();
    }
    
    public abstract b b();
    
    public abstract c c();
    
    public abstract static class a
    {
        public abstract w a();
        
        public abstract a b(final b p0);
        
        public abstract a c(final c p0);
    }
    
    public enum b
    {
        W0("IWLAN", 18, 18), 
        X("HSPAP", 15, 15), 
        X0("LTE_CA", 19, 19), 
        Y("GSM", 16, 16), 
        Y0("COMBINED", 20, 100), 
        Z("TD_SCDMA", 17, 17);
        
        private static final SparseArray Z0;
        private static final b[] a1;
        
        b("UNKNOWN_MOBILE_SUBTYPE", 0, 0), 
        c("GPRS", 1, 1), 
        d("EDGE", 2, 2), 
        e("UMTS", 3, 3), 
        f("CDMA", 4, 4), 
        g("EVDO_0", 5, 5), 
        h("EVDO_A", 6, 6), 
        i("RTT", 7, 7), 
        j("HSDPA", 8, 8), 
        k("HSUPA", 9, 9), 
        l("HSPA", 10, 10), 
        v("IDEN", 11, 11), 
        w("EVDO_B", 12, 12), 
        x("LTE", 13, 13), 
        y("EHRPD", 14, 14);
        
        private final int a;
        
        static {
            final SparseArray z0 = new SparseArray();
            final b b2;
            (Z0 = z0).put(0, (Object)b2);
            final b b3;
            z0.put(1, (Object)b3);
            final b b4;
            z0.put(2, (Object)b4);
            final b b5;
            z0.put(3, (Object)b5);
            final b b6;
            z0.put(4, (Object)b6);
            final b b7;
            z0.put(5, (Object)b7);
            final b b8;
            z0.put(6, (Object)b8);
            final b b9;
            z0.put(7, (Object)b9);
            final b b10;
            z0.put(8, (Object)b10);
            final b b11;
            z0.put(9, (Object)b11);
            final b b12;
            z0.put(10, (Object)b12);
            final b b13;
            z0.put(11, (Object)b13);
            final b b14;
            z0.put(12, (Object)b14);
            final b b15;
            z0.put(13, (Object)b15);
            final b b16;
            z0.put(14, (Object)b16);
            final b b17;
            z0.put(15, (Object)b17);
            final b b18;
            z0.put(16, (Object)b18);
            final b b19;
            z0.put(17, (Object)b19);
            final b b20;
            z0.put(18, (Object)b20);
            final b b21;
            z0.put(19, (Object)b21);
        }
        
        private b(final String s, final int n, final int a) {
            this.a = a;
        }
        
        public static b a(final int n) {
            return (b)b.Z0.get(n);
        }
        
        public int b() {
            return this.a;
        }
    }
    
    public enum c
    {
        W0("NONE", 18, -1), 
        X("MOBILE_EMERGENCY", 15, 15);
        
        private static final SparseArray X0;
        
        Y("PROXY", 16, 16);
        
        private static final c[] Y0;
        
        Z("VPN", 17, 17), 
        b("MOBILE", 0, 0), 
        c("WIFI", 1, 1), 
        d("MOBILE_MMS", 2, 2), 
        e("MOBILE_SUPL", 3, 3), 
        f("MOBILE_DUN", 4, 4), 
        g("MOBILE_HIPRI", 5, 5), 
        h("WIMAX", 6, 6), 
        i("BLUETOOTH", 7, 7), 
        j("DUMMY", 8, 8), 
        k("ETHERNET", 9, 9), 
        l("MOBILE_FOTA", 10, 10), 
        v("MOBILE_IMS", 11, 11), 
        w("MOBILE_CBS", 12, 12), 
        x("WIFI_P2P", 13, 13), 
        y("MOBILE_IA", 14, 14);
        
        private final int a;
        
        static {
            final c c2;
            final c c3;
            final c c4;
            final c c5;
            final c c6;
            final c c7;
            final c c8;
            final c c9;
            final c c10;
            final c c11;
            final c c12;
            final c c13;
            final c c14;
            final c c15;
            final c c16;
            final c c17;
            final c c18;
            final c c19;
            final c c20;
            Y0 = new c[] { c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, c15, c16, c17, c18, c19, c20 };
            final SparseArray x2 = new SparseArray();
            (X0 = x2).put(0, (Object)c2);
            x2.put(1, (Object)c3);
            x2.put(2, (Object)c4);
            x2.put(3, (Object)c5);
            x2.put(4, (Object)c6);
            x2.put(5, (Object)c7);
            x2.put(6, (Object)c8);
            x2.put(7, (Object)c9);
            x2.put(8, (Object)c10);
            x2.put(9, (Object)c11);
            x2.put(10, (Object)c12);
            x2.put(11, (Object)c13);
            x2.put(12, (Object)c14);
            x2.put(13, (Object)c15);
            x2.put(14, (Object)c16);
            x2.put(15, (Object)c17);
            x2.put(16, (Object)c18);
            x2.put(17, (Object)c19);
            x2.put(-1, (Object)c20);
        }
        
        private c(final String s, final int n, final int a) {
            this.a = a;
        }
        
        public static c a(final int n) {
            return (c)c.X0.get(n);
        }
        
        public int b() {
            return this.a;
        }
    }
}
