package a3;

final class f extends p
{
    private final s a;
    private final p.b b;
    
    private f(final s a, final p.b b) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public s b() {
        return this.a;
    }
    
    @Override
    public p.b c() {
        return this.b;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof p) {
            final p p = (p)o;
            final s a = this.a;
            if (a == null) {
                if (p.b() != null) {
                    return false;
                }
            }
            else if (!a.equals(p.b())) {
                return false;
            }
            final p.b b = this.b;
            if (b == null) {
                if (p.c() != null) {
                    return false;
                }
            }
            else if (!b.equals(p.c())) {
                return false;
            }
            return true;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        final s a = this.a;
        int hashCode = 0;
        int hashCode2;
        if (a == null) {
            hashCode2 = 0;
        }
        else {
            hashCode2 = a.hashCode();
        }
        final p.b b = this.b;
        if (b != null) {
            hashCode = b.hashCode();
        }
        return (hashCode2 ^ 0xF4243) * 1000003 ^ hashCode;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("ComplianceData{privacyContext=");
        sb.append((Object)this.a);
        sb.append(", productIdOrigin=");
        sb.append((Object)this.b);
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends a
    {
        private s a;
        private p.b b;
        
        @Override
        public p a() {
            return new f(this.a, this.b, null);
        }
        
        @Override
        public a b(final s a) {
            this.a = a;
            return this;
        }
        
        @Override
        public a c(final p.b b) {
            this.b = b;
            return this;
        }
    }
}
