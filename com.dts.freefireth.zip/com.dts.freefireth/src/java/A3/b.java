package a3;

import G5.d;
import H5.a;

public final class b implements H5.a
{
    public static final H5.a a;
    
    static {
        a = (H5.a)new b();
    }
    
    private b() {
    }
    
    public void a(final b b) {
        final b a = b.a;
        b.a((Class)n.class, (G5.d)a);
        b.a((Class)a3.d.class, (G5.d)a);
        final i a2 = i.a;
        b.a((Class)u.class, (G5.d)a2);
        b.a((Class)k.class, (G5.d)a2);
        final c a3 = c.a;
        b.a((Class)o.class, (G5.d)a3);
        b.a((Class)a3.e.class, (G5.d)a3);
        final a a4 = a3.b.a.a;
        b.a((Class)a3.a.class, (G5.d)a4);
        b.a((Class)a3.c.class, (G5.d)a4);
        final h a5 = h.a;
        b.a((Class)t.class, (G5.d)a5);
        b.a((Class)a3.j.class, (G5.d)a5);
        final d a6 = d.a;
        b.a((Class)p.class, (G5.d)a6);
        b.a((Class)a3.f.class, (G5.d)a6);
        final g a7 = g.a;
        b.a((Class)s.class, (G5.d)a7);
        b.a((Class)a3.i.class, (G5.d)a7);
        final f a8 = f.a;
        b.a((Class)r.class, (G5.d)a8);
        b.a((Class)a3.h.class, (G5.d)a8);
        final j a9 = j.a;
        b.a((Class)w.class, (G5.d)a9);
        b.a((Class)m.class, (G5.d)a9);
        final e a10 = e.a;
        b.a((Class)q.class, (G5.d)a10);
        b.a((Class)a3.g.class, (G5.d)a10);
    }
    
    private static final class a implements G5.d
    {
        static final a a;
        private static final G5.c b;
        private static final G5.c c;
        private static final G5.c d;
        private static final G5.c e;
        private static final G5.c f;
        private static final G5.c g;
        private static final G5.c h;
        private static final G5.c i;
        private static final G5.c j;
        private static final G5.c k;
        private static final G5.c l;
        private static final G5.c m;
        
        static {
            a = new a();
            b = G5.c.d("sdkVersion");
            c = G5.c.d("model");
            d = G5.c.d("hardware");
            e = G5.c.d("device");
            f = G5.c.d("product");
            g = G5.c.d("osBuild");
            h = G5.c.d("manufacturer");
            i = G5.c.d("fingerprint");
            j = G5.c.d("locale");
            k = G5.c.d("country");
            l = G5.c.d("mccMnc");
            m = G5.c.d("applicationBuild");
        }
        
        public void b(final a3.a a, final G5.e e) {
            e.a(a3.b.a.b, (Object)a.m());
            e.a(a3.b.a.c, (Object)a.j());
            e.a(a3.b.a.d, (Object)a.f());
            e.a(a3.b.a.e, (Object)a.d());
            e.a(a3.b.a.f, (Object)a.l());
            e.a(a3.b.a.g, (Object)a.k());
            e.a(a3.b.a.h, (Object)a.h());
            e.a(a3.b.a.i, (Object)a.e());
            e.a(a3.b.a.j, (Object)a.g());
            e.a(a3.b.a.k, (Object)a.c());
            e.a(a3.b.a.l, (Object)a.i());
            e.a(a3.b.a.m, (Object)a.b());
        }
    }
    
    private static final class b implements G5.d
    {
        static final b a;
        private static final G5.c b;
        
        static {
            a = new b();
            b = G5.c.d("logRequest");
        }
        
        public void b(final n n, final G5.e e) {
            e.a(a3.b.b.b, (Object)n.c());
        }
    }
    
    private static final class c implements G5.d
    {
        static final c a;
        private static final G5.c b;
        private static final G5.c c;
        
        static {
            a = new c();
            b = G5.c.d("clientType");
            c = G5.c.d("androidClientInfo");
        }
        
        public void b(final o o, final G5.e e) {
            e.a(a3.b.c.b, (Object)o.c());
            e.a(a3.b.c.c, (Object)o.b());
        }
    }
    
    private static final class d implements G5.d
    {
        static final d a;
        private static final G5.c b;
        private static final G5.c c;
        
        static {
            a = new d();
            b = G5.c.d("privacyContext");
            c = G5.c.d("productIdOrigin");
        }
        
        public void b(final p p2, final G5.e e) {
            e.a(d.b, (Object)p2.b());
            e.a(d.c, (Object)p2.c());
        }
    }
    
    private static final class e implements G5.d
    {
        static final e a;
        private static final G5.c b;
        private static final G5.c c;
        
        static {
            a = new e();
            b = G5.c.d("clearBlob");
            c = G5.c.d("encryptedBlob");
        }
        
        public void b(final q q, final G5.e e) {
            e.a(a3.b.e.b, (Object)q.b());
            e.a(a3.b.e.c, (Object)q.c());
        }
    }
    
    private static final class f implements G5.d
    {
        static final f a;
        private static final G5.c b;
        
        static {
            a = new f();
            b = G5.c.d("originAssociatedProductId");
        }
        
        public void b(final r r, final G5.e e) {
            e.a(f.b, (Object)r.b());
        }
    }
    
    private static final class g implements G5.d
    {
        static final g a;
        private static final G5.c b;
        
        static {
            a = new g();
            b = G5.c.d("prequest");
        }
        
        public void b(final s s, final G5.e e) {
            e.a(g.b, (Object)s.b());
        }
    }
    
    private static final class h implements G5.d
    {
        static final h a;
        private static final G5.c b;
        private static final G5.c c;
        private static final G5.c d;
        private static final G5.c e;
        private static final G5.c f;
        private static final G5.c g;
        private static final G5.c h;
        private static final G5.c i;
        private static final G5.c j;
        
        static {
            a = new h();
            b = G5.c.d("eventTimeMs");
            c = G5.c.d("eventCode");
            d = G5.c.d("complianceData");
            e = G5.c.d("eventUptimeMs");
            f = G5.c.d("sourceExtension");
            g = G5.c.d("sourceExtensionJsonProto3");
            h = G5.c.d("timezoneOffsetSeconds");
            i = G5.c.d("networkConnectionInfo");
            j = G5.c.d("experimentIds");
        }
        
        public void b(final t t, final G5.e e) {
            e.c(a3.b.h.b, t.d());
            e.a(a3.b.h.c, (Object)t.c());
            e.a(a3.b.h.d, (Object)t.b());
            e.c(a3.b.h.e, t.e());
            e.a(a3.b.h.f, (Object)t.h());
            e.a(a3.b.h.g, (Object)t.i());
            e.c(a3.b.h.h, t.j());
            e.a(a3.b.h.i, (Object)t.g());
            e.a(a3.b.h.j, (Object)t.f());
        }
    }
    
    private static final class i implements G5.d
    {
        static final i a;
        private static final G5.c b;
        private static final G5.c c;
        private static final G5.c d;
        private static final G5.c e;
        private static final G5.c f;
        private static final G5.c g;
        private static final G5.c h;
        
        static {
            a = new i();
            b = G5.c.d("requestTimeMs");
            c = G5.c.d("requestUptimeMs");
            d = G5.c.d("clientInfo");
            e = G5.c.d("logSource");
            f = G5.c.d("logSourceName");
            g = G5.c.d("logEvent");
            h = G5.c.d("qosTier");
        }
        
        public void b(final u u, final G5.e e) {
            e.c(i.b, u.g());
            e.c(i.c, u.h());
            e.a(i.d, (Object)u.b());
            e.a(i.e, (Object)u.d());
            e.a(i.f, (Object)u.e());
            e.a(i.g, (Object)u.c());
            e.a(i.h, (Object)u.f());
        }
    }
    
    private static final class j implements G5.d
    {
        static final j a;
        private static final G5.c b;
        private static final G5.c c;
        
        static {
            a = new j();
            b = G5.c.d("networkType");
            c = G5.c.d("mobileSubtype");
        }
        
        public void b(final w w, final G5.e e) {
            e.a(j.b, (Object)w.c());
            e.a(j.c, (Object)w.b());
        }
    }
}
