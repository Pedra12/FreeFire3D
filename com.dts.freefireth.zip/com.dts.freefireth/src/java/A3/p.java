package a3;

import android.util.SparseArray;

public abstract class p
{
    public static a a() {
        return (a)new f.b();
    }
    
    public abstract s b();
    
    public abstract b c();
    
    public abstract static class a
    {
        public abstract p a();
        
        public abstract a b(final s p0);
        
        public abstract a c(final b p0);
    }
    
    public enum b
    {
        b("NOT_SET", 0, 0), 
        c("EVENT_OVERRIDE", 1, 5);
        
        private static final SparseArray d;
        private static final b[] e;
        private final int a;
        
        static {
            final b b2;
            final b b3;
            e = new b[] { b2, b3 };
            final SparseArray d2 = new SparseArray();
            (d = d2).put(0, (Object)b2);
            d2.put(5, (Object)b3);
        }
        
        private b(final String s, final int n, final int a) {
            this.a = a;
        }
    }
}
