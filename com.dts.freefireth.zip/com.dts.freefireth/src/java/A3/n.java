package a3;

import G5.a;
import java.util.List;

public abstract class n
{
    public static n a(final List list) {
        return new d(list);
    }
    
    public static a b() {
        return new I5.d().j(b.a).k(true).i();
    }
    
    public abstract List c();
}
