package a3;

final class h extends r
{
    private final Integer a;
    
    private h(final Integer a) {
        this.a = a;
    }
    
    @Override
    public Integer b() {
        return this.a;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof r)) {
            return false;
        }
        final r r = (r)o;
        final Integer a = this.a;
        final Integer b = r.b();
        if (a == null) {
            return b == null;
        }
        return a.equals((Object)b);
    }
    
    @Override
    public int hashCode() {
        final Integer a = this.a;
        int hashCode;
        if (a == null) {
            hashCode = 0;
        }
        else {
            hashCode = a.hashCode();
        }
        return hashCode ^ 0xF4243;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("ExternalPRequestContext{originAssociatedProductId=");
        sb.append((Object)this.a);
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends a
    {
        private Integer a;
        
        @Override
        public r a() {
            return new h(this.a, null);
        }
        
        @Override
        public a b(final Integer a) {
            this.a = a;
            return this;
        }
    }
}
