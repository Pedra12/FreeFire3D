package a3;

public abstract class s
{
    public static a a() {
        return (a)new i.b();
    }
    
    public abstract r b();
    
    public abstract static class a
    {
        public abstract s a();
        
        public abstract a b(final r p0);
    }
}
