package a3;

import android.util.SparseArray;

public enum x
{
    b("DEFAULT", 0, 0), 
    c("UNMETERED_ONLY", 1, 1), 
    d("UNMETERED_OR_DAILY", 2, 2), 
    e("FAST_IF_RADIO_AWAKE", 3, 3), 
    f("NEVER", 4, 4), 
    g("UNRECOGNIZED", 5, -1);
    
    private static final SparseArray h;
    private static final x[] i;
    private final int a;
    
    static {
        final x x;
        final x x2;
        final x x3;
        final x x4;
        final x x5;
        final x x6;
        i = new x[] { x, x2, x3, x4, x5, x6 };
        final SparseArray h2 = new SparseArray();
        (h = h2).put(0, (Object)x);
        h2.put(1, (Object)x2);
        h2.put(2, (Object)x3);
        h2.put(3, (Object)x4);
        h2.put(4, (Object)x5);
        h2.put(-1, (Object)x6);
    }
    
    private x(final String s, final int n, final int a) {
        this.a = a;
    }
}
