package a3;

final class m extends w
{
    private final c a;
    private final w.b b;
    
    private m(final c a, final w.b b) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public w.b b() {
        return this.b;
    }
    
    @Override
    public c c() {
        return this.a;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof w) {
            final w w = (w)o;
            final c a = this.a;
            if (a == null) {
                if (w.c() != null) {
                    return false;
                }
            }
            else if (!a.equals(w.c())) {
                return false;
            }
            final w.b b = this.b;
            if (b == null) {
                if (w.b() != null) {
                    return false;
                }
            }
            else if (!b.equals(w.b())) {
                return false;
            }
            return true;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        final c a = this.a;
        int hashCode = 0;
        int hashCode2;
        if (a == null) {
            hashCode2 = 0;
        }
        else {
            hashCode2 = a.hashCode();
        }
        final w.b b = this.b;
        if (b != null) {
            hashCode = b.hashCode();
        }
        return (hashCode2 ^ 0xF4243) * 1000003 ^ hashCode;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("NetworkConnectionInfo{networkType=");
        sb.append((Object)this.a);
        sb.append(", mobileSubtype=");
        sb.append((Object)this.b);
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends a
    {
        private c a;
        private w.b b;
        
        @Override
        public w a() {
            return new m(this.a, this.b, null);
        }
        
        @Override
        public a b(final w.b b) {
            this.b = b;
            return this;
        }
        
        @Override
        public a c(final c a) {
            this.a = a;
            return this;
        }
    }
}
