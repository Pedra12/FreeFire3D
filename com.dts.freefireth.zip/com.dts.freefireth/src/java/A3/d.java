package a3;

import java.util.List;

final class d extends n
{
    private final List a;
    
    d(final List a) {
        if (a != null) {
            this.a = a;
            return;
        }
        throw new NullPointerException("Null logRequests");
    }
    
    @Override
    public List c() {
        return this.a;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o == this || (o instanceof n && this.a.equals((Object)((n)o).c()));
    }
    
    @Override
    public int hashCode() {
        return this.a.hashCode() ^ 0xF4243;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("BatchedLogRequest{logRequests=");
        sb.append((Object)this.a);
        sb.append("}");
        return sb.toString();
    }
}
