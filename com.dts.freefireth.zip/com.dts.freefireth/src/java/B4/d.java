package b4;

import r3.a;

public final class d implements a
{
}
