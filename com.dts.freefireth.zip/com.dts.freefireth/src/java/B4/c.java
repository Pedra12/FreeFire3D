package b4;

import android.os.IBinder;
import android.os.IInterface;

public final class c extends a implements IInterface
{
    c(final IBinder binder) {
        super(binder, "com.google.android.gms.auth.api.internal.IAuthService");
    }
}
