package b4;

import android.os.IBinder;
import android.os.IInterface;

public abstract class a implements IInterface
{
    private final IBinder g;
    private final String h;
    
    protected a(final IBinder g, final String h) {
        this.g = g;
        this.h = h;
    }
    
    public final IBinder asBinder() {
        return this.g;
    }
}
