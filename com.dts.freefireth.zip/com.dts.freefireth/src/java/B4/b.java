package b4;

import android.os.IInterface;
import android.os.IBinder;
import android.text.TextUtils;
import x3.j;
import x3.e;
import z3.d;
import android.os.Looper;
import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.common.internal.c;

public final class b extends c
{
    private final Bundle K;
    
    public b(final Context context, final Looper looper, final d d, final p3.c c, final e e, final j j) {
        super(context, looper, 16, d, e, j);
        this.K = new Bundle();
    }
    
    protected final Bundle A() {
        return this.K;
    }
    
    protected final String E() {
        return "com.google.android.gms.auth.api.internal.IAuthService";
    }
    
    protected final String F() {
        return "com.google.android.gms.auth.service.START";
    }
    
    public final boolean T() {
        return true;
    }
    
    public final int k() {
        return 12451000;
    }
    
    public final boolean n() {
        final d k0 = this.k0();
        return !TextUtils.isEmpty((CharSequence)k0.b()) && !k0.e(p3.b.a).isEmpty();
    }
}
