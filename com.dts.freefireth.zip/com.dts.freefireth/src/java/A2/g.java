package a2;

import java.util.regex.Matcher;
import java.text.ParseException;
import java.text.NumberFormat;
import n2.W;
import java.util.regex.Pattern;
import kotlin.text.StringsKt;
import android.os.Build;
import android.view.Window;
import android.view.View;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager$NameNotFoundException;
import com.facebook.e;
import java.util.Arrays;
import G7.G;
import kotlin.jvm.internal.Intrinsics;

public final class g
{
    public static final g a;
    
    static {
        a = new g();
    }
    
    private g() {
    }
    
    public static final void a() {
    }
    
    public static final void b() {
    }
    
    public static final String c(final byte[] array) {
        Intrinsics.checkNotNullParameter((Object)array, "bytes");
        final StringBuffer sb = new StringBuffer();
        for (final byte b : array) {
            final G a = G.a;
            final String format = String.format("%02x", Arrays.copyOf(new Object[] { b }, 1));
            Intrinsics.checkNotNullExpressionValue((Object)format, "format(format, *args)");
            sb.append(format);
        }
        final String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue((Object)string, "toString(...)");
        return string;
    }
    
    public static final String d() {
        final Context l = e.l();
        try {
            final String versionName = l.getPackageManager().getPackageInfo(l.getPackageName(), 0).versionName;
            if (versionName == null) {
                return "";
            }
            return versionName;
        }
        catch (final PackageManager$NameNotFoundException ex) {
            return "";
        }
    }
    
    public static final View e(final Activity activity) {
        if (activity == null) {
            return null;
        }
        try {
            final Window window = activity.getWindow();
            if (window == null) {
                return null;
            }
            return window.getDecorView().getRootView();
        }
        catch (final Exception ex) {
            return null;
        }
    }
    
    public static final boolean f() {
        final String fingerprint = Build.FINGERPRINT;
        Intrinsics.checkNotNullExpressionValue((Object)fingerprint, "FINGERPRINT");
        if (!StringsKt.J(fingerprint, "generic", false, 2, (Object)null)) {
            Intrinsics.checkNotNullExpressionValue((Object)fingerprint, "FINGERPRINT");
            if (!StringsKt.J(fingerprint, "unknown", false, 2, (Object)null)) {
                final String model = Build.MODEL;
                Intrinsics.checkNotNullExpressionValue((Object)model, "MODEL");
                if (!StringsKt.P((CharSequence)model, (CharSequence)"google_sdk", false, 2, (Object)null)) {
                    Intrinsics.checkNotNullExpressionValue((Object)model, "MODEL");
                    if (!StringsKt.P((CharSequence)model, (CharSequence)"Emulator", false, 2, (Object)null)) {
                        Intrinsics.checkNotNullExpressionValue((Object)model, "MODEL");
                        if (!StringsKt.P((CharSequence)model, (CharSequence)"Android SDK built for x86", false, 2, (Object)null)) {
                            final String manufacturer = Build.MANUFACTURER;
                            Intrinsics.checkNotNullExpressionValue((Object)manufacturer, "MANUFACTURER");
                            if (!StringsKt.P((CharSequence)manufacturer, (CharSequence)"Genymotion", false, 2, (Object)null)) {
                                final String brand = Build.BRAND;
                                Intrinsics.checkNotNullExpressionValue((Object)brand, "BRAND");
                                if (StringsKt.J(brand, "generic", false, 2, (Object)null)) {
                                    final String device = Build.DEVICE;
                                    Intrinsics.checkNotNullExpressionValue((Object)device, "DEVICE");
                                    if (StringsKt.J(device, "generic", false, 2, (Object)null)) {
                                        return true;
                                    }
                                }
                                if (!Intrinsics.a((Object)"google_sdk", (Object)Build.PRODUCT)) {
                                    return false;
                                }
                            }
                        }
                    }
                }
            }
        }
        return true;
    }
    
    public static final double g(String group) {
        final double n = 0.0;
        try {
            final Matcher matcher = Pattern.compile("[-+]*\\d+([.,]\\d+)*([.,]\\d+)?", 8).matcher((CharSequence)group);
            double doubleValue = n;
            if (matcher.find()) {
                group = matcher.group(0);
                doubleValue = NumberFormat.getNumberInstance(W.A()).parse(group).doubleValue();
            }
            return doubleValue;
        }
        catch (final ParseException ex) {
            return n;
        }
    }
}
