package a2;

import y7.a;
import java.util.Iterator;
import R1.B;
import n2.H;
import n2.W;
import S1.p;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;
import android.content.Context;
import n2.b;
import kotlin.collections.F;
import s7.u;
import kotlin.Pair;
import java.util.Map;

public final class h
{
    public static final h a;
    private static final Map b;
    
    static {
        a = new h();
        b = (Map)F.k(new Pair[] { u.a((Object)h.a.a, (Object)"MOBILE_APP_INSTALL"), u.a((Object)h.a.b, (Object)"CUSTOM_APP_EVENTS") });
    }
    
    private h() {
    }
    
    public static final JSONObject a(final a a, final b b, final String s, final boolean b2, final Context context) {
        Intrinsics.checkNotNullParameter((Object)a, "activityType");
        Intrinsics.checkNotNullParameter((Object)context, "context");
        final JSONObject jsonObject = new JSONObject();
        jsonObject.put("event", h.b.get((Object)a));
        final String f = p.b.f();
        if (f != null) {
            jsonObject.put("app_user_id", (Object)f);
        }
        W.F0(jsonObject, b, s, b2, context);
        try {
            W.G0(jsonObject, context);
        }
        catch (final Exception ex) {
            H.e.c(B.e, "AppEvents", "Fetching extended device info parameters failed: '%s'", new Object[] { ex.toString() });
        }
        final JSONObject c = W.C();
        if (c != null) {
            final Iterator keys = c.keys();
            while (keys.hasNext()) {
                final String s2 = (String)keys.next();
                jsonObject.put(s2, c.get(s2));
            }
        }
        jsonObject.put("application_package_name", (Object)context.getPackageName());
        return jsonObject;
    }
    
    public enum a
    {
        a("MOBILE_INSTALL_EVENT", 0), 
        b("CUSTOM_APP_EVENTS", 1);
        
        private static final a[] c;
        private static final y7.a d;
        
        static {
            d = y7.b.a((Enum[])(c = a()));
        }
        
        private a(final String s, final int n) {
        }
        
        private static final /* synthetic */ a[] a() {
            return new a[] { a.a, a.b };
        }
    }
}
