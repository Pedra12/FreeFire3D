package a2;

import android.os.BaseBundle;
import java.util.Arrays;
import java.util.Locale;
import G7.G;
import n2.H$a;
import R1.B;
import n2.H;
import S1.F$a;
import S1.p$b;
import com.facebook.AccessToken;
import S1.F;
import w2.a;
import android.os.Bundle;
import android.content.pm.ApplicationInfo;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import kotlin.jvm.internal.Intrinsics;
import android.content.Context;

public final class n
{
    public static final n a;
    private static final String b;
    private static final long[] c;
    
    static {
        a = new n();
        b = n.class.getCanonicalName();
        c = new long[] { 300000L, 900000L, 1800000L, 3600000L, 21600000L, 43200000L, 86400000L, 172800000L, 259200000L, 604800000L, 1209600000L, 1814400000L, 2419200000L, 5184000000L, 7776000000L, 10368000000L, 12960000000L, 15552000000L, 31536000000L };
    }
    
    private n() {
    }
    
    private final String a(final Context context) {
        try {
            final PackageManager packageManager = context.getPackageManager();
            final String versionName = packageManager.getPackageInfo(context.getPackageName(), 0).versionName;
            final StringBuilder sb = new StringBuilder();
            sb.append("PCKGCHKSUM;");
            sb.append(versionName);
            final String string = sb.toString();
            final SharedPreferences sharedPreferences = context.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0);
            final String string2 = sharedPreferences.getString(string, (String)null);
            if (string2 != null && string2.length() == 32) {
                return string2;
            }
            final String c = l.c(context, null);
            String b;
            if (c != null) {
                b = c;
            }
            else {
                final ApplicationInfo applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 0);
                Intrinsics.checkNotNullExpressionValue((Object)applicationInfo, "getApplicationInfo(...)");
                b = l.b(applicationInfo.sourceDir);
            }
            sharedPreferences.edit().putString(string, b).apply();
            return b;
        }
        catch (final Exception ex) {
            return null;
        }
    }
    
    public static final int b(final long n) {
        int n2 = 0;
        while (true) {
            final long[] c = n.c;
            if (n2 >= c.length || c[n2] >= n) {
                break;
            }
            ++n2;
        }
        return n2;
    }
    
    public static final void c(final String s, final o o, final String s2, final Context context) {
        Intrinsics.checkNotNullParameter((Object)s, "activityName");
        Intrinsics.checkNotNullParameter((Object)context, "context");
        String string;
        if (o == null || (string = o.toString()) == null) {
            string = "Unclassified";
        }
        final Bundle bundle = new Bundle();
        ((BaseBundle)bundle).putString("fb_mobile_launch_source", string);
        ((BaseBundle)bundle).putString("fb_mobile_pckg_fp", n.a.a(context));
        ((BaseBundle)bundle).putString("fb_mobile_app_cert_hash", w2.a.a(context));
        final F$a b = F.b;
        final F b2 = b.b(s, s2, (AccessToken)null);
        b2.d("fb_mobile_activate_app", bundle);
        if (b.d() != p$b.b) {
            b2.a();
        }
    }
    
    private final void d() {
        final H$a e = H.e;
        final B e2 = B.e;
        final String b = n.b;
        Intrinsics.c((Object)b);
        e.b(e2, b, "Clock skew detected");
    }
    
    public static final void e(final String s, final m m, final String s2) {
        Intrinsics.checkNotNullParameter((Object)s, "activityName");
        if (m == null) {
            return;
        }
        final Long b = m.b();
        final long n = 0L;
        long longValue;
        if (b != null) {
            longValue = b;
        }
        else {
            final Long e = m.e();
            long longValue2;
            if (e != null) {
                longValue2 = e;
            }
            else {
                longValue2 = 0L;
            }
            longValue = 0L - longValue2;
        }
        long n2 = longValue;
        if (longValue < 0L) {
            a2.n.a.d();
            n2 = 0L;
        }
        long f;
        if ((f = m.f()) < 0L) {
            a2.n.a.d();
            f = 0L;
        }
        final Bundle bundle = new Bundle();
        ((BaseBundle)bundle).putInt("fb_mobile_app_interruptions", m.c());
        final G a = G.a;
        final String format = String.format(Locale.ROOT, "session_quanta_%d", Arrays.copyOf(new Object[] { b(n2) }, 1));
        Intrinsics.checkNotNullExpressionValue((Object)format, "format(locale, format, *args)");
        ((BaseBundle)bundle).putString("fb_mobile_time_between_sessions", format);
        final o g = m.g();
        String string;
        if (g == null || (string = g.toString()) == null) {
            string = "Unclassified";
        }
        ((BaseBundle)bundle).putString("fb_mobile_launch_source", string);
        final Long e2 = m.e();
        long longValue3 = n;
        if (e2 != null) {
            longValue3 = e2;
        }
        ((BaseBundle)bundle).putLong("_logTime", longValue3 / 1000);
        F.b.b(s, s2, (AccessToken)null).c("fb_mobile_deactivate_app", f / (double)1000L, bundle);
    }
}
