package a2;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.DataInputStream;
import java.net.URL;
import kotlin.jvm.internal.Intrinsics;
import java.io.File;
import android.os.AsyncTask;

public final class k extends AsyncTask
{
    private final String a;
    private final File b;
    private final a c;
    
    public k(final String a, final File b, final a c) {
        Intrinsics.checkNotNullParameter((Object)a, "uriStr");
        Intrinsics.checkNotNullParameter((Object)b, "destFile");
        Intrinsics.checkNotNullParameter((Object)c, "onSuccess");
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public Boolean a(final String... array) {
        Intrinsics.checkNotNullParameter((Object)array, "args");
        try {
            final URL url = new URL(this.a);
            final int contentLength = url.openConnection().getContentLength();
            final DataInputStream dataInputStream = new DataInputStream(url.openStream());
            final byte[] array2 = new byte[contentLength];
            dataInputStream.readFully(array2);
            ((InputStream)dataInputStream).close();
            final DataOutputStream dataOutputStream = new DataOutputStream((OutputStream)new FileOutputStream(this.b));
            ((OutputStream)dataOutputStream).write(array2);
            dataOutputStream.flush();
            ((OutputStream)dataOutputStream).close();
            return Boolean.TRUE;
        }
        catch (final Exception ex) {
            return Boolean.FALSE;
        }
    }
    
    protected void b(final boolean b) {
        if (b) {
            this.c.a(this.b);
        }
    }
    
    public interface a
    {
        void a(final File p0);
    }
}
