package a2;

public final class j
{
    public static final j a;
    
    static {
        a = new j();
    }
    
    private j() {
    }
    
    public static final int a() {
        return 60;
    }
}
