package a2;

import java.io.Closeable;
import C7.b;
import java.security.MessageDigest;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.lang.reflect.Field;
import android.content.pm.PackageManager;
import java.lang.reflect.Proxy;
import java.util.Iterator;
import android.util.Log;
import java.math.BigInteger;
import java.util.List;
import java.lang.reflect.Method;
import java.util.concurrent.locks.Condition;
import java.lang.reflect.InvocationHandler;
import java.util.concurrent.locks.ReentrantLock;
import G7.C;
import java.util.Collection;
import kotlin.collections.CollectionsKt;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import android.util.Base64;
import java.util.ArrayList;
import java.security.cert.CertificateFactory;
import kotlin.jvm.internal.Intrinsics;
import android.content.Context;
import java.io.File;

public final class l
{
    public static final l a;
    private static final String b;
    private static final String[] c;
    
    static {
        a = new l();
        b = l.class.getSimpleName();
        c = new String[] { "MIIEQzCCAyugAwIBAgIJAMLgh0ZkSjCNMA0GCSqGSIb3DQEBBAUAMHQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtHb29nbGUgSW5jLjEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDAeFw0wODA4MjEyMzEzMzRaFw0zNjAxMDcyMzEzMzRaMHQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtHb29nbGUgSW5jLjEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDCCASAwDQYJKoZIhvcNAQEBBQADggENADCCAQgCggEBAKtWLgDYO6IIrgqWbxJOKdoR8qtW0I9Y4sypEwPpt1TTcvZApxsdyxMJZ2JORland2qSGT2y5b+3JKkedxiLDmpHpDsz2WCbdxgxRczfey5YZnTJ4VZbH0xqWVW/8lGmPav5xVwnIiJS6HXk+BVKZF+JcWjAsb/GEuq/eFdpuzSqeYTcfi6idkyugwfYwXFU1+5fZKUaRKYCwkkFQVfcAs1fXA5V+++FGfvjJ/CxURaSxaBvGdGDhfXE28LWuT9ozCl5xw4Yq5OGazvV24mZVSoOO0yZ31j7kYvtwYK6NeADwbSxDdJEqO4k//0zOHKrUiGYXtqw/A0LFFtqoZKFjnkCAQOjgdkwgdYwHQYDVR0OBBYEFMd9jMIhF1Ylmn/Tgt9r45jk14alMIGmBgNVHSMEgZ4wgZuAFMd9jMIhF1Ylmn/Tgt9r45jk14aloXikdjB0MQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLR29vZ2xlIEluYy4xEDAOBgNVBAsTB0FuZHJvaWQxEDAOBgNVBAMTB0FuZHJvaWSCCQDC4IdGZEowjTAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBAUAA4IBAQBt0lLO74UwLDYKqs6Tm8/yzKkEu116FmH4rkaymUIE0P9KaMftGlMexFlaYjzmB2OxZyl6euNXEsQH8gjwyxCUKRJNexBiGcCEyj6z+a1fuHHvkiaai+KL8W1EyNmgjmyy8AW7P+LLlkR+ho5zEHatRbM/YAnqGcFh5iZBqpknHf1SKMXFh4dd239FJ1jWYfbMDMy3NS5CTMQ2XFI1MvcyUTdZPErjQfTbQe3aDQsQcafEQPD+nqActifKZ0Np0IS9L9kR/wbNvyz6ENwPiTrjV2KRkEjH78ZMcUQXg0L3BYHJ3lc69Vs5Ddf9uUGGMYldX3WfMBEmh/9iFBDAaTCK", "MIIEqDCCA5CgAwIBAgIJANWFuGx90071MA0GCSqGSIb3DQEBBAUAMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbTAeFw0wODA0MTUyMzM2NTZaFw0zNTA5MDEyMzM2NTZaMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbTCCASAwDQYJKoZIhvcNAQEBBQADggENADCCAQgCggEBANbOLggKv+IxTdGNs8/TGFy0PTP6DHThvbbR24kT9ixcOd9W+EaBPWW+wPPKQmsHxajtWjmQwWfna8mZuSeJS48LIgAZlKkpFeVyxW0qMBujb8X8ETrWy550NaFtI6t9+u7hZeTfHwqNvacKhp1RbE6dBRGWynwMVX8XW8N1+UjFaq6GCJukT4qmpN2afb8sCjUigq0GuMwYXrFVee74bQgLHWGJwPmvmLHC69EH6kWr22ijx4OKXlSIx2xT1AsSHee70w5iDBiK4aph27yH3TxkXy9V89TDdexAcKk/cVHYNnDBapcavl7y0RiQ4biu8ymM8Ga/nmzhRKya6G0cGw8CAQOjgfwwgfkwHQYDVR0OBBYEFI0cxb6VTEM8YYY6FbBMvAPyT+CyMIHJBgNVHSMEgcEwgb6AFI0cxb6VTEM8YYY6FbBMvAPyT+CyoYGapIGXMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbYIJANWFuGx90071MAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEEBQADggEBABnTDPEF+3iSP0wNfdIjIz1AlnrPzgAIHVvXxunW7SBrDhEglQZBbKJEk5kT0mtKoOD1JMrSu1xuTKEBahWRbqHsXclaXjoBADb0kkjVEJu/Lh5hgYZnOjvlba8Ld7HCKePCVePoTJBdI4fvugnL8TsgK05aIskyY0hKI9L8KfqfGTl1lzOv2KoWD0KWwtAWPoGChZxmQ+nBli+gwYMzM1vAkP+aayLe0a1EQimlOalO762r0GXO0ks+UeXde2Z4e+8S/pf7pITEI/tP+MxJTALw9QUWEv9lKTk+jkbqxbsh8nfBUapfKqYn0eidpwq2AzVp3juYl7//fKnaPhJD9gs=" };
    }
    
    private l() {
    }
    
    public static final /* synthetic */ String a() {
        return l.b;
    }
    
    public static final String b(final String s) {
        return l.a.d(new File(s));
    }
    
    public static final String c(final Context context, final Long n) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        final CertificateFactory instance = CertificateFactory.getInstance("X.509");
        final String[] c = l.c;
        final ArrayList list = new ArrayList(c.length);
        for (int length = c.length, i = 0; i < length; ++i) {
            ((Collection)list).add((Object)instance.generateCertificate((InputStream)new ByteArrayInputStream(Base64.decode(c[i], 0))));
        }
        final List o0 = CollectionsKt.o0((Collection)list);
        final C c2 = new C();
        final ReentrantLock reentrantLock = new ReentrantLock();
        final Condition condition = reentrantLock.newCondition();
        reentrantLock.lock();
        try {
            final Field field = Class.forName("android.content.pm.Checksum").getField("TYPE_WHOLE_MD5");
            Intrinsics.checkNotNullExpressionValue((Object)field, "getField(...)");
            final Object value = field.get((Object)null);
            final Class<?> forName = Class.forName("android.content.pm.PackageManager$OnChecksumsReadyListener");
            final Object proxyInstance = Proxy.newProxyInstance(l.class.getClassLoader(), new Class[] { forName }, (InvocationHandler)new InvocationHandler(value, c2, reentrantLock, condition) {
                final Object a;
                final C b;
                final ReentrantLock c;
                final Condition d;
                
                public Object invoke(Object o, Method method, final Object[] array) {
                    Intrinsics.checkNotNullParameter((Object)method, "method");
                    Intrinsics.checkNotNullParameter((Object)array, "objects");
                    Label_0238: {
                        try {
                            if (!Intrinsics.a((Object)method.getName(), (Object)"onChecksumsReady") || array.length != 1) {
                                return null;
                            }
                            o = array[0];
                            if (o instanceof List) {
                                Intrinsics.d(o, "null cannot be cast to non-null type kotlin.collections.List<*>");
                                final Iterator iterator = ((List)o).iterator();
                                Block_10: {
                                    while (iterator.hasNext()) {
                                        o = iterator.next();
                                        if (o != null) {
                                            final Method method2 = o.getClass().getMethod("getSplitName", (Class<?>[])null);
                                            Intrinsics.checkNotNullExpressionValue((Object)method2, "getMethod(...)");
                                            final Method method3 = o.getClass().getMethod("getType", (Class<?>[])null);
                                            Intrinsics.checkNotNullExpressionValue((Object)method3, "getMethod(...)");
                                            if (method2.invoke(o, (Object[])null) == null && Intrinsics.a(method3.invoke(o, (Object[])null), this.a)) {
                                                break Block_10;
                                            }
                                            continue;
                                        }
                                    }
                                    return null;
                                }
                                method = o.getClass().getMethod("getValue", (Class<?>[])null);
                                Intrinsics.checkNotNullExpressionValue((Object)method, "getMethod(...)");
                                o = method.invoke(o, (Object[])null);
                                Intrinsics.d(o, "null cannot be cast to non-null type kotlin.ByteArray");
                                final byte[] array2 = (byte[])o;
                                final C b = this.b;
                                o = new BigInteger(1, array2);
                                b.a = ((BigInteger)o).toString(16);
                                this.c.lock();
                                final InvocationHandler invocationHandler = (InvocationHandler)this;
                                final Condition condition = invocationHandler.d;
                                condition.signalAll();
                                return null;
                            }
                            return null;
                        }
                        finally {
                            break Label_0238;
                        }
                        try {
                            final InvocationHandler invocationHandler = (InvocationHandler)this;
                            final Condition condition = invocationHandler.d;
                            condition.signalAll();
                            return null;
                        }
                        finally {
                            this.c.unlock();
                        }
                    }
                    final Throwable t;
                    Log.d(l.a(), "Can't fetch checksum.", t);
                    return null;
                }
            });
            Intrinsics.checkNotNullExpressionValue(proxyInstance, "newProxyInstance(...)");
            final Method method = PackageManager.class.getMethod("requestChecksums", String.class, Boolean.TYPE, Integer.TYPE, List.class, forName);
            Intrinsics.checkNotNullExpressionValue((Object)method, "getMethod(...)");
            method.invoke((Object)context.getPackageManager(), new Object[] { context.getPackageName(), Boolean.FALSE, value, CollectionsKt.o0((Collection)o0), proxyInstance });
            if (n == null) {
                condition.await();
            }
            else {
                condition.awaitNanos((long)n);
            }
            final String s = (String)c2.a;
            reentrantLock.unlock();
            return s;
        }
        finally {
            reentrantLock.unlock();
            return null;
        }
    }
    
    private final String d(File file) {
        file = (File)new BufferedInputStream((InputStream)new FileInputStream(file), 1024);
        Label_0059: {
            try {
                final MessageDigest instance = MessageDigest.getInstance("MD5");
                final byte[] array = new byte[1024];
                final int read;
                Label_0032: {
                    read = ((InputStream)file).read(array);
                }
                if (read > 0) {
                    instance.update(array, 0, read);
                }
                break Label_0059;
            }
            finally {
                try {}
                finally {
                    final Throwable t;
                    C7.b.a((Closeable)file, t);
                }
                final int read;
                iftrue(Label_0032:)(read != -1);
                final MessageDigest instance;
                final String string = new BigInteger(1, instance.digest()).toString(16);
                Intrinsics.checkNotNullExpressionValue((Object)string, "toString(...)");
                C7.b.a((Closeable)file, (Throwable)null);
                return string;
            }
        }
    }
}
