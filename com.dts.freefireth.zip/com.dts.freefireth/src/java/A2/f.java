package a2;

import java.util.concurrent.Executor;
import java.lang.ref.Reference;
import java.util.concurrent.Future;
import S1.p;
import R1.B;
import n2.H;
import android.os.Bundle;
import android.app.Application$ActivityLifecycleCallbacks;
import n2.s$a;
import n2.s;
import n2.s$b;
import android.app.Application;
import Y1.k;
import T1.b;
import java.util.concurrent.TimeUnit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import n2.W;
import android.util.Log;
import n2.w;
import n2.A;
import com.facebook.e;
import java.util.UUID;
import kotlin.Unit;
import android.app.Activity;
import android.content.Context;
import java.util.concurrent.Executors;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledExecutorService;

public final class f
{
    public static final f a;
    private static final String b;
    private static final ScheduledExecutorService c;
    private static volatile ScheduledFuture d;
    private static final Object e;
    private static final AtomicInteger f;
    private static volatile m g;
    private static final AtomicBoolean h;
    private static String i;
    private static long j;
    private static int k;
    private static WeakReference l;
    
    static {
        a = new f();
        String canonicalName;
        if ((canonicalName = f.class.getCanonicalName()) == null) {
            canonicalName = "com.facebook.appevents.internal.ActivityLifecycleTracker";
        }
        b = canonicalName;
        c = Executors.newSingleThreadScheduledExecutor();
        e = new Object();
        f = new AtomicInteger(0);
        h = new AtomicBoolean(false);
    }
    
    private f() {
    }
    
    public static final /* synthetic */ int f() {
        return a2.f.k;
    }
    
    public static final /* synthetic */ String g() {
        return a2.f.b;
    }
    
    public static final /* synthetic */ void j(final int k) {
        a2.f.k = k;
    }
    
    private final void k() {
        final Object e;
        monitorenter(e = a2.f.e);
        Label_0048: {
            try {
                if (a2.f.d != null) {
                    final ScheduledFuture d = a2.f.d;
                    if (d != null) {
                        ((Future)d).cancel(false);
                    }
                }
            }
            finally {
                break Label_0048;
            }
            a2.f.d = null;
            final Unit a = Unit.a;
            monitorexit(e);
            return;
        }
        monitorexit(e);
    }
    
    public static final Activity l() {
        final WeakReference l = a2.f.l;
        if (l != null && l != null) {
            return (Activity)((Reference)l).get();
        }
        return null;
    }
    
    public static final UUID m() {
        if (a2.f.g != null) {
            final m g = a2.f.g;
            if (g != null) {
                return g.d();
            }
        }
        return null;
    }
    
    private final int n() {
        final w f = A.f(com.facebook.e.m());
        if (f == null) {
            return a2.j.a();
        }
        return f.l();
    }
    
    public static final boolean o() {
        return a2.f.k == 0;
    }
    
    public static final void p(final Activity activity) {
        ((Executor)a2.f.c).execute((Runnable)new d());
    }
    
    private static final void q() {
        if (a2.f.g == null) {
            a2.f.g = m.g.b();
        }
    }
    
    private final void r(final Activity activity) {
        V1.e.j(activity);
    }
    
    private final void s(final Activity activity) {
        final AtomicInteger f = a2.f.f;
        if (f.decrementAndGet() < 0) {
            f.set(0);
            Log.w(a2.f.b, "Unexpected activity pause without a matching activity resume. Logging data may be incorrect. Make sure you call activateApp from your Application's onCreate method");
        }
        this.k();
        final long currentTimeMillis = System.currentTimeMillis();
        final String t = W.t((Context)activity);
        V1.e.k(activity);
        ((Executor)a2.f.c).execute((Runnable)new c(currentTimeMillis, t));
    }
    
    private static final void t(final long n, final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "$activityName");
        if (a2.f.g == null) {
            a2.f.g = new m(n, null, null, 4, null);
        }
        final m g = a2.f.g;
        if (g != null) {
            g.k(n);
        }
        if (a2.f.f.get() <= 0) {
            final a2.e e = new a2.e(n, s);
            final Object e2 = a2.f.e;
            synchronized (e2) {
                a2.f.d = a2.f.c.schedule((Runnable)e, (long)a2.f.a.n(), TimeUnit.SECONDS);
                final Unit a = Unit.a;
            }
        }
        final long j = a2.f.j;
        long n2 = 0L;
        if (j > 0L) {
            n2 = (n - j) / 1000;
        }
        a2.i.e(s, n2);
        final m g2 = a2.f.g;
        if (g2 != null) {
            g2.m();
        }
    }
    
    private static final void u(final long n, final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "$activityName");
        if (a2.f.g == null) {
            a2.f.g = new m(n, null, null, 4, null);
        }
        if (a2.f.f.get() <= 0) {
            n.e(s, a2.f.g, a2.f.i);
            m.g.a();
            a2.f.g = null;
        }
        final Object e = a2.f.e;
        synchronized (e) {
            a2.f.d = null;
            final Unit a = Unit.a;
        }
    }
    
    public static final void v(final Activity activity) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        a2.f.l = new WeakReference((Object)activity);
        a2.f.f.incrementAndGet();
        a2.f.a.k();
        final long n = a2.f.j = System.currentTimeMillis();
        final String t = W.t((Context)activity);
        V1.e.l(activity);
        T1.b.d(activity);
        e2.e.h(activity);
        Y1.k.b();
        ((Executor)a2.f.c).execute((Runnable)new a2.b(n, t, ((Context)activity).getApplicationContext()));
    }
    
    private static final void w(final long n, final String s, final Context context) {
        Intrinsics.checkNotNullParameter((Object)s, "$activityName");
        final m g = a2.f.g;
        Long e;
        if (g != null) {
            e = g.e();
        }
        else {
            e = null;
        }
        if (a2.f.g == null) {
            a2.f.g = new m(n, null, null, 4, null);
            final String i = a2.f.i;
            Intrinsics.c((Object)context);
            n.c(s, null, i, context);
        }
        else if (e != null) {
            final long n2 = n - e;
            if (n2 > a2.f.a.n() * 1000) {
                n.e(s, a2.f.g, a2.f.i);
                final String j = a2.f.i;
                Intrinsics.c((Object)context);
                n.c(s, null, j, context);
                a2.f.g = new m(n, null, null, 4, null);
            }
            else if (n2 > 1000L) {
                final m g2 = a2.f.g;
                if (g2 != null) {
                    g2.h();
                }
            }
        }
        final m g3 = a2.f.g;
        if (g3 != null) {
            g3.k(n);
        }
        final m g4 = a2.f.g;
        if (g4 != null) {
            g4.m();
        }
    }
    
    public static final void x(final Application application, final String i) {
        Intrinsics.checkNotNullParameter((Object)application, "application");
        if (!a2.f.h.compareAndSet(false, true)) {
            return;
        }
        s.a(s$b.f, (s$a)new a());
        a2.f.i = i;
        application.registerActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)new Application$ActivityLifecycleCallbacks() {
            public void onActivityCreated(final Activity activity, final Bundle bundle) {
                Intrinsics.checkNotNullParameter((Object)activity, "activity");
                H.e.b(B.e, a2.f.g(), "onActivityCreated");
                a2.g.a();
                a2.f.p(activity);
            }
            
            public void onActivityDestroyed(final Activity activity) {
                Intrinsics.checkNotNullParameter((Object)activity, "activity");
                H.e.b(B.e, a2.f.g(), "onActivityDestroyed");
                a2.f.a.r(activity);
            }
            
            public void onActivityPaused(final Activity activity) {
                Intrinsics.checkNotNullParameter((Object)activity, "activity");
                H.e.b(B.e, a2.f.g(), "onActivityPaused");
                a2.g.a();
                a2.f.a.s(activity);
            }
            
            public void onActivityResumed(final Activity activity) {
                Intrinsics.checkNotNullParameter((Object)activity, "activity");
                H.e.b(B.e, a2.f.g(), "onActivityResumed");
                a2.g.a();
                a2.f.v(activity);
            }
            
            public void onActivitySaveInstanceState(final Activity activity, final Bundle bundle) {
                Intrinsics.checkNotNullParameter((Object)activity, "activity");
                Intrinsics.checkNotNullParameter((Object)bundle, "outState");
                H.e.b(B.e, a2.f.g(), "onActivitySaveInstanceState");
            }
            
            public void onActivityStarted(final Activity activity) {
                Intrinsics.checkNotNullParameter((Object)activity, "activity");
                a2.f.j(a2.f.f() + 1);
                H.e.b(B.e, a2.f.g(), "onActivityStarted");
            }
            
            public void onActivityStopped(final Activity activity) {
                Intrinsics.checkNotNullParameter((Object)activity, "activity");
                H.e.b(B.e, a2.f.g(), "onActivityStopped");
                p.b.i();
                a2.f.j(a2.f.f() - 1);
            }
        });
    }
    
    private static final void y(final boolean b) {
        if (b) {
            V1.e.f();
            return;
        }
        V1.e.e();
    }
}
