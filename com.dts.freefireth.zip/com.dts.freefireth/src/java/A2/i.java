package a2;

import n2.v;
import android.content.Context;
import S1.p;
import android.app.Application;
import n2.w;
import n2.A;
import java.util.Iterator;
import android.util.Log;
import java.util.Currency;
import java.math.BigDecimal;
import java.util.Map$Entry;
import org.json.JSONException;
import kotlin.jvm.internal.Intrinsics;
import android.os.Bundle;
import org.json.JSONObject;
import java.util.Map;
import java.util.HashMap;
import com.facebook.e;
import S1.F;

public final class i
{
    public static final i a;
    private static final String b;
    private static final F c;
    
    static {
        a = new i();
        b = i.class.getCanonicalName();
        c = new F(e.l());
    }
    
    private i() {
    }
    
    private final a a(final String s, final String s2) {
        return this.b(s, s2, (Map)new HashMap());
    }
    
    private final a b(final String s, String s2, final Map map) {
        Label_0333: {
            JSONObject jsonObject2;
            Bundle bundle;
            try {
                final JSONObject jsonObject = new JSONObject(s);
                jsonObject2 = new JSONObject(s2);
                bundle = new Bundle(1);
                bundle.putCharSequence("fb_iap_product_id", (CharSequence)jsonObject.getString("productId"));
                bundle.putCharSequence("fb_iap_purchase_time", (CharSequence)jsonObject.getString("purchaseTime"));
                bundle.putCharSequence("fb_iap_purchase_token", (CharSequence)jsonObject.getString("purchaseToken"));
                bundle.putCharSequence("fb_iap_package_name", (CharSequence)jsonObject.optString("packageName"));
                bundle.putCharSequence("fb_iap_product_title", (CharSequence)jsonObject2.optString("title"));
                bundle.putCharSequence("fb_iap_product_description", (CharSequence)jsonObject2.optString("description"));
                s2 = jsonObject2.optString("type");
                bundle.putCharSequence("fb_iap_product_type", (CharSequence)s2);
                if (Intrinsics.a((Object)s2, (Object)"subs")) {
                    bundle.putCharSequence("fb_iap_subs_auto_renewing", (CharSequence)Boolean.toString(jsonObject.optBoolean("autoRenewing", false)));
                    bundle.putCharSequence("fb_iap_subs_period", (CharSequence)jsonObject2.optString("subscriptionPeriod"));
                    bundle.putCharSequence("fb_free_trial_period", (CharSequence)jsonObject2.optString("freeTrialPeriod"));
                    s2 = jsonObject2.optString("introductoryPriceCycles");
                    Intrinsics.c((Object)s2);
                    if (((CharSequence)s2).length() != 0) {
                        bundle.putCharSequence("fb_intro_price_amount_micros", (CharSequence)jsonObject2.optString("introductoryPriceAmountMicros"));
                        bundle.putCharSequence("fb_intro_price_cycles", (CharSequence)s2);
                    }
                }
            }
            catch (final JSONException ex) {
                break Label_0333;
            }
            for (final Map$Entry map$Entry : map.entrySet()) {
                bundle.putCharSequence((String)map$Entry.getKey(), (CharSequence)map$Entry.getValue());
            }
            final BigDecimal bigDecimal = new BigDecimal(jsonObject2.getLong("price_amount_micros") / 1000000.0);
            final Currency instance = Currency.getInstance(jsonObject2.getString("price_currency_code"));
            Intrinsics.checkNotNullExpressionValue((Object)instance, "getInstance(...)");
            return new a(bigDecimal, instance, bundle);
        }
        final JSONException ex;
        Log.e(i.b, "Error parsing in-app subscription data.", (Throwable)ex);
        return null;
    }
    
    public static final boolean c() {
        final w f = A.f(e.m());
        return f != null && e.p() && f.f();
    }
    
    public static final void d() {
        final Context l = e.l();
        final String m = e.m();
        if (e.p()) {
            if (l instanceof Application) {
                p.b.a((Application)l, m);
                return;
            }
            Log.w(i.b, "Automatic logging of basic events will not happen, because FacebookSdk.getApplicationContext() returns object that is not instance of android.app.Application. Make sure you call FacebookSdk.sdkInitialize() from Application class and pass application context.");
        }
    }
    
    public static final void e(final String s, final long n) {
        final Context l = e.l();
        final w o = A.o(e.m(), false);
        if (o != null && o.a() && n > 0L) {
            final F f = new F(l);
            final Bundle bundle = new Bundle(1);
            bundle.putCharSequence("fb_aa_time_spent_view_name", (CharSequence)s);
            f.c("fb_aa_time_spent_on_view", (double)n, bundle);
        }
    }
    
    public static final void f(String s, final String s2, final boolean b) {
        Intrinsics.checkNotNullParameter((Object)s, "purchase");
        Intrinsics.checkNotNullParameter((Object)s2, "skuDetails");
        if (c()) {
            final a a = i.a.a(s, s2);
            if (a != null) {
                if (b && v.d("app_events_if_auto_log_subs", e.m(), false)) {
                    if (Y1.i.a.m(s2)) {
                        s = "StartTrial";
                    }
                    else {
                        s = "Subscribe";
                    }
                    i.c.i(s, a.c(), a.a(), a.b());
                    return;
                }
                i.c.j(a.c(), a.a(), a.b());
            }
        }
    }
    
    private static final class a
    {
        private BigDecimal a;
        private Currency b;
        private Bundle c;
        
        public a(final BigDecimal a, final Currency b, final Bundle c) {
            Intrinsics.checkNotNullParameter((Object)a, "purchaseAmount");
            Intrinsics.checkNotNullParameter((Object)b, "currency");
            Intrinsics.checkNotNullParameter((Object)c, "param");
            this.a = a;
            this.b = b;
            this.c = c;
        }
        
        public final Currency a() {
            return this.b;
        }
        
        public final Bundle b() {
            return this.c;
        }
        
        public final BigDecimal c() {
            return this.a;
        }
    }
}
