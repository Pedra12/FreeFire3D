package a2;

import android.content.SharedPreferences;
import android.content.SharedPreferences$Editor;
import android.preference.PreferenceManager;
import com.facebook.e;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class o
{
    public static final a c;
    private final String a;
    private final boolean b;
    
    static {
        c = new a(null);
    }
    
    private o(final String a, final boolean b) {
        this.a = a;
        this.b = b;
    }
    
    public final void a() {
        final SharedPreferences$Editor edit = PreferenceManager.getDefaultSharedPreferences(e.l()).edit();
        edit.putString("com.facebook.appevents.SourceApplicationInfo.callingApplicationPackage", this.a);
        edit.putBoolean("com.facebook.appevents.SourceApplicationInfo.openedByApplink", this.b);
        edit.apply();
    }
    
    @Override
    public String toString() {
        String s;
        if (this.b) {
            s = "Applink";
        }
        else {
            s = "Unclassified";
        }
        final String a = this.a;
        String string = s;
        if (a != null) {
            final StringBuilder sb = new StringBuilder();
            sb.append(s);
            sb.append("(");
            sb.append(a);
            sb.append(")");
            string = sb.toString();
        }
        return string;
    }
    
    public static final class a
    {
        private a() {
        }
        
        public final void a() {
            final SharedPreferences$Editor edit = PreferenceManager.getDefaultSharedPreferences(e.l()).edit();
            edit.remove("com.facebook.appevents.SourceApplicationInfo.callingApplicationPackage");
            edit.remove("com.facebook.appevents.SourceApplicationInfo.openedByApplink");
            edit.apply();
        }
        
        public final o b() {
            final SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(e.l());
            if (!defaultSharedPreferences.contains("com.facebook.appevents.SourceApplicationInfo.callingApplicationPackage")) {
                return null;
            }
            return new o(defaultSharedPreferences.getString("com.facebook.appevents.SourceApplicationInfo.callingApplicationPackage", (String)null), defaultSharedPreferences.getBoolean("com.facebook.appevents.SourceApplicationInfo.openedByApplink", false), null);
        }
    }
}
