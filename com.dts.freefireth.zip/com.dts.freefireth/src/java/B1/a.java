package b1;

import U0.b$b;
import R7.f;
import R7.e;
import R7.g;
import kotlin.Unit;
import x7.l;
import kotlin.jvm.functions.Function2;
import s7.q;
import w7.b;
import x7.d;
import v7.c;
import Y0.w;
import U0.k;
import kotlin.jvm.internal.Intrinsics;
import P0.u;

public abstract class a
{
    private static final String a;
    
    static {
        final String i = u.i("ConstraintTrkngWrkr");
        Intrinsics.checkNotNullExpressionValue((Object)i, "tagWithPrefix(\"ConstraintTrkngWrkr\")");
        a = i;
    }
    
    public static final /* synthetic */ String b() {
        return b1.a.a;
    }
    
    private static final Object c(final k k, final w w, final c c) {
        Object o = null;
        Label_0050: {
            if (c instanceof a$b) {
                final d d = (a$b)c;
                final int b = d.b;
                if ((b & Integer.MIN_VALUE) != 0x0) {
                    d.b = b + Integer.MIN_VALUE;
                    o = d;
                    break Label_0050;
                }
            }
            o = new d(c) {
                Object a;
                int b;
                
                public final Object invokeSuspend(final Object a) {
                    this.a = a;
                    this.b |= Integer.MIN_VALUE;
                    return c(null, null, (c)this);
                }
            };
        }
        final Object a = ((a$b)o).a;
        final Object e = b.e();
        final int b2 = ((a$b)o).b;
        Object m;
        if (b2 != 0) {
            if (b2 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            q.b(a);
            m = a;
        }
        else {
            q.b(a);
            final e e2 = (e)new e(g.q(k.b(w), (Function2)new Function2(w, null) {
                int a;
                final w b;
                
                public final c create(final Object o, final c c) {
                    return (c)new Function2(this.b, c) {
                        int a;
                        final w b;
                    };
                }
                
                public final Object g(final U0.b b, final c c) {
                    return ((a$c)this.create(b, c)).invokeSuspend(Unit.a);
                }
                
                public final Object invokeSuspend(final Object o) {
                    w7.b.e();
                    if (this.a == 0) {
                        q.b(o);
                        final String b = b1.a.b();
                        final w b2 = this.b;
                        final u e = u.e();
                        final StringBuilder sb = new StringBuilder();
                        sb.append("Constraints changed for ");
                        sb.append((Object)b2);
                        e.a(b, sb.toString());
                        return Unit.a;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            })) {
                final e a;
                
                public Object b(final f f, final c c) {
                    final Object b = this.a.b((f)new f(f) {
                        final f a;
                        
                        public final Object e(final Object o, final c c) {
                            d d2 = null;
                            Label_0051: {
                                if (c instanceof a$a$a$a) {
                                    final d d = (a$a$a$a)c;
                                    final int b = d.b;
                                    if ((b & Integer.MIN_VALUE) != 0x0) {
                                        d.b = b + Integer.MIN_VALUE;
                                        d2 = d;
                                        break Label_0051;
                                    }
                                }
                                d2 = new d(this, c) {
                                    Object a;
                                    int b;
                                    final a$a$a c;
                                    
                                    public final Object invokeSuspend(final Object a) {
                                        this.a = a;
                                        this.b |= Integer.MIN_VALUE;
                                        return this.c.e(null, (c)this);
                                    }
                                };
                            }
                            final Object a = d2.a;
                            final Object e = w7.b.e();
                            final int b2 = d2.b;
                            if (b2 != 0) {
                                if (b2 != 1) {
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                q.b(a);
                            }
                            else {
                                q.b(a);
                                final f a2 = this.a;
                                if (o instanceof b$b) {
                                    d2.b = 1;
                                    if (a2.e(o, (c)d2) == e) {
                                        return e;
                                    }
                                }
                            }
                            return Unit.a;
                        }
                    }, c);
                    if (b == w7.b.e()) {
                        return b;
                    }
                    return Unit.a;
                }
            };
            ((a$b)o).b = 1;
            if ((m = g.m((e)e2, (c)o)) == e) {
                return e;
            }
        }
        return x7.b.b(((b$b)m).a());
    }
}
