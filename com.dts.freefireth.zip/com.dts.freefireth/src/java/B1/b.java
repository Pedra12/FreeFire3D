package b1;

import Y0.i;
import java.util.Iterator;
import kotlin.jvm.functions.Function1;
import kotlin.collections.CollectionsKt;
import Y0.z;
import android.os.Build$VERSION;
import Y0.w;
import java.util.List;
import Y0.k;
import Y0.C;
import Y0.p;
import kotlin.jvm.internal.Intrinsics;
import P0.u;

public abstract class b
{
    private static final String a;
    
    static {
        final String i = u.i("DiagnosticsWrkr");
        Intrinsics.checkNotNullExpressionValue((Object)i, "tagWithPrefix(\"DiagnosticsWrkr\")");
        a = i;
    }
    
    private static final String c(final w w, final String s, final Integer n, final String s2) {
        final StringBuilder sb = new StringBuilder();
        sb.append('\n');
        sb.append(w.a);
        sb.append("\t ");
        sb.append(w.c);
        sb.append("\t ");
        sb.append((Object)n);
        sb.append("\t ");
        sb.append(((Enum)w.b).name());
        sb.append("\t ");
        sb.append(s);
        sb.append("\t ");
        sb.append(s2);
        sb.append('\t');
        return sb.toString();
    }
    
    private static final String d(final p p4, final C c, final k k, final List list) {
        final StringBuilder sb = new StringBuilder();
        String s;
        if (Build$VERSION.SDK_INT >= 23) {
            s = "Job Id";
        }
        else {
            s = "Alarm Id";
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("\n Id \t Class Name\t ");
        sb2.append(s);
        sb2.append("\t State\t Unique Name\t Tags\t");
        sb.append(sb2.toString());
        for (final w w : list) {
            final i d = k.d(z.a(w));
            Integer value;
            if (d != null) {
                value = d.c;
            }
            else {
                value = null;
            }
            sb.append(c(w, CollectionsKt.V((Iterable)p4.b(w.a), (CharSequence)",", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null), value, CollectionsKt.V((Iterable)c.a(w.a), (CharSequence)",", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null)));
        }
        final String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue((Object)string, "StringBuilder().apply(builderAction).toString()");
        return string;
    }
}
