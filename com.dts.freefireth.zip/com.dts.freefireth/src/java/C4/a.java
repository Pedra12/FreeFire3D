package c4;

import android.os.Parcel;
import android.os.IBinder;
import android.os.IInterface;

public abstract class a implements IInterface
{
    private final IBinder g;
    private final String h;
    
    protected a(final IBinder g, final String h) {
        this.g = g;
        this.h = h;
    }
    
    public final IBinder asBinder() {
        return this.g;
    }
    
    protected final Parcel f() {
        final Parcel obtain = Parcel.obtain();
        obtain.writeInterfaceToken(this.h);
        return obtain;
    }
    
    protected final void g(final int n, final Parcel parcel) {
        final Parcel obtain = Parcel.obtain();
        try {
            this.g.transact(n, parcel, obtain, 0);
            obtain.readException();
        }
        finally {
            parcel.recycle();
            obtain.recycle();
        }
    }
}
