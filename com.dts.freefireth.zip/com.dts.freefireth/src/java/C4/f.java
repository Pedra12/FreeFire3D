package c4;

import android.os.IInterface;
import android.os.IBinder;
import android.os.Bundle;
import com.google.android.gms.common.api.c$b;
import com.google.android.gms.common.api.c$a;
import z3.d;
import android.os.Looper;
import android.content.Context;
import p3.g;
import com.google.android.gms.common.internal.c;

public final class f extends c
{
    private final g K;
    
    public f(final Context context, final Looper looper, final d d, final g g, final c$a c$a, final c$b c$b) {
        super(context, looper, 68, d, c$a, c$b);
        g d2 = g;
        if (g == null) {
            d2 = g.d;
        }
        final p3.f f = new p3.f(d2);
        f.a(b.a());
        this.K = new g(f);
    }
    
    protected final Bundle A() {
        return this.K.a();
    }
    
    protected final String E() {
        return "com.google.android.gms.auth.api.credentials.internal.ICredentialsService";
    }
    
    protected final String F() {
        return "com.google.android.gms.auth.api.credentials.service.START";
    }
    
    public final int k() {
        return 12800000;
    }
}
