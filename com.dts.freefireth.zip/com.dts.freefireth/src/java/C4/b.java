package c4;

import android.util.Base64;
import java.security.SecureRandom;

public abstract class b
{
    private static final SecureRandom a;
    
    static {
        a = new SecureRandom();
    }
    
    public static String a() {
        final byte[] array = new byte[16];
        b.a.nextBytes(array);
        return Base64.encodeToString(array, 11);
    }
}
