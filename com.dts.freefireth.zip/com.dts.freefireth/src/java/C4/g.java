package c4;

import android.os.IBinder;
import android.os.IInterface;

public final class g extends a implements IInterface
{
    g(final IBinder binder) {
        super(binder, "com.google.android.gms.auth.api.credentials.internal.ICredentialsService");
    }
}
