package com.beetalk.sdk.account;

import android.accounts.AbstractAccountAuthenticator;
import android.content.Context;
import android.os.IBinder;
import android.content.Intent;
import android.app.Service;

public class AccountAuthenticatorService extends Service
{
    public IBinder onBind(final Intent intent) {
        return ((AbstractAccountAuthenticator)new a((Context)this)).getIBinder();
    }
}
