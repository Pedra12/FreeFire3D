package com.beetalk.sdk.account;

import W2.b;
import com.garena.pay.android.l;
import com.beetalk.sdk.s;
import java.util.concurrent.Callable;
import com.beetalk.sdk.X$e;
import android.app.Activity;
import com.beetalk.sdk.networking.model.VerifyOTPResponse;
import com.beetalk.sdk.networking.model.UnBindMobileNumberResponse;
import com.beetalk.sdk.networking.model.GetOTPResponse;
import com.beetalk.sdk.networking.model.BoundMobileNumberResponse;
import com.beetalk.sdk.networking.service.G;
import com.beetalk.sdk.helper.M;
import com.beetalk.sdk.networking.model.UpdateMobileNumberResponse;

public final class h
{
    private h() {
    }
    
    public static void f(final Activity activity, final String s, final String s2, final X$e x$e) {
        M.e(activity, x$e, (Callable)new g(s, s2));
    }
    
    private static s g() {
        final s w = s.w();
        if (s.j(w)) {
            return w;
        }
        throw new b(l.b1);
    }
    
    public static void h(final Activity activity, final String s, final String s2, final X$e x$e) {
        M.e(activity, x$e, (Callable)new f(s, s2));
    }
    
    public static void i(final Activity activity, final X$e x$e) {
        M.e(activity, x$e, (Callable)new d());
    }
    
    public static void j(final Activity activity, final String s, final String s2, final X$e x$e) {
        M.e(activity, x$e, (Callable)new c(s, s2));
    }
    
    public static void k(final Activity activity, final String s, final String s2, final X$e x$e) {
        M.e(activity, x$e, (Callable)new e(s, s2));
    }
}
