package com.beetalk.sdk.account;

import android.accounts.Account;
import android.os.Bundle;
import android.accounts.AccountAuthenticatorResponse;
import android.content.Context;
import android.accounts.AbstractAccountAuthenticator;

public class a extends AbstractAccountAuthenticator
{
    public a(final Context context) {
        super(context);
    }
    
    public Bundle addAccount(final AccountAuthenticatorResponse accountAuthenticatorResponse, final String s, final String s2, final String[] array, final Bundle bundle) {
        return null;
    }
    
    public Bundle confirmCredentials(final AccountAuthenticatorResponse accountAuthenticatorResponse, final Account account, final Bundle bundle) {
        return null;
    }
    
    public Bundle editProperties(final AccountAuthenticatorResponse accountAuthenticatorResponse, final String s) {
        return null;
    }
    
    public Bundle getAccountRemovalAllowed(final AccountAuthenticatorResponse accountAuthenticatorResponse, final Account account) {
        return super.getAccountRemovalAllowed(accountAuthenticatorResponse, account);
    }
    
    public Bundle getAuthToken(final AccountAuthenticatorResponse accountAuthenticatorResponse, final Account account, final String s, final Bundle bundle) {
        return null;
    }
    
    public String getAuthTokenLabel(final String s) {
        return s;
    }
    
    public Bundle hasFeatures(final AccountAuthenticatorResponse accountAuthenticatorResponse, final Account account, final String[] array) {
        return null;
    }
    
    public Bundle updateCredentials(final AccountAuthenticatorResponse accountAuthenticatorResponse, final Account account, final String s, final Bundle bundle) {
        return null;
    }
}
