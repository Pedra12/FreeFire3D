package com.beetalk.sdk.account;

import android.os.BaseBundle;
import android.os.ParcelFileDescriptor;
import android.os.Bundle;
import c1.g;
import java.util.concurrent.Callable;
import c1.i;
import java.util.HashMap;
import android.content.ActivityNotFoundException;
import org.json.JSONException;
import org.json.JSONObject;
import android.os.Parcelable;
import android.content.Intent;
import com.beetalk.sdk.X;
import java.io.Writer;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import java.io.BufferedWriter;
import java.util.Map;
import java.io.FileDescriptor;
import android.text.TextUtils;
import java.io.IOException;
import java.io.Reader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.BufferedReader;
import com.beetalk.sdk.helper.t;
import android.content.Context;
import k0.a;
import java.util.Iterator;
import android.content.UriPermission;
import com.beetalk.sdk.helper.k;
import android.net.Uri;
import android.app.Activity;

public class MigrateGuestActivity extends Activity
{
    private int a;
    
    public MigrateGuestActivity() {
        this.a = 0;
    }
    
    private boolean b(final String s) {
        String string = s;
        if (s == null) {
            string = Uri.parse("content://com.android.externalstorage.documents/document/primary:com.garena.msdk").toString();
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("checkSAFPermission: guest: ");
        sb.append(string);
        k.a(sb.toString(), new Object[0]);
        for (final UriPermission uriPermission : ((Context)this).getContentResolver().getPersistedUriPermissions()) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("checkSAFPermission: ");
            sb2.append(uriPermission.getUri().toString());
            k.a(sb2.toString(), new Object[0]);
            if (uriPermission.getUri().toString().equals((Object)string) && uriPermission.isReadPermission() && uriPermission.isWritePermission()) {
                return true;
            }
        }
        return false;
    }
    
    private void c(final Uri p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: aload_1        
        //     2: invokestatic    k0/a.b:(Landroid/content/Context;Landroid/net/Uri;)Lk0/a;
        //     5: astore          11
        //     7: iconst_0       
        //     8: istore          5
        //    10: iconst_0       
        //    11: istore_3       
        //    12: iconst_0       
        //    13: istore          4
        //    15: aload           11
        //    17: ifnonnull       35
        //    20: ldc             "documentFile is null"
        //    22: iconst_0       
        //    23: anewarray       Ljava/lang/Object;
        //    26: invokestatic    com/beetalk/sdk/helper/k.c:(Ljava/lang/String;[Ljava/lang/Object;)V
        //    29: aload_0        
        //    30: iconst_1       
        //    31: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.k:(I)V
        //    34: return         
        //    35: aload           11
        //    37: invokevirtual   k0/a.f:()[Lk0/a;
        //    40: astore          12
        //    42: aload_0        
        //    43: invokestatic    com/beetalk/sdk/helper/t.f:(Landroid/content/Context;)I
        //    46: istore          7
        //    48: aload           12
        //    50: arraylength    
        //    51: istore          6
        //    53: iconst_0       
        //    54: istore_2       
        //    55: aconst_null    
        //    56: astore          15
        //    58: aconst_null    
        //    59: astore          17
        //    61: aconst_null    
        //    62: astore          10
        //    64: aconst_null    
        //    65: astore          16
        //    67: iload_2        
        //    68: iload           6
        //    70: if_icmpge       167
        //    73: aload           12
        //    75: iload_2        
        //    76: aaload         
        //    77: astore          9
        //    79: aload           9
        //    81: invokevirtual   k0/a.e:()Z
        //    84: ifne            90
        //    87: goto            122
        //    90: aload           9
        //    92: invokevirtual   k0/a.c:()Ljava/lang/String;
        //    95: astore          13
        //    97: aload           13
        //    99: ifnonnull       105
        //   102: goto            122
        //   105: aload           13
        //   107: iload           7
        //   109: invokestatic    java/lang/String.valueOf:(I)Ljava/lang/String;
        //   112: invokevirtual   java/lang/String.contains:(Ljava/lang/CharSequence;)Z
        //   115: istore          8
        //   117: iload           8
        //   119: ifne            170
        //   122: iinc            2, 1
        //   125: goto            55
        //   128: astore          12
        //   130: new             Ljava/lang/StringBuilder;
        //   133: dup            
        //   134: invokespecial   java/lang/StringBuilder.<init>:()V
        //   137: astore          9
        //   139: aload           9
        //   141: ldc             "backup visit file: "
        //   143: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   146: pop            
        //   147: aload           9
        //   149: aload           12
        //   151: invokevirtual   java/lang/Throwable.getMessage:()Ljava/lang/String;
        //   154: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   157: pop            
        //   158: aload_0        
        //   159: aload           9
        //   161: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   164: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.m:(Ljava/lang/String;)V
        //   167: aconst_null    
        //   168: astore          9
        //   170: aload           9
        //   172: astore          14
        //   174: aload           9
        //   176: ifnonnull       272
        //   179: aload           11
        //   181: ldc             "application/dat"
        //   183: aload_0        
        //   184: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.f:()Ljava/lang/String;
        //   187: invokevirtual   k0/a.a:(Ljava/lang/String;Ljava/lang/String;)Lk0/a;
        //   190: astore          14
        //   192: goto            272
        //   195: astore_1       
        //   196: new             Ljava/lang/StringBuilder;
        //   199: dup            
        //   200: invokespecial   java/lang/StringBuilder.<init>:()V
        //   203: astore          9
        //   205: aload           9
        //   207: ldc             "guestFile create exception: "
        //   209: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   212: pop            
        //   213: aload           9
        //   215: aload_1        
        //   216: invokevirtual   java/lang/Throwable.getMessage:()Ljava/lang/String;
        //   219: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   222: pop            
        //   223: aload           9
        //   225: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   228: iconst_0       
        //   229: anewarray       Ljava/lang/Object;
        //   232: invokestatic    com/beetalk/sdk/helper/k.c:(Ljava/lang/String;[Ljava/lang/Object;)V
        //   235: new             Ljava/lang/StringBuilder;
        //   238: dup            
        //   239: invokespecial   java/lang/StringBuilder.<init>:()V
        //   242: astore          9
        //   244: aload           9
        //   246: ldc             "backup create exception: "
        //   248: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   251: pop            
        //   252: aload           9
        //   254: aload_1        
        //   255: invokevirtual   java/lang/Throwable.getMessage:()Ljava/lang/String;
        //   258: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   261: pop            
        //   262: aload_0        
        //   263: aload           9
        //   265: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   268: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.m:(Ljava/lang/String;)V
        //   271: return         
        //   272: aload_0        
        //   273: invokevirtual   android/content/Context.getContentResolver:()Landroid/content/ContentResolver;
        //   276: aload           14
        //   278: invokevirtual   k0/a.d:()Landroid/net/Uri;
        //   281: ldc             "r"
        //   283: invokevirtual   android/content/ContentResolver.openFileDescriptor:(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;
        //   286: astore          9
        //   288: new             Ljava/io/BufferedReader;
        //   291: astore          13
        //   293: new             Ljava/io/InputStreamReader;
        //   296: astore          12
        //   298: new             Ljava/io/FileInputStream;
        //   301: astore          11
        //   303: aload           11
        //   305: aload           9
        //   307: invokevirtual   android/os/ParcelFileDescriptor.getFileDescriptor:()Ljava/io/FileDescriptor;
        //   310: invokespecial   java/io/FileInputStream.<init>:(Ljava/io/FileDescriptor;)V
        //   313: aload           12
        //   315: aload           11
        //   317: invokespecial   java/io/InputStreamReader.<init>:(Ljava/io/InputStream;)V
        //   320: aload           13
        //   322: aload           12
        //   324: invokespecial   java/io/BufferedReader.<init>:(Ljava/io/Reader;)V
        //   327: aload           9
        //   329: astore          10
        //   331: aload           13
        //   333: astore          11
        //   335: new             Ljava/lang/StringBuilder;
        //   338: astore          12
        //   340: aload           9
        //   342: astore          10
        //   344: aload           13
        //   346: astore          11
        //   348: aload           12
        //   350: invokespecial   java/lang/StringBuilder.<init>:()V
        //   353: aload           9
        //   355: astore          10
        //   357: aload           13
        //   359: astore          11
        //   361: aload           13
        //   363: invokevirtual   java/io/BufferedReader.readLine:()Ljava/lang/String;
        //   366: astore          18
        //   368: aload           18
        //   370: ifnull          426
        //   373: aload           9
        //   375: astore          10
        //   377: aload           13
        //   379: astore          11
        //   381: aload           12
        //   383: aload           18
        //   385: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   388: pop            
        //   389: goto            353
        //   392: astore_1       
        //   393: aload           10
        //   395: astore          9
        //   397: aload           11
        //   399: astore          10
        //   401: goto            1429
        //   404: astore          10
        //   406: aload           9
        //   408: astore          12
        //   410: aload           13
        //   412: astore          9
        //   414: aload           10
        //   416: astore          13
        //   418: goto            610
        //   421: astore          18
        //   423: goto            448
        //   426: aload           9
        //   428: astore          10
        //   430: aload           13
        //   432: astore          11
        //   434: aload           12
        //   436: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   439: astore          12
        //   441: aload           12
        //   443: astore          10
        //   445: goto            542
        //   448: aload           9
        //   450: astore          10
        //   452: aload           13
        //   454: astore          11
        //   456: new             Ljava/lang/StringBuilder;
        //   459: astore          12
        //   461: aload           9
        //   463: astore          10
        //   465: aload           13
        //   467: astore          11
        //   469: aload           12
        //   471: invokespecial   java/lang/StringBuilder.<init>:()V
        //   474: aload           9
        //   476: astore          10
        //   478: aload           13
        //   480: astore          11
        //   482: aload           12
        //   484: ldc             "backup read IO: "
        //   486: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   489: pop            
        //   490: aload           9
        //   492: astore          10
        //   494: aload           13
        //   496: astore          11
        //   498: aload           12
        //   500: aload           18
        //   502: invokevirtual   java/lang/Throwable.getMessage:()Ljava/lang/String;
        //   505: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   508: pop            
        //   509: aload           9
        //   511: astore          10
        //   513: aload           13
        //   515: astore          11
        //   517: aload_0        
        //   518: aload           12
        //   520: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   523: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.m:(Ljava/lang/String;)V
        //   526: aload           9
        //   528: astore          10
        //   530: aload           13
        //   532: astore          11
        //   534: aload           18
        //   536: invokevirtual   java/lang/Throwable.printStackTrace:()V
        //   539: aconst_null    
        //   540: astore          10
        //   542: aload           13
        //   544: invokevirtual   java/io/BufferedReader.close:()V
        //   547: goto            557
        //   550: astore          11
        //   552: aload           11
        //   554: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //   557: aload           9
        //   559: invokevirtual   android/os/ParcelFileDescriptor.close:()V
        //   562: goto            744
        //   565: astore          9
        //   567: aload           9
        //   569: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //   572: goto            744
        //   575: astore_1       
        //   576: goto            1429
        //   579: astore          13
        //   581: aconst_null    
        //   582: astore          10
        //   584: aload           9
        //   586: astore          12
        //   588: aload           10
        //   590: astore          9
        //   592: goto            610
        //   595: astore_1       
        //   596: aconst_null    
        //   597: astore          9
        //   599: goto            1429
        //   602: astore          13
        //   604: aconst_null    
        //   605: astore          12
        //   607: aconst_null    
        //   608: astore          9
        //   610: aload           12
        //   612: astore          10
        //   614: aload           9
        //   616: astore          11
        //   618: new             Ljava/lang/StringBuilder;
        //   621: astore          18
        //   623: aload           12
        //   625: astore          10
        //   627: aload           9
        //   629: astore          11
        //   631: aload           18
        //   633: invokespecial   java/lang/StringBuilder.<init>:()V
        //   636: aload           12
        //   638: astore          10
        //   640: aload           9
        //   642: astore          11
        //   644: aload           18
        //   646: ldc             "backup read: "
        //   648: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   651: pop            
        //   652: aload           12
        //   654: astore          10
        //   656: aload           9
        //   658: astore          11
        //   660: aload           18
        //   662: aload           13
        //   664: invokevirtual   java/lang/Throwable.getMessage:()Ljava/lang/String;
        //   667: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   670: pop            
        //   671: aload           12
        //   673: astore          10
        //   675: aload           9
        //   677: astore          11
        //   679: aload_0        
        //   680: aload           18
        //   682: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   685: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.m:(Ljava/lang/String;)V
        //   688: aload           12
        //   690: astore          10
        //   692: aload           9
        //   694: astore          11
        //   696: aload           13
        //   698: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //   701: aload           9
        //   703: ifnull          721
        //   706: aload           9
        //   708: invokevirtual   java/io/BufferedReader.close:()V
        //   711: goto            721
        //   714: astore          9
        //   716: aload           9
        //   718: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //   721: aload           12
        //   723: ifnull          741
        //   726: aload           12
        //   728: invokevirtual   android/os/ParcelFileDescriptor.close:()V
        //   731: goto            741
        //   734: astore          9
        //   736: aload           9
        //   738: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //   741: aconst_null    
        //   742: astore          10
        //   744: aload_0        
        //   745: aload           10
        //   747: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.o:(Ljava/lang/String;)Ljava/util/Map;
        //   750: astore          13
        //   752: invokestatic    com/beetalk/sdk/cache/a.s:()Lcom/beetalk/sdk/cache/a;
        //   755: invokevirtual   com/beetalk/sdk/cache/l.f:()Ljava/lang/String;
        //   758: astore          9
        //   760: invokestatic    com/beetalk/sdk/cache/a.s:()Lcom/beetalk/sdk/cache/a;
        //   763: invokevirtual   com/beetalk/sdk/cache/l.c:()Ljava/lang/String;
        //   766: astore          10
        //   768: aload           9
        //   770: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   773: ifne            1371
        //   776: aload           10
        //   778: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   781: ifeq            787
        //   784: goto            1371
        //   787: invokestatic    com/beetalk/sdk/cache/a.s:()Lcom/beetalk/sdk/cache/a;
        //   790: invokevirtual   com/beetalk/sdk/cache/l.g:()Ljava/lang/String;
        //   793: astore          11
        //   795: invokestatic    com/beetalk/sdk/cache/a.s:()Lcom/beetalk/sdk/cache/a;
        //   798: invokevirtual   com/beetalk/sdk/cache/l.d:()Ljava/lang/String;
        //   801: astore          12
        //   803: aload           13
        //   805: aload           11
        //   807: aload           9
        //   809: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   814: pop            
        //   815: aload           13
        //   817: aload           12
        //   819: aload           10
        //   821: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   826: pop            
        //   827: aload_0        
        //   828: aload           13
        //   830: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.i:(Ljava/util/Map;)Ljava/lang/String;
        //   833: astore          13
        //   835: aload_0        
        //   836: invokevirtual   android/content/Context.getContentResolver:()Landroid/content/ContentResolver;
        //   839: aload           14
        //   841: invokevirtual   k0/a.d:()Landroid/net/Uri;
        //   844: ldc             "wt"
        //   846: invokevirtual   android/content/ContentResolver.openFileDescriptor:(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;
        //   849: astore          9
        //   851: aload           9
        //   853: astore          12
        //   855: aload           16
        //   857: astore          11
        //   859: new             Ljava/io/BufferedWriter;
        //   862: astore          10
        //   864: aload           9
        //   866: astore          12
        //   868: aload           16
        //   870: astore          11
        //   872: new             Ljava/io/OutputStreamWriter;
        //   875: astore          17
        //   877: aload           9
        //   879: astore          12
        //   881: aload           16
        //   883: astore          11
        //   885: new             Ljava/io/FileOutputStream;
        //   888: astore          14
        //   890: aload           9
        //   892: astore          12
        //   894: aload           16
        //   896: astore          11
        //   898: aload           14
        //   900: aload           9
        //   902: invokevirtual   android/os/ParcelFileDescriptor.getFileDescriptor:()Ljava/io/FileDescriptor;
        //   905: invokespecial   java/io/FileOutputStream.<init>:(Ljava/io/FileDescriptor;)V
        //   908: aload           9
        //   910: astore          12
        //   912: aload           16
        //   914: astore          11
        //   916: aload           17
        //   918: aload           14
        //   920: invokespecial   java/io/OutputStreamWriter.<init>:(Ljava/io/OutputStream;)V
        //   923: aload           9
        //   925: astore          12
        //   927: aload           16
        //   929: astore          11
        //   931: aload           10
        //   933: aload           17
        //   935: invokespecial   java/io/BufferedWriter.<init>:(Ljava/io/Writer;)V
        //   938: iload           4
        //   940: istore_3       
        //   941: aload           10
        //   943: aload           13
        //   945: invokevirtual   java/io/Writer.write:(Ljava/lang/String;)V
        //   948: iload           4
        //   950: istore_3       
        //   951: aload           10
        //   953: invokevirtual   java/io/BufferedWriter.flush:()V
        //   956: iload           4
        //   958: istore_3       
        //   959: ldc_w           "doBackupeGuest success"
        //   962: iconst_0       
        //   963: anewarray       Ljava/lang/Object;
        //   966: invokestatic    com/beetalk/sdk/helper/k.a:(Ljava/lang/String;[Ljava/lang/Object;)V
        //   969: aload_0        
        //   970: iconst_0       
        //   971: aload_1        
        //   972: invokevirtual   android/net/Uri.toString:()Ljava/lang/String;
        //   975: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.l:(ILjava/lang/String;)V
        //   978: aload           10
        //   980: invokevirtual   java/io/BufferedWriter.close:()V
        //   983: goto            991
        //   986: astore_1       
        //   987: aload_1        
        //   988: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //   991: aload           9
        //   993: invokevirtual   android/os/ParcelFileDescriptor.close:()V
        //   996: goto            1386
        //   999: astore_1       
        //  1000: aload_1        
        //  1001: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //  1004: goto            1386
        //  1007: astore_1       
        //  1008: aload           10
        //  1010: astore          11
        //  1012: goto            1325
        //  1015: astore          11
        //  1017: aload           10
        //  1019: astore_1       
        //  1020: iconst_1       
        //  1021: istore_2       
        //  1022: aload           9
        //  1024: astore          10
        //  1026: aload           11
        //  1028: astore          9
        //  1030: goto            1195
        //  1033: astore_1       
        //  1034: iconst_1       
        //  1035: istore_2       
        //  1036: goto            1061
        //  1039: astore          11
        //  1041: aload           10
        //  1043: astore_1       
        //  1044: iload_3        
        //  1045: istore_2       
        //  1046: aload           9
        //  1048: astore          10
        //  1050: aload           11
        //  1052: astore          9
        //  1054: goto            1195
        //  1057: astore_1       
        //  1058: iload           5
        //  1060: istore_2       
        //  1061: iload_2        
        //  1062: istore_3       
        //  1063: new             Ljava/lang/StringBuilder;
        //  1066: astore          11
        //  1068: iload_2        
        //  1069: istore_3       
        //  1070: aload           11
        //  1072: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1075: iload_2        
        //  1076: istore_3       
        //  1077: aload           11
        //  1079: ldc_w           "backup write IO: "
        //  1082: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1085: pop            
        //  1086: iload_2        
        //  1087: istore_3       
        //  1088: aload           11
        //  1090: aload_1        
        //  1091: invokevirtual   java/lang/Throwable.getMessage:()Ljava/lang/String;
        //  1094: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1097: pop            
        //  1098: iload_2        
        //  1099: istore_3       
        //  1100: aload_0        
        //  1101: aload           11
        //  1103: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1106: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.m:(Ljava/lang/String;)V
        //  1109: iload_2        
        //  1110: istore_3       
        //  1111: aload_1        
        //  1112: invokevirtual   java/lang/Throwable.printStackTrace:()V
        //  1115: aload           10
        //  1117: invokevirtual   java/io/BufferedWriter.close:()V
        //  1120: goto            1128
        //  1123: astore_1       
        //  1124: aload_1        
        //  1125: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //  1128: iload_2        
        //  1129: istore_3       
        //  1130: aload           9
        //  1132: invokevirtual   android/os/ParcelFileDescriptor.close:()V
        //  1135: iload_2        
        //  1136: istore_3       
        //  1137: goto            1313
        //  1140: astore_1       
        //  1141: aload_1        
        //  1142: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //  1145: goto            1313
        //  1148: astore_1       
        //  1149: aload           12
        //  1151: astore          9
        //  1153: goto            1325
        //  1156: astore          11
        //  1158: iload_3        
        //  1159: istore_2       
        //  1160: aload           9
        //  1162: astore          10
        //  1164: aload           15
        //  1166: astore_1       
        //  1167: aload           11
        //  1169: astore          9
        //  1171: goto            1195
        //  1174: astore_1       
        //  1175: aconst_null    
        //  1176: astore          9
        //  1178: aload           17
        //  1180: astore          11
        //  1182: goto            1325
        //  1185: astore          9
        //  1187: aconst_null    
        //  1188: astore          10
        //  1190: aload           15
        //  1192: astore_1       
        //  1193: iload_3        
        //  1194: istore_2       
        //  1195: aload           10
        //  1197: astore          12
        //  1199: aload_1        
        //  1200: astore          11
        //  1202: new             Ljava/lang/StringBuilder;
        //  1205: astore          13
        //  1207: aload           10
        //  1209: astore          12
        //  1211: aload_1        
        //  1212: astore          11
        //  1214: aload           13
        //  1216: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1219: aload           10
        //  1221: astore          12
        //  1223: aload_1        
        //  1224: astore          11
        //  1226: aload           13
        //  1228: ldc_w           "backup write: "
        //  1231: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1234: pop            
        //  1235: aload           10
        //  1237: astore          12
        //  1239: aload_1        
        //  1240: astore          11
        //  1242: aload           13
        //  1244: aload           9
        //  1246: invokevirtual   java/lang/Throwable.getMessage:()Ljava/lang/String;
        //  1249: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1252: pop            
        //  1253: aload           10
        //  1255: astore          12
        //  1257: aload_1        
        //  1258: astore          11
        //  1260: aload_0        
        //  1261: aload           13
        //  1263: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1266: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.m:(Ljava/lang/String;)V
        //  1269: aload           10
        //  1271: astore          12
        //  1273: aload_1        
        //  1274: astore          11
        //  1276: aload           9
        //  1278: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //  1281: aload_1        
        //  1282: ifnull          1297
        //  1285: aload_1        
        //  1286: invokevirtual   java/io/BufferedWriter.close:()V
        //  1289: goto            1297
        //  1292: astore_1       
        //  1293: aload_1        
        //  1294: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //  1297: iload_2        
        //  1298: istore_3       
        //  1299: aload           10
        //  1301: ifnull          1313
        //  1304: iload_2        
        //  1305: istore_3       
        //  1306: aload           10
        //  1308: invokevirtual   android/os/ParcelFileDescriptor.close:()V
        //  1311: iload_2        
        //  1312: istore_3       
        //  1313: iload_3        
        //  1314: ifne            1386
        //  1317: aload_0        
        //  1318: iconst_1       
        //  1319: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.k:(I)V
        //  1322: goto            1386
        //  1325: aload           11
        //  1327: ifnull          1345
        //  1330: aload           11
        //  1332: invokevirtual   java/io/BufferedWriter.close:()V
        //  1335: goto            1345
        //  1338: astore          10
        //  1340: aload           10
        //  1342: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //  1345: aload           9
        //  1347: ifnull          1365
        //  1350: aload           9
        //  1352: invokevirtual   android/os/ParcelFileDescriptor.close:()V
        //  1355: goto            1365
        //  1358: astore          9
        //  1360: aload           9
        //  1362: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //  1365: aload_1        
        //  1366: athrow         
        //  1367: astore_1       
        //  1368: goto            1387
        //  1371: ldc_w           "strUid or strPwd is null"
        //  1374: iconst_0       
        //  1375: anewarray       Ljava/lang/Object;
        //  1378: invokestatic    com/beetalk/sdk/helper/k.c:(Ljava/lang/String;[Ljava/lang/Object;)V
        //  1381: aload_0        
        //  1382: iconst_1       
        //  1383: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.k:(I)V
        //  1386: return         
        //  1387: new             Ljava/lang/StringBuilder;
        //  1390: dup            
        //  1391: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1394: astore          9
        //  1396: aload           9
        //  1398: ldc_w           "backup mod: "
        //  1401: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1404: pop            
        //  1405: aload           9
        //  1407: aload_1        
        //  1408: invokevirtual   java/lang/Throwable.getMessage:()Ljava/lang/String;
        //  1411: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1414: pop            
        //  1415: aload_0        
        //  1416: aload           9
        //  1418: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1421: invokespecial   com/beetalk/sdk/account/MigrateGuestActivity.m:(Ljava/lang/String;)V
        //  1424: aload_1        
        //  1425: invokevirtual   java/lang/Throwable.printStackTrace:()V
        //  1428: return         
        //  1429: aload           10
        //  1431: ifnull          1449
        //  1434: aload           10
        //  1436: invokevirtual   java/io/BufferedReader.close:()V
        //  1439: goto            1449
        //  1442: astore          10
        //  1444: aload           10
        //  1446: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //  1449: aload           9
        //  1451: ifnull          1469
        //  1454: aload           9
        //  1456: invokevirtual   android/os/ParcelFileDescriptor.close:()V
        //  1459: goto            1469
        //  1462: astore          9
        //  1464: aload           9
        //  1466: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //  1469: aload_1        
        //  1470: athrow         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  79     87     128    167    Any
        //  90     97     128    167    Any
        //  105    117    128    167    Any
        //  179    192    195    272    Any
        //  272    288    602    610    Ljava/lang/Exception;
        //  272    288    595    602    Any
        //  288    327    579    595    Ljava/lang/Exception;
        //  288    327    575    579    Any
        //  335    340    421    542    Ljava/io/IOException;
        //  335    340    404    421    Ljava/lang/Exception;
        //  335    340    392    404    Any
        //  348    353    421    542    Ljava/io/IOException;
        //  348    353    404    421    Ljava/lang/Exception;
        //  348    353    392    404    Any
        //  361    368    421    542    Ljava/io/IOException;
        //  361    368    404    421    Ljava/lang/Exception;
        //  361    368    392    404    Any
        //  381    389    421    542    Ljava/io/IOException;
        //  381    389    404    421    Ljava/lang/Exception;
        //  381    389    392    404    Any
        //  434    441    421    542    Ljava/io/IOException;
        //  434    441    404    421    Ljava/lang/Exception;
        //  434    441    392    404    Any
        //  456    461    404    421    Ljava/lang/Exception;
        //  456    461    392    404    Any
        //  469    474    404    421    Ljava/lang/Exception;
        //  469    474    392    404    Any
        //  482    490    404    421    Ljava/lang/Exception;
        //  482    490    392    404    Any
        //  498    509    404    421    Ljava/lang/Exception;
        //  498    509    392    404    Any
        //  517    526    404    421    Ljava/lang/Exception;
        //  517    526    392    404    Any
        //  534    539    404    421    Ljava/lang/Exception;
        //  534    539    392    404    Any
        //  542    547    550    557    Ljava/io/IOException;
        //  557    562    565    575    Ljava/io/IOException;
        //  618    623    392    404    Any
        //  631    636    392    404    Any
        //  644    652    392    404    Any
        //  660    671    392    404    Any
        //  679    688    392    404    Any
        //  696    701    392    404    Any
        //  706    711    714    721    Ljava/io/IOException;
        //  726    731    734    741    Ljava/io/IOException;
        //  744    784    1367   1371   Any
        //  787    835    1367   1371   Any
        //  835    851    1185   1195   Ljava/lang/Exception;
        //  835    851    1174   1185   Any
        //  859    864    1156   1174   Ljava/lang/Exception;
        //  859    864    1148   1156   Any
        //  872    877    1156   1174   Ljava/lang/Exception;
        //  872    877    1148   1156   Any
        //  885    890    1156   1174   Ljava/lang/Exception;
        //  885    890    1148   1156   Any
        //  898    908    1156   1174   Ljava/lang/Exception;
        //  898    908    1148   1156   Any
        //  916    923    1156   1174   Ljava/lang/Exception;
        //  916    923    1148   1156   Any
        //  931    938    1156   1174   Ljava/lang/Exception;
        //  931    938    1148   1156   Any
        //  941    948    1057   1061   Ljava/io/IOException;
        //  941    948    1039   1057   Ljava/lang/Exception;
        //  941    948    1007   1015   Any
        //  951    956    1057   1061   Ljava/io/IOException;
        //  951    956    1039   1057   Ljava/lang/Exception;
        //  951    956    1007   1015   Any
        //  959    969    1057   1061   Ljava/io/IOException;
        //  959    969    1039   1057   Ljava/lang/Exception;
        //  959    969    1007   1015   Any
        //  969    978    1033   1039   Ljava/io/IOException;
        //  969    978    1015   1033   Ljava/lang/Exception;
        //  969    978    1007   1015   Any
        //  978    983    986    991    Ljava/io/IOException;
        //  991    996    999    1007   Ljava/io/IOException;
        //  1063   1068   1039   1057   Ljava/lang/Exception;
        //  1063   1068   1007   1015   Any
        //  1070   1075   1039   1057   Ljava/lang/Exception;
        //  1070   1075   1007   1015   Any
        //  1077   1086   1039   1057   Ljava/lang/Exception;
        //  1077   1086   1007   1015   Any
        //  1088   1098   1039   1057   Ljava/lang/Exception;
        //  1088   1098   1007   1015   Any
        //  1100   1109   1039   1057   Ljava/lang/Exception;
        //  1100   1109   1007   1015   Any
        //  1111   1115   1039   1057   Ljava/lang/Exception;
        //  1111   1115   1007   1015   Any
        //  1115   1120   1123   1128   Ljava/io/IOException;
        //  1130   1135   1140   1148   Ljava/io/IOException;
        //  1202   1207   1148   1156   Any
        //  1214   1219   1148   1156   Any
        //  1226   1235   1148   1156   Any
        //  1242   1253   1148   1156   Any
        //  1260   1269   1148   1156   Any
        //  1276   1281   1148   1156   Any
        //  1285   1289   1292   1297   Ljava/io/IOException;
        //  1306   1311   1140   1148   Ljava/io/IOException;
        //  1330   1335   1338   1345   Ljava/io/IOException;
        //  1350   1355   1358   1365   Ljava/io/IOException;
        //  1371   1386   1367   1371   Any
        //  1434   1439   1442   1449   Ljava/io/IOException;
        //  1454   1459   1462   1469   Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException: Attempt to invoke virtual method 'g5.m0 g5.d2.L()' on a null object reference
        //     at e5.d0.e(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:26)
        //     at e5.c0.s(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:1643)
        //     at q5.g.o(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:2651)
        //     at q5.g.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:2099)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:21)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        //     at java.lang.Thread.run(Thread.java:1571)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void d(final Uri uri) {
        Object o = k0.a.b((Context)this, uri);
        if (o == null) {
            k.c("documentFile is null", new Object[0]);
            this.k(1);
            return;
        }
        final a[] f = ((a)o).f();
        if (f.length <= 0) {
            k.c("documentFiles do not contain element", new Object[0]);
            this.k(1);
            return;
        }
        final int f2 = t.f((Context)this);
        final int length = f.length;
        int i = 0;
        int n = 0;
        while (i < length) {
            final a a = f[i];
            Object g = null;
            Object d;
            Object o2 = d = null;
            int n2 = 0;
            Label_0646: {
                try {
                    try {
                        if (!a.e()) {
                            n2 = n;
                            break Label_0646;
                        }
                        d = o2;
                        o = a.c();
                        if (o == null) {
                            n2 = n;
                            break Label_0646;
                        }
                        d = o2;
                        if (!((String)o).contains((CharSequence)String.valueOf(f2))) {
                            n2 = n;
                            break Label_0646;
                        }
                        d = o2;
                        final FileDescriptor fileDescriptor = ((Context)this).getContentResolver().openFileDescriptor(a.d(), "r").getFileDescriptor();
                        d = o2;
                        o = new(java.io.BufferedReader.class)();
                        d = o2;
                        d = o2;
                        d = o2;
                        final FileInputStream fileInputStream = new FileInputStream(fileDescriptor);
                        d = o2;
                        final InputStreamReader inputStreamReader = new InputStreamReader((InputStream)fileInputStream);
                        d = o2;
                        new BufferedReader((Reader)inputStreamReader);
                        n2 = n;
                        Label_0474: {
                            try {
                                try {
                                    n2 = n;
                                    final StringBuilder sb = new StringBuilder();
                                    while (true) {
                                        n2 = n;
                                        o2 = ((BufferedReader)o).readLine();
                                        if (o2 == null) {
                                            break;
                                        }
                                        n2 = n;
                                        sb.append((String)o2);
                                    }
                                }
                                catch (final Exception o2) {
                                    n = n2;
                                }
                                finally {
                                    d = o;
                                }
                            }
                            catch (final IOException d) {
                                break Label_0474;
                            }
                            n2 = n;
                            o2 = this.o(((StringBuilder)d).toString());
                            n2 = n;
                            g = com.beetalk.sdk.cache.a.s().g();
                            n2 = n;
                            d = com.beetalk.sdk.cache.a.s().d();
                            n2 = n;
                            g = ((Map)o2).get(g);
                            n2 = n;
                            d = ((Map)o2).get(d);
                            n2 = n;
                            if (!TextUtils.isEmpty((CharSequence)g)) {
                                n2 = n;
                                if (!TextUtils.isEmpty((CharSequence)d)) {
                                    n2 = n;
                                    com.beetalk.sdk.cache.a.s().j((String)g, (String)d);
                                    n2 = n;
                                    k.a("doMigrateGuest success", new Object[0]);
                                    try {
                                        final Uri uri2;
                                        this.l(0, uri2.toString());
                                        try {
                                            ((BufferedReader)o).close();
                                        }
                                        catch (final IOException ex) {
                                            k.b((Exception)ex);
                                        }
                                        return;
                                    }
                                    catch (final Exception o2) {
                                        n = 1;
                                    }
                                    catch (final IOException d) {
                                        n = 1;
                                        break Label_0474;
                                    }
                                }
                            }
                            n2 = n;
                            k.c("strUid or strPwd is null", new Object[0]);
                            n2 = n;
                            this.k(1);
                            ((BufferedReader)o).close();
                            return;
                        }
                        n2 = n;
                        o2 = new(java.lang.StringBuilder.class)();
                        n2 = n;
                        new StringBuilder();
                        n2 = n;
                        ((StringBuilder)o2).append("migrate IO: ");
                        n2 = n;
                        ((StringBuilder)o2).append(((Throwable)d).getMessage());
                        n2 = n;
                        this.m(((StringBuilder)o2).toString());
                        n2 = n;
                        ((Throwable)d).printStackTrace();
                        n2 = n;
                        try {
                            ((BufferedReader)o).close();
                            n2 = n;
                        }
                        catch (final IOException o) {
                            k.b((Exception)o);
                        }
                        break Label_0646;
                    }
                    finally {}
                }
                catch (final Exception o2) {
                    o = g;
                }
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("migrate: ");
                sb2.append(((Throwable)o2).getMessage());
                this.m(sb2.toString());
                k.b((Exception)o2);
                n2 = n;
                if (o != null) {
                    ((BufferedReader)o).close();
                    n2 = n;
                }
            }
            ++i;
            n = n2;
            continue;
            if (d != null) {
                try {
                    ((BufferedReader)d).close();
                }
                catch (final IOException ex2) {
                    k.b((Exception)ex2);
                }
            }
            return;
        }
        if (n == 0) {
            this.k(1);
        }
    }
    
    private void e(Uri uri) {
        final a b = k0.a.b((Context)this, uri);
        final int n = 0;
        if (b == null) {
            k.c("documentFile is null", new Object[0]);
            this.k(1);
            return;
        }
        final a[] f = b.f();
        final int f2 = t.f((Context)this);
        final int length = f.length;
        int n2 = 0;
        a a;
        while (true) {
            final BufferedWriter bufferedWriter = null;
            final Object o = null;
            Object string = null;
            if (n2 >= length) {
                a = null;
                break;
            }
            a = f[n2];
            try {
                if (a.e()) {
                    final String c = a.c();
                    if (c != null) {
                        if (c.contains((CharSequence)String.valueOf(f2))) {
                            break;
                        }
                    }
                }
            }
            finally {
                string = new StringBuilder();
                ((StringBuilder)string).append("reset visit file: ");
                final Object o2;
                ((StringBuilder)string).append(((Throwable)o2).getMessage());
                this.m(((StringBuilder)string).toString());
            }
            ++n2;
        }
        if (a == null) {
            try {
                b.a("application/dat", this.f());
                k.c("guestFile does not exist.", new Object[0]);
                this.k(1);
            }
            finally {
                final StringBuilder sb = new(java.lang.StringBuilder.class)();
                final StringBuilder sb3;
                final StringBuilder sb2 = sb3 = sb;
                new StringBuilder();
                final StringBuilder sb4 = sb2;
                final String s = "guestFile create exception: ";
                sb4.append(s);
                final StringBuilder sb5 = sb2;
                final Throwable t2;
                final Throwable t = t2;
                final String s2 = t.getMessage();
                sb5.append(s2);
                final StringBuilder sb6 = sb2;
                final String s3 = sb6.toString();
                final int n3 = 0;
                final Object[] array = new Object[n3];
                k.c(s3, array);
                final StringBuilder sb7 = new(java.lang.StringBuilder.class)();
                final StringBuilder sb9;
                final StringBuilder sb8 = sb9 = sb7;
                new StringBuilder();
                final StringBuilder sb10 = sb8;
                final String s4 = "reset create exception: ";
                sb10.append(s4);
                final StringBuilder sb11 = sb8;
                final Throwable t3 = t2;
                final String s5 = t3.getMessage();
                sb11.append(s5);
                final MigrateGuestActivity migrateGuestActivity = this;
                final StringBuilder sb12 = sb8;
                final String s6 = sb12.toString();
                migrateGuestActivity.m(s6);
            }
            return;
        }
        Label_0285: {
            break Label_0285;
            try {
                final StringBuilder sb = new(java.lang.StringBuilder.class)();
                final StringBuilder sb3;
                final StringBuilder sb2 = sb3 = sb;
                new StringBuilder();
                final StringBuilder sb4 = sb2;
                final String s = "guestFile create exception: ";
                sb4.append(s);
                final StringBuilder sb5 = sb2;
                final Throwable t2;
                final Throwable t = t2;
                final String s2 = t.getMessage();
                sb5.append(s2);
                final StringBuilder sb6 = sb2;
                final String s3 = sb6.toString();
                final int n3 = 0;
                final Object[] array = new Object[n3];
                k.c(s3, array);
                final StringBuilder sb7 = new(java.lang.StringBuilder.class)();
                final StringBuilder sb9;
                final StringBuilder sb8 = sb9 = sb7;
                new StringBuilder();
                final StringBuilder sb10 = sb8;
                final String s4 = "reset create exception: ";
                sb10.append(s4);
                final StringBuilder sb11 = sb8;
                final Throwable t3 = t2;
                final String s5 = t3.getMessage();
                sb11.append(s5);
                final MigrateGuestActivity migrateGuestActivity = this;
                final StringBuilder sb12 = sb8;
                final String s6 = sb12.toString();
                migrateGuestActivity.m(s6);
                Label_1353: {
                    return;
                }
                while (true) {
                    BufferedReader bufferedReader = null;
                    Label_1374: {
                    Label_0759:
                        while (true) {
                            Label_0756: {
                                final BufferedWriter bufferedWriter;
                                Object o;
                                Object string = null;
                                Object o2 = null;
                                Object openFileDescriptor;
                                Object o3;
                                Object o4;
                                String line;
                                Object o5;
                                String g;
                                String d;
                                String i;
                                Object openFileDescriptor2;
                                Object o6;
                                FileOutputStream fileOutputStream;
                                StringBuilder sb13;
                                BufferedWriter bufferedWriter2;
                                Exception ex11;
                                Writer writer;
                                StringBuilder sb14;
                                StringBuilder sb15;
                                final Throwable t4;
                                StringBuilder sb16;
                                Label_1394:Block_15_Outer:Block_17_Outer:
                                while (true) {
                                    while (true) {
                                        while (true) {
                                            while (true) {
                                                iftrue(Label_1374:)(string == null);
                                                Block_16: {
                                                    Block_20: {
                                                        break Block_20;
                                                        iftrue(Label_0756:)(o2 == null);
                                                        break Block_16;
                                                        try {
                                                            bufferedReader.close();
                                                        }
                                                        catch (final IOException ex) {
                                                            k.b((Exception)ex);
                                                        }
                                                        continue Label_1394;
                                                        iftrue(Label_0775:)(((String)string).length() > 0);
                                                    }
                                                    try {
                                                        ((BufferedReader)string).close();
                                                    }
                                                    catch (final IOException ex2) {
                                                        k.b((Exception)ex2);
                                                    }
                                                    break Label_1374;
                                                }
                                                try {
                                                    ((ParcelFileDescriptor)o2).close();
                                                }
                                                catch (final IOException ex3) {
                                                    k.b((Exception)ex3);
                                                }
                                                break Label_0756;
                                                try {
                                                    openFileDescriptor = ((Context)this).getContentResolver().openFileDescriptor(a.d(), "r");
                                                    try {
                                                        o3 = new(java.io.BufferedReader.class)();
                                                        o2 = new FileInputStream(((ParcelFileDescriptor)openFileDescriptor).getFileDescriptor());
                                                        new BufferedReader((Reader)new InputStreamReader((InputStream)o2));
                                                        string = openFileDescriptor;
                                                        o4 = o3;
                                                        Label_0439: {
                                                            try {
                                                                try {
                                                                    try {
                                                                        string = openFileDescriptor;
                                                                        o4 = o3;
                                                                        o2 = new StringBuilder();
                                                                        while (true) {
                                                                            string = openFileDescriptor;
                                                                            o4 = o3;
                                                                            line = ((BufferedReader)o3).readLine();
                                                                            if (line == null) {
                                                                                break Label_0439;
                                                                            }
                                                                            string = openFileDescriptor;
                                                                            o4 = o3;
                                                                            ((StringBuilder)o2).append(line);
                                                                        }
                                                                    }
                                                                    finally {
                                                                        openFileDescriptor = string;
                                                                        string = o4;
                                                                    }
                                                                }
                                                                catch (final Exception string) {
                                                                    o2 = openFileDescriptor;
                                                                    openFileDescriptor = o3;
                                                                    o3 = string;
                                                                }
                                                            }
                                                            catch (final IOException ex4) {
                                                                string = openFileDescriptor;
                                                                o2 = new(java.lang.StringBuilder.class)();
                                                                string = openFileDescriptor;
                                                                new StringBuilder();
                                                                string = openFileDescriptor;
                                                                ((StringBuilder)o2).append("reset read IO: ");
                                                                string = openFileDescriptor;
                                                                ((StringBuilder)o2).append(((Throwable)ex4).getMessage());
                                                                string = openFileDescriptor;
                                                                this.m(((StringBuilder)o2).toString());
                                                                string = openFileDescriptor;
                                                                ((Throwable)ex4).printStackTrace();
                                                                string = null;
                                                                string = openFileDescriptor;
                                                                o2 = (string = ((StringBuilder)o2).toString());
                                                            }
                                                        }
                                                        try {
                                                            ((BufferedReader)o3).close();
                                                        }
                                                        catch (final IOException ex5) {
                                                            k.b((Exception)ex5);
                                                        }
                                                        try {
                                                            ((ParcelFileDescriptor)openFileDescriptor).close();
                                                            break Label_0759;
                                                        }
                                                        catch (final IOException openFileDescriptor) {
                                                            k.b((Exception)openFileDescriptor);
                                                            break Label_0759;
                                                        }
                                                    }
                                                    catch (final Exception o3) {
                                                        string = null;
                                                        o2 = openFileDescriptor;
                                                    }
                                                }
                                                catch (final Exception o3) {
                                                    o2 = null;
                                                    bufferedReader = null;
                                                }
                                                finally {
                                                    bufferedReader = null;
                                                    continue Block_15_Outer;
                                                }
                                                break;
                                            }
                                            Label_0624: {
                                                break Label_0624;
                                                try {
                                                    Label_0775:
                                                    o5 = this.o((String)string);
                                                    if (o5 != null) {
                                                        g = com.beetalk.sdk.cache.a.s().g();
                                                        d = com.beetalk.sdk.cache.a.s().d();
                                                        ((Map)o5).remove((Object)g);
                                                        ((Map)o5).remove((Object)d);
                                                        i = this.i((Map)o5);
                                                        Label_1270: {
                                                            try {
                                                                o6 = (openFileDescriptor2 = ((Context)this).getContentResolver().openFileDescriptor(a.d(), "wt"));
                                                                try {
                                                                    try {
                                                                        o5 = new(java.io.BufferedWriter.class)();
                                                                        openFileDescriptor2 = o6;
                                                                        openFileDescriptor2 = o6;
                                                                        openFileDescriptor2 = o6;
                                                                        fileOutputStream = new FileOutputStream(((ParcelFileDescriptor)o6).getFileDescriptor());
                                                                        openFileDescriptor2 = o6;
                                                                        o = new OutputStreamWriter((OutputStream)fileOutputStream);
                                                                        openFileDescriptor2 = o6;
                                                                        new BufferedWriter((Writer)o);
                                                                        try {
                                                                            try {
                                                                                try {
                                                                                    ((Writer)o5).write(i);
                                                                                    ((BufferedWriter)o5).flush();
                                                                                }
                                                                                finally {}
                                                                            }
                                                                            catch (final Exception ex6) {
                                                                                uri = (Uri)o5;
                                                                                n2 = n;
                                                                                o5 = o6;
                                                                            }
                                                                        }
                                                                        catch (final IOException openFileDescriptor2) {
                                                                            sb13 = new StringBuilder();
                                                                            sb13.append("reset write IO: ");
                                                                            sb13.append(((Throwable)openFileDescriptor2).getMessage());
                                                                            this.m(sb13.toString());
                                                                            ((Throwable)openFileDescriptor2).printStackTrace();
                                                                        }
                                                                        k.a("doResetGuest success", new Object[0]);
                                                                        try {
                                                                            this.l(0, uri.toString());
                                                                            try {
                                                                                ((BufferedWriter)o5).close();
                                                                            }
                                                                            catch (final IOException ex7) {
                                                                                k.b((Exception)ex7);
                                                                            }
                                                                            try {
                                                                                ((ParcelFileDescriptor)o6).close();
                                                                            }
                                                                            catch (final IOException ex8) {
                                                                                k.b((Exception)ex8);
                                                                            }
                                                                        }
                                                                        catch (final Exception ex9) {
                                                                            n2 = 1;
                                                                            o5 = o6;
                                                                        }
                                                                    }
                                                                    finally {
                                                                        o6 = openFileDescriptor2;
                                                                    }
                                                                }
                                                                catch (final Exception ex10) {
                                                                    n2 = n;
                                                                    o5 = o6;
                                                                }
                                                            }
                                                            catch (final Exception ex11) {
                                                                o5 = null;
                                                                bufferedWriter2 = bufferedWriter;
                                                                n2 = n;
                                                            }
                                                            finally {
                                                                ex11 = null;
                                                                writer = (Writer)o;
                                                                break Label_1270;
                                                            }
                                                            sb14 = new StringBuilder();
                                                            sb14.append("reset write: ");
                                                            sb14.append(((Throwable)ex11).getMessage());
                                                            this.m(sb14.toString());
                                                            k.b(ex11);
                                                            if (bufferedWriter2 != null) {
                                                                try {
                                                                    bufferedWriter2.close();
                                                                }
                                                                catch (final IOException ex12) {
                                                                    k.b((Exception)ex12);
                                                                }
                                                            }
                                                            if (o5 != null) {
                                                                try {
                                                                    ((ParcelFileDescriptor)o5).close();
                                                                }
                                                                catch (final IOException ex13) {
                                                                    k.b((Exception)ex13);
                                                                }
                                                            }
                                                            if (n2 == 0) {
                                                                this.k(1);
                                                            }
                                                        }
                                                        if (writer != null) {
                                                            try {
                                                                ((BufferedWriter)writer).close();
                                                            }
                                                            catch (final IOException ex14) {
                                                                k.b((Exception)ex14);
                                                            }
                                                        }
                                                        if (ex11 != null) {
                                                            try {
                                                                ((ParcelFileDescriptor)ex11).close();
                                                            }
                                                            catch (final IOException ex15) {
                                                                k.b((Exception)ex15);
                                                            }
                                                        }
                                                    }
                                                }
                                                finally {
                                                    sb15 = new StringBuilder();
                                                    sb15.append("reset mod: ");
                                                    sb15.append(t4.getMessage());
                                                    this.m(sb15.toString());
                                                    t4.printStackTrace();
                                                }
                                            }
                                            sb16 = new StringBuilder();
                                            sb16.append("reset read: ");
                                            sb16.append(((Throwable)o3).getMessage());
                                            this.m(sb16.toString());
                                            k.b((Exception)o3);
                                            iftrue(Label_1394:)(bufferedReader == null);
                                            continue Block_17_Outer;
                                        }
                                        iftrue(Label_1353:)(string == null);
                                        continue;
                                    }
                                    try {
                                        ((ParcelFileDescriptor)bufferedReader).close();
                                    }
                                    catch (final IOException ex16) {
                                        k.b((Exception)ex16);
                                    }
                                    continue Label_1394;
                                }
                            }
                            Object string = null;
                            continue Label_0759;
                        }
                    }
                    iftrue(Label_1394:)(bufferedReader == null);
                    continue;
                }
            }
            finally {}
        }
    }
    
    private String f() {
        final int f = t.f(X.M());
        if (f != -1 && f != 100006) {
            final StringBuilder sb = new StringBuilder();
            sb.append("guest");
            sb.append(t.f(X.M()));
            sb.append(".dat");
            return sb.toString();
        }
        return "guest.dat";
    }
    
    private String g() {
        return this.getPreferences(0).getString("last_guest_uri", (String)null);
    }
    
    public static Intent h() {
        final Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
        intent.putExtra("android.provider.extra.INITIAL_URI", (Parcelable)Uri.parse("content://com.android.externalstorage.documents/document/primary:com.garena.msdk"));
        return intent;
    }
    
    private String i(final Map map) {
        final JSONObject jsonObject = new JSONObject();
        final JSONObject jsonObject2 = new JSONObject(map);
        try {
            jsonObject.put("guest_account_info", (Object)jsonObject2);
        }
        catch (final JSONException ex) {
            k.b((Exception)ex);
        }
        return jsonObject.toString();
    }
    
    private void j() {
        try {
            this.startActivityForResult(h(), 1000);
        }
        catch (final ActivityNotFoundException ex) {
            final StringBuilder sb = new StringBuilder();
            sb.append("request: ");
            sb.append(((Throwable)ex).getMessage());
            this.m(sb.toString());
            this.finish();
        }
    }
    
    private void k(final int n) {
        this.l(n, null);
    }
    
    private void l(final int n, final String s) {
        final Intent intent = new Intent();
        intent.putExtra("KEY_SAF_PERMISSION_RET", n);
        if (!TextUtils.isEmpty((CharSequence)s)) {
            intent.putExtra("KEY_SAF_REQ_URI", s);
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("@MigrateGuestActivity.setActivityResult: ");
        sb.append(n);
        k.a(sb.toString(), new Object[0]);
        this.setResult(-1, intent);
    }
    
    private void m(final String s) {
        final Intent intent = new Intent();
        intent.putExtra("KEY_SAF_PERMISSION_RET", 3);
        if (!TextUtils.isEmpty((CharSequence)s)) {
            intent.putExtra("KEY_SAF_EXCEPTION", s);
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("@MigrateGuestActivity.setExceptionResult: ");
        sb.append(s);
        k.a(sb.toString(), new Object[0]);
        this.setResult(-1, intent);
    }
    
    private void n(final String s) {
        this.getPreferences(0).edit().putString("last_guest_uri", s).commit();
    }
    
    private Map o(String s) {
        final HashMap hashMap = new HashMap();
        if (s != null && s.length() > 0) {
            try {
                final JSONObject jsonObject = new JSONObject(s).getJSONObject("guest_account_info");
                final Iterator keys = jsonObject.keys();
                while (keys.hasNext()) {
                    s = (String)keys.next();
                    ((Map)hashMap).put((Object)s, (Object)jsonObject.getString(s));
                }
            }
            catch (final JSONException ex) {
                k.b((Exception)ex);
            }
        }
        return (Map)hashMap;
    }
    
    private void p() {
        final Uri parse = Uri.parse(this.g());
        final StringBuilder sb = new StringBuilder();
        sb.append("workWithPermission: ");
        sb.append(parse.toString());
        k.a(sb.toString(), new Object[0]);
        final int a = this.a;
        if (a == 1001) {
            this.d(parse);
            return;
        }
        if (a == 2001 || a == 3001) {
            this.c(parse);
            return;
        }
        if (a != 4001) {
            return;
        }
        this.e(parse);
    }
    
    protected void onActivityResult(int flags, final int n, final Intent intent) {
        super.onActivityResult(flags, n, intent);
        if (1000 != flags || n != -1 || intent == null) {
            k.c("onActivityResult do not grant SAF permission from user", new Object[0]);
            this.k(2);
            this.finish();
            return;
        }
        final Uri data = intent.getData();
        if (data == null) {
            k.c("treeUri is null", new Object[0]);
            this.k(2);
            this.finish();
            return;
        }
        flags = intent.getFlags();
        ((Context)this).getContentResolver().takePersistableUriPermission(data, (flags & 0x1) | 0x2);
        if (!this.b(data.toString())) {
            final StringBuilder sb = new StringBuilder();
            sb.append("onActivityResult take persistable permission failed: ");
            sb.append((Object)data);
            k.c(sb.toString(), new Object[0]);
            this.k(2);
            this.finish();
            return;
        }
        this.n(data.toString());
        i.f((Callable)new MigrateGuestActivity$d(this)).l((g)new MigrateGuestActivity$c(this), i.k);
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        if (bundle != null && ((BaseBundle)bundle).containsKey("RequestCode")) {
            this.a = ((BaseBundle)bundle).getInt("RequestCode");
            return;
        }
        final Intent intent = this.getIntent();
        if (intent != null) {
            this.a = intent.getIntExtra("RequestCode", 0);
        }
        if (this.a == 0) {
            this.m("onCreate no intent");
            this.finish();
            return;
        }
        if (this.b(this.g())) {
            i.f((Callable)new MigrateGuestActivity$b(this)).l((g)new MigrateGuestActivity$a(this), i.k);
            return;
        }
        final int a = this.a;
        if (a != 3001 && a != 4001) {
            this.j();
            return;
        }
        this.k(2);
        this.finish();
    }
    
    protected void onSaveInstanceState(final Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (bundle != null) {
            ((BaseBundle)bundle).putInt("RequestCode", this.a);
        }
    }
}
