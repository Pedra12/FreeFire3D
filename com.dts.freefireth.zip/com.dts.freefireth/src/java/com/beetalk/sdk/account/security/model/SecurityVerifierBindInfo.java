package com.beetalk.sdk.account.security.model;

import kotlin.jvm.internal.Intrinsics;
import g1.b;
import org.jetbrains.annotations.NotNull;
import kotlin.Metadata;

@Metadata
public final class SecurityVerifierBindInfo
{
    @NotNull
    private final String email;
    @NotNull
    private final String emailToBe;
    private final boolean isInCoolDown;
    @NotNull
    private final String mobile;
    @NotNull
    private final String mobileToBe;
    private final long remainingCoolDownTime;
    
    public SecurityVerifierBindInfo(@NotNull final b b) {
        Intrinsics.checkNotNullParameter((Object)b, "response");
        this(b.f(), b.d(), b.g(), b.e(), b.h(), b.h() > 0L);
    }
    
    private SecurityVerifierBindInfo(final String mobile, final String email, final String mobileToBe, final String emailToBe, final long remainingCoolDownTime, final boolean isInCoolDown) {
        this.mobile = mobile;
        this.email = email;
        this.mobileToBe = mobileToBe;
        this.emailToBe = emailToBe;
        this.remainingCoolDownTime = remainingCoolDownTime;
        this.isInCoolDown = isInCoolDown;
    }
    
    public final String a() {
        return this.email;
    }
    
    public final String b() {
        return this.emailToBe;
    }
    
    public final String c() {
        return this.mobile;
    }
    
    public final String d() {
        return this.mobileToBe;
    }
    
    public final long e() {
        return this.remainingCoolDownTime;
    }
    
    public final boolean f() {
        return this.isInCoolDown;
    }
    
    @Override
    public String toString() {
        final String mobile = this.mobile;
        final String email = this.email;
        final String mobileToBe = this.mobileToBe;
        final String emailToBe = this.emailToBe;
        final long remainingCoolDownTime = this.remainingCoolDownTime;
        final boolean isInCoolDown = this.isInCoolDown;
        final StringBuilder sb = new StringBuilder();
        sb.append("SecurityVerifierBindInfo(mobile='");
        sb.append(mobile);
        sb.append("', email='");
        sb.append(email);
        sb.append("', mobileToBe='");
        sb.append(mobileToBe);
        sb.append("', emailToBe='");
        sb.append(emailToBe);
        sb.append("', remainingCoolDownTime=");
        sb.append(remainingCoolDownTime);
        sb.append(", isInCoolDown=");
        sb.append(isInCoolDown);
        sb.append(")");
        return sb.toString();
    }
}
