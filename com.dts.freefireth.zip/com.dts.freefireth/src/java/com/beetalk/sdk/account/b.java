package com.beetalk.sdk.account;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;
import android.content.Context;
import android.content.Intent;
import com.beetalk.sdk.helper.k;
import android.os.Build$VERSION;
import android.app.Activity;

public class b
{
    public static void a(final Activity activity) {
        if (Build$VERSION.SDK_INT < 30) {
            k.c("Your device is below Android 11!", new Object[0]);
            return;
        }
        final Intent intent = new Intent();
        intent.setClass((Context)activity, (Class)MigrateGuestActivity.class);
        intent.putExtra("RequestCode", 3001);
        activity.startActivityForResult(intent, 3001);
    }
    
    public static void b(final Activity activity) {
        if (Build$VERSION.SDK_INT < 30) {
            k.c("Your device is below Android 11!", new Object[0]);
            return;
        }
        final Intent intent = new Intent();
        intent.setClass((Context)activity, (Class)MigrateGuestActivity.class);
        intent.putExtra("RequestCode", 2001);
        activity.startActivityForResult(intent, 2001);
    }
    
    public static void c(final Activity activity) {
        if (Build$VERSION.SDK_INT < 30) {
            k.c("Your device is below Android 11!", new Object[0]);
            return;
        }
        final Intent intent = new Intent();
        intent.setClass((Context)activity, (Class)MigrateGuestActivity.class);
        intent.putExtra("RequestCode", 1001);
        activity.startActivityForResult(intent, 1001);
    }
    
    public static void d(final Activity activity) {
        if (Build$VERSION.SDK_INT < 30) {
            k.c("Your device is below Android 11!", new Object[0]);
            return;
        }
        final Intent intent = new Intent();
        intent.setClass((Context)activity, (Class)MigrateGuestActivity.class);
        intent.putExtra("RequestCode", 4001);
        activity.startActivityForResult(intent, 4001);
    }
    
    @Retention(RetentionPolicy.SOURCE)
    @Target({ ElementType.FIELD, ElementType.PARAMETER })
    public @interface a {
    }
}
