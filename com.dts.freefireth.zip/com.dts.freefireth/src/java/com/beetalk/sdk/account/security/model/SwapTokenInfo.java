package com.beetalk.sdk.account.security.model;

import kotlin.jvm.internal.Intrinsics;
import g1.e;
import org.jetbrains.annotations.NotNull;
import kotlin.Metadata;

@Metadata
public final class SwapTokenInfo
{
    @NotNull
    private final String openId;
    @NotNull
    private final String token;
    
    public SwapTokenInfo(@NotNull final e e) {
        Intrinsics.checkNotNullParameter((Object)e, "response");
        this(e.e(), e.d());
    }
    
    private SwapTokenInfo(final String token, final String openId) {
        this.token = token;
        this.openId = openId;
    }
    
    public final String a() {
        return this.openId;
    }
    
    public final String b() {
        return this.token;
    }
    
    @Override
    public String toString() {
        final String token = this.token;
        final String openId = this.openId;
        final StringBuilder sb = new StringBuilder();
        sb.append("SwapTokenInfo(token: ");
        sb.append(token);
        sb.append(", openId: ");
        sb.append(openId);
        sb.append(")");
        return sb.toString();
    }
}
