package com.beetalk.sdk;

import W2.b;
import java.util.concurrent.Callable;
import c1.i;
import java.io.Serializable;
import android.os.Bundle;
import android.content.pm.ResolveInfo;
import android.content.Intent;
import com.beetalk.sdk.networking.service.j;
import p1.c;
import android.app.Activity;
import c1.g;
import java.util.ArrayList;
import android.os.Looper;
import com.beetalk.sdk.helper.N;
import com.beetalk.sdk.cache.k;
import android.text.TextUtils;
import android.content.Context;
import k1.a;
import com.beetalk.sdk.cache.l;
import java.util.List;
import android.os.Handler;

public class s
{
    private static volatile s o;
    private static volatile s p;
    private static volatile s q;
    private static volatile s r;
    private final Handler a;
    private final List b;
    private final Object c;
    private l d;
    private final e e;
    private volatile B0 f;
    private final String g;
    private String h;
    private i i;
    private a j;
    private volatile int k;
    private final int l;
    public boolean m;
    public int n;
    
    private s(final Context context, final String s, final String h, final e e, final int l, final i i, l d) {
        this.c = new Object();
        this.k = com.garena.pay.android.l.b2.b();
        this.m = false;
        this.n = 3600;
        String j = s;
        if (context != null) {
            j = s;
            if (TextUtils.isEmpty((CharSequence)s)) {
                j = X.J();
            }
        }
        if (d == null) {
            d = (l)new k(context);
        }
        this.d = d;
        final a h2 = d.h();
        if (h2 != null && h2.f() == i.b() && h2.m()) {
            this.j = h2;
        }
        N.b((Object)j, "applicationId");
        this.g = j;
        this.h = h;
        this.e = e;
        this.a = new Handler(Looper.getMainLooper());
        this.b = (List)new ArrayList();
        this.l = l;
        this.i = i;
        B0 f;
        if (this.j != null) {
            f = B0.d;
        }
        else {
            f = B0.b;
        }
        this.f = f;
    }
    
    private void I(final s.s$h s$h, final f f) {
        B.j(this, f).k((g)new s$c(this, s$h));
    }
    
    private static boolean K(final s s) {
        final i f = s.F();
        return f == i.k || f == i.l;
    }
    
    private static boolean L(final s s) {
        return s != null && (s.f == B0.c || s.f == B0.d);
    }
    
    public static boolean M() {
        final s w = w();
        if (w != null) {
            final a h = w.H();
            if (h != null && h.m()) {
                return true;
            }
        }
        return false;
    }
    
    public static void O(final Activity activity, final c c, final s.s$h s$h) {
        final s u = u();
        if (u == null) {
            if (s$h != null) {
                final s a = new s.s$f(X.M()).a();
                a.g0(B0.f, com.garena.pay.android.l.y.b());
                s$h.onSessionProcessed(a, new Exception("session is null"));
            }
            return;
        }
        final f f = new f(activity, s$h, 56301, "", "app_platform_bind", c);
        u.b0((l)k.s());
        R(s$h, f, u);
    }
    
    public static void P(final Activity activity, final String s, final c c, final s.s$h s$h) {
        final f f = new f(activity, s$h, 56300, "", s, c);
        final s v = v();
        if (v == null) {
            if (s$h != null) {
                final s a = new s.s$f(X.M()).a();
                a.g0(B0.f, com.garena.pay.android.l.y.b());
                s$h.onSessionProcessed(a, new Exception("session is null"));
            }
            return;
        }
        v.b0((l)k.r());
        R(s$h, f, v);
    }
    
    public static void Q(final Activity activity, final c c, final s.s$h s$h) {
        final s w = w();
        if (w == null) {
            if (s$h != null) {
                final s a = new s.s$f(X.M()).a();
                a.g0(B0.f, com.garena.pay.android.l.y.b());
                s$h.onSessionProcessed(a, new Exception("session is null"));
            }
            return;
        }
        R(s$h, new f(activity, s$h, 56221, "", w.A(), c), w);
    }
    
    private static void R(final s.s$h s$h, final f f, final s s) {
        if (K(s)) {
            if (s$h != null) {
                s.g0(B0.f, com.garena.pay.android.l.y.b());
                s$h.onSessionProcessed(s, new Exception("Huawei Login & Apple Login is not supported"));
            }
        }
        else {
            if (!L(s)) {
                U(s$h, f, s);
                return;
            }
            final int n = s$e.a[((Enum)s.f).ordinal()];
            if (n == 1) {
                s$h.onSessionProcessed(s, (Exception)new m1.a("Session is awaiting fulfillment. Please destroy before requesting for a new Session"));
                return;
            }
            if (n == 2) {
                s.I(s$h, f);
            }
        }
    }
    
    public static void S(final Activity activity, final String s, final c c, final s.s$h s$h) {
        final s x = x();
        if (x == null) {
            if (s$h != null) {
                final s a = new s.s$f(X.M()).a();
                a.g0(B0.f, com.garena.pay.android.l.y.b());
                s$h.onSessionProcessed(a, new Exception("session is null"));
            }
            return;
        }
        x.b0((l)k.t());
        x.J();
        m((s.s$g)new r((s.s$h)new q(s$h), new f(activity, s$h, 56302, "", s, c), x));
    }
    
    private static void U(final s.s$h s$h, final f f, final s s) {
        final Object c;
        monitorenter(c = s.c);
        Label_0042: {
            try {
                final B0 f2 = s.f;
                final B0 b = B0.b;
                if (f2 == b) {
                    s.f = B0.c;
                }
                break Label_0042;
            }
            finally {
                monitorexit(c);
                iftrue(Label_0057:)(s$h == null);
                s.b.add((Object)s$h);
                final B0 c2;
                Label_0057: {
                    c2 = B0.c;
                }
                final B0 b;
                s.V(b, c2, null);
                monitorexit(c);
                iftrue(Label_0090:)(s.f != c2);
                f.j(s);
                s.p(f);
                Label_0090:;
            }
        }
    }
    
    private void V(final B0 b0, final B0 b2, final Exception ex) {
        final List b3;
        monitorenter(b3 = this.b);
        Label_0025: {
            if (b0 != b2) {
                break Label_0025;
            }
            try {
                monitorexit(b3);
            }
            finally {
                monitorexit(b3);
                a0(this.a, (Runnable)new s$d(this, ex));
                monitorexit(b3);
            }
        }
    }
    
    public static void W() {
        if (s.o == null) {
            return;
        }
        s.o.X();
    }
    
    public static boolean Y(final d$c d$c) {
        final int f = d$c.f();
        return f == 56301 || f == 56302;
    }
    
    public static s Z(final int n, final s s) {
        if (n == 56301) {
            return u();
        }
        if (n == 56300) {
            return v();
        }
        if (n == 56302) {
            return x();
        }
        return s;
    }
    
    private static void a0(final Handler handler, final Runnable runnable) {
        if (handler != null) {
            handler.post(runnable);
        }
    }
    
    public static void c0(final s q) {
        synchronized (s.class) {
            s.q = q;
        }
    }
    
    public static void d0(final s p) {
        synchronized (s.class) {
            s.p = p;
        }
    }
    
    public static void e0(final s o) {
        synchronized (s.class) {
            s.o = o;
        }
    }
    
    public static void f0(final s r) {
        synchronized (s.class) {
            s.r = r;
        }
    }
    
    private boolean h(final f f) {
        final Intent z = f.f().z(f);
        if (f.f().h0(z)) {
            f.b().startActivityForResult(z, f.e());
            return true;
        }
        return false;
    }
    
    private boolean h0(final Intent intent) {
        ResolveInfo resolveActivity;
        if (X.M().getPackageManager() == null) {
            resolveActivity = null;
        }
        else {
            resolveActivity = X.M().getPackageManager().resolveActivity(intent, 0);
        }
        return resolveActivity != null;
    }
    
    public static boolean i() {
        return j(w());
    }
    
    public static boolean j(final s s) {
        if (s != null) {
            final a h = s.H();
            if (h != null && !TextUtils.isEmpty((CharSequence)h.c())) {
                return true;
            }
        }
        return false;
    }
    
    public static boolean k() {
        synchronized (s.class) {
            return l(null);
        }
    }
    
    public static boolean l(final s.s$g p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     2: dup            
        //     3: astore_3       
        //     4: monitorenter   
        //     5: getstatic       com/beetalk/sdk/s.o:Lcom/beetalk/sdk/s;
        //     8: ifnull          27
        //    11: getstatic       com/beetalk/sdk/s.o:Lcom/beetalk/sdk/s;
        //    14: invokevirtual   com/beetalk/sdk/s.N:()V
        //    17: getstatic       com/beetalk/sdk/s.o:Lcom/beetalk/sdk/s;
        //    20: invokevirtual   com/beetalk/sdk/s.J:()V
        //    23: aconst_null    
        //    24: putstatic       com/beetalk/sdk/s.o:Lcom/beetalk/sdk/s;
        //    27: getstatic       com/beetalk/sdk/s.p:Lcom/beetalk/sdk/s;
        //    30: ifnull          43
        //    33: getstatic       com/beetalk/sdk/s.p:Lcom/beetalk/sdk/s;
        //    36: invokevirtual   com/beetalk/sdk/s.J:()V
        //    39: aconst_null    
        //    40: putstatic       com/beetalk/sdk/s.p:Lcom/beetalk/sdk/s;
        //    43: getstatic       com/beetalk/sdk/s.q:Lcom/beetalk/sdk/s;
        //    46: ifnull          59
        //    49: getstatic       com/beetalk/sdk/s.q:Lcom/beetalk/sdk/s;
        //    52: invokevirtual   com/beetalk/sdk/s.J:()V
        //    55: aconst_null    
        //    56: putstatic       com/beetalk/sdk/s.q:Lcom/beetalk/sdk/s;
        //    59: new             Lcom/beetalk/sdk/cache/i;
        //    62: astore_2       
        //    63: aload_2        
        //    64: invokespecial   com/beetalk/sdk/cache/i.<init>:()V
        //    67: aload_2        
        //    68: invokevirtual   com/beetalk/sdk/cache/i.a:()V
        //    71: aload_2        
        //    72: invokevirtual   com/beetalk/sdk/cache/i.b:()V
        //    75: invokestatic    com/beetalk/sdk/cache/e.d:()Lcom/beetalk/sdk/cache/e;
        //    78: invokevirtual   com/beetalk/sdk/cache/e.c:()V
        //    81: aload_0        
        //    82: invokestatic    com/beetalk/sdk/s.m:(Lcom/beetalk/sdk/s$g;)Z
        //    85: istore_1       
        //    86: aload_3        
        //    87: monitorexit    
        //    88: iload_1        
        //    89: ireturn        
        //    90: astore_0       
        //    91: aload_3        
        //    92: monitorexit    
        //    93: aload_0        
        //    94: athrow         
        //    95: astore_2       
        //    96: goto            27
        //    99: astore_2       
        //   100: goto            43
        //   103: astore_2       
        //   104: goto            59
        //   107: astore_2       
        //   108: goto            75
        //   111: astore_2       
        //   112: goto            81
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  5      27     95     99     Any
        //  27     43     99     103    Any
        //  43     59     103    107    Any
        //  59     75     107    111    Any
        //  75     81     111    115    Any
        //  81     86     90     95     Any
        //  91     93     90     95     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 56 out of bounds for length 56
        //     at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:100)
        //     at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:106)
        //     at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:302)
        //     at java.util.Objects.checkIndex(Objects.java:371)
        //     at java.util.ArrayList.get(ArrayList.java:435)
        //     at q5.g.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at q5.g.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:2125)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:21)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        //     at java.lang.Thread.run(Thread.java:1571)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static boolean m(final s.s$g p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: invokestatic    com/facebook/e.F:()Z
        //     7: ifeq            14
        //    10: aload_1        
        //    11: invokestatic    n1/a.a:(Landroid/content/Context;)V
        //    14: invokestatic    com/twitter/sdk/android/core/u.f:()Lcom/twitter/sdk/android/core/u;
        //    17: invokevirtual   com/twitter/sdk/android/core/u.g:()Lcom/twitter/sdk/android/core/k;
        //    20: invokeinterface com/twitter/sdk/android/core/k.a:()V
        //    25: invokestatic    com/beetalk/sdk/vk/h.d:()V
        //    28: aload_1        
        //    29: invokestatic    o1/c.b:(Landroid/content/Context;)V
        //    32: goto            36
        //    35: astore_2       
        //    36: getstatic       e1/c.a:Le1/c;
        //    39: invokevirtual   e1/c.d:()V
        //    42: new             Landroid/os/Handler;
        //    45: dup            
        //    46: invokestatic    android/os/Looper.getMainLooper:()Landroid/os/Looper;
        //    49: invokespecial   android/os/Handler.<init>:(Landroid/os/Looper;)V
        //    52: new             Lcom/beetalk/sdk/s$a;
        //    55: dup            
        //    56: aload_1        
        //    57: invokespecial   com/beetalk/sdk/s$a.<init>:(Landroid/content/Context;)V
        //    60: invokevirtual   android/os/Handler.post:(Ljava/lang/Runnable;)Z
        //    63: pop            
        //    64: invokestatic    com/beetalk/sdk/X.M:()Landroid/content/Context;
        //    67: invokestatic    com/garena/pay/android/helper/a.a:(Landroid/content/Context;)LF2/a;
        //    70: astore_2       
        //    71: aload_2        
        //    72: invokevirtual   F2/a.h:()Z
        //    75: ifeq            123
        //    78: aload_1        
        //    79: invokestatic    com/beetalk/sdk/j0.i:(Landroid/content/Context;)Lcom/google/android/gms/auth/api/signin/b;
        //    82: astore_1       
        //    83: aload_1        
        //    84: ifnull          137
        //    87: ldc_w           "Start to sign out Google account."
        //    90: iconst_0       
        //    91: anewarray       Ljava/lang/Object;
        //    94: invokestatic    com/beetalk/sdk/helper/k.a:(Ljava/lang/String;[Ljava/lang/Object;)V
        //    97: getstatic       p3/a.d:Ls3/a;
        //   100: aload_1        
        //   101: invokevirtual   com/google/android/gms/common/api/GoogleApi.g:()Lcom/google/android/gms/common/api/c;
        //   104: invokeinterface s3/a.a:(Lcom/google/android/gms/common/api/c;)Lw3/e;
        //   109: new             Lcom/beetalk/sdk/s$b;
        //   112: dup            
        //   113: aload_0        
        //   114: invokespecial   com/beetalk/sdk/s$b.<init>:(Lcom/beetalk/sdk/s$g;)V
        //   117: invokevirtual   w3/e.c:(Lw3/e$a;)V
        //   120: goto            137
        //   123: aload_2        
        //   124: invokestatic    com/garena/pay/android/helper/a.b:(LF2/a;)V
        //   127: aload_0        
        //   128: ifnull          137
        //   131: aload_0        
        //   132: invokeinterface com/beetalk/sdk/s$g.onComplete:()V
        //   137: iconst_1       
        //   138: ireturn        
        //   139: astore_2       
        //   140: goto            14
        //   143: astore_2       
        //   144: goto            25
        //   147: astore_2       
        //   148: goto            28
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  4      14     139    143    Any
        //  14     25     143    147    Any
        //  25     28     147    151    Any
        //  28     32     35     36     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 65 out of bounds for length 65
        //     at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:100)
        //     at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:106)
        //     at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:302)
        //     at java.util.Objects.checkIndex(Objects.java:371)
        //     at java.util.ArrayList.get(ArrayList.java:435)
        //     at q5.g.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at q5.g.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:2125)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:21)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        //     at java.lang.Thread.run(Thread.java:1571)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static boolean n(final s.s$g s$g) {
        synchronized (s.class) {
            s.r = null;
            ((l)k.t()).a();
            return m(s$g);
        }
    }
    
    public static boolean o(final s.s$g s$g) {
        final Class<s> clazz;
        monitorenter(clazz = s.class);
        Label_0028: {
            try {
                if (s.p != null) {
                    s.p.J();
                    s.p = null;
                }
                break Label_0028;
            }
            finally {
                monitorexit(clazz);
                final boolean m = m(s$g);
                monitorexit(clazz);
                return m;
            }
        }
    }
    
    private void p(final f f) {
        f.g(this.g);
        f.i(this.l);
        f.h(this.h);
        if (!this.h(f)) {
            synchronized (s.class) {
                final B0 f2 = f.f().f;
                f.f().f = B0.f;
                f.f().V(f2, f.f().f, (Exception)new m1.a("Failed to Validate the authenticity of the internal package.Did you forget to include the BTLoginActivity in your AndroidManifest.xml"));
            }
        }
    }
    
    public static s q(final Activity activity, final s.s$h s$h, final c c, final String s) {
        final f f = new f(activity, s$h, 56221, "", s, c);
        f.j(s.o);
        s.o.b.add((Object)s$h);
        N.a((Object)s.o.b.size(), (Object)1, "[forceOpenSession] Callback Array Size");
        s.o.f = B0.c;
        s.o.p(f);
        return s.o;
    }
    
    public static s u() {
        synchronized (s.class) {
            return s.q;
        }
    }
    
    public static s v() {
        synchronized (s.class) {
            return s.p;
        }
    }
    
    public static s w() {
        synchronized (s.class) {
            return s.o;
        }
    }
    
    public static s x() {
        synchronized (s.class) {
            return s.r;
        }
    }
    
    private Intent z(final f f) {
        final Intent intent = new Intent();
        intent.setClass(X.M(), (Class)BTLoginActivity.class);
        final Bundle bundle = new Bundle();
        bundle.putSerializable("request_extra", (Serializable)f.c());
        intent.putExtras(bundle);
        return intent;
    }
    
    public String A() {
        if (this.l == 56302) {
            return "account_swap";
        }
        return "normal";
    }
    
    public e B() {
        return this.e;
    }
    
    public String C() {
        if (this.H() != null) {
            return this.H().h();
        }
        return "";
    }
    
    public Integer D() {
        return this.F().b();
    }
    
    public int E() {
        return this.l;
    }
    
    public i F() {
        return this.i;
    }
    
    public B0 G() {
        return this.f;
    }
    
    public a H() {
        return this.j;
    }
    
    public void J() {
        final l d = this.d;
        if (d != null) {
            d.a();
        }
    }
    
    public void N() {
        this.f = B0.e;
        c1.i.f((Callable)new p(this));
    }
    
    final void T(final Activity activity, int n, final int n2, final Intent intent) {
        N.b((Object)activity, "currentActivity");
        com.beetalk.sdk.helper.k.a("onActivityResult", new Object[0]);
        if (n == this.l) {
            final Exception ex = null;
            if (intent != null && n2 == -1) {
                final Class<s> clazz;
                monitorenter(clazz = s.class);
                Label_0082: {
                    try {
                        com.beetalk.sdk.helper.k.a("onActivityResult: success", new Object[0]);
                        final B0 f = this.f;
                        final Bundle extras = intent.getExtras();
                        if (extras == null) {
                            monitorexit(clazz);
                            return;
                        }
                        break Label_0082;
                    }
                    finally {
                        monitorexit(clazz);
                        while (true) {
                            a b;
                            final i c;
                            while (true) {
                                final d$e d$e;
                                b = d$e.b;
                                iftrue(Label_0115:)(b != null);
                                Label_0271: {
                                    break Label_0271;
                                    final B0 f2 = B0.f;
                                    this.g0(f2, com.garena.pay.android.l.y.b());
                                    final B0 f;
                                    this.V(f, f2, new Exception("Unsupported platform"));
                                    monitorexit(clazz);
                                    return;
                                Label_0238:
                                    while (true) {
                                        this.d.k(this.j);
                                        break Label_0238;
                                        Label_0177: {
                                            this.i = c;
                                        }
                                        final a b2 = d$e.b;
                                        (this.j = b2).t(b2.h());
                                        this.d.l(this.j);
                                        iftrue(Label_0238:)(this.i != s.i.d);
                                        continue;
                                    }
                                    final B0 d = B0.d;
                                    this.g0(d, com.garena.pay.android.l.c.b());
                                    this.V(f, d, null);
                                    monitorexit(clazz);
                                    return;
                                }
                                monitorexit(clazz);
                                return;
                                final Bundle extras;
                                d$e = (d$e)extras.getSerializable("auth_result");
                                iftrue(Label_0271:)(d$e == null);
                                continue;
                            }
                            Label_0115: {
                                c = s.i.c(b.f());
                            }
                            iftrue(Label_0177:)(c != null);
                            continue;
                        }
                    }
                }
            }
            if (n2 == 0) {
                final Class<s> clazz2;
                monitorenter(clazz2 = s.class);
            Block_19_Outer:
                while (true) {
                    try {
                        final B0 f3 = this.f;
                        final Intent intent2 = intent;
                        final Bundle bundle = intent2.getExtras();
                        final String s = "auth_result";
                        final Serializable s2 = bundle.getSerializable(s);
                        final d$e d$e2 = (d$e)s2;
                        break Label_0325;
                    }
                    finally {
                        monitorexit(clazz2);
                        final d$e d$e2;
                        Label_0362: {
                            iftrue(Label_0379:)(d$e2 != null);
                        }
                        n = com.garena.pay.android.l.b2.b();
                    Label_0431_Outer:
                        while (true) {
                        Label_0431:
                            while (true) {
                            Block_22:
                                while (true) {
                                    break Label_0384;
                                    this.g0(B0.e, com.garena.pay.android.l.f.b());
                                    Object o = ex;
                                    while (true) {
                                        Label_0467: {
                                            break Label_0467;
                                            iftrue(Label_0401:)(n != com.garena.pay.android.l.c2.b());
                                            this.X();
                                            Label_0401: {
                                                break Label_0401;
                                                Label_0426:
                                                final String g = d$e2.g;
                                                break Label_0431;
                                            }
                                            this.g0(B0.f, n);
                                            final com.garena.pay.android.l c2 = com.garena.pay.android.l.c(n);
                                            iftrue(Label_0426:)(d$e2 != null);
                                            break Block_22;
                                            Label_0457:
                                            o = new b(c2);
                                            break Label_0467;
                                            final String g;
                                            o = new b(c2, c2.d(), g);
                                        }
                                        final B0 f3;
                                        this.V(f3, this.f, (Exception)o);
                                        monitorexit(clazz2);
                                        return;
                                        final String g;
                                        iftrue(Label_0457:)(TextUtils.isEmpty((CharSequence)g));
                                        continue;
                                    }
                                    Label_0379:
                                    n = d$e2.d;
                                    continue Block_19_Outer;
                                }
                                final String g = "";
                                continue Label_0431;
                            }
                            iftrue(Label_0362:)(d$e2 == null || d$e2.d != d$e.h);
                            continue Label_0431_Outer;
                        }
                    }
                    try {
                        final Intent intent2 = intent;
                        final Bundle bundle = intent2.getExtras();
                        final String s = "auth_result";
                        final Serializable s2 = bundle.getSerializable(s);
                        final d$e d$e2 = (d$e)s2;
                        continue;
                    }
                    catch (final NullPointerException ex2) {}
                    break;
                }
            }
        }
    }
    
    void X() {
        final a j = this.j;
        if (j != null) {
            j.p("");
            this.j.q(0);
            this.j.r(0);
            this.f = B0.f;
            this.k = com.garena.pay.android.l.c2.b();
        }
        final l d = this.d;
        if (d != null) {
            d.m("com.garena.msdk.token");
            if (this.i == s.i.d) {
                this.d.n();
            }
        }
    }
    
    public void b0(final l d) {
        this.d = d;
    }
    
    public s g0(final B0 f, final int k) {
        synchronized (this) {
            this.f = f;
            this.k = k;
            return this;
        }
    }
    
    public String r() {
        return this.g;
    }
    
    public String s() {
        return this.h;
    }
    
    public l t() {
        return this.d;
    }
    
    public int y() {
        return this.k;
    }
    
    public enum i
    {
        b(1), 
        c(3), 
        d(4), 
        e(5), 
        f(6), 
        g(8), 
        h(11), 
        i(13), 
        j(14), 
        k(7), 
        l(10);
        
        private static final i[] v;
        private int a;
        
        static {
            v = a();
        }
        
        private i(final int a) {
            this.a = a;
        }
        
        private static /* synthetic */ i[] a() {
            return new i[] { i.b, i.c, i.d, i.e, i.f, i.g, i.h, i.i, i.j, i.k, i.l };
        }
        
        public static i c(final int n) {
            switch (n) {
                default: {
                    return null;
                }
                case 14: {
                    return i.j;
                }
                case 13: {
                    return i.i;
                }
                case 11: {
                    return i.h;
                }
                case 10: {
                    return i.l;
                }
                case 8: {
                    return i.g;
                }
                case 7: {
                    return i.k;
                }
                case 6: {
                    return i.f;
                }
                case 5: {
                    return i.e;
                }
                case 4: {
                    return i.d;
                }
                case 3: {
                    return i.c;
                }
                case 1: {
                    return i.b;
                }
            }
        }
        
        public int b() {
            return this.a;
        }
    }
}
