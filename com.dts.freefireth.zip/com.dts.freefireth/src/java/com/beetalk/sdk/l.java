package com.beetalk.sdk;

import android.content.Context;
import p1.a;
import android.content.Intent;
import com.beetalk.sdk.helper.k;

public class l extends g
{
    protected l(final d d) {
        super(d);
    }
    
    private void d(final d.e e) {
        if (e != null) {
            if (e.b != null) {
                final s z = s.Z(super.a.j().f(), s.w());
                if (z != null) {
                    z.t().l(e.b);
                }
            }
            k.a(e.toString(), new Object[0]);
            super.a.l(e);
            return;
        }
        super.a.q();
    }
    
    boolean b(final int n, final int n2, final Intent intent, final d.c c) {
        if (n != c.f()) {
            return false;
        }
        if (!super.a.j().c().equals((Object)c.c())) {
            this.d(d.e.a(com.garena.pay.android.l.Y.b()));
            return true;
        }
        Object o;
        if (n2 == 0) {
            o = d.e.a(com.garena.pay.android.l.f.b());
        }
        else if (n2 == -1) {
            o = intent.getSerializableExtra("email_auth_result");
        }
        else {
            o = d.e.a(com.garena.pay.android.l.b2.b());
        }
        this.d((d.e)o);
        return true;
    }
    
    boolean c(final d.c c) {
        if (c == null) {
            return false;
        }
        if (!(c.d() instanceof a)) {
            return false;
        }
        k.a("start email auth", new Object[0]);
        super.a.f().startActivityForResult(EmailAuthActivity.g((Context)super.a.f().getContext(), c), c.f());
        return true;
    }
}
