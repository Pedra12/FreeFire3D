package com.beetalk.sdk;

import com.beetalk.sdk.networking.model.RegisterGuestResponse;
import com.beetalk.sdk.networking.h;
import com.beetalk.sdk.networking.h$c;
import com.beetalk.sdk.networking.service.j;
import com.beetalk.sdk.networking.r;
import android.text.TextUtils;
import org.json.JSONException;
import com.beetalk.sdk.helper.k;
import com.beetalk.sdk.cache.a;
import com.garena.pay.android.helper.c;
import com.garena.pay.android.l;
import org.json.JSONObject;

public class n0 extends g
{
    public n0(final d d) {
        super(d);
    }
    
    private String g(final Exception ex) {
        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("stage", (Object)"guest_registration_info");
            jsonObject.put("exceptionClass", (Object)ex.getClass().getName());
            jsonObject.put("exceptionMessage", (Object)((Throwable)ex).getMessage());
            return jsonObject.toString();
        }
        catch (final JSONException ex2) {
            k.b((Exception)ex2);
            final StringBuilder sb = new StringBuilder();
            sb.append(ex.getClass().getName());
            sb.append(": ");
            sb.append(((Throwable)ex).getMessage());
            return sb.toString();
        }
    }
    
    private d.e h(JSONObject optJSONObject) {
        final l h1 = l.h1;
        final int intValue = h1.b();
        final d.e e = null;
        int n = intValue;
        d.e d = null;
        Label_0194: {
            Label_0187: {
                try {
                    final String optString = optJSONObject.optString("error", "");
                    n = intValue;
                    if (!TextUtils.isEmpty((CharSequence)optString)) {
                        n = intValue;
                        final int n2 = n = (n = r.c(optString).b());
                        final StringBuilder sb = new StringBuilder();
                        n = n2;
                        sb.append("grant token failed, msg:");
                        n = n2;
                        sb.append(optString);
                        n = n2;
                        k.i(sb.toString(), new Object[0]);
                        n = n2;
                        d = e;
                        break Label_0194;
                    }
                }
                catch (final JSONException ex) {
                    break Label_0187;
                }
                optJSONObject = optJSONObject.optJSONObject("data");
                if (optJSONObject == null) {
                    n = h1.b();
                    d = e;
                    break Label_0194;
                }
                if (!optJSONObject.has("open_id")) {
                    n = l.v.b();
                    d = e;
                    break Label_0194;
                }
                d = com.beetalk.sdk.d.e.d(k1.a.o(4, optJSONObject));
                n = intValue;
                break Label_0194;
            }
            final JSONException ex;
            k.b((Exception)ex);
            d = e;
        }
        Object a = d;
        if (d == null) {
            a = com.beetalk.sdk.d.e.a(n);
        }
        return (d.e)a;
    }
    
    private void i(final String s, final String s2) {
        j.t(s, s2, z1.a.c, super.a.j().a(), (h$c)new l0(this));
    }
    
    boolean c(final d.c c) {
        final String f = a.s().f();
        final String c2 = a.s().c();
        if (!TextUtils.isEmpty((CharSequence)f) && !TextUtils.isEmpty((CharSequence)c2)) {
            this.i(f, c2);
        }
        else {
            final String f2 = com.beetalk.sdk.cache.g.s(X.M()).f();
            if (TextUtils.isEmpty((CharSequence)f2)) {
                try {
                    final k1.c c3 = new k1.c();
                    j.z(c3, new h.e(this, c3) {
                        final k1.c a;
                        final n0 b;
                        
                        @Override
                        public void a(final String s) {
                            final RegisterGuestResponse registerGuestResponse = (RegisterGuestResponse)h.f.fromJson(s, (Class)RegisterGuestResponse.class);
                            if (!TextUtils.isEmpty((CharSequence)registerGuestResponse.a())) {
                                this.b.a.l(com.beetalk.sdk.d.e.a(r.c(registerGuestResponse.a()).b()));
                                return;
                            }
                            final String b = registerGuestResponse.b();
                            com.beetalk.sdk.cache.a.s().j(b, this.a.a);
                            try {
                                com.beetalk.sdk.cache.g.s(X.M()).j(b, this.a.a);
                            }
                            catch (final Exception ex) {
                                k.b(ex);
                            }
                            this.b.i(b, this.a.a);
                        }
                    });
                    return true;
                }
                catch (final Exception ex) {
                    k.b(ex);
                    super.a.l(d.e.b(l.e2.b(), this.g(ex)));
                    return true;
                }
            }
            final String c4 = com.beetalk.sdk.cache.g.s(X.M()).c();
            a.s().j(f2, c4);
            try {
                com.beetalk.sdk.cache.g.s(X.M()).j(f2, c4);
            }
            catch (final Exception ex2) {
                k.b(ex2);
            }
            this.i(f2, c4);
        }
        return true;
    }
}
