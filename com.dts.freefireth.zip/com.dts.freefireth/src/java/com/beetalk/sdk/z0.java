package com.beetalk.sdk;

import android.app.Activity;
import T3.h;
import android.content.Intent;
import com.google.android.gms.tasks.OnCompleteListener;
import android.text.TextUtils;
import com.beetalk.sdk.helper.t;
import java.util.concurrent.Callable;
import com.beetalk.sdk.helper.k;
import T3.c;
import com.google.android.gms.tasks.Task;
import com.garena.pay.android.l;
import c1.i;
import com.beetalk.sdk.networking.service.j;
import T3.f;

public class z0 extends g
{
    private f b;
    
    protected z0(final d d) {
        super(d);
    }
    
    private void i(final String s) {
        i.f((Callable)new x0(s, super.a.j())).k((c1.g)new y0(this));
    }
    
    private String j(final Exception ex) {
        if (ex != null) {
            return ((Throwable)ex).getMessage();
        }
        return "Unknown";
    }
    
    private void k(final String s) {
        this.l(d$e.c("error", s, (int)l.t1.b()));
    }
    
    private void l(final d$e d$e) {
        if (d$e != null) {
            super.a.l(d$e);
            return;
        }
        super.a.q();
    }
    
    private void m() {
        final String e = t.e(super.a.g());
        if (TextUtils.isEmpty((CharSequence)e)) {
            k.c("Invalid Google Play Games Client ID", new Object[0]);
            this.k("Failed to get Play Games OAuth token, reason: invalid Google Play Games Client ID");
            return;
        }
        k.a("Request Play Games OAuth token", new Object[0]);
        this.b.a(e, false).addOnCompleteListener((OnCompleteListener)new v0(this));
    }
    
    private void n() {
        k.a("Request Play Games sign in", new Object[0]);
        this.b.c().addOnCompleteListener((OnCompleteListener)new w0(this));
    }
    
    boolean b(final int n, final int n2, final Intent intent, final d$c d$c) {
        return true;
    }
    
    boolean c(final d$c d$c) {
        T3.i.a(super.a.g());
        this.b = h.b((Activity)super.a.e());
        k.a("start Google Play Games Auth", new Object[0]);
        if (d$c == null) {
            return false;
        }
        if (!t.r(super.a.g())) {
            k.a("Invalid Google Play Games app id", new Object[0]);
            return false;
        }
        this.b.b().addOnCompleteListener((OnCompleteListener)new u0(this));
        return true;
    }
}
