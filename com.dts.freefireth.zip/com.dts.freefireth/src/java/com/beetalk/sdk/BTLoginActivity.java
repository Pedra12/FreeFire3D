package com.beetalk.sdk;

import android.os.BaseBundle;
import android.app.Activity;
import android.webkit.CookieSyncManager;
import com.beetalk.sdk.helper.k;
import android.content.Intent;
import java.io.Serializable;
import android.os.Bundle;
import androidx.appcompat.app.c;

public class BTLoginActivity extends c
{
    private String g1;
    protected d h1;
    private d$c i1;
    
    private void A0(final d$e d$e) {
        this.i1 = null;
        int n;
        if (d$e != null && !d$e.h(d$e.a)) {
            n = -1;
        }
        else {
            n = 0;
        }
        final Bundle bundle = new Bundle();
        bundle.putSerializable("auth_result", (Serializable)d$e);
        final Intent intent = new Intent();
        intent.putExtras(bundle);
        ((Activity)this).setResult(n, intent);
        ((Activity)this).finish();
        ((Activity)this).overridePendingTransition(0, 17432577);
    }
    
    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        k.a("onActivityResult", new Object[0]);
        final d h1 = this.h1;
        if (h1 != null) {
            h1.m(n, n2, intent);
        }
    }
    
    protected void onCreate(final Bundle p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     2: iconst_0       
        //     3: anewarray       Ljava/lang/Object;
        //     6: invokestatic    com/beetalk/sdk/helper/k.a:(Ljava/lang/String;[Ljava/lang/Object;)V
        //     9: aload_0        
        //    10: aload_1        
        //    11: invokespecial   androidx/fragment/app/h.onCreate:(Landroid/os/Bundle;)V
        //    14: aload_0        
        //    15: invokestatic    android/webkit/CookieSyncManager.createInstance:(Landroid/content/Context;)Landroid/webkit/CookieSyncManager;
        //    18: pop            
        //    19: goto            23
        //    22: astore_2       
        //    23: invokestatic    com/beetalk/sdk/s.w:()Lcom/beetalk/sdk/s;
        //    26: ifnonnull       52
        //    29: ldc             "recreate session"
        //    31: iconst_0       
        //    32: anewarray       Ljava/lang/Object;
        //    35: invokestatic    com/beetalk/sdk/helper/k.a:(Ljava/lang/String;[Ljava/lang/Object;)V
        //    38: new             Lcom/beetalk/sdk/s$f;
        //    41: dup            
        //    42: aload_0        
        //    43: invokespecial   com/beetalk/sdk/s$f.<init>:(Landroid/content/Context;)V
        //    46: invokevirtual   com/beetalk/sdk/s$f.a:()Lcom/beetalk/sdk/s;
        //    49: invokestatic    com/beetalk/sdk/s.e0:(Lcom/beetalk/sdk/s;)V
        //    52: aload_1        
        //    53: ifnull          120
        //    56: aload_0        
        //    57: aload_1        
        //    58: ldc             "saved_auth_client"
        //    60: invokevirtual   android/os/Bundle.getSerializable:(Ljava/lang/String;)Ljava/io/Serializable;
        //    63: checkcast       Lcom/beetalk/sdk/d;
        //    66: putfield        com/beetalk/sdk/BTLoginActivity.h1:Lcom/beetalk/sdk/d;
        //    69: aload_1        
        //    70: ldc             "saved_sandbox_mode"
        //    72: invokevirtual   android/os/BaseBundle.containsKey:(Ljava/lang/String;)Z
        //    75: ifeq            90
        //    78: aload_1        
        //    79: ldc             "saved_sandbox_mode"
        //    81: invokevirtual   android/os/BaseBundle.getString:(Ljava/lang/String;)Ljava/lang/String;
        //    84: invokestatic    com/beetalk/sdk/A0$e.valueOf:(Ljava/lang/String;)Lcom/beetalk/sdk/A0$e;
        //    87: invokestatic    com/beetalk/sdk/X.B:(Lcom/beetalk/sdk/A0$e;)V
        //    90: aload_1        
        //    91: ldc             "saved_gop_dev_sandbox_mode"
        //    93: invokevirtual   android/os/BaseBundle.containsKey:(Ljava/lang/String;)Z
        //    96: ifeq            108
        //    99: aload_1        
        //   100: ldc             "saved_gop_dev_sandbox_mode"
        //   102: invokevirtual   android/os/Bundle.getBoolean:(Ljava/lang/String;)Z
        //   105: invokestatic    com/beetalk/sdk/A0.e0:(Z)V
        //   108: ldc             "BTLoginActivity onCreate, get authClient from savedInstanceState"
        //   110: iconst_0       
        //   111: anewarray       Ljava/lang/Object;
        //   114: invokestatic    com/beetalk/sdk/helper/k.a:(Ljava/lang/String;[Ljava/lang/Object;)V
        //   117: goto            156
        //   120: aload_0        
        //   121: new             Lcom/beetalk/sdk/d;
        //   124: dup            
        //   125: invokespecial   com/beetalk/sdk/d.<init>:()V
        //   128: putfield        com/beetalk/sdk/BTLoginActivity.h1:Lcom/beetalk/sdk/d;
        //   131: aload_0        
        //   132: aload_0        
        //   133: invokevirtual   android/app/Activity.getIntent:()Landroid/content/Intent;
        //   136: ldc             "request_extra"
        //   138: invokevirtual   android/content/Intent.getSerializableExtra:(Ljava/lang/String;)Ljava/io/Serializable;
        //   141: checkcast       Lcom/beetalk/sdk/d$c;
        //   144: putfield        com/beetalk/sdk/BTLoginActivity.i1:Lcom/beetalk/sdk/d$c;
        //   147: ldc             "BTLoginActivity onCreate, savedInstanceState is null, create authClient"
        //   149: iconst_0       
        //   150: anewarray       Ljava/lang/Object;
        //   153: invokestatic    com/beetalk/sdk/helper/k.a:(Ljava/lang/String;[Ljava/lang/Object;)V
        //   156: aload_0        
        //   157: aload_0        
        //   158: invokevirtual   android/app/Activity.getCallingPackage:()Ljava/lang/String;
        //   161: putfield        com/beetalk/sdk/BTLoginActivity.g1:Ljava/lang/String;
        //   164: aload_0        
        //   165: getfield        com/beetalk/sdk/BTLoginActivity.h1:Lcom/beetalk/sdk/d;
        //   168: new             Lcom/beetalk/sdk/BTLoginActivity$a;
        //   171: dup            
        //   172: aload_0        
        //   173: invokespecial   com/beetalk/sdk/BTLoginActivity$a.<init>:(Lcom/beetalk/sdk/BTLoginActivity;)V
        //   176: invokevirtual   com/beetalk/sdk/d.o:(Lcom/beetalk/sdk/d$d;)V
        //   179: aload_0        
        //   180: getfield        com/beetalk/sdk/BTLoginActivity.h1:Lcom/beetalk/sdk/d;
        //   183: aload_0        
        //   184: aload_0        
        //   185: getfield        com/beetalk/sdk/BTLoginActivity.i1:Lcom/beetalk/sdk/d$c;
        //   188: invokevirtual   com/beetalk/sdk/d.n:(Landroidx/appcompat/app/c;Lcom/beetalk/sdk/d$c;)V
        //   191: return         
        //   192: astore_2       
        //   193: goto            90
        //   196: astore_1       
        //   197: goto            108
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  14     19     22     23     Any
        //  69     90     192    196    Any
        //  90     108    196    200    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0090:
        //     at q5.p.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:150)
        //     at q5.p.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:470)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:30)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        //     at java.lang.Thread.run(Thread.java:1571)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    protected void onDestroy() {
        k.a("destroy", new Object[0]);
        this.h1.b();
        super.onDestroy();
    }
    
    protected void onPause() {
        super.onPause();
        try {
            CookieSyncManager.getInstance().stopSync();
        }
        finally {}
    }
    
    protected void onResume() {
        super.onResume();
        try {
            CookieSyncManager.getInstance().startSync();
        }
        finally {}
        if (this.g1 == null) {
            k.c("Error Calling Package must be set", new Object[0]);
            ((Activity)this).finish();
            return;
        }
        this.h1.p(this.i1);
    }
    
    protected void onSaveInstanceState(final Bundle bundle) {
        super.onSaveInstanceState(bundle);
        k.a("save bundle", new Object[0]);
        bundle.putSerializable("saved_auth_client", (Serializable)this.h1);
        ((BaseBundle)bundle).putString("saved_sandbox_mode", A0.s().name());
        bundle.putBoolean("saved_gop_dev_sandbox_mode", A0.B());
    }
}
