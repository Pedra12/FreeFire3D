package com.beetalk.sdk;

public enum e
{
    b("native"), 
    c("legacy_only"), 
    d("legacy");
    
    private static final e[] e;
    String a;
    
    static {
        e = a();
    }
    
    private e(final String a) {
        this.a = a;
    }
    
    private static /* synthetic */ e[] a() {
        return new e[] { com.beetalk.sdk.e.b, com.beetalk.sdk.e.c, com.beetalk.sdk.e.d };
    }
}
