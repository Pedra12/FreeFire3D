package com.beetalk.sdk;

import android.content.Intent;
import android.app.Activity;

public interface c
{
    Activity getContext();
    
    void startActivityForResult(final Intent p0, final int p1);
}
