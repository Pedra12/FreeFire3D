package com.beetalk.sdk;

import kotlin.Metadata;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;

@Retention(RetentionPolicy.SOURCE)
@Target({ ElementType.METHOD, ElementType.PARAMETER })
@Metadata
public @interface s0 {
    @Metadata
    public static final class a
    {
        static final a a;
        
        static {
            a = new a();
        }
        
        private a() {
        }
    }
}
