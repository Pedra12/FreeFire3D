package com.beetalk.sdk;

import g.j;
import android.text.TextUtils;
import k1.a;
import android.content.Context;
import android.content.Intent;
import android.app.Activity;
import com.garena.pay.android.l;
import com.beetalk.sdk.helper.k;
import androidx.appcompat.app.c;
import java.io.Serializable;

public class d implements Serializable
{
    private static final long serialVersionUID = 1L;
    private c a;
    private transient g b;
    private transient androidx.appcompat.app.c c;
    private transient com.beetalk.sdk.c d;
    private transient d.d$d e;
    
    private void c(final c a) {
        if (a == null) {
            k.a("request is null", new Object[0]);
            return;
        }
        k.a("commenceAuth()", new Object[0]);
        if (this.a == null) {
            this.a = a;
            this.q();
            return;
        }
        throw new RuntimeException("Attempted to authorize while a request is pending.");
    }
    
    private void d() {
        this.l(com.beetalk.sdk.d.e.a(l.d.b()));
    }
    
    private void k(final c c) {
        final s$i g = c.g();
        if (g == s$i.c) {
            k.a("add facebook auth handler", new Object[0]);
            this.b = new o(this);
            return;
        }
        if (g == s$i.b) {
            k.a("add garena auth handler", new Object[0]);
            this.b = new g0(this);
            return;
        }
        if (g == s$i.d) {
            k.a("add guest auth handler", new Object[0]);
            this.b = new n0(this);
            return;
        }
        if (g == s$i.e) {
            k.a("add vk auth handler", new Object[0]);
            this.b = (g)new I0(this);
            return;
        }
        if (g == s$i.f) {
            k.a("add line auth handler", new Object[0]);
            this.b = new r0(this);
            return;
        }
        if (g == s$i.g) {
            k.a("add google auth handler", new Object[0]);
            this.b = new j0(this);
            return;
        }
        if (g == s$i.h) {
            k.a("Add Twitter auth handler", new Object[0]);
            this.b = (g)new F0(this);
            return;
        }
        if (g == s$i.j) {
            k.a("Add Google Play Games auth handler", new Object[0]);
            this.b = (g)new z0(this);
            return;
        }
        if (g == s$i.i) {
            k.a("Add Email auth handler", new Object[0]);
            this.b = new com.beetalk.sdk.l(this);
        }
    }
    
    void b() {
        final g b = this.b;
        if (b != null) {
            b.a();
        }
    }
    
    public androidx.appcompat.app.c e() {
        return this.c;
    }
    
    public com.beetalk.sdk.c f() {
        final com.beetalk.sdk.c d = this.d;
        if (d != null) {
            return d;
        }
        if (this.a != null) {
            return new com.beetalk.sdk.c(this) {
                final d a;
                
                @Override
                public Activity getContext() {
                    return this.a.a.h().getContext();
                }
                
                @Override
                public void startActivityForResult(final Intent intent, final int n) {
                    this.a.a.h().startActivityForResult(intent, n);
                }
            };
        }
        return null;
    }
    
    public Context g() {
        return (Context)this.c;
    }
    
    public g h() {
        return this.b;
    }
    
    boolean i() {
        return this.a != null;
    }
    
    public c j() {
        return this.a;
    }
    
    public void l(final e e) {
        final d.d$d e2 = this.e;
        if (e2 != null) {
            e2.a(e);
        }
        this.a = null;
        this.b = null;
    }
    
    public boolean m(final int n, final int n2, final Intent intent) {
        final c a = this.a;
        if (a != null) {
            k.a("PendingRequest %s", a.toString());
            return this.h().b(n, n2, intent, this.a);
        }
        return false;
    }
    
    public void n(final androidx.appcompat.app.c c, final c c2) {
        this.c = c;
        this.d = new com.beetalk.sdk.c(this, c) {
            final c a;
            final d b;
            
            @Override
            public Activity getContext() {
                return (Activity)this.a;
            }
            
            @Override
            public void startActivityForResult(final Intent intent, final int n) {
                ((j)this.a).startActivityForResult(intent, n);
            }
        };
        c a = c2;
        if (c2 == null) {
            a = this.a;
        }
        if (a == null) {
            this.l(com.beetalk.sdk.d.e.a(l.y.b()));
            return;
        }
        this.k(a);
    }
    
    public void o(final d.d$d e) {
        this.e = e;
    }
    
    void p(final c c) {
        if (!this.i()) {
            this.c(c);
        }
    }
    
    protected void q() {
        k.a("try one handler", new Object[0]);
        final g b = this.b;
        if (b != null && !b.c(this.a)) {
            if (this.a != null) {
                k.a("all handlers fail, auth fail", new Object[0]);
                this.d();
            }
            return;
        }
        k.a("handler started, return", new Object[0]);
    }
    
    public static class c implements Serializable
    {
        private static final long serialVersionUID = 1L;
        private final transient com.beetalk.sdk.c a;
        private String b;
        private int c;
        private String d;
        private final String e;
        private s$i f;
        private k1.a g;
        private final String h;
        private final p1.c i;
        
        public c(final com.beetalk.sdk.c a, final String b, final int c, final String d, final String e, final String h, final p1.c i) {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.e = e;
            this.h = h;
            this.i = i;
        }
        
        public String a() {
            return this.d;
        }
        
        public String b() {
            return this.e;
        }
        
        public String c() {
            return this.b;
        }
        
        public p1.c d() {
            return this.i;
        }
        
        public String e() {
            return this.h;
        }
        
        public int f() {
            return this.c;
        }
        
        public s$i g() {
            return this.f;
        }
        
        public com.beetalk.sdk.c h() {
            return this.a;
        }
        
        public void i(final k1.a g) {
            this.g = g;
        }
        
        public void j(final s$i f) {
            this.f = f;
        }
    }
    
    public static class e implements Serializable
    {
        public static final int h;
        private static final long serialVersionUID = 1L;
        final a a;
        final k1.a b;
        final String c;
        final int d;
        final String e;
        final int f;
        final String g;
        
        static {
            h = l.c.b();
        }
        
        private e(final a a, final k1.a b, final String c, final int d, final String e, final int f, final String g) {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.e = e;
            this.f = f;
            this.g = g;
        }
        
        public static e a(final int n) {
            return c("", "", n);
        }
        
        static e b(final int n, final String s) {
            return new e(a.d, null, "", n, null, 0, s);
        }
        
        static e c(String join, final String s, final int n) {
            join = TextUtils.join((CharSequence)": ", (Object[])new String[] { join, s });
            return new e(a.d, null, join, n, null, 0, null);
        }
        
        public static e d(final k1.a a) {
            return new e(e.a.b, a, null, e.h, null, 0, null);
        }
        
        public static boolean h(final a a) {
            return a != e.a.b;
        }
        
        public int e() {
            return this.d;
        }
        
        public k1.a f() {
            return this.b;
        }
        
        public boolean g() {
            return this.a != com.beetalk.sdk.d.e.a.b;
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append("Result{resultCode=");
            sb.append((Object)this.a);
            sb.append(", token=");
            sb.append((Object)this.b);
            sb.append(", errorMessage='");
            sb.append(this.c);
            sb.append('\'');
            sb.append(", errorCode=");
            sb.append(this.d);
            sb.append(", openId='");
            sb.append(this.e);
            sb.append('\'');
            sb.append(", platform=");
            sb.append(this.f);
            sb.append('}');
            return sb.toString();
        }
        
        enum a
        {
            b("success"), 
            c("cancel"), 
            d("error");
            
            private static final a[] e;
            public final String a;
            
            static {
                e = a();
            }
            
            private a(final String a) {
                this.a = a;
            }
            
            private static /* synthetic */ a[] a() {
                return new a[] { a.b, a.c, a.d };
            }
        }
    }
}
