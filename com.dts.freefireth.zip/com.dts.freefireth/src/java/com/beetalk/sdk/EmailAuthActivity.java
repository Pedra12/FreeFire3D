package com.beetalk.sdk;

import android.view.View;
import java.util.Locale;
import java.io.UnsupportedEncodingException;
import kotlin.jvm.functions.Function1;
import com.beetalk.sdk.networking.w;
import java.util.List;
import com.beetalk.sdk.helper.I;
import com.beetalk.sdk.networking.c;
import com.beetalk.sdk.helper.A;
import java.util.ArrayList;
import p1.b;
import java.util.concurrent.Callable;
import c1.i;
import com.garena.pay.android.l;
import android.webkit.WebViewClient;
import Q2.f;
import android.webkit.CookieManager;
import Q2.d;
import Q2.e;
import D2.a;
import android.os.Build$VERSION;
import android.os.Bundle;
import android.text.TextUtils;
import com.beetalk.sdk.networking.service.j;
import com.beetalk.sdk.helper.k;
import java.io.Serializable;
import android.content.Intent;
import android.content.Context;
import android.webkit.WebView;
import android.app.Activity;

public class EmailAuthActivity extends Activity
{
    private WebView a;
    private d$c b;
    private String c;
    
    public static Intent g(final Context context, final d$c d$c) {
        final Intent intent = new Intent();
        intent.setClass(context, (Class)EmailAuthActivity.class);
        intent.putExtra("email_auth_request", (Serializable)d$c);
        intent.putExtra("gop_environment", A0.s().toString());
        intent.putExtra("gop_dev_sandbox", A0.B());
        intent.putExtra("gop_root_url", A0.K());
        intent.putExtra("gop_new_root_url", A0.J());
        intent.putExtra("datadome_sdk_key", A0.q());
        intent.putExtra("datadome_activate_logger", A0.p());
        return intent;
    }
    
    private void h() {
        this.setResult(0);
        this.finish();
    }
    
    private void i(final int n) {
        k.i("onAuthFailed-failed", new Object[0]);
        ((View)this.a).post((Runnable)new Runnable(this, d$e.a(n)) {
            final d$e a;
            final EmailAuthActivity b;
            
            public void run() {
                this.b.k(this.a);
            }
        });
    }
    
    private void j(final String s) {
        k.i("onAuthSuccess-user code %s", new Object[] { s });
        ((View)this.a).post((Runnable)new Runnable(this, this.l(s, this.b)) {
            final d$e a;
            final EmailAuthActivity b;
            
            public void run() {
                this.b.k(this.a);
            }
        });
    }
    
    private void k(final d$e d$e) {
        final Intent intent = new Intent();
        intent.putExtra("email_auth_result", (Serializable)d$e);
        int n;
        if (d$e.h(d$e.a)) {
            n = 0;
        }
        else {
            n = -1;
        }
        this.setResult(n, intent);
        this.finish();
    }
    
    private d$e l(final String s, final d$c d$c) {
        return j.m(s, this.c, d$c.a(), d$c.b(), d$c.e(), 13);
    }
    
    private void m(final Intent intent) {
        try {
            final String stringExtra = intent.getStringExtra("gop_environment");
            if (!TextUtils.isEmpty((CharSequence)stringExtra)) {
                X.B(A0.e.valueOf(stringExtra));
            }
        }
        catch (final Exception ex) {
            k.b(ex);
        }
        try {
            A0.e0(intent.getBooleanExtra("gop_dev_sandbox", A0.B()));
        }
        catch (final Exception ex2) {
            k.b(ex2);
        }
        if (intent.hasExtra("gop_root_url")) {
            A0.g0(intent.getStringExtra("gop_root_url"));
        }
        if (intent.hasExtra("gop_new_root_url")) {
            A0.f0(intent.getStringExtra("gop_new_root_url"));
        }
        if (intent.hasExtra("datadome_sdk_key")) {
            A0.c0(intent.getStringExtra("datadome_sdk_key"));
        }
        A0.b0(intent.getBooleanExtra("datadome_activate_logger", A0.p()));
    }
    
    protected void onCreate(Bundle r) {
        super.onCreate(r);
        X.Z(((Context)this).getApplicationContext());
        this.m(this.getIntent());
        r = (Bundle)A0.r();
        if (TextUtils.isEmpty((CharSequence)r)) {
            k.c("failed to get base url for email login", new Object[0]);
            this.finish();
            return;
        }
        if (Build$VERSION.SDK_INT >= 28) {
            final a a = D2.a.a;
            if (!a.b()) {
                try {
                    h.a("email_login");
                    a.e(true);
                }
                catch (final Exception ex) {}
            }
        }
        this.setContentView(e.a);
        final WebView a2 = (WebView)this.findViewById(d.u);
        this.a = a2;
        a2.getSettings().setUseWideViewPort(true);
        this.a.getSettings().setLoadWithOverviewMode(true);
        this.a.getSettings().setJavaScriptEnabled(true);
        this.a.getSettings().setBuiltInZoomControls(true);
        this.a.getSettings().setDomStorageEnabled(true);
        this.a.clearCache(true);
        CookieManager.getInstance().removeAllCookie();
        if (TextUtils.isEmpty((CharSequence)X.Q())) {
            this.setTitle(f.a);
        }
        else {
            this.setTitle((CharSequence)X.Q());
        }
        this.a.setWebViewClient((WebViewClient)new WebViewClient(this) {
            final EmailAuthActivity a;
            
            public void onReceivedError(final WebView webView, final int n, final String s, final String s2) {
                super.onReceivedError(webView, n, s, s2);
                this.a.k(d$e.a((int)l.v.b()));
            }
            
            public boolean shouldOverrideUrlLoading(final WebView webView, final String s) {
                if (s.contains((CharSequence)this.a.c)) {
                    final int index = s.indexOf("code=");
                    if (index != -1) {
                        final String substring = s.substring(index + 5);
                        k.i("web code %s %s", new Object[] { s, substring });
                        i.f((Callable)new com.beetalk.sdk.j(this, substring));
                    }
                    else {
                        final int index2 = s.indexOf("error=");
                        if (index2 == -1) {
                            i.f((Callable)new com.beetalk.sdk.k(this));
                        }
                        else if (s.substring(index2 + 6).equals((Object)"access_denied")) {
                            this.a.h();
                        }
                    }
                    return true;
                }
                return super.shouldOverrideUrlLoading(webView, s);
            }
        });
        try {
            final d$c b = (d$c)this.getIntent().getSerializableExtra("email_auth_request");
            this.b = b;
            final String a3 = b.a();
            X.r0(a3);
            this.c = p1.b.a.a();
            final p1.c d = this.b.d();
            if (!(d instanceof p1.a)) {
                this.finish();
                return;
            }
            final ArrayList list = new ArrayList();
            final Locale e = A.e(((Context)this).getApplicationContext());
            ((List)list).add((Object)new c("app_id", a3));
            ((List)list).add((Object)new c("redirect_uri", this.c));
            ((List)list).add((Object)new c("locale", A.f(e)));
            ((List)list).add((Object)new c("source", String.valueOf((Object)X.N())));
            ((List)list).add((Object)new c("region", ((p1.a)d).b()));
            if (s.Y(this.b)) {
                ((List)list).add((Object)new c("create_grant", "false"));
                ((List)list).add((Object)new c("grant", "true"));
            }
            ((List)list).add((Object)new c("login_scenario", this.b.e()));
            try {
                final WebView a4 = this.a;
                final StringBuilder sb = new StringBuilder();
                sb.append((String)r);
                sb.append(I.b((List)list));
                w.c(a4, sb.toString(), (Function1)new com.beetalk.sdk.i(this));
            }
            catch (final UnsupportedEncodingException ex2) {
                k.b((Exception)ex2);
                this.finish();
            }
        }
        catch (final NullPointerException ex3) {
            k.b((Exception)ex3);
            this.finish();
        }
    }
}
