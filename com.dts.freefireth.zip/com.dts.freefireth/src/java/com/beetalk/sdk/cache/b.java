package com.beetalk.sdk.cache;

import android.content.SharedPreferences$Editor;
import android.content.Context;
import android.content.SharedPreferences;

public abstract class b
{
    protected SharedPreferences a;
    
    public b() {
        this.a();
    }
    
    public void a() {
        if (this.a == null) {
            final Context b = this.b();
            if (b != null) {
                this.a = b.getSharedPreferences(this.e(), 0);
            }
        }
    }
    
    protected abstract Context b();
    
    public long c(final String s, final long n) {
        final SharedPreferences a = this.a;
        if (a == null) {
            return n;
        }
        return a.getLong(s, n);
    }
    
    public String d(final String s, final String s2) {
        final SharedPreferences a = this.a;
        if (a == null) {
            return s2;
        }
        return a.getString(s, s2);
    }
    
    protected String e() {
        return "";
    }
    
    public void f(final String s, final long n) {
        final SharedPreferences a = this.a;
        if (a == null) {
            return;
        }
        final SharedPreferences$Editor edit = a.edit();
        edit.putLong(s, n);
        edit.apply();
    }
    
    public void g(final String s, final String s2) {
        final SharedPreferences a = this.a;
        if (a == null) {
            return;
        }
        final SharedPreferences$Editor edit = a.edit();
        edit.putString(s, s2);
        edit.apply();
    }
}
