package com.beetalk.sdk.cache;

import java.util.Map;
import com.garena.pay.android.l;
import c1.g;
import com.beetalk.sdk.networking.service.E;
import com.beetalk.sdk.helper.k;
import V.b;
import org.json.JSONObject;
import com.beetalk.sdk.networking.model.ChannelsReq;
import com.beetalk.sdk.X;
import com.beetalk.sdk.s;
import c1.i;
import com.garena.pay.android.p;
import android.content.Context;
import com.beetalk.sdk.networking.model.ChannelsResp;

public class e
{
    private static volatile e d;
    private String a;
    private ChannelsResp b;
    private long c;
    
    public e() {
        this.c = 0L;
    }
    
    public static e d() {
        if (e.d == null) {
            final Class<e> clazz;
            monitorenter(clazz = e.class);
            Label_0036: {
                try {
                    if (e.d == null) {
                        e.d = new e();
                    }
                    break Label_0036;
                }
                finally {
                    monitorexit(clazz);
                    monitorexit(clazz);
                }
            }
        }
        return e.d;
    }
    
    public void c() {
        this.c = 0L;
        this.b = null;
        this.a = null;
    }
    
    public i e(final Context context, final boolean b, final p p3) {
        if (s.w() == null || X.N() == null) {
            this.c();
            return i.t((Object)null);
        }
        final Map a = ChannelsReq.a(context, p3);
        final StringBuilder sb = new StringBuilder();
        sb.append(new JSONObject(a).toString());
        sb.append(p3.c().m());
        final String string = sb.toString();
        if (!b && this.b != null && System.currentTimeMillis() - this.c <= 60000L && b.a((Object)this.a, (Object)string)) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("Cache hit: ");
            sb2.append(this.a);
            k.a(sb2.toString(), new Object[0]);
            return i.t((Object)this.b);
        }
        this.a = string;
        return E.z(context, p3, a).l((g)new g(this) {
            final e a;
            
            public ChannelsResp b(final i i) {
                if (i.z() || i.v() == null) {
                    this.a.c();
                    return null;
                }
                final ChannelsResp channelsResp = (ChannelsResp)i.v();
                if (channelsResp.b() != l.c.b()) {
                    this.a.c();
                    return channelsResp;
                }
                if (channelsResp.j() != null && !channelsResp.j().isEmpty()) {
                    e.a(this.a, channelsResp);
                    e.b(this.a, System.currentTimeMillis());
                    return channelsResp;
                }
                this.a.c();
                return null;
            }
        }, i.k);
    }
}
