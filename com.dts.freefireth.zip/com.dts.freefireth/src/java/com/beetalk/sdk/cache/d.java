package com.beetalk.sdk.cache;

import com.garena.pay.android.E;
import java.util.Iterator;
import com.beetalk.sdk.A0;
import android.text.TextUtils;
import com.beetalk.sdk.networking.h;
import com.garena.pay.android.data.UserTransactionInfo;
import com.beetalk.sdk.X;
import java.util.HashSet;
import org.json.JSONException;
import com.beetalk.sdk.helper.k;
import org.json.JSONArray;
import android.content.SharedPreferences$Editor;
import java.util.ArrayList;
import com.android.billingclient.api.Purchase;
import android.content.Context;
import java.util.Set;
import android.content.SharedPreferences;

public class d
{
    private static volatile d d;
    private final SharedPreferences a;
    private long b;
    private Set c;
    
    private d(final Context context) {
        final SharedPreferences sharedPreferences = context.getSharedPreferences("com.garena.android.msdk.PayCachePreference", 0);
        this.a = sharedPreferences;
        this.b = sharedPreferences.getLong("TIME_CREATED", 0L);
    }
    
    public static void a(final Context context, final Purchase purchase) {
        if (purchase != null) {
            final ArrayList j = purchase.j();
            if (!j.isEmpty() && !"9999".equals(j.get(0))) {
                if (!"android.test.purchased".equals(j.get(0))) {
                    if (b(context)) {
                        l(context);
                    }
                    final String g = purchase.g();
                    final Set c = c(context);
                    if (!c.contains((Object)g)) {
                        c.add((Object)g);
                        i(context, c);
                    }
                }
            }
        }
    }
    
    private static boolean b(final Context context) {
        if (h(context)) {
            e(context).b = 0L;
            e(context).c = null;
            final SharedPreferences$Editor edit = e(context).a.edit();
            edit.putString("COMMIT_CACHE", "[]");
            edit.putLong("TIME_CREATED", 0L);
            edit.apply();
            return true;
        }
        return false;
    }
    
    private static Set c(final Context context) {
        if (e(context).c != null && !e(context).c.isEmpty()) {
            return e(context).c;
        }
        final String string = e(context).a.getString("COMMIT_CACHE", "[]");
        JSONArray jsonArray;
        try {
            jsonArray = new JSONArray(string);
        }
        catch (final JSONException ex) {
            k.b((Exception)ex);
            jsonArray = null;
        }
        final HashSet c = new HashSet();
        if (jsonArray != null) {
            for (int i = 0; i < jsonArray.length(); ++i) {
                ((Set)c).add((Object)jsonArray.optString(i));
            }
        }
        return e(context).c = (Set)c;
    }
    
    public static d d() {
        return e(X.M());
    }
    
    public static d e(final Context context) {
        if (com.beetalk.sdk.cache.d.d == null) {
            final Class<d> clazz;
            monitorenter(clazz = d.class);
            Label_0037: {
                try {
                    if (com.beetalk.sdk.cache.d.d == null) {
                        com.beetalk.sdk.cache.d.d = new d(context);
                    }
                    break Label_0037;
                }
                finally {
                    monitorexit(clazz);
                    monitorexit(clazz);
                }
            }
        }
        return com.beetalk.sdk.cache.d.d;
    }
    
    public static UserTransactionInfo f(final String s, String s2) {
        final StringBuilder sb = new StringBuilder();
        sb.append("TRANSACTION_INFO_");
        sb.append(s);
        sb.append("_");
        sb.append(s2);
        s2 = sb.toString();
        s2 = d().a.getString(s2, "{}");
        try {
            final UserTransactionInfo userTransactionInfo = (UserTransactionInfo)h.f.fromJson(s2, (Class)UserTransactionInfo.class);
            if (TextUtils.equals((CharSequence)s, (CharSequence)userTransactionInfo.accountId) && userTransactionInfo.a()) {
                return userTransactionInfo;
            }
        }
        catch (final Exception ex) {
            k.b(ex);
        }
        return new UserTransactionInfo();
    }
    
    public static boolean g(final Context context, final Purchase purchase) {
        return purchase != null && !b(context) && c(context).contains((Object)purchase.g());
    }
    
    private static boolean h(final Context context) {
        return System.currentTimeMillis() - k(context) > A0.o();
    }
    
    private static void i(final Context context, final Set c) {
        final SharedPreferences$Editor edit = e(context).a.edit();
        final JSONArray jsonArray = new JSONArray();
        final Iterator iterator = c.iterator();
        while (iterator.hasNext()) {
            jsonArray.put((Object)iterator.next());
        }
        edit.putString("COMMIT_CACHE", jsonArray.toString());
        edit.apply();
        e(context).c = c;
    }
    
    public static void j(final String s, String b, final String s2, final E e) {
        final String d = e.d();
        final long c = e.c();
        final String f = e.f();
        final StringBuilder sb = new StringBuilder();
        sb.append("TRANSACTION_INFO_");
        sb.append(s);
        sb.append("_");
        sb.append(f);
        final String string = sb.toString();
        b = new UserTransactionInfo(s, b, s2, d, c).b();
        final SharedPreferences$Editor edit = d().a.edit();
        edit.putString(string, b);
        edit.apply();
    }
    
    private static long k(final Context context) {
        final long b = e(context).b;
        if (b > 0L) {
            return b;
        }
        return e(context).b = e(context).a.getLong("TIME_CREATED", 0L);
    }
    
    private static void l(final Context context) {
        final long currentTimeMillis = System.currentTimeMillis();
        final SharedPreferences$Editor edit = e(context).a.edit();
        edit.putLong("TIME_CREATED", currentTimeMillis);
        edit.apply();
        e(context).b = currentTimeMillis;
    }
}
