package com.beetalk.sdk.cache;

import java.util.Collection;
import org.jetbrains.annotations.NotNull;
import android.content.SharedPreferences$OnSharedPreferenceChangeListener;
import kotlin.collections.F;
import s7.u;
import java.util.ArrayList;
import java.util.Map;
import android.content.SharedPreferences$Editor;
import com.beetalk.sdk.helper.G;
import java.util.Set;
import s7.p$a;
import kotlin.text.Charsets;
import s7.q;
import android.util.Base64;
import s7.p;
import java.util.Iterator;
import kotlin.ranges.IntRange;
import kotlin.collections.E;
import java.util.LinkedHashSet;
import org.json.JSONArray;
import kotlin.jvm.internal.Intrinsics;
import com.beetalk.sdk.helper.d;
import com.beetalk.sdk.helper.g;
import kotlin.jvm.functions.Function1;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import javax.crypto.SecretKey;
import android.content.Context;
import kotlin.Metadata;
import android.content.SharedPreferences;

@Metadata
public final class c implements SharedPreferences
{
    public static final a g;
    private final Context a;
    private final String b;
    private final SharedPreferences c;
    private final String d;
    private final SecretKey e;
    private final SecretKey f;
    
    static {
        g = new a(null);
    }
    
    private c(final Context a, final String b, final String s, final SharedPreferences c) {
        this.a = a;
        this.b = b;
        this.c = c;
        final String v = CollectionsKt.V((Iterable)CollectionsKt.n((Object[])new String[] { a.getPackageName(), s, b, "com.garena.sdk.android.security.CryptoSharedPreferenceV2.v1" }), (CharSequence)":", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null);
        this.d = v;
        this.e = com.beetalk.sdk.helper.g.a.a(v);
        final d a2 = com.beetalk.sdk.helper.d.a;
        final StringBuilder sb = new StringBuilder();
        sb.append(v);
        sb.append(":keys");
        this.f = a2.a(sb.toString());
        final SharedPreferences sharedPreferences = a.getSharedPreferences(b, 0);
        Intrinsics.c((Object)sharedPreferences);
        this.j(sharedPreferences);
    }
    
    private final Object d(final String s) {
        final int length = s.length();
        final Object o = null;
        if (length < 2) {
            return null;
        }
        final String substring = s.substring(2);
        Intrinsics.checkNotNullExpressionValue((Object)substring, "substring(...)");
        final char char1 = s.charAt(0);
        if (char1 == 'N') {
            return null;
        }
        if (char1 == 's') {
            return substring;
        }
        if (char1 == 'i') {
            return Integer.parseInt(substring);
        }
        if (char1 == 'l') {
            return Long.parseLong(substring);
        }
        if (char1 == 'f') {
            return Float.parseFloat(substring);
        }
        if (char1 == 'b') {
            return Boolean.parseBoolean(substring);
        }
        Object o2 = o;
        if (char1 == 'S') {
            final JSONArray jsonArray = new JSONArray(substring);
            final IntRange k = kotlin.ranges.d.k(0, jsonArray.length());
            final LinkedHashSet set = new LinkedHashSet();
            final Iterator iterator = ((Iterable)k).iterator();
            while (true) {
                o2 = set;
                if (!iterator.hasNext()) {
                    break;
                }
                ((Collection)set).add((Object)jsonArray.optString(((E)iterator).a()));
            }
        }
        return o2;
    }
    
    private final String e(final String s) {
        Object b3 = null;
        try {
            final p$a b = p.b;
            p.b((Object)Base64.decode(s, 2));
        }
        finally {
            final p$a b2 = p.b;
            final Throwable t;
            b3 = p.b(q.a(t));
        }
        Object o = b3;
        if (p.f(b3)) {
            o = null;
        }
        final byte[] array = (byte[])o;
        if (array == null) {
            return null;
        }
        final byte[] b4 = com.beetalk.sdk.helper.g.a.b(this.e, array);
        if (b4 == null) {
            return null;
        }
        return new String(b4, Charsets.UTF_8);
    }
    
    private final String f(String s) {
        final String s2 = null;
        if (s == null) {
            return null;
        }
        Object b3 = null;
        try {
            final p$a b = p.b;
            p.b((Object)Base64.decode(s, 2));
        }
        finally {
            final p$a b2 = p.b;
            final Throwable t;
            b3 = p.b(q.a(t));
        }
        Object o = b3;
        if (p.f(b3)) {
            o = null;
        }
        final byte[] array = (byte[])o;
        if (array == null) {
            return null;
        }
        final byte[] b4 = com.beetalk.sdk.helper.d.a.b(this.f, array);
        s = s2;
        if (b4 != null) {
            s = new String(b4, Charsets.UTF_8);
        }
        return s;
    }
    
    private final String g(Object o) {
        if (o == null) {
            return "N:";
        }
        if (o instanceof String) {
            final StringBuilder sb = new StringBuilder();
            sb.append("s:");
            sb.append(o);
            return sb.toString();
        }
        if (o instanceof Integer) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("i:");
            sb2.append(o);
            return sb2.toString();
        }
        if (o instanceof Long) {
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("l:");
            sb3.append(o);
            return sb3.toString();
        }
        if (o instanceof Float) {
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("f:");
            sb4.append(o);
            return sb4.toString();
        }
        if (o instanceof Boolean) {
            final StringBuilder sb5 = new StringBuilder();
            sb5.append("b:");
            sb5.append(o);
            return sb5.toString();
        }
        if (o instanceof Set) {
            final JSONArray jsonArray = new JSONArray();
            for (final Object next : (Iterable)o) {
                if (next instanceof String) {
                    jsonArray.put(next);
                }
            }
            o = new StringBuilder();
            ((StringBuilder)o).append("S:");
            ((StringBuilder)o).append((Object)jsonArray);
            return ((StringBuilder)o).toString();
        }
        final Class<?> class1 = o.getClass();
        final StringBuilder sb6 = new StringBuilder();
        sb6.append("Unsupported type: ");
        sb6.append((Object)class1);
        throw new IllegalArgumentException(sb6.toString());
    }
    
    private final String h(final String s) {
        final g a = com.beetalk.sdk.helper.g.a;
        final SecretKey e = this.e;
        final byte[] bytes = s.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue((Object)bytes, "getBytes(...)");
        final byte[] d = a.d(e, bytes);
        if (d == null) {
            return null;
        }
        return Base64.encodeToString(d, 2);
    }
    
    private final String i(final String s) {
        if (s == null) {
            return null;
        }
        final d a = com.beetalk.sdk.helper.d.a;
        final SecretKey f = this.f;
        final byte[] bytes = s.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue((Object)bytes, "getBytes(...)");
        final byte[] c = a.c(f, bytes);
        if (c != null) {
            return Base64.encodeToString(c, 2);
        }
        return null;
    }
    
    private final void j(final SharedPreferences sharedPreferences) {
        if (G.a(sharedPreferences, (SharedPreferences)this)) {
            final SharedPreferences$Editor edit = sharedPreferences.edit();
            edit.clear();
            edit.apply();
        }
    }
    
    public boolean contains(String i) {
        i = this.i(i);
        return i != null && this.c.contains(i);
    }
    
    public SharedPreferences$Editor edit() {
        final SharedPreferences$Editor edit = this.c.edit();
        Intrinsics.checkNotNullExpressionValue((Object)edit, "edit(...)");
        return (SharedPreferences$Editor)new b(edit);
    }
    
    public Map getAll() {
        final Map all = this.c.getAll();
        final Set keySet = all.keySet();
        final ArrayList list = new ArrayList();
        final Iterator iterator = ((Iterable)keySet).iterator();
    Label_0129_Outer:
        while (true) {
            Label_0152: {
                if (!iterator.hasNext()) {
                    break Label_0152;
                }
                final String s = (String)iterator.next();
                final String f = this.f(s);
                Object a = null;
                final Object o = null;
                Label_0136: {
                    if (f == null) {
                        break Label_0136;
                    }
                    final Object value = all.get((Object)s);
                    String s2;
                    if (value instanceof String) {
                        s2 = (String)value;
                    }
                    else {
                        s2 = null;
                    }
                    Object d = o;
                    while (true) {
                        if (s2 == null) {
                            break Label_0129;
                        }
                        try {
                            final String e = this.e(s2);
                            if (e == null) {
                                d = o;
                            }
                            else {
                                d = this.d(e);
                            }
                            a = u.a((Object)f, d);
                            if (a != null) {
                                ((Collection)list).add(a);
                                continue Label_0129_Outer;
                            }
                            continue Label_0129_Outer;
                            return F.r((Iterable)list);
                        }
                        catch (final Exception ex) {
                            d = o;
                            continue;
                        }
                        break;
                    }
                }
            }
        }
    }
    
    public boolean getBoolean(String s, boolean booleanValue) {
        s = this.i(s);
        final Boolean b = null;
        Boolean b2;
        if (s == null) {
            b2 = b;
        }
        else {
            final Object value = this.c.getAll().get((Object)s);
            if (value instanceof String) {
                s = (String)value;
            }
            else {
                s = null;
            }
            if (s == null) {
                b2 = b;
            }
            else {
                try {
                    s = this.e(s);
                    if (s == null) {
                        b2 = b;
                    }
                    else {
                        Object d;
                        if (!((d = this.d(s)) instanceof Boolean)) {
                            d = null;
                        }
                        b2 = (Boolean)d;
                    }
                }
                catch (final Exception ex) {
                    b2 = b;
                }
            }
        }
        if (b2 != null) {
            booleanValue = b2;
        }
        return booleanValue;
    }
    
    public float getFloat(String s, float floatValue) {
        s = this.i(s);
        final Float n = null;
        Float n2;
        if (s == null) {
            n2 = n;
        }
        else {
            final Object value = this.c.getAll().get((Object)s);
            if (value instanceof String) {
                s = (String)value;
            }
            else {
                s = null;
            }
            if (s == null) {
                n2 = n;
            }
            else {
                try {
                    s = this.e(s);
                    if (s == null) {
                        n2 = n;
                    }
                    else {
                        Object d;
                        if (!((d = this.d(s)) instanceof Float)) {
                            d = null;
                        }
                        n2 = (Float)d;
                    }
                }
                catch (final Exception ex) {
                    n2 = n;
                }
            }
        }
        if (n2 != null) {
            floatValue = n2;
        }
        return floatValue;
    }
    
    public int getInt(String s, int intValue) {
        s = this.i(s);
        final Integer n = null;
        Integer n2;
        if (s == null) {
            n2 = n;
        }
        else {
            final Object value = this.c.getAll().get((Object)s);
            if (value instanceof String) {
                s = (String)value;
            }
            else {
                s = null;
            }
            if (s == null) {
                n2 = n;
            }
            else {
                try {
                    s = this.e(s);
                    if (s == null) {
                        n2 = n;
                    }
                    else {
                        Object d;
                        if (!((d = this.d(s)) instanceof Integer)) {
                            d = null;
                        }
                        n2 = (Integer)d;
                    }
                }
                catch (final Exception ex) {
                    n2 = n;
                }
            }
        }
        if (n2 != null) {
            intValue = n2;
        }
        return intValue;
    }
    
    public long getLong(String s, long longValue) {
        s = this.i(s);
        final Long n = null;
        Long n2;
        if (s == null) {
            n2 = n;
        }
        else {
            final Object value = this.c.getAll().get((Object)s);
            if (value instanceof String) {
                s = (String)value;
            }
            else {
                s = null;
            }
            if (s == null) {
                n2 = n;
            }
            else {
                try {
                    s = this.e(s);
                    if (s == null) {
                        n2 = n;
                    }
                    else {
                        Object d;
                        if (!((d = this.d(s)) instanceof Long)) {
                            d = null;
                        }
                        n2 = (Long)d;
                    }
                }
                catch (final Exception ex) {
                    n2 = n;
                }
            }
        }
        if (n2 != null) {
            longValue = n2;
        }
        return longValue;
    }
    
    public String getString(String s, String s2) {
        s = this.i(s);
        final String s3 = null;
        if (s == null) {
            s = s3;
        }
        else {
            final Object value = this.c.getAll().get((Object)s);
            if (value instanceof String) {
                s = (String)value;
            }
            else {
                s = null;
            }
            if (s == null) {
                s = s3;
            }
            else {
                try {
                    s = this.e(s);
                    if (s == null) {
                        s = s3;
                    }
                    else {
                        Object d;
                        if (!((d = this.d(s)) instanceof String)) {
                            d = null;
                        }
                        s = (String)d;
                    }
                }
                catch (final Exception ex) {
                    s = s3;
                }
            }
        }
        if (s != null) {
            s2 = s;
        }
        return s2;
    }
    
    public Set getStringSet(String s, Set set) {
        s = this.i(s);
        final Set set2 = null;
        Set set3;
        if (s == null) {
            set3 = set2;
        }
        else {
            final Object value = this.c.getAll().get((Object)s);
            if (value instanceof String) {
                s = (String)value;
            }
            else {
                s = null;
            }
            if (s == null) {
                set3 = set2;
            }
            else {
                try {
                    s = this.e(s);
                    if (s == null) {
                        set3 = set2;
                    }
                    else {
                        Object d;
                        if (!((d = this.d(s)) instanceof Set)) {
                            d = null;
                        }
                        set3 = (Set)d;
                    }
                }
                catch (final Exception ex) {
                    set3 = set2;
                }
            }
        }
        if (set3 != null) {
            set = set3;
        }
        return set;
    }
    
    public void registerOnSharedPreferenceChangeListener(final SharedPreferences$OnSharedPreferenceChangeListener sharedPreferences$OnSharedPreferenceChangeListener) {
        this.c.registerOnSharedPreferenceChangeListener(sharedPreferences$OnSharedPreferenceChangeListener);
    }
    
    public void unregisterOnSharedPreferenceChangeListener(final SharedPreferences$OnSharedPreferenceChangeListener sharedPreferences$OnSharedPreferenceChangeListener) {
        this.c.unregisterOnSharedPreferenceChangeListener(sharedPreferences$OnSharedPreferenceChangeListener);
    }
    
    @Metadata
    public static final class a
    {
        private a() {
        }
        
        public final SharedPreferences a(final Context p0, final String p1) {
            // 
            // This method could not be decompiled.
            // 
            // Original Bytecode:
            // 
            //     1: dup            
            //     2: astore          4
            //     4: monitorenter   
            //     5: aload_1        
            //     6: ldc             "context"
            //     8: invokestatic    kotlin/jvm/internal/Intrinsics.checkNotNullParameter:(Ljava/lang/Object;Ljava/lang/String;)V
            //    11: aload_2        
            //    12: ldc             "fileName"
            //    14: invokestatic    kotlin/jvm/internal/Intrinsics.checkNotNullParameter:(Ljava/lang/Object;Ljava/lang/String;)V
            //    17: getstatic       com/beetalk/sdk/helper/j.a:Lcom/beetalk/sdk/helper/j;
            //    20: invokevirtual   com/beetalk/sdk/helper/j.c:()Ljava/lang/String;
            //    23: astore_3       
            //    24: aload_3        
            //    25: invokeinterface java/lang/CharSequence.length:()I
            //    30: ifne            46
            //    33: invokestatic    com/beetalk/sdk/helper/G.b:()Landroid/content/SharedPreferences;
            //    36: astore_1       
            //    37: aload           4
            //    39: monitorexit    
            //    40: aload_1        
            //    41: areturn        
            //    42: astore_1       
            //    43: goto            74
            //    46: new             Lcom/beetalk/sdk/cache/c;
            //    49: dup            
            //    50: aload_1        
            //    51: aload_2        
            //    52: aload_3        
            //    53: aconst_null    
            //    54: bipush          8
            //    56: aconst_null    
            //    57: invokespecial   com/beetalk/sdk/cache/c.<init>:(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/content/SharedPreferences;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
            //    60: astore_1       
            //    61: goto            69
            //    64: astore_1       
            //    65: invokestatic    com/beetalk/sdk/helper/G.b:()Landroid/content/SharedPreferences;
            //    68: astore_1       
            //    69: aload           4
            //    71: monitorexit    
            //    72: aload_1        
            //    73: areturn        
            //    74: aload           4
            //    76: monitorexit    
            //    77: aload_1        
            //    78: athrow         
            //    Exceptions:
            //  Try           Handler
            //  Start  End    Start  End    Type                 
            //  -----  -----  -----  -----  ---------------------
            //  5      17     42     79     Any
            //  17     37     64     69     Ljava/lang/Exception;
            //  17     37     42     79     Any
            //  46     61     64     69     Ljava/lang/Exception;
            //  46     61     42     79     Any
            //  65     69     42     79     Any
            //  74     77     42     79     Any
            // 
            // The error that occurred was:
            // 
            // java.lang.IllegalStateException: Expression is linked from several locations: Label_0046:
            //     at q5.p.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:150)
            //     at q5.p.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:470)
            //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:30)
            //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
            //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
            //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
            //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
            //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:799)
            //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
            //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
            //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
            //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
            //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
            //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
            //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
            //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
            //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
            //     at java.lang.Thread.run(Thread.java:1571)
            // 
            throw new IllegalStateException("An error occurred while decompiling this method.");
        }
    }
    
    @Metadata
    private final class b implements SharedPreferences$Editor
    {
        private final SharedPreferences$Editor a;
        final c b;
        
        public b(@NotNull final c b, final SharedPreferences$Editor a) {
            Intrinsics.checkNotNullParameter((Object)a, "delegate");
            this.b = b;
            this.a = a;
        }
        
        private final String a(final Object o) {
            final c b = this.b;
            return b.h(b.g(o));
        }
        
        private final SharedPreferences$Editor b(String c, final Object o) {
            c = this.b.i(c);
            if (c != null) {
                if (o == null) {
                    this.a.remove(c);
                    return (SharedPreferences$Editor)this;
                }
                final String a = this.a(o);
                if (a != null) {
                    this.a.putString(c, a);
                    return (SharedPreferences$Editor)this;
                }
            }
            return (SharedPreferences$Editor)this;
        }
        
        public void apply() {
            this.a.apply();
        }
        
        public SharedPreferences$Editor clear() {
            return this.a.clear();
        }
        
        public boolean commit() {
            return this.a.commit();
        }
        
        public SharedPreferences$Editor putBoolean(final String s, final boolean b) {
            return this.b(s, b);
        }
        
        public SharedPreferences$Editor putFloat(final String s, final float n) {
            return this.b(s, n);
        }
        
        public SharedPreferences$Editor putInt(final String s, final int n) {
            return this.b(s, n);
        }
        
        public SharedPreferences$Editor putLong(final String s, final long n) {
            return this.b(s, n);
        }
        
        public SharedPreferences$Editor putString(final String s, final String s2) {
            return this.b(s, s2);
        }
        
        public SharedPreferences$Editor putStringSet(final String s, final Set set) {
            return this.b(s, set);
        }
        
        public SharedPreferences$Editor remove(String c) {
            c = this.b.i(c);
            if (c == null) {
                return (SharedPreferences$Editor)this;
            }
            this.a.remove(c);
            return (SharedPreferences$Editor)this;
        }
    }
}
