package com.beetalk.sdk.cache;

import java.util.HashMap;
import java.util.Map;
import k1.a;
import com.beetalk.sdk.A0$e;
import com.beetalk.sdk.A0;

public abstract class l
{
    private String e() {
        if (A0.s() == A0$e.b) {
            return "com.garena.msdk.guest_token_sandbox";
        }
        A0.s();
        final A0$e a = A0$e.a;
        return "com.garena.msdk.guest_token";
    }
    
    public void a() {
        this.m("com.garena.msdk.token");
        this.m("com.garena.msdk.guest_token");
        this.m("com.garena.msdk.guest_token_sandbox");
    }
    
    public String b() {
        final String f = this.f();
        this.m(this.g());
        this.m(this.d());
        return f;
    }
    
    public String c() {
        return (String)this.i().get((Object)this.d());
    }
    
    public String d() {
        if (A0.s() == A0$e.b) {
            return "com.garena.msdk.guest_password_sandbox";
        }
        A0.s();
        final A0$e a = A0$e.a;
        return "com.garena.msdk.guest_password";
    }
    
    public String f() {
        return (String)this.i().get((Object)this.g());
    }
    
    public String g() {
        if (A0.s() == A0$e.b) {
            return "com.garena.msdk.guest_uid_sandbox";
        }
        A0.s();
        final A0$e a = A0$e.a;
        return "com.garena.msdk.guest_uid";
    }
    
    public a h() {
        final String s = (String)this.i().get((Object)"com.garena.msdk.token");
        if (s == null) {
            return null;
        }
        return a.b(s);
    }
    
    public abstract Map i();
    
    public void j(final String s, final String s2) {
        final HashMap hashMap = new HashMap();
        ((Map)hashMap).put((Object)this.g(), (Object)s);
        ((Map)hashMap).put((Object)this.d(), (Object)s2);
        this.o((Map)hashMap);
    }
    
    public void k(final a a) {
        final HashMap hashMap = new HashMap();
        ((Map)hashMap).put((Object)this.e(), (Object)a.x(a));
        this.o((Map)hashMap);
    }
    
    public void l(final a a) {
        if (a == null) {
            this.m("com.garena.msdk.token");
            return;
        }
        final HashMap hashMap = new HashMap();
        ((Map)hashMap).put((Object)"com.garena.msdk.token", (Object)a.x(a));
        this.o((Map)hashMap);
    }
    
    public abstract void m(final String p0);
    
    public void n() {
        this.m(this.e());
    }
    
    public abstract void o(final Map p0);
}
