package com.beetalk.sdk.cache;

import com.beetalk.sdk.X;
import android.content.Context;

public class i
{
    private final a a;
    
    public i() {
        this.a = new a(null);
    }
    
    private int c() {
        return (int)(System.currentTimeMillis() / 1000L) % 86400 / 3600;
    }
    
    private long e() {
        final long n = System.currentTimeMillis() / 1000L;
        return (n - n % 86400L - 86400L) * 1000L + 68400000L;
    }
    
    private long f() {
        final long n = System.currentTimeMillis() / 1000L;
        return (n - n % 86400L) * 1000L + 68400000L;
    }
    
    private boolean h(final long n) {
        long n2;
        if (this.c() >= 19) {
            n2 = this.f();
        }
        else {
            n2 = this.e();
        }
        return n <= n2 || n >= System.currentTimeMillis();
    }
    
    public void a() {
        this.a.g("KEY_MSDK_TOKEN_SESSION", "");
    }
    
    public void b() {
        this.a.f("KEY_LAST_REDEEM_TIME", -1L);
    }
    
    public String d() {
        return this.a.d("KEY_MSDK_TOKEN_SESSION", "");
    }
    
    public boolean g() {
        final long c = this.a.c("KEY_LAST_REDEEM_TIME", 0L);
        return this.h(c) || c == 0L || System.currentTimeMillis() - c > 28800000L;
    }
    
    public void i(final String s) {
        this.a.g("KEY_MSDK_TOKEN_SESSION", s);
    }
    
    public void j() {
        this.a.f("KEY_LAST_REDEEM_TIME", System.currentTimeMillis());
    }
    
    private static class a extends b
    {
        @Override
        protected Context b() {
            return X.M();
        }
    }
}
