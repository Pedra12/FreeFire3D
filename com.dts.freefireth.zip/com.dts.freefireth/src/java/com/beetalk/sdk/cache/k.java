package com.beetalk.sdk.cache;

import android.content.SharedPreferences$Editor;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import com.beetalk.sdk.X;
import android.text.TextUtils;
import android.content.Context;
import android.content.SharedPreferences;
import java.io.Serializable;

public class k extends l implements Serializable
{
    private final SharedPreferences a;
    private String b;
    
    public k(final Context context) {
        this(context, null);
    }
    
    public k(Context context, final String b) {
        this.b = b;
        if (TextUtils.isEmpty((CharSequence)b)) {
            this.b = "com.garena.msdk.token_cache";
        }
        final Context applicationContext = context.getApplicationContext();
        if (applicationContext != null) {
            context = applicationContext;
        }
        this.a = context.getSharedPreferences(this.b, 0);
    }
    
    public static k q() {
        return new k(X.M());
    }
    
    public static k r() {
        return new k(X.M(), "com.garena.msdk.bind_token");
    }
    
    public static k s() {
        return new k(X.M(), "com.garena.msdk.app_platform_bind_token");
    }
    
    public static k t() {
        return new k(X.M(), "com.garena.msdk.account_security_verifier_token");
    }
    
    private String u(final Object o) {
        if (o instanceof String) {
            return (String)o;
        }
        return "";
    }
    
    @Override
    public Map i() {
        final HashMap hashMap = new HashMap();
        for (final String s : this.a.getAll().keySet()) {
            hashMap.put((Object)s, (Object)this.a.getString(s, ""));
        }
        return (Map)hashMap;
    }
    
    @Override
    public void m(final String s) {
        final SharedPreferences$Editor edit = this.a.edit();
        edit.remove(s);
        edit.apply();
    }
    
    @Override
    public void o(final Map map) {
        final SharedPreferences$Editor edit = this.a.edit();
        for (final String s : map.keySet()) {
            edit.putString(s, this.u(map.get((Object)s)));
        }
        edit.apply();
    }
    
    public void p() {
        final SharedPreferences$Editor edit = this.a.edit();
        edit.clear();
        edit.apply();
    }
}
