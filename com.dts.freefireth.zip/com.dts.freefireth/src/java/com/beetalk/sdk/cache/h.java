package com.beetalk.sdk.cache;

import android.content.Context;
import android.content.SharedPreferences$Editor;
import android.content.SharedPreferences;

public class h
{
    private static volatile h c;
    private final SharedPreferences a;
    private final SharedPreferences$Editor b;
    
    private h(final Context context) {
        final SharedPreferences sharedPreferences = context.getSharedPreferences("com.garena.msdk.common_cache", 0);
        this.a = sharedPreferences;
        this.b = sharedPreferences.edit();
    }
    
    public static h a(final Context context) {
        if (h.c == null) {
            final Class<h> clazz;
            monitorenter(clazz = h.class);
            Label_0040: {
                try {
                    if (h.c == null) {
                        h.c = new h(context.getApplicationContext());
                    }
                    break Label_0040;
                }
                finally {
                    monitorexit(clazz);
                    monitorexit(clazz);
                }
            }
        }
        return h.c;
    }
    
    public String b(final String s, final String s2) {
        return this.a.getString(s, s2);
    }
    
    public void c(final String s, final String s2) {
        this.b.putString(s, s2);
        this.b.apply();
    }
}
