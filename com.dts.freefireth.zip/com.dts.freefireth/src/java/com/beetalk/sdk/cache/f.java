package com.beetalk.sdk.cache;

import android.content.SharedPreferences$Editor;
import com.beetalk.sdk.A0$e;
import com.beetalk.sdk.A0;
import android.content.Context;
import android.content.SharedPreferences;

public class f
{
    private static volatile f b;
    private final SharedPreferences a;
    
    private f(final Context context) {
        this.a = context.getSharedPreferences("com.garena.android.msdk.PendingPayCachePreference", 0);
    }
    
    public static f a(final Context context) {
        if (f.b == null) {
            final Class<f> clazz;
            monitorenter(clazz = f.class);
            Label_0037: {
                try {
                    if (f.b == null) {
                        f.b = new f(context);
                    }
                    break Label_0037;
                }
                finally {
                    monitorexit(clazz);
                    monitorexit(clazz);
                }
            }
        }
        return f.b;
    }
    
    private long c(final Context context, final String s) {
        return a(context).a.getLong(s, 0L);
    }
    
    public long b(final Context context) {
        if (A0.s() == A0$e.b) {
            return 50000L;
        }
        return a(context).a.getLong("KEY_PENDING_COMMIT_REQUEST_INTERVAL", 86400000L);
    }
    
    public boolean d(final Context context, final String s) {
        return System.currentTimeMillis() - this.c(context, s) > this.b(context);
    }
    
    public void e(final Context context, final String s) {
        final SharedPreferences$Editor edit = a(context).a.edit();
        edit.putLong(s, System.currentTimeMillis());
        edit.apply();
    }
}
