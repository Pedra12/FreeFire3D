package com.beetalk.sdk.cache;

import V.b;
import android.text.TextUtils;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import androidx.core.widget.j;
import android.os.Build$VERSION;
import com.beetalk.sdk.helper.t;
import com.beetalk.sdk.X;
import android.os.Environment;
import java.util.Map$Entry;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;
import android.content.Context;

public class g extends l
{
    private static volatile g b;
    private final k a;
    
    private g(final Context context) {
        this.a = new k(context.getApplicationContext(), "com.garena.msdk.persist.fallback");
    }
    
    private Map A(String s) {
        final HashMap hashMap = new HashMap();
        try {
            final JSONObject jsonObject = new JSONObject(s).getJSONObject("guest_account_info");
            final Iterator keys = jsonObject.keys();
            while (keys.hasNext()) {
                s = (String)keys.next();
                ((Map)hashMap).put((Object)s, (Object)jsonObject.getString(s));
            }
        }
        catch (final JSONException ex) {
            com.beetalk.sdk.helper.k.b((Exception)ex);
        }
        return (Map)hashMap;
    }
    
    private void B(final Map map, final Map map2) {
        final String g = this.g();
        final String s = (String)map2.get((Object)g);
        final String s2 = (String)map.get((Object)g);
        final long n = 0L;
        long long1 = 0L;
        Label_0053: {
            if (s != null) {
                try {
                    long1 = Long.parseLong(s);
                    break Label_0053;
                }
                finally {}
            }
            long1 = 0L;
        }
        long long2 = n;
        while (true) {
            if (s2 == null) {
                break Label_0069;
            }
            try {
                long2 = Long.parseLong(s2);
                final HashMap hashMap = new HashMap();
                final HashMap hashMap2 = new HashMap();
                final HashMap hashMap3 = new HashMap();
                for (final Map$Entry map$Entry : map2.entrySet()) {
                    if (map$Entry != null && map$Entry.getKey() != null) {
                        if (map$Entry.getValue() == null) {
                            continue;
                        }
                        if (map.containsKey(map$Entry.getKey())) {
                            continue;
                        }
                        ((Map)hashMap3).put((Object)map$Entry.getKey(), (Object)map$Entry.getValue());
                    }
                }
                for (final Map$Entry map$Entry2 : map.entrySet()) {
                    if (map$Entry2 != null && map$Entry2.getKey() != null) {
                        if (map$Entry2.getValue() == null) {
                            continue;
                        }
                        if (!map2.containsKey(map$Entry2.getKey())) {
                            ((Map)hashMap2).put((Object)map$Entry2.getKey(), (Object)map$Entry2.getValue());
                        }
                        else {
                            if (((String)map$Entry2.getValue()).equals(map2.get(map$Entry2.getKey()))) {
                                continue;
                            }
                            ((Map)hashMap).put((Object)map$Entry2.getKey(), (Object)map2.get(map$Entry2.getKey()));
                        }
                    }
                }
                map.putAll((Map)hashMap3);
                if (long1 > long2) {
                    if (!((Map)hashMap).isEmpty() || !((Map)hashMap3).isEmpty()) {
                        map.putAll((Map)hashMap);
                        this.a.o(map);
                    }
                    if (!((Map)hashMap2).isEmpty()) {
                        this.y(map);
                    }
                }
                else {
                    if (!((Map)hashMap).isEmpty() || !((Map)hashMap2).isEmpty()) {
                        this.y(map);
                    }
                    if (!((Map)hashMap3).isEmpty()) {
                        this.a.o(map);
                    }
                }
            }
            finally {
                long2 = n;
                continue;
            }
            break;
        }
    }
    
    private String q() {
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory().getAbsolutePath());
        sb.append("/com.garena.msdk");
        return sb.toString();
    }
    
    private String r() {
        final int f = t.f(X.M());
        if (f != -1 && f != 100006) {
            final StringBuilder sb = new StringBuilder();
            sb.append("guest");
            sb.append(t.f(X.M()));
            sb.append(".dat");
            return sb.toString();
        }
        return "guest.dat";
    }
    
    public static g s(final Context context) {
        if (g.b == null) {
            final Class<g> clazz;
            monitorenter(clazz = g.class);
            Label_0037: {
                try {
                    if (g.b == null) {
                        g.b = new g(context);
                    }
                    break Label_0037;
                }
                finally {
                    monitorexit(clazz);
                    monitorexit(clazz);
                }
            }
        }
        return g.b;
    }
    
    private boolean t() {
        return Build$VERSION.SDK_INT >= 23;
    }
    
    private boolean u() {
        return Build$VERSION.SDK_INT >= 30;
    }
    
    private boolean v() {
        if (this.u()) {
            return false;
        }
        if (this.t()) {
            final Context m = X.M();
            return m != null && j.a(m, "android.permission.WRITE_EXTERNAL_STORAGE") == 0;
        }
        return true;
    }
    
    private Map w() {
        final HashMap hashMap = new HashMap();
        final File file = new File(this.q());
        if (file.exists()) {
            final File file2 = new File(file, this.r());
            if (file2.exists()) {
                Object o = null;
                Object o2 = null;
                Label_0300: {
                    try {
                        BufferedReader bufferedReader2;
                        BufferedReader bufferedReader = bufferedReader2 = new BufferedReader((Reader)new FileReader(file2));
                        Label_0126: {
                            try {
                                try {
                                    bufferedReader2 = bufferedReader;
                                    final StringBuilder sb = new StringBuilder();
                                    while (true) {
                                        bufferedReader2 = bufferedReader;
                                        final String line = bufferedReader.readLine();
                                        if (line == null) {
                                            break Label_0126;
                                        }
                                        bufferedReader2 = bufferedReader;
                                        sb.append(line);
                                    }
                                }
                                finally {
                                    bufferedReader = bufferedReader2;
                                }
                            }
                            catch (final IOException o) {
                                try {
                                    ((Throwable)o).printStackTrace();
                                    o = new StringBuilder();
                                    ((StringBuilder)o).append("read failed from file: ");
                                    ((StringBuilder)o).append(file2.getAbsolutePath());
                                    com.beetalk.sdk.helper.k.c(((StringBuilder)o).toString(), new Object[0]);
                                    try {
                                        bufferedReader.close();
                                        return null;
                                    }
                                    catch (final IOException ex) {}
                                }
                                catch (final FileNotFoundException ex2) {}
                                ((Map)hashMap).putAll(this.A(((StringBuilder)o).toString()));
                                bufferedReader.close();
                                return (Map)hashMap;
                            }
                        }
                    }
                    catch (final FileNotFoundException o) {
                        o2 = null;
                    }
                    finally {
                        o2 = o;
                        break Label_0300;
                    }
                    ((Throwable)o).printStackTrace();
                    final StringBuilder sb2 = new StringBuilder();
                    sb2.append("fail to read from file: ");
                    sb2.append(file2.getAbsolutePath());
                    com.beetalk.sdk.helper.k.c(sb2.toString(), new Object[0]);
                    if (o2 != null) {
                        ((BufferedReader)o2).close();
                        return (Map)hashMap;
                    }
                    return (Map)hashMap;
                }
                if (o2 != null) {
                    try {
                        ((BufferedReader)o2).close();
                    }
                    catch (final IOException ex3) {
                        ((Throwable)ex3).printStackTrace();
                    }
                }
            }
        }
        return (Map)hashMap;
    }
    
    private String x(final Map map) {
        final JSONObject jsonObject = new JSONObject();
        final JSONObject jsonObject2 = new JSONObject(map);
        try {
            jsonObject.put("guest_account_info", (Object)jsonObject2);
        }
        catch (final JSONException ex) {
            com.beetalk.sdk.helper.k.b((Exception)ex);
        }
        return jsonObject.toString();
    }
    
    private void y(final Map map) {
        this.z(this.x(map));
    }
    
    private void z(final String s) {
        final File file = new File(this.q());
        if (!file.exists() && !file.mkdir()) {
            final StringBuilder sb = new StringBuilder();
            sb.append("can't create dir: ");
            sb.append(file.getAbsolutePath());
            com.beetalk.sdk.helper.k.c(sb.toString(), new Object[0]);
            return;
        }
        final File file2 = new File(file, this.r());
        Label_0127: {
            try {
                final FileOutputStream fileOutputStream = new FileOutputStream(file2);
                final PrintWriter printWriter = new PrintWriter((OutputStream)fileOutputStream);
                printWriter.write(s);
                printWriter.flush();
                printWriter.close();
                fileOutputStream.close();
                return;
            }
            catch (final IOException ex) {}
            catch (final FileNotFoundException ex2) {
                break Label_0127;
            }
            final IOException ex;
            ((Throwable)ex).printStackTrace();
            return;
        }
        final FileNotFoundException ex2;
        ((Throwable)ex2).printStackTrace();
        com.beetalk.sdk.helper.k.c("******* File not found. Did you add a WRITE_EXTERNAL_STORAGE permission to the   manifest?", new Object[0]);
    }
    
    @Override
    public Map i() {
        final Map i = this.a.i();
        if (this.v()) {
            this.B(i, this.w());
        }
        return i;
    }
    
    @Override
    public void m(final String s) {
        this.a.m(s);
        if (this.v()) {
            final Map w = this.w();
            if (w.remove((Object)s) != null) {
                this.y(w);
            }
        }
    }
    
    @Override
    public void o(final Map map) {
        this.a.o(map);
        if (this.v()) {
            final HashMap hashMap = (HashMap)this.i();
            for (final String s : map.keySet()) {
                hashMap.put((Object)s, (Object)map.get((Object)s));
            }
            this.y((Map)hashMap);
            return;
        }
        com.beetalk.sdk.helper.k.a("external storage not accessible, save in internal storage only", new Object[0]);
    }
    
    public String p() {
        if (!this.v()) {
            return super.b();
        }
        final Map i = this.a.i();
        final Map w = this.w();
        if (w == null) {
            return super.b();
        }
        final String g = this.g();
        final String d = this.d();
        final String s = (String)w.get((Object)g);
        final String s2 = (String)i.get((Object)g);
        final String s3 = (String)w.get((Object)d);
        final String s4 = (String)i.get((Object)d);
        if ((!TextUtils.isEmpty((CharSequence)s2) && !V.b.a((Object)s2, (Object)s)) || (!TextUtils.isEmpty((CharSequence)s4) && !V.b.a((Object)s4, (Object)s3))) {
            this.a.m(g);
            this.a.m(d);
            return s2;
        }
        return super.b();
    }
}
