package com.beetalk.sdk.cache;

import android.os.BaseBundle;
import V.b;
import android.os.Handler;
import android.accounts.AccountManagerCallback;
import java.util.Iterator;
import android.os.Bundle;
import java.util.Map$Entry;
import android.text.TextUtils;
import java.util.HashMap;
import java.util.Map;
import android.accounts.Account;
import com.beetalk.sdk.helper.t;
import com.beetalk.sdk.X;
import android.accounts.AccountManager;

public class a extends l
{
    private static volatile a c;
    private static final String d;
    private final AccountManager a;
    private final k b;
    
    static {
        final StringBuilder sb = new StringBuilder();
        sb.append("com.garena.msdk");
        sb.append(t.f(X.M()));
        sb.append(t.i(X.M()));
        d = sb.toString();
    }
    
    private a() {
        this.a = AccountManager.get(X.M());
        this.b = new k(X.M(), "com.garena.msdk.persist.fallback");
    }
    
    private Account r() {
        Label_0028: {
            try {
                final Account[] accountsByType = this.a.getAccountsByType(com.beetalk.sdk.cache.a.d);
                if (accountsByType.length > 0) {
                    return accountsByType[0];
                }
            }
            catch (final Exception ex) {
                break Label_0028;
            }
            return null;
        }
        final Exception ex;
        com.beetalk.sdk.helper.k.b(ex);
        return null;
    }
    
    public static a s() {
        if (a.c == null) {
            final Class<a> clazz;
            monitorenter(clazz = a.class);
            Label_0036: {
                try {
                    if (a.c == null) {
                        a.c = new a();
                    }
                    break Label_0036;
                }
                finally {
                    monitorexit(clazz);
                    monitorexit(clazz);
                }
            }
        }
        return a.c;
    }
    
    private Map t() {
        final HashMap hashMap = new HashMap();
        try {
            final Account r = this.r();
            if (r != null && com.beetalk.sdk.cache.a.d.equals((Object)r.type)) {
                final String g = this.g();
                final String d = this.d();
                final String userData = this.a.getUserData(r, g);
                final String userData2 = this.a.getUserData(r, d);
                if (!TextUtils.isEmpty((CharSequence)userData) && !TextUtils.isEmpty((CharSequence)userData2)) {
                    ((Map)hashMap).put((Object)g, (Object)userData);
                    ((Map)hashMap).put((Object)d, (Object)userData2);
                    return (Map)hashMap;
                }
            }
        }
        catch (final Exception ex) {
            com.beetalk.sdk.helper.k.b(ex);
        }
        return (Map)hashMap;
    }
    
    private Map u() {
        final HashMap hashMap = new HashMap();
        final Map i = this.b.i();
        if (i != null) {
            final String g = this.g();
            final String d = this.d();
            final String s = (String)i.get((Object)g);
            final String s2 = (String)i.get((Object)d);
            if (!TextUtils.isEmpty((CharSequence)s) && !TextUtils.isEmpty((CharSequence)s2)) {
                ((Map)hashMap).put((Object)g, (Object)s);
                ((Map)hashMap).put((Object)d, (Object)s2);
            }
        }
        return (Map)hashMap;
    }
    
    private void v(final Map map) {
        if (map != null) {
            Label_0260: {
                try {
                    final Account r = this.r();
                    if (r != null && com.beetalk.sdk.cache.a.d.equals((Object)r.type) && map.entrySet() != null) {
                        for (final Map$Entry map$Entry : map.entrySet()) {
                            this.a.setUserData(r, (String)map$Entry.getKey(), (String)map$Entry.getValue());
                        }
                        return;
                    }
                }
                catch (final Exception ex) {
                    break Label_0260;
                }
                if (map.containsKey((Object)this.g())) {
                    final String s = (String)map.get((Object)this.g());
                    final String d = this.d();
                    String s2;
                    if (map.containsKey((Object)d)) {
                        s2 = (String)map.get((Object)d);
                    }
                    else {
                        s2 = null;
                    }
                    final Account account = new Account(s, com.beetalk.sdk.cache.a.d);
                    final Bundle bundle = new Bundle();
                    for (final Map$Entry map$Entry2 : map.entrySet()) {
                        this.a.setUserData(account, (String)map$Entry2.getKey(), (String)map$Entry2.getValue());
                    }
                    this.a.addAccountExplicitly(account, s2, bundle);
                    return;
                }
                return;
            }
            final Exception ex;
            com.beetalk.sdk.helper.k.b(ex);
        }
    }
    
    private void w(final Map map, final Map map2) {
        final String g = this.g();
        final String s = (String)map2.get((Object)g);
        final String s2 = (String)map.get((Object)g);
        long long1;
        if (s != null) {
            long1 = Long.parseLong(s);
        }
        else {
            long1 = 0L;
        }
        if (s2 != null) {
            Long.parseLong(s2);
        }
        final HashMap hashMap = new HashMap();
        final HashMap hashMap2 = new HashMap();
        final HashMap hashMap3 = new HashMap();
        for (final Map$Entry map$Entry : map2.entrySet()) {
            if (map$Entry != null && map$Entry.getKey() != null) {
                if (map$Entry.getValue() == null) {
                    continue;
                }
                if (map.containsKey(map$Entry.getKey())) {
                    continue;
                }
                ((Map)hashMap3).put((Object)map$Entry.getKey(), (Object)map$Entry.getValue());
            }
        }
        for (final Map$Entry map$Entry2 : map.entrySet()) {
            if (map$Entry2 != null && map$Entry2.getKey() != null) {
                if (map$Entry2.getValue() == null) {
                    continue;
                }
                if (!map2.containsKey(map$Entry2.getKey())) {
                    ((Map)hashMap2).put((Object)map$Entry2.getKey(), (Object)map$Entry2.getValue());
                }
                else {
                    if (((String)map$Entry2.getValue()).equals(map2.get(map$Entry2.getKey()))) {
                        continue;
                    }
                    ((Map)hashMap).put((Object)map$Entry2.getKey(), (Object)map2.get(map$Entry2.getKey()));
                }
            }
        }
        map.putAll((Map)hashMap3);
        if (long1 > 0L) {
            if (!((Map)hashMap).isEmpty() || !((Map)hashMap3).isEmpty()) {
                map.putAll((Map)hashMap);
                this.b.o(map);
            }
            if (!((Map)hashMap2).isEmpty()) {
                this.v(map);
            }
        }
        else {
            if (!((Map)hashMap).isEmpty() || !((Map)hashMap2).isEmpty()) {
                this.v(map);
            }
            if (!((Map)hashMap3).isEmpty()) {
                this.b.o(map);
            }
        }
    }
    
    @Override
    public Map i() {
        final Map u = this.u();
        this.w(u, this.t());
        return u;
    }
    
    @Override
    public void j(final String s, final String s2) {
        Label_0117: {
            try {
                final Account r = this.r();
                if (r != null && com.beetalk.sdk.cache.a.d.equals((Object)r.type)) {
                    this.a.setUserData(r, this.g(), s);
                    this.a.setUserData(r, this.d(), s2);
                    return;
                }
            }
            catch (final Exception ex) {
                break Label_0117;
            }
            final String g = this.g();
            final String d = this.d();
            final Account account = new Account(s, com.beetalk.sdk.cache.a.d);
            final Bundle bundle = new Bundle();
            ((BaseBundle)bundle).putString(g, s);
            ((BaseBundle)bundle).putString(d, s2);
            this.a.addAccountExplicitly(account, s2, bundle);
            return;
        }
        final Exception ex;
        com.beetalk.sdk.helper.k.b(ex);
    }
    
    @Override
    public void m(final String s) {
        this.b.m(s);
    }
    
    @Override
    public void o(final Map map) {
        this.b.o(map);
        final HashMap hashMap = (HashMap)this.i();
        for (final String s : map.keySet()) {
            hashMap.put((Object)s, (Object)map.get((Object)s));
        }
        this.v((Map)hashMap);
    }
    
    public void p() {
        this.b.p();
        try {
            final Account r = this.r();
            if (r != null && com.beetalk.sdk.cache.a.d.equals((Object)r.type)) {
                this.a.removeAccount(r, (AccountManagerCallback)null, (Handler)null);
            }
        }
        catch (final Exception ex) {
            com.beetalk.sdk.helper.k.b(ex);
        }
    }
    
    public String q() {
        final Map i = this.b.i();
        final Map t = this.t();
        if (t == null) {
            return super.b();
        }
        final String g = this.g();
        final String d = this.d();
        final String s = (String)t.get((Object)g);
        final String s2 = (String)i.get((Object)g);
        final String s3 = (String)t.get((Object)d);
        final String s4 = (String)i.get((Object)d);
        if ((!TextUtils.isEmpty((CharSequence)s2) && !V.b.a((Object)s2, (Object)s)) || (!TextUtils.isEmpty((CharSequence)s4) && !V.b.a((Object)s4, (Object)s3))) {
            this.b.m(g);
            this.b.m(d);
            return s2;
        }
        this.p();
        return s;
    }
}
