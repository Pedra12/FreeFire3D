package com.beetalk.sdk;

import android.view.ViewGroup;
import java.io.UnsupportedEncodingException;
import kotlin.jvm.functions.Function1;
import com.beetalk.sdk.networking.w;
import java.util.List;
import com.beetalk.sdk.helper.I;
import com.beetalk.sdk.helper.A;
import com.beetalk.sdk.networking.c;
import java.util.ArrayList;
import android.net.Uri;
import android.webkit.DownloadListener;
import java.util.concurrent.Callable;
import c1.i;
import com.garena.pay.android.l;
import android.webkit.WebViewClient;
import android.widget.LinearLayout$LayoutParams;
import android.view.View;
import h2.a;
import android.view.ViewGroup$LayoutParams;
import android.widget.FrameLayout$LayoutParams;
import android.widget.LinearLayout;
import Q2.f;
import android.text.TextUtils;
import android.webkit.CookieManager;
import android.content.Context;
import android.os.Bundle;
import com.beetalk.sdk.networking.service.j;
import java.io.Serializable;
import android.content.Intent;
import com.beetalk.sdk.helper.k;
import android.webkit.WebView;
import android.app.Activity;

public class GarenaAuthActivity extends Activity
{
    private WebView a;
    private d$c b;
    private String c;
    
    private void g() {
        this.setResult(0);
        this.finish();
    }
    
    private void h(final int n) {
        k.i("onAuthFailed-failed", new Object[0]);
        ((View)this.a).post((Runnable)new Runnable(this, d$e.a(n)) {
            final d$e a;
            final GarenaAuthActivity b;
            
            public void run() {
                this.b.j(this.a);
            }
        });
    }
    
    private void i(final String s) {
        k.i("onAuthSuccess-user code %s", new Object[] { s });
        ((View)this.a).post((Runnable)new Runnable(this, this.k(s, this.b)) {
            final d$e a;
            final GarenaAuthActivity b;
            
            public void run() {
                this.b.j(this.a);
            }
        });
    }
    
    private void j(final d$e d$e) {
        if (d$e != null && d$e.b != null) {
            final s z = s.Z(this.b.f(), s.w());
            if (z != null) {
                z.t().l(d$e.b);
            }
        }
        final Intent intent = new Intent();
        intent.putExtra("garena_auth_result", (Serializable)d$e);
        int n;
        if (d$e.h(d$e.a)) {
            n = 0;
        }
        else {
            n = -1;
        }
        this.setResult(n, intent);
        this.finish();
    }
    
    private d$e k(final String s, final d$c d$c) {
        return j.l(s, this.c, d$c.a(), d$c.b(), d$c.e());
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        final WebView a = new WebView((Context)this);
        this.a = a;
        a.getSettings().setUseWideViewPort(true);
        this.a.getSettings().setLoadWithOverviewMode(true);
        this.a.getSettings().setJavaScriptEnabled(true);
        this.a.getSettings().setBuiltInZoomControls(true);
        this.a.getSettings().setDomStorageEnabled(true);
        this.a.clearCache(true);
        CookieManager.getInstance().removeAllCookie();
        if (TextUtils.isEmpty((CharSequence)X.Q())) {
            this.setTitle(f.b);
        }
        else {
            this.setTitle((CharSequence)X.Q());
        }
        final LinearLayout contentView = new LinearLayout((Context)this);
        ((View)contentView).setLayoutParams((ViewGroup$LayoutParams)new FrameLayout$LayoutParams(-1, -1));
        ((View)contentView).setBackgroundColor(((Context)this).getResources().getColor(h2.a.a));
        this.setContentView((View)contentView);
        ((ViewGroup)contentView).addView((View)this.a, (ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, -1));
        this.a.setWebViewClient((WebViewClient)new WebViewClient(this) {
            final GarenaAuthActivity a;
            
            public void onReceivedError(final WebView webView, final int n, final String s, final String s2) {
                super.onReceivedError(webView, n, s, s2);
                this.a.j(d$e.a((int)l.v.b()));
            }
            
            public boolean shouldOverrideUrlLoading(final WebView webView, final String s) {
                if (!s.contains((CharSequence)A0.x()) && !s.contains((CharSequence)this.a.c)) {
                    return super.shouldOverrideUrlLoading(webView, s);
                }
                final int index = s.indexOf("code=");
                if (index != -1) {
                    final String substring = s.substring(index + 5);
                    k.i("web code 1%s %s", new Object[] { s, substring });
                    i.f((Callable)new c0(this, substring));
                }
                else {
                    final int index2 = s.indexOf("error=");
                    if (index2 == -1) {
                        i.f((Callable)new d0(this));
                    }
                    else if (s.substring(index2 + 6).equals((Object)"access_denied")) {
                        this.a.g();
                    }
                }
                return true;
            }
        });
        this.a.setDownloadListener((DownloadListener)new DownloadListener(this) {
            final GarenaAuthActivity a;
            
            public void onDownloadStart(final String s, final String s2, final String s3, final String s4, final long n) {
                final Intent intent = new Intent("android.intent.action.VIEW");
                intent.setFlags(268435456);
                intent.setData(Uri.parse(s));
                ((Context)this.a).startActivity(intent);
            }
        });
        try {
            final d$c b = (d$c)this.getIntent().getSerializableExtra("garena_request_info");
            this.b = b;
            final String a2 = b.a();
            final StringBuilder sb = new StringBuilder();
            sb.append("gop");
            sb.append(this.b.a());
            sb.append("://auth/");
            this.c = sb.toString();
            final ArrayList list = new ArrayList();
            ((List)list).add((Object)new c("redirect_uri", this.c));
            ((List)list).add((Object)new c("response_type", "code"));
            ((List)list).add((Object)new c("client_id", a2));
            if (s.Y(this.b)) {
                ((List)list).add((Object)new c("create_grant", "false"));
                ((List)list).add((Object)new c("grant", "true"));
            }
            ((List)list).add((Object)new c("login_scenario", this.b.e()));
            ((List)list).add((Object)new c("locale", A.f(A.e(((Context)this).getApplicationContext()))));
            try {
                final WebView a3 = this.a;
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(A0.y());
                sb2.append(I.b((List)list));
                w.c(a3, sb2.toString(), (Function1)new b0(this));
            }
            catch (final UnsupportedEncodingException ex) {
                k.b((Exception)ex);
                this.finish();
            }
        }
        catch (final NullPointerException ex2) {
            k.b((Exception)ex2);
            this.finish();
        }
    }
}
