package com.beetalk.sdk.widget;

import kotlin.Metadata;

@Metadata
public interface e
{
    String getName();
}
