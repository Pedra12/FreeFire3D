package com.beetalk.sdk.widget;

import kotlin.text.StringsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import G7.n;

@Metadata
final class c extends n implements Function1<String, CharSequence>
{
    public static final c b;
    
    static {
        b = new c();
    }
    
    c() {
        super(1);
    }
    
    public final CharSequence a(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "it");
        final String f = StringsKt.F(s, "'", "\\'", false, 4, (Object)null);
        final StringBuilder sb = new StringBuilder();
        sb.append("window.location.host.endsWith('");
        sb.append(f);
        sb.append("')");
        return (CharSequence)sb.toString();
    }
}
