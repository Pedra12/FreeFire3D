package com.beetalk.sdk.widget;

import java.util.concurrent.Callable;
import g2.o;
import com.google.gson.Gson;
import com.beetalk.sdk.networking.h;
import kotlin.text.StringsKt;
import kotlin.Unit;
import android.webkit.ValueCallback;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import android.webkit.WebView;
import kotlin.Metadata;

@Metadata
public final class d
{
    private final WebView a;
    private final String b;
    private final String c;
    private String d;
    
    public d(@NotNull final WebView a, @NotNull final String b, @NotNull final String c) {
        Intrinsics.checkNotNullParameter((Object)a, "webViewCore");
        Intrinsics.checkNotNullParameter((Object)b, "callbackFunctionName");
        Intrinsics.checkNotNullParameter((Object)c, "messageId");
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = "true";
    }
    
    private static final Unit d(final d d, final String s, final ValueCallback valueCallback) {
        Intrinsics.checkNotNullParameter((Object)d, "this$0");
        Intrinsics.checkNotNullParameter((Object)s, "$script");
        d.a.evaluateJavascript(s, valueCallback);
        return Unit.a;
    }
    
    private final String e(final Object o) {
        if (o instanceof String) {
            final String f = StringsKt.F((String)o, "'", "\\'", false, 4, (Object)null);
            final StringBuilder sb = new StringBuilder();
            sb.append("'");
            sb.append(f);
            sb.append("'");
            return sb.toString();
        }
        if (o instanceof Number || o instanceof Boolean) {
            return o.toString();
        }
        final Gson f2 = h.f;
        final String json = f2.toJson((Object)f2.toJson(o));
        Intrinsics.c((Object)json);
        return json;
    }
    
    public final void b(final Object o, final ValueCallback valueCallback) {
        Intrinsics.checkNotNullParameter(o, "result");
        if (((CharSequence)this.b).length() == 0) {
            return;
        }
        final String e = this.e(o);
        final String f = StringsKt.F(this.c, "'", "\\'", false, 4, (Object)null);
        final StringBuilder sb = new StringBuilder();
        sb.append("'");
        sb.append(f);
        sb.append("'");
        final String string = sb.toString();
        final String d = this.d;
        final String b = this.b;
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("\n            if (");
        sb2.append(d);
        sb2.append(") {\n                ");
        sb2.append(b);
        sb2.append("(");
        sb2.append(string);
        sb2.append(", ");
        sb2.append(e);
        sb2.append(");\n            }\n        ");
        o.j.g((Callable)new b(this, StringsKt.j(sb2.toString()), valueCallback), o.m);
    }
}
