package com.beetalk.sdk.widget;

import android.view.View;
import com.beetalk.sdk.helper.p;
import O0.b;
import com.beetalk.sdk.helper.l$a;
import android.util.AttributeSet;
import android.webkit.WebSettings;
import com.beetalk.sdk.helper.t;
import android.webkit.WebViewClient;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import android.content.Context;
import kotlin.jvm.internal.DefaultConstructorMarker;
import android.annotation.SuppressLint;
import kotlin.Metadata;
import android.webkit.WebView;

@Metadata
@SuppressLint({ "SetJavaScriptEnabled" })
public final class a extends WebView
{
    public static final b b;
    private a.a$c a;
    
    static {
        b = new b(null);
    }
    
    public a(@NotNull final Context context) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        super(context);
        final WebSettings settings = this.getSettings();
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        this.setWebViewClient((WebViewClient)new WebViewClient(this) {
            final a a;
            
            public boolean shouldOverrideUrlLoading(final WebView webView, final String s) {
                Intrinsics.checkNotNullParameter((Object)webView, "view");
                Intrinsics.checkNotNullParameter((Object)s, "url");
                return t.B(((View)this.a).getContext(), s) == -1;
            }
        });
    }
    
    public a(@NotNull final Context context, final AttributeSet set) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        super(context, set);
        final WebSettings settings = this.getSettings();
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        this.setWebViewClient((WebViewClient)new WebViewClient(this) {
            final a a;
            
            public boolean shouldOverrideUrlLoading(final WebView webView, final String s) {
                Intrinsics.checkNotNullParameter((Object)webView, "view");
                Intrinsics.checkNotNullParameter((Object)s, "url");
                return t.B(((View)this.a).getContext(), s) == -1;
            }
        });
    }
    
    public a(@NotNull final Context context, final AttributeSet set, final int n) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        super(context, set, n);
        final WebSettings settings = this.getSettings();
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        this.setWebViewClient((WebViewClient)new WebViewClient(this) {
            final a a;
            
            public boolean shouldOverrideUrlLoading(final WebView webView, final String s) {
                Intrinsics.checkNotNullParameter((Object)webView, "view");
                Intrinsics.checkNotNullParameter((Object)s, "url");
                return t.B(((View)this.a).getContext(), s) == -1;
            }
        });
    }
    
    public a(@NotNull final Context context, final AttributeSet set, final int n, final int n2) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        super(context, set, n, n2);
        final WebSettings settings = this.getSettings();
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        this.setWebViewClient((WebViewClient)new WebViewClient(this) {
            final a a;
            
            public boolean shouldOverrideUrlLoading(final WebView webView, final String s) {
                Intrinsics.checkNotNullParameter((Object)webView, "view");
                Intrinsics.checkNotNullParameter((Object)s, "url");
                return t.B(((View)this.a).getContext(), s) == -1;
            }
        });
    }
    
    public a(@NotNull final Context context, final AttributeSet set, final int n, final boolean b) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        super(context, set, n, b);
        final WebSettings settings = this.getSettings();
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        this.setWebViewClient((WebViewClient)new WebViewClient(this) {
            final a a;
            
            public boolean shouldOverrideUrlLoading(final WebView webView, final String s) {
                Intrinsics.checkNotNullParameter((Object)webView, "view");
                Intrinsics.checkNotNullParameter((Object)s, "url");
                return t.B(((View)this.a).getContext(), s) == -1;
            }
        });
    }
    
    public final void a() {
        final a.a$c a = this.a;
        if (a != null) {
            a.a();
        }
    }
    
    public final a b(final a.a$c a) {
        Intrinsics.checkNotNullParameter((Object)a, "listener");
        this.a = a;
        return this;
    }
    
    @Metadata
    public static final class b
    {
        private b() {
        }
        
        public final boolean a() {
            final boolean b = false;
            try {
                if (l$a.a.b() && O0.b.a() == null) {
                    return false;
                }
                return p.a.i();
            }
            finally {
                return b;
            }
        }
    }
}
