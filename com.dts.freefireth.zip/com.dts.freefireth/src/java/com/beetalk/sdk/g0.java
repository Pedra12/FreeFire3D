package com.beetalk.sdk;

import android.os.BaseBundle;
import android.content.pm.ResolveInfo;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.widget.Toast;
import com.beetalk.sdk.helper.N;
import java.util.concurrent.Callable;
import com.garena.pay.android.l;
import android.content.pm.Signature;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager$NameNotFoundException;
import android.os.Build;
import java.io.Serializable;
import android.content.Context;
import android.content.Intent;
import com.beetalk.sdk.networking.service.j;
import com.beetalk.sdk.helper.k;
import c1.i;

public class g0 extends g
{
    protected g0(final d d) {
        super(d);
    }
    
    private void f(final d.e e) {
        if (e != null) {
            k.a(e.toString(), new Object[0]);
            if (e.b != null) {
                final s z = s.Z(super.a.j().f(), s.w());
                if (z != null) {
                    z.t().l(e.b);
                }
            }
            super.a.l(e);
            return;
        }
        super.a.q();
    }
    
    private d.e g(final String s) {
        final d.c j = super.a.j();
        final StringBuilder sb = new StringBuilder();
        sb.append("gop");
        sb.append(j.a());
        sb.append("://auth/");
        return com.beetalk.sdk.networking.service.j.l(s, sb.toString(), j.a(), j.b(), j.e());
    }
    
    private void h(final d.c c) {
        final Intent intent = new Intent();
        intent.setClass((Context)super.a.f().getContext(), (Class)GarenaAuthActivity.class);
        intent.putExtra("garena_request_info", (Serializable)c);
        super.a.f().startActivityForResult(intent, c.f());
    }
    
    protected static boolean i(final Context context, String charsString) {
        final String brand = Build.BRAND;
        final int flags = context.getApplicationInfo().flags;
        if (brand.startsWith("generic") && (flags & 0x2) != 0x0) {
            return true;
        }
        try {
            final PackageManager packageManager = context.getPackageManager();
            if (packageManager == null) {
                return false;
            }
            final Signature[] signatures = packageManager.getPackageInfo(charsString, 64).signatures;
            for (int length = signatures.length, i = 0; i < length; ++i) {
                charsString = signatures[i].toCharsString();
                if ("3082030b308201f3a00302010202047a0636e6300d06092a864886f70d01010b05003036311e301c060355040b1315476172656e61204f6e6c696e6520507464204c7464311430120603550403130b476172656e6120506c7573301e170d3134303831393130323431345a170d3135303831393130323431345a3036311e301c060355040b1315476172656e61204f6e6c696e6520507464204c7464311430120603550403130b476172656e6120506c757330820122300d06092a864886f70d01010105000382010f003082010a028201010084f9e11b108453d15322f95c388cb9f10deded1953a1b2343835345e2bdd2509f390014167000b4e73f1cf302b4d4d173f37eefa986fe7c235741adac823ec50d98f980d5f80c8f2d9e54e0d9113afbd6530b1272299f8b32966405af143041050bc8ce9010ca59ddab081bdc080f95818f7511a2e0f9d754bcfd9b4b9cd54cb08c41a9e42e27ee73689c35262267765379651e0837bec77fdeb8f69fc4ff71ac140d41f620fe0943e5cb1466fd764d3d6822ef8663ed9521b279ba55ed897c9b067dcd15799fd1e1e6783aeeafe3de47e6e004cebcc41cc7472e2d78d52095bea62f5db81e0653db2c08227248d0abfe2c243d49521b645549e1d9b40d2830d0203010001a321301f301d0603551d0e0416041431118e3818aaad6f0025d4724af957f6d9a82e11300d06092a864886f70d01010b050003820101007689d7b46da6e227ffc6fc29f2d8f78d1b79b8fc265745efb461c985eb160a248ddb54601b203b70817838743061f4d20dc0ec68fdd2e7d2e2f268a4626f643cd91126e6c5956bddaefdf6186c9e89a3d300ea9d55065161969acd92e061c2993d8cac35e6517c49942944d54083ddd4f4503018f88d1f5028725a10f1f188a020ee62d72a523c29dae1f93eb657bfe04855d29f83c8964942958b4fea9a5c82a9a4fe5820df5a606e5b950ee809178d167f3e651c474bc5507efa6d935f02dc37dee116f5ed2657b1b53d3087c0f291e333c6726557e9977d64626b7e49f1de3b8fcf8df1d81c09768658300d5b8f06a81ed56a819fe7a34beafcac50f39f5a".equals((Object)charsString)) {
                    return true;
                }
                if (("308203b53082029da00302010202041c5ce5b9300d06092a864886f70d01010b050030818a310b3009060355040613023635311230100603550408130953696e6761706f7265311230100603550407130953696e6761706f7265311e301c060355040a1315476172656e61204f6e6c696e6520507465204c7464311d301b060355040b1314536f66747761726520456e67696e656572696e67311430120603550403130b476172656e6120506c7573301e170d3134303831393130333330345a170d3339303831333130333330345a30818a310b3009060355040613023635311230100603550408130953696e6761706f7265311230100603550407130953696e6761706f7265311e301c060355040a1315476172656e61204f6e6c696e6520507465204c7464311d301b060355040b1314536f66747761726520456e67696e656572696e67311430120603550403130b476172656e6120506c757330820122300d06092a864886f70d01010105000382010f003082010a02820101008f7cec7d1529db09e6d8bb56b00ca4d2a9ca0ba1d3d17fe249ebcc39472cf1a5733cd9972f48bfc6e56c47d123d5d451ae15bff099d96ca22d9a3d9775e0d59b74a1b23cc7cc745fd29d5060a74d3a48246a82ddaac587a6cfffe0f264e16241b7a91bebd8db4589776e61b9916e20e0c749e205715930e9c54b5a5b5d7d14f3b27693eba1a3264eb0c0818ae11809b85bbe9e6099e641fb24940b534336fcc519e284e4d944a385732ae1a792025eadd49486a10a01b6d09c52bac1798d0d74c9e1ea07ae3b7ac20e0aee6ba9e23c402ae0cc047a8e11b96a47d4ebd4674d1e3c565bb5ca3ef8af9037df8f9d2e3b34b389cfe1fd4854b331f2735b6a8c01250203010001a321301f301d0603551d0e0416041466f6c0a324150c5c5b770186ba3e0d8efbec0e5f300d06092a864886f70d01010b0500038201010083e3ae177a46cf6a51b8f747f546d91a287db288c57553d36cbef7b7271e024cfba3f5b65b9b2fff74c25304da082bee95740ce61acf9bbbcc3004f976ca801244a1a62bcac998107b80f37c3b5b8361305817fa7ef2ba1c52d443228696bbd5d1220da5d5729dd034a01c2e702226d292e1eb00d3e554217934cb392623c06a15c9f0579f8e234f4ddf66077ee787953dc4a206dcef4799d9017b20df91b3098fa6ed640c51f2c215663f27a8dce98b6cf12d014522ad9be495a645cfffc66dac9bf984342161a4a60e06601622020ed9e49a3d886a408b89ae69e85bb903f0a38eb169ed7177a0848401862e96e6a8b6561d567311af414dc203686ea41ecf".equals((Object)charsString) || "308205873082036fa00302010202150085da7daa7fb5c103987bba339a00f89579bb359d300d06092a864886f70d01010b05003074310b3009060355040613025553311330110603550408130a43616c69666f726e6961311630140603550407130d4d6f756e7461696e205669657731143012060355040a130b476f6f676c6520496e632e3110300e060355040b1307416e64726f69643110300e06035504031307416e64726f6964301e170d3137303830333033333431325a170d3437303830333033333431325a3074310b3009060355040613025553311330110603550408130a43616c69666f726e6961311630140603550407130d4d6f756e7461696e205669657731143012060355040a130b476f6f676c6520496e632e3110300e060355040b1307416e64726f69643110300e06035504031307416e64726f696430820222300d06092a864886f70d01010105000382020f003082020a02820201009a34e999f1a0f4f2148b218cc057b60c9553ea1ca8ebdc2fcba8d781247e74d57455c9ffc32b14b2bc5b0345c003fd67f0aed8c86a497de486a537abbbd80551b3a8604dc3b07cc160a846ea2b4d2a996829d68405418e5756325623d6cde17b1a25a10c8a24acdbb07bd483eaa84718b71cb74894de35464571dcf84da4fe5709245a27763eebbc6580e85f749c46c509b5bd12ebaf9c9595b319778df08c7ff9a4c30b653d736b7b50134a5ee437d1dd3d93fe7c2ecd48318cf865d3c6b9440cea8e55c0ed26427540353c372e5df55a05fc66a4e8451b28f681f3ae90608a779a40336934daee6e0ab19dcdaea947592fb6fc2104fc9ae5a9bb3d1a65a50d5e6e77e4f9ffce6a881bc99dfe4bac6eef228f362b7b5ede79e9d487c31885a08380c1777abb8dd40cb08b2ed96671d12912337ae5ef808af421e402bcba3b8e1a1deb550f2e2c5b9de0b99eb7206385bc2ee1f5b9aa112cc6a92ae6e906d585b7b21a63db32b8417de6ce347dc582b5edfd7d216435b50bc4dafab09d45d0c8d55b4520891e7493880f860301f61b2b1aa40c943ea51784c18ed29256b5f83b4ed727a30e15d0788866de51272740079f437c52b9a52b24e95ce7257133ae2b7d886e89624387fc4f5990585e539ac708e088e2631dafa2432a73c4eb0f0cb5866138e674f1a422d7a6515fcd1d42fcd99dee81dbe092862077f882e32644410203010001a310300e300c0603551d13040530030101ff300d06092a864886f70d01010b050003820201008067799ce549eb1e16e6c0dc53df5c0b9d32db4649701aa57a7f655786bd53e39d6efb711be372a84f1e3a6724d016369ab45dfe73440fc8f758206b362e697a6da6d05b9cd243982dda6fe83c8fdae5f0e6e734867de6698dc172072b0ad8feaab32e33a543c7385ea79e47612242f3ad7d585738a0dee68bbec067f4904552e36c3e47e28fd87eeceb59b9bdc4e3582780c38ea6d3ea5d998076ddb84c054385a41fd18c4fb6242f990f5efd5c21f03aa77444207162276bd77a95510546c2ed653b2d5715f2c467f3808d8525a0ebe02fd9492803b1426bf423696262a493c54d87a069acf8a5917976d9b30dcbd0e60ad797a678a4faec00c34aa58d915efe861e197b832d171c1826e042761df310bf9919126e81e009319a985425539f73beced7a969569b54d0a768fc43cb58c9623e81fb5ba00cd1dc80807d84fa41e824e82ad9b5000b4ca0423b2380b274a7792559edb86d4934ee56a098f224e239a1d1bdcce4149bc0d7eadf977cd0467b777e723bfd14e241bc4adb21a508c2ed492f93959ae5b5695562ea99a4c58b8342f74ff702b4f3ddfecee1f330d44883de94da81d61f819a1541d9020d15510e05b7b9d8affa8266994b4843947ddb961c36336ab75d94cfecb9068f88c911144fd396a56a9d4a2977b6e7e458184b3049acdf975f0ae5ee18b4e7cc7159569bbbd3bc32af36f3fc5f1cb0c9d62c7b".equals((Object)charsString)) && A0.a) {
                    return true;
                }
            }
            return false;
        }
        catch (final PackageManager$NameNotFoundException ex) {
            return false;
        }
    }
    
    public static boolean j(final Context context, final String s, final int n) {
        try {
            final PackageManager packageManager = context.getPackageManager();
            return packageManager != null && (packageManager.getPackageInfo(s, 0).versionCode >= n || A0.a);
        }
        catch (final PackageManager$NameNotFoundException ex) {
            return false;
        }
    }
    
    boolean b(final int n, final int n2, final Intent intent, d.c o) {
        if (n != ((d.c)o).f()) {
            return false;
        }
        if (!super.a.j().c().equals((Object)((d.c)o).c())) {
            this.f(d.e.a(l.Y.b()));
            return true;
        }
        String stringExtra;
        if (intent != null && intent.hasExtra("error")) {
            stringExtra = intent.getStringExtra("error");
        }
        else {
            stringExtra = "";
        }
        Label_0342: {
            Label_0328: {
                if (n2 != 0) {
                    if (n2 == 189) {
                        this.h((d.c)o);
                        return true;
                    }
                    switch (n2) {
                        default: {
                            switch (n2) {
                                default: {
                                    o = d.e.a(l.b2.b());
                                    break Label_0342;
                                }
                                case 187: {
                                    o = d.e.a(l.e.b());
                                    break Label_0342;
                                }
                                case 185: {
                                    o = d.e.a(l.y.b());
                                    break Label_0342;
                                }
                                case 183:
                                case 186: {
                                    o = d.e.a(l.j.b());
                                    break Label_0342;
                                }
                                case 182: {
                                    o = d.e.a(l.v.b());
                                    break Label_0342;
                                }
                                case 184: {
                                    break Label_0328;
                                }
                            }
                            break;
                        }
                        case 180: {
                            o = d.e.a(l.b2.b());
                            break Label_0342;
                        }
                        case 179: {
                            if ("error_user_ban".equals((Object)stringExtra)) {
                                o = d.e.a(l.d2.b());
                                break Label_0342;
                            }
                            o = d.e.a(l.t1.b());
                            break Label_0342;
                        }
                        case 178: {
                            o = d.e.a(l.l.b());
                            break Label_0342;
                        }
                    }
                }
            }
            o = d.e.a(l.f.b());
        }
        Object o2 = o;
        if (n2 == -1) {
            if (intent != null && intent.hasExtra("garena_auth_result")) {
                o2 = intent.getSerializableExtra("garena_auth_result");
            }
            else {
                try {
                    i.f((Callable)new e0(this, ((BaseBundle)intent.getExtras()).getString("gg_token_value"))).l((c1.g)new f0(this), i.k);
                    return true;
                }
                catch (final NullPointerException ex) {
                    k.b((Exception)ex);
                    o2 = o;
                }
            }
        }
        this.f((d.e)o2);
        return true;
    }
    
    boolean c(final d.c c) {
        if (c == null) {
            return false;
        }
        k.a("start gas auth", new Object[0]);
        final Activity context = super.a.f().getContext();
        N.b(context, "Auth Activity");
        final Intent intent = new Intent();
        String s = "com.garena.gas";
        final Intent setClassName = intent.setClassName("com.garena.gas", "com.garena.gameauth.GPProxyAuthActivity");
        setClassName.setPackage("com.garena.gas");
        setClassName.putExtra("gg_request_code", c.f());
        setClassName.putExtra("gg_application_id", c.a());
        setClassName.putExtra("gg_application_key", c.b());
        final StringBuilder sb = new StringBuilder();
        sb.append("gop");
        sb.append(c.a());
        sb.append("://auth/");
        setClassName.putExtra("gg_app_redirect_url", sb.toString());
        setClassName.putExtra("gg_auth_id", c.c());
        setClassName.putExtra("gg_key_hash", com.garena.pay.android.helper.d.b((Context)context));
        setClassName.putExtra("gg_sdk_env", A0.s().toString());
        final PackageManager packageManager = ((Context)super.a.f().getContext()).getPackageManager();
        final ResolveInfo resolveInfo = null;
        ResolveInfo resolveActivity;
        if (packageManager == null) {
            resolveActivity = null;
        }
        else {
            resolveActivity = packageManager.resolveActivity(setClassName, 0);
        }
        if (resolveActivity == null) {
            s = "com.garena.gaslite";
            setClassName.setClassName("com.garena.gaslite", "com.garena.gameauth.GPProxyAuthActivity");
            ResolveInfo resolveActivity2;
            if (packageManager == null) {
                resolveActivity2 = resolveInfo;
            }
            else {
                resolveActivity2 = packageManager.resolveActivity(setClassName, 0);
            }
            if (resolveActivity2 == null) {
                this.h(c);
                return true;
            }
        }
        final int f = super.a.j().f();
        if (f != 56301) {
            if (f != 56302) {
                if (!i((Context)context, s)) {
                    Toast.makeText((Context)context, (CharSequence)"No valid Gas Signature Found", 0).show();
                    return false;
                }
                if (!j((Context)context, s, 19)) {
                    Toast.makeText((Context)context, (CharSequence)"Please upgrade the Gas app", 0).show();
                    return false;
                }
                try {
                    context.startActivityForResult(setClassName, c.f());
                    return true;
                }
                catch (final ActivityNotFoundException ex) {
                    return false;
                }
            }
        }
        this.h(c);
        return true;
    }
}
