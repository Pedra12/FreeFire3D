package com.beetalk.sdk;

import h1.a$c;
import h1.a$b;
import com.beetalk.sdk.helper.A;
import java.util.Locale;
import h1.c;
import e1.q;
import kotlin.jvm.internal.Intrinsics;
import android.app.Activity;
import kotlin.Metadata;

@Metadata
public final class b
{
    public static final b a;
    
    static {
        a = new b();
    }
    
    private b() {
    }
    
    public static final void b(final Activity activity, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        q.a.n(activity, x$e);
    }
    
    public static final void c(final Activity activity, final c c, final String s, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)s, "secondaryPassword");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        q.a.p(activity, c, s, x$e);
    }
    
    public static final void d(final Activity activity, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        q.a.r(activity, c, x$e);
    }
    
    public static final void e(final Activity activity, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        q.a.t(activity, x$e);
    }
    
    public static final void f(final Activity activity, final String s, final c c, final h1.b b, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)s, "region");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)b, "otpFlow");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        h(activity, s, null, c, b, x$e, 4, null);
    }
    
    public static final void g(final Activity activity, final String s, final Locale locale, final c c, final h1.b b, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)s, "region");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)b, "otpFlow");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        final q a = q.a;
        Locale d = locale;
        if (locale == null) {
            d = A.d();
        }
        Intrinsics.c((Object)d);
        a.z(activity, s, d, c, b, x$e);
    }
    
    public static /* synthetic */ void h(final Activity activity, String s, Locale locale, final c c, final h1.b b, final X$e x$e, final int n, final Object o) {
        if ((n & 0x2) != 0x0) {
            s = "";
        }
        if ((n & 0x4) != 0x0) {
            locale = null;
        }
        g(activity, s, locale, c, b, x$e);
    }
    
    public static final void i(final Activity activity, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        q.a.B(activity, x$e);
    }
    
    public static final void j(final Activity activity, final String s, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)s, "region");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        l(activity, s, null, c, x$e, 4, null);
    }
    
    public static final void k(final Activity activity, final String s, final Locale locale, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)s, "region");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        final q a = q.a;
        Locale d = locale;
        if (locale == null) {
            d = A.d();
        }
        Intrinsics.c((Object)d);
        a.D(activity, s, d, c, x$e);
    }
    
    public static /* synthetic */ void l(final Activity activity, String s, Locale locale, final c c, final X$e x$e, final int n, final Object o) {
        if ((n & 0x2) != 0x0) {
            s = "";
        }
        if ((n & 0x4) != 0x0) {
            locale = null;
        }
        k(activity, s, locale, c, x$e);
    }
    
    public static final void m(final Activity activity, final s$h s$h) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)s$h, "callback");
        q.a.v(activity, (s$h)new a(s$h));
    }
    
    private static final void n(final s$h s$h, final s s, final Exception ex) {
        Intrinsics.checkNotNullParameter((Object)s$h, "$callback");
        s$h.onSessionProcessed(s, ex);
        if (s.G().c()) {
            s.m((s.g)null);
        }
    }
    
    public static final void o(final Activity activity, final String s, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)s, "otp");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        q.a.G(activity, s, c, x$e);
    }
    
    public static final void p(final Activity activity, final a$b a$b, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)a$b, "credential");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        q.a.I(activity, a$b, c, x$e);
    }
    
    public static final void q(final Activity activity, final a$c a$c, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)a$c, "credential");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        q.a.K(activity, a$c, c, x$e);
    }
    
    public static final void r(final Activity activity, final String s, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)s, "otp");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        q.a.M(activity, s, c, x$e);
    }
}
