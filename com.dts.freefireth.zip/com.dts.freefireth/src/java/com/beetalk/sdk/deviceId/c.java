package com.beetalk.sdk.deviceId;

import android.content.SharedPreferences$Editor;
import android.content.SharedPreferences;
import java.util.UUID;
import com.beetalk.sdk.exts.e;
import com.beetalk.sdk.X;
import T.b;
import android.telephony.TelephonyManager;
import com.beetalk.sdk.helper.D;
import kotlin.jvm.functions.Function1;
import kotlin.collections.j;
import android.os.Build;
import android.os.Build$VERSION;
import kotlin.jvm.internal.Intrinsics;
import android.provider.Settings$Secure;
import android.content.Context;
import kotlin.Metadata;

@Metadata
public final class c
{
    public static final c a;
    
    static {
        a = new c();
    }
    
    private c() {
    }
    
    private final String r(final Context context, final String s) {
        try {
            final String string = Settings$Secure.getString(context.getContentResolver(), s);
            Intrinsics.checkNotNullExpressionValue((Object)string, "getString(...)");
            return string;
        }
        catch (final Exception ex) {
            return "";
        }
    }
    
    public final String a(final Context context) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        return this.r(context, "ad_aaid");
    }
    
    public final String b(final Context context) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        return this.r(context, "android_id");
    }
    
    public final String c() {
        final String release = Build$VERSION.RELEASE;
        Intrinsics.checkNotNullExpressionValue((Object)release, "RELEASE");
        return release;
    }
    
    public final int d() {
        return Build$VERSION.SDK_INT;
    }
    
    public final String e() {
        final String manufacturer = Build.MANUFACTURER;
        Intrinsics.checkNotNullExpressionValue((Object)manufacturer, "MANUFACTURER");
        return manufacturer;
    }
    
    public final long f() {
        return Build.TIME;
    }
    
    public final String g() {
        final String display = Build.DISPLAY;
        Intrinsics.checkNotNullExpressionValue((Object)display, "DISPLAY");
        return display;
    }
    
    public final String h() {
        final String id = Build.ID;
        Intrinsics.checkNotNullExpressionValue((Object)id, "ID");
        return id;
    }
    
    public final String i() {
        final String[] supported_ABIS = Build.SUPPORTED_ABIS;
        Intrinsics.checkNotNullExpressionValue((Object)supported_ABIS, "SUPPORTED_ABIS");
        return j.L((Object[])supported_ABIS, (CharSequence)",", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null);
    }
    
    public final String j() {
        final String model = Build.MODEL;
        Intrinsics.checkNotNullExpressionValue((Object)model, "MODEL");
        return model;
    }
    
    public final String k() {
        final String fingerprint = Build.FINGERPRINT;
        Intrinsics.checkNotNullExpressionValue((Object)fingerprint, "FINGERPRINT");
        return fingerprint;
    }
    
    public final String l(final Context context) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        return this.r(context, "gcbooster_uuid");
    }
    
    public final String m() {
        final String hardware = Build.HARDWARE;
        Intrinsics.checkNotNullExpressionValue((Object)hardware, "HARDWARE");
        return hardware;
    }
    
    public final String n(final Context context) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        if (!D.a.a(context)) {
            return "";
        }
        try {
            final Object systemService = context.getSystemService("phone");
            final boolean b = systemService instanceof TelephonyManager;
            String a = null;
            TelephonyManager telephonyManager;
            if (b) {
                telephonyManager = (TelephonyManager)systemService;
            }
            else {
                telephonyManager = null;
            }
            if (telephonyManager != null) {
                a = T.b.a(telephonyManager);
            }
            if (a == null) {
                return "";
            }
            return a;
        }
        catch (final SecurityException ex) {
            return "";
        }
    }
    
    public final String o(final Context context) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        return this.r(context, "key_mqs_uuid");
    }
    
    public final String p() {
        final String product = Build.PRODUCT;
        Intrinsics.checkNotNullExpressionValue((Object)product, "PRODUCT");
        return product;
    }
    
    public final String q() {
        final Context m = X.M();
        Intrinsics.checkNotNullExpressionValue((Object)m, "getApplicationContext(...)");
        final SharedPreferences a = e.a(m, "com.garena.msdk");
        final String string = a.getString("uuid", "");
        if (string != null && ((CharSequence)string).length() != 0) {
            return string;
        }
        final String string2 = UUID.randomUUID().toString();
        Intrinsics.checkNotNullExpressionValue((Object)string2, "toString(...)");
        final SharedPreferences$Editor edit = a.edit();
        edit.putString("uuid", string2);
        edit.apply();
        return string2;
    }
    
    public final String s() {
        if (Build$VERSION.SDK_INT >= 31) {
            final String a = com.beetalk.sdk.deviceId.b.a();
            Intrinsics.c((Object)a);
            return a;
        }
        return "";
    }
    
    public final String t() {
        if (Build$VERSION.SDK_INT >= 31) {
            final String a = com.beetalk.sdk.deviceId.a.a();
            Intrinsics.c((Object)a);
            return a;
        }
        return "";
    }
}
