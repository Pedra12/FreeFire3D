package com.beetalk.sdk.deviceId;

import android.os.Build$VERSION;
import kotlin.jvm.functions.Function1;
import kotlin.collections.j;
import android.media.MediaDrm;
import java.util.UUID;
import kotlin.Metadata;

@Metadata
public final class h implements AutoCloseable
{
    private final UUID a;
    private final MediaDrm b;
    
    public h() {
        final UUID fromString = UUID.fromString("edef8ba9-79d6-4ace-a3c8-27dcd51d21ed");
        this.a = fromString;
        MediaDrm b;
        try {
            b = new MediaDrm(fromString);
        }
        catch (final Exception ex) {
            b = null;
        }
        this.b = b;
    }
    
    private final String a(final byte[] array) {
        return j.K(array, (CharSequence)"", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)h$a.b, 30, (Object)null);
    }
    
    private final MediaDrm b() {
        return this.b;
    }
    
    public final String c() {
        final String s = "";
        try {
            final MediaDrm b = this.b();
            byte[] propertyByteArray;
            if (b == null || (propertyByteArray = b.getPropertyByteArray("deviceUniqueId")) == null) {
                propertyByteArray = new byte[0];
            }
            if (propertyByteArray.length == 0) {
                return "";
            }
            return this.a(propertyByteArray);
        }
        catch (final Exception ex) {
            return s;
        }
    }
    
    public void close() {
        if (Build$VERSION.SDK_INT >= 28) {
            final MediaDrm b = this.b();
            if (b != null) {
                b.release();
            }
        }
        else {
            final MediaDrm b2 = this.b();
            if (b2 != null) {
                b2.release();
            }
        }
    }
    
    public final String d() {
        try {
            final MediaDrm b = this.b();
            String propertyString;
            if (b != null) {
                propertyString = b.getPropertyString("vendor");
            }
            else {
                propertyString = null;
            }
            if (propertyString == null) {
                return "";
            }
            return propertyString;
        }
        catch (final Exception ex) {
            return "";
        }
    }
}
