package com.beetalk.sdk.deviceId;

import android.content.SharedPreferences$Editor;
import com.beetalk.sdk.helper.k;
import android.content.Context;
import com.beetalk.sdk.X;
import s7.p$a;
import s7.q;
import l1.b;
import s7.p;
import java.util.concurrent.Callable;
import c1.i;
import com.google.gson.Gson;
import android.content.SharedPreferences;
import kotlin.jvm.internal.Intrinsics;
import com.beetalk.sdk.networking.h;
import l1.c;
import kotlin.Unit;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;

@Metadata
public final class g
{
    public static final g a;
    private static final AtomicBoolean b;
    
    static {
        a = new g();
        b = new AtomicBoolean(true);
    }
    
    private g() {
    }
    
    private final String d() {
        return this.e().a();
    }
    
    private final c e() {
        final SharedPreferences k = this.k();
        final String j = this.j();
        String s = "";
        final String string = k.getString(j, "");
        if (string != null) {
            s = string;
        }
        final Gson f = h.f;
        Intrinsics.checkNotNullExpressionValue((Object)f, "GLOBAL_GSON");
        final c c = new c();
        Label_0072: {
            if (((CharSequence)s).length() == 0) {
                final Object fromJson = c;
                break Label_0072;
            }
            try {
                final Object fromJson = f.fromJson(s, (Class)c.class);
                return (c)fromJson;
            }
            catch (final Exception ex) {
                final Object fromJson = c;
                return (c)fromJson;
            }
        }
    }
    
    public static final String f() {
        if (!g.b.get()) {
            return "";
        }
        final String d = g.a.d();
        i.f((Callable)new e());
        return d;
    }
    
    private static final Unit g() {
        final g a = g.a;
        final g g;
        monitorenter(g = a);
        Label_0097: {
            try {
                if (((CharSequence)a.d()).length() <= 0) {
                    Object b3 = null;
                    try {
                        final p$a b = p.b;
                        p.b((Object)l1.b.a.a());
                    }
                    finally {
                        final p$a b2 = p.b;
                        final Throwable t;
                        b3 = p.b(q.a(t));
                    }
                    Object o = b3;
                    if (p.f(b3)) {
                        o = null;
                    }
                    final c c = (c)o;
                    if (c != null) {
                        com.beetalk.sdk.deviceId.g.a.n(c);
                    }
                }
            }
            finally {
                break Label_0097;
            }
            monitorexit(g);
            return Unit.a;
        }
        monitorexit(g);
    }
    
    public static final i h() {
        if (!g.b.get()) {
            final i t = i.t((Object)"");
            Intrinsics.checkNotNullExpressionValue((Object)t, "forResult(...)");
            return t;
        }
        Object d = g.a.d();
        if (((CharSequence)d).length() <= 0) {
            d = null;
        }
        if (d != null) {
            final i t2 = i.t(d);
            Intrinsics.checkNotNullExpressionValue((Object)t2, "forResult(...)");
            return t2;
        }
        final i f = i.f((Callable)new f());
        Intrinsics.checkNotNullExpressionValue((Object)f, "callInBackground(...)");
        return f;
    }
    
    private static final String i() {
        final g a = g.a;
        final g g;
        monitorenter(g = a);
        Label_0093: {
            String a3 = null;
            Label_0088: {
                String s;
                c a2;
                try {
                    Object d = a.d();
                    final int length = ((CharSequence)d).length();
                    s = null;
                    if (length <= 0) {
                        d = null;
                    }
                    if (d != null) {
                        break Label_0088;
                    }
                    a2 = l1.b.a.a();
                    if (a2 != null) {
                        a.n(a2);
                    }
                }
                finally {
                    break Label_0093;
                }
                a3 = s;
                if (a2 != null) {
                    a3 = a2.a();
                }
                if (a3 == null) {
                    a3 = "";
                }
            }
            monitorexit(g);
            return a3;
        }
        monitorexit(g);
    }
    
    private final String j() {
        if (X.k().b()) {
            return "deviceId";
        }
        return "deviceId.sandbox";
    }
    
    private final SharedPreferences k() {
        final Context m = X.M();
        Intrinsics.checkNotNullExpressionValue((Object)m, "getApplicationContext(...)");
        return com.beetalk.sdk.exts.e.a(m, "com.garena.msdk.SERVICE_PREF");
    }
    
    public static final void l() {
        if (!g.b.get()) {
            return;
        }
        i.f((Callable)new d());
    }
    
    private static final Unit m() {
        final g a = g.a;
        final g g;
        monitorenter(g = a);
        Label_0105: {
            Label_0099: {
                try {
                    if (a.e().b() > System.currentTimeMillis() / 1000L) {
                        k.i("too early to refresh device id, skip", new Object[0]);
                        break Label_0099;
                    }
                }
                finally {
                    break Label_0105;
                }
                final c c;
                final String a2 = c.a();
                if (((CharSequence)a2).length() == 0) {
                    k.i("device id is empty, skip to refresh device id", new Object[0]);
                }
                else {
                    final c b = l1.b.a.b(a2);
                    if (b == null) {
                        k.a("refresh device id failed", new Object[0]);
                    }
                    else {
                        a.n(b);
                    }
                }
            }
            monitorexit(g);
            return Unit.a;
        }
        monitorexit(g);
    }
    
    private final void n(final c c) {
        final SharedPreferences$Editor edit = this.k().edit();
        final String j = g.a.j();
        final Gson f = h.f;
        Intrinsics.checkNotNullExpressionValue((Object)f, "GLOBAL_GSON");
        edit.putString(j, com.beetalk.sdk.exts.h.b(f, c));
        edit.apply();
    }
    
    public static final void o(final boolean b) {
        g.b.set(b);
    }
}
