package com.beetalk.sdk.plugin.impl.misc;

import c1.g;
import java.util.concurrent.Callable;
import com.beetalk.sdk.helper.t;
import android.content.Intent;
import android.app.Activity;
import c1.i;
import org.json.JSONObject;
import com.garena.pay.android.l;
import org.json.JSONException;
import com.beetalk.sdk.helper.k;
import com.beetalk.sdk.plugin.f;
import com.beetalk.sdk.plugin.a;

public class c extends a<c$d, f>
{
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public String d() {
        return "app.feedback";
    }
    
    @Override
    public Integer e() {
        return 2891;
    }
    
    @Override
    public boolean f(final Activity activity, final int n, final Intent intent) {
        return false;
    }
    
    protected void m(final Activity activity, final c$d c$d) {
        if (!t.t(c$d.b) && !t.t(c$d.c) && !t.t(c$d.a)) {
            i.f((Callable)new com.beetalk.sdk.plugin.impl.misc.a(this, c$d)).l((g)new b(), i.k);
            return;
        }
        com.beetalk.sdk.plugin.c.k().o(new f(this) {
            final c e;
            
            {
                super.c = e.d();
                super.b = "Required params missing. Have you logged in?";
                super.d = l.y.b();
                super.a = -1;
            }
        }, activity, this.d());
    }
}
