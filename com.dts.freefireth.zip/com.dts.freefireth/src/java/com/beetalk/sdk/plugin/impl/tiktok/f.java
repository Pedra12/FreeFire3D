package com.beetalk.sdk.plugin.impl.tiktok;

import java.lang.ref.Reference;
import android.content.BroadcastReceiver;
import android.app.Application$ActivityLifecycleCallbacks;
import com.beetalk.sdk.helper.H;
import java.lang.ref.WeakReference;
import java.util.concurrent.Callable;
import android.content.Intent;
import c1.g;
import F1.d;
import com.garena.android.share.model.ShareVideoContent;
import java.util.Iterator;
import com.garena.android.share.model.ShareImageContent;
import com.beetalk.sdk.X;
import android.net.Uri;
import android.content.Context;
import com.bytedance.sdk.open.tiktok.base.e;
import com.bytedance.sdk.open.tiktok.base.h;
import com.garena.pay.android.l;
import java.util.ArrayList;
import java.util.Collection;
import c1.i;
import android.app.Activity;
import java.util.Collections;
import com.beetalk.sdk.tiktok.TiktokGreenScreenVideoShareContent;
import com.beetalk.sdk.tiktok.TiktokVideoShareContent;
import com.beetalk.sdk.tiktok.TiktokGreenScreenImageShareContent;
import com.beetalk.sdk.tiktok.TiktokImageShareContent;
import java.util.List;
import com.garena.android.share.model.ShareContent;

public class f extends com.beetalk.sdk.plugin.impl.tiktok.a<ShareContent>
{
    private a a;
    
    public f() {
        this.a = null;
    }
    
    private P1.b m(final ShareContent shareContent, final ArrayList a) {
        P1.a g = P1.a.b;
        final com.bytedance.sdk.open.tiktok.base.f h = new com.bytedance.sdk.open.tiktok.base.f();
        final boolean b = shareContent instanceof TiktokGreenScreenImageShareContent;
        if (b || shareContent instanceof TiktokGreenScreenVideoShareContent) {
            g = P1.a.c;
        }
        if (!(shareContent instanceof TiktokImageShareContent) && !b) {
            final h a2 = new h();
            a2.a = a;
            h.a = (com.bytedance.sdk.open.tiktok.base.d)a2;
        }
        else {
            h.a = (com.bytedance.sdk.open.tiktok.base.d)new e(a);
        }
        final P1.b b2 = new P1.b();
        b2.h = h;
        ((M1.a)b2).d = TiktokShareResponseActivity.class.getCanonicalName();
        b2.g = g;
        return b2;
    }
    
    private Activity o() {
        final a a = this.a;
        if (a != null) {
            return (Activity)((Reference)a.a).get();
        }
        return null;
    }
    
    private static void p(final Context context, final Uri uri) {
        context.grantUriPermission("com.zhiliaoapp.musically", uri, 1);
        context.grantUriPermission("com.ss.android.ugc.trill", uri, 1);
    }
    
    private List v(final TiktokGreenScreenImageShareContent tiktokGreenScreenImageShareContent) {
        final Uri c = H2.b.c(tiktokGreenScreenImageShareContent.i(), "tiktok_share");
        p(X.M(), c);
        return Collections.singletonList((Object)c.toString());
    }
    
    private List w(final TiktokGreenScreenVideoShareContent tiktokGreenScreenVideoShareContent) {
        final Uri e = H2.b.e(tiktokGreenScreenVideoShareContent.i(), "tiktok_share");
        p(X.M(), e);
        return Collections.singletonList((Object)e.toString());
    }
    
    private List x(final TiktokImageShareContent tiktokImageShareContent) {
        final List i = tiktokImageShareContent.i();
        final ArrayList list = new ArrayList(i.size());
        final Iterator iterator = i.iterator();
        int n = 0;
        while (iterator.hasNext()) {
            final ShareImageContent shareImageContent = (ShareImageContent)iterator.next();
            final StringBuilder sb = new StringBuilder();
            sb.append("tiktok_share");
            sb.append(n);
            final Uri c = H2.b.c(shareImageContent, sb.toString());
            p(X.M(), c);
            ((List)list).add((Object)c.toString());
            ++n;
        }
        return (List)list;
    }
    
    private List y(final TiktokVideoShareContent tiktokVideoShareContent) {
        final List i = tiktokVideoShareContent.i();
        final ArrayList list = new ArrayList(i.size());
        final Iterator iterator = i.iterator();
        int n = 0;
        while (iterator.hasNext()) {
            final ShareVideoContent shareVideoContent = (ShareVideoContent)iterator.next();
            final StringBuilder sb = new StringBuilder();
            sb.append("tiktok_share");
            sb.append(n);
            final Uri e = H2.b.e(shareVideoContent, sb.toString());
            p(X.M(), e);
            ((List)list).add((Object)e.toString());
            ++n;
        }
        return (List)list;
    }
    
    @Override
    public String d() {
        return "tiktok.share";
    }
    
    @Override
    protected void h(final Activity activity, final int n, final String s) {
        super.h(activity, n, s);
        final a a = this.a;
        if (a != null) {
            a.b(activity);
            this.a = null;
        }
    }
    
    protected void n(final Activity activity, final ShareContent shareContent) {
        final a a = this.a;
        if (a != null) {
            a.b(activity);
        }
        this.a = null;
        final G1.a a2 = d.a(activity);
        if (a2 == null) {
            this.h(activity, l.y.b(), "Tiktok SDK hasn't initialized, have you configured tiktok secret key?");
            return;
        }
        this.u(shareContent, com.beetalk.sdk.helper.b.i(activity).c()).l((g)new com.beetalk.sdk.plugin.impl.tiktok.d(this, shareContent, activity, a2), i.k);
    }
    
    public void q(final Intent intent) {
        final Activity o = this.o();
        if (o != null) {
            final l y = l.y;
            this.h(o, y.b(), y.d());
        }
    }
    
    public void r(final M1.b b) {
        final Activity o = this.o();
        if (o != null) {
            if (b.d()) {
                this.i(o, l.c);
                return;
            }
            final int intValue = l.t1.b();
            final StringBuilder sb = new StringBuilder();
            sb.append(b.a);
            sb.append(":");
            sb.append(b.b);
            this.h(o, intValue, sb.toString());
        }
    }
    
    public void s() {
        final Activity o = this.o();
        if (o != null) {
            final l t1 = l.t1;
            this.h(o, t1.b(), t1.d());
        }
    }
    
    public void t() {
        final Activity o = this.o();
        if (o != null) {
            this.i(o, l.c);
        }
    }
    
    public i u(final ShareContent shareContent, final c1.d d) {
        if (!shareContent.t()) {
            return i.s((Exception)new IllegalArgumentException(l.y.d()));
        }
        return i.g((Callable)new com.beetalk.sdk.plugin.impl.tiktok.e(this, shareContent), d);
    }
    
    private static class a
    {
        private final WeakReference a;
        private b b;
        
        public a(final Activity activity, final b b) {
            this.a = new WeakReference((Object)activity);
            this.b = b;
            activity.getApplication().registerActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)new H(this) {
                final a a;
                
                @Override
                public void onActivityDestroyed(final Activity activity) {
                    super.onActivityDestroyed(activity);
                    activity.getApplication().unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                    this.a.b(activity);
                }
            });
        }
        
        public void b(final Activity activity) {
            final b b = this.b;
            if (b != null) {
                ((Context)activity).unregisterReceiver((BroadcastReceiver)b);
                this.b = null;
            }
        }
    }
}
