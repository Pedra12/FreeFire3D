package com.beetalk.sdk.plugin.impl.vk;

import android.app.Fragment;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.view.Window;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ColorDrawable;
import android.app.Dialog;
import android.os.Bundle;
import android.content.DialogInterface;
import android.app.DialogFragment;

public class d extends DialogFragment implements f.d
{
    private final f a;
    
    public d() {
        this.a = new f((f.d)this);
    }
    
    d a(final e e) {
        this.a.i(e.a);
        this.a.k(e.b);
        return this;
    }
    
    public void dismiss() {
        if (((Fragment)this).getFragmentManager() != null) {
            super.dismiss();
        }
    }
    
    public void dismissAllowingStateLoss() {
        if (((Fragment)this).getFragmentManager() != null) {
            super.dismissAllowingStateLoss();
        }
    }
    
    public void onCancel(final DialogInterface dialogInterface) {
        super.onCancel(dialogInterface);
        this.a.f();
    }
    
    public Dialog onCreateDialog(final Bundle bundle) {
        final Dialog onCreateDialog = super.onCreateDialog(bundle);
        onCreateDialog.requestWindowFeature(1);
        final Window window = onCreateDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable((Drawable)new ColorDrawable(0));
        }
        onCreateDialog.setCanceledOnTouchOutside(false);
        return onCreateDialog;
    }
    
    public View onCreateView(final LayoutInflater layoutInflater, final ViewGroup viewGroup, final Bundle bundle) {
        return this.a.g(layoutInflater, viewGroup, bundle);
    }
    
    public void onPause() {
        super.onPause();
        this.a.f();
    }
    
    public void onSaveInstanceState(final Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.a.h(bundle);
    }
    
    public void onStart() {
        super.onStart();
        final Window window = this.getDialog().getWindow();
        if (window != null) {
            window.setLayout(com.beetalk.sdk.exts.f.a((Number)358), -2);
        }
    }
    
    public interface a extends e.a
    {
    }
}
