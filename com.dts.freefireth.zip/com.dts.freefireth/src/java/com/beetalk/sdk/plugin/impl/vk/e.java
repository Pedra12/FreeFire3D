package com.beetalk.sdk.plugin.impl.vk;

import com.garena.pay.android.l;
import android.app.FragmentManager;
import com.beetalk.sdk.vk.VkShareDialogParam;

public class e
{
    VkShareDialogParam a;
    a b;
    
    public void a(final VkShareDialogParam a) {
        this.a = a;
    }
    
    public e b(final a b) {
        this.b = b;
        return this;
    }
    
    public void c(final FragmentManager fragmentManager, final String s) {
        new d().a(this).show(fragmentManager, s);
    }
    
    public interface a
    {
        void a();
        
        void b(final l p0);
        
        void c(final int p0);
    }
}
