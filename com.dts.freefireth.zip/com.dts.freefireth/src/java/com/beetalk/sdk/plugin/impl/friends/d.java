package com.beetalk.sdk.plugin.impl.friends;

import java.util.concurrent.Callable;
import c1.i;
import android.content.Intent;
import org.json.JSONObject;
import com.beetalk.sdk.plugin.c;
import com.beetalk.sdk.plugin.g;
import com.garena.pay.android.l;
import com.beetalk.sdk.networking.service.H;
import android.app.Activity;
import k1.b$f;
import java.util.List;

public class d extends a<List<String>, b$f>
{
    @Override
    public String d() {
        return "msdk.group.friend.info";
    }
    
    @Override
    public Integer e() {
        return 2899;
    }
    
    @Override
    public boolean f(final Activity activity, final int n, final Intent intent) {
        return false;
    }
    
    protected void m(final Activity activity, final List list) {
        i.f((Callable)new com.beetalk.sdk.plugin.impl.friends.c(this, list, activity));
    }
}
