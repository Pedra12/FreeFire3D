package com.beetalk.sdk.plugin.impl.vk;

import android.content.Context;
import com.beetalk.sdk.helper.t;
import com.beetalk.sdk.X;
import android.net.Uri;
import com.garena.android.share.model.ShareImageContent;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.os.Parcelable;
import android.content.Intent;
import com.beetalk.sdk.helper.k;
import H2.b;
import com.garena.pay.android.l;
import android.app.Activity;
import android.text.TextUtils;
import com.beetalk.sdk.vk.e;
import com.beetalk.sdk.plugin.a;

public class c<S, T> extends a<S, T>
{
    private String k(final e e) {
        final StringBuilder sb = new StringBuilder();
        if (!TextUtils.isEmpty((CharSequence)e.a)) {
            sb.append(e.a);
        }
        if (!TextUtils.isEmpty((CharSequence)e.b)) {
            if (sb.length() > 0) {
                sb.append('\n');
            }
            sb.append(e.b);
        }
        return sb.toString();
    }
    
    private void l(final Activity activity, final Object o) {
        if (!(o instanceof e)) {
            this.i(activity, l.y);
            return;
        }
        final e e = (e)o;
        final ShareImageContent c = e.c;
        Uri c2 = null;
        Label_0071: {
            if (c != null && c.t()) {
                try {
                    c2 = b.c(c, "vk_share_image.png");
                    break Label_0071;
                }
                catch (final Exception ex) {
                    k.b(ex);
                    this.h(activity, l.y.b(), "generate image uri failed");
                    return;
                }
            }
            c2 = null;
        }
        final String k = this.k(e);
        if (c2 == null && TextUtils.isEmpty((CharSequence)k)) {
            this.i(activity, l.y);
            return;
        }
        final Intent intent = new Intent("android.intent.action.SEND");
        intent.setPackage("com.vkontakte.android");
        if (c2 != null) {
            intent.setType("image/*");
            intent.putExtra("android.intent.extra.STREAM", (Parcelable)c2);
            intent.setClipData(ClipData.newRawUri((CharSequence)"vk_share_image", c2));
            intent.addFlags(1);
        }
        else {
            intent.setType("text/plain");
        }
        if (!TextUtils.isEmpty((CharSequence)k)) {
            intent.putExtra("android.intent.extra.TEXT", k);
        }
        if (intent.resolveActivity(((Context)activity).getPackageManager()) == null) {
            this.h(activity, l.X.b(), "activity not found");
            return;
        }
        Label_0225: {
            if (c2 != null) {
                Label_0239: {
                    try {
                        ((Context)activity).grantUriPermission("com.vkontakte.android", c2, 1);
                    }
                    catch (final ActivityNotFoundException ex2) {
                        break Label_0239;
                    }
                    break Label_0225;
                }
                final ActivityNotFoundException ex2;
                com.beetalk.sdk.helper.k.b((Exception)ex2);
                this.h(activity, l.X.b(), "activity not found");
                return;
            }
        }
        activity.startActivity(intent);
        this.i(activity, l.c);
    }
    
    @Override
    protected void b(final Activity activity, final Object o) {
        if (o == null) {
            this.g(activity, l.y.b());
            return;
        }
        if (!t.u("com.vkontakte.android", X.M())) {
            this.i(activity, l.d);
            return;
        }
        this.l(activity, o);
    }
    
    @Override
    public String d() {
        return "vk.share";
    }
    
    @Override
    public Integer e() {
        return 0;
    }
    
    @Override
    public boolean f(final Activity activity, final int n, final Intent intent) {
        return false;
    }
    
    @Override
    public void j(final androidx.appcompat.app.c c) {
    }
}
