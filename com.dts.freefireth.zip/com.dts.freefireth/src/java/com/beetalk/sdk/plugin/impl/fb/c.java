package com.beetalk.sdk.plugin.impl.fb;

import n2.k;
import com.facebook.share.model.GameRequestContent;
import java.util.Collections;
import com.facebook.share.model.GameRequestContent$b;
import j2.a$f;
import R1.j;
import R1.g;
import com.garena.pay.android.l;
import android.app.Activity;
import com.beetalk.sdk.plugin.f;

public class c extends a<t1.a, f>
{
    @Override
    public String d() {
        return "facebook.game.message";
    }
    
    @Override
    public Integer e() {
        return 2900;
    }
    
    @Override
    public void k(final Exception ex, final Activity activity) {
        com.beetalk.sdk.plugin.c.k().o(new f(this, ex) {
            final Exception e;
            final c f;
            
            {
                super.c = f.d();
                super.a = -1;
                super.d = l.h.b();
                super.b = ((Throwable)e).getMessage();
            }
        }, activity, this.d());
    }
    
    @Override
    public void m(final Activity activity) {
        final Object a = super.a;
        if (a == null || ((t1.a)a).a.isEmpty()) {
            final f f = new f();
            f.c = this.d();
            f.a = -1;
            f.d = l.y.b();
            f.b = "User id is invalid";
            com.beetalk.sdk.plugin.c.k().o(f, activity, this.d());
            return;
        }
        final j2.a a2 = new j2.a(activity);
        ((k)a2).j(super.b, (g)new g(this, activity) {
            final Activity a;
            final c b;
            
            public void a() {
                final f f = new f();
                f.c = this.b.d();
                f.a = -1;
                final l f2 = l.f;
                f.d = f2.b();
                f.b = f2.d();
                com.beetalk.sdk.plugin.c.k().o(f, this.a, this.b.d());
            }
            
            public void b(final j j) {
                final f f = new f();
                f.c = this.b.d();
                f.a = -1;
                f.d = l.t1.b();
                if (j != null) {
                    f.b = ((Throwable)j).getMessage();
                }
                else {
                    f.b = "Failed to send message";
                }
                com.beetalk.sdk.plugin.c.k().o(f, this.a, this.b.d());
            }
            
            public void c(final a$f a$f) {
                final f f = new f();
                f.c = this.b.d();
                f.a = 0;
                f.d = l.c.b();
                f.b = "Successfully sent";
                com.beetalk.sdk.plugin.c.k().o(f, this.a, this.b.d());
            }
        });
        final GameRequestContent a3 = new GameRequestContent$b().n(((t1.a)super.a).b).l(((t1.a)super.a).c).k(((t1.a)super.a).f).m(Collections.singletonList((Object)String.valueOf((Object)((t1.a)super.a).a))).a();
        if (((k)a2).b((Object)a3)) {
            ((k)a2).l((Object)a3);
            return;
        }
        final f f2 = new f();
        f2.c = this.d();
        f2.a = -1;
        f2.d = l.e.b();
        f2.b = "Cannot show game request dialog";
        com.beetalk.sdk.plugin.c.k().o(f2, activity, this.d());
    }
}
