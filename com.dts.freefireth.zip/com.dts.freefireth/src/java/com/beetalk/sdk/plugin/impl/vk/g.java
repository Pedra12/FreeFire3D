package com.beetalk.sdk.plugin.impl.vk;

import com.beetalk.sdk.helper.k;
import g2.o;
import com.beetalk.sdk.vk.VkShareDialogParam;
import com.beetalk.sdk.plugin.c;
import com.garena.pay.android.l;
import android.app.Activity;
import com.beetalk.sdk.plugin.f;
import com.beetalk.sdk.vk.e;

public class g extends b<e, f>
{
    private void q(final Activity activity, final l l) {
        final f f = new f();
        f.c = this.d();
        f.a = -1;
        f.d = l.b();
        f.b = l.d();
        c.k().o(f, activity, this.d());
    }
    
    @Override
    public String d() {
        return "vk.share";
    }
    
    protected void p(final Activity activity, final e e) {
        VkShareDialogParam.e.b(e).k((g2.f)new g2.f(this, activity) {
            final Activity a;
            final g b;
            
            public Void b(final o o) {
                if (o.u()) {
                    this.b.q(this.a, l.y);
                }
                else {
                    final com.beetalk.sdk.plugin.impl.vk.e e = new com.beetalk.sdk.plugin.impl.vk.e();
                    e.a((VkShareDialogParam)o.r());
                    e.b((com.beetalk.sdk.plugin.impl.vk.e.a)new d.a(this) {
                        final g$a a;
                        
                        @Override
                        public void a() {
                            k.a("vk share canceled", new Object[0]);
                            final g2.f a = this.a;
                            a.b.q(a.a, l.f);
                        }
                        
                        @Override
                        public void b(final l l) {
                            k.a("vk share failed: %s", l);
                            final l f = l.f;
                            if (l == f) {
                                final g2.f a = this.a;
                                a.b.q(a.a, f);
                                return;
                            }
                            final g2.f a2 = this.a;
                            a2.b.q(a2.a, l.l);
                        }
                        
                        @Override
                        public void c(final int n) {
                            k.a("vk share complete", new Object[0]);
                            final f f = new f();
                            f.c = this.a.b.d();
                            f.a = 0;
                            f.d = l.c.b();
                            f.b = "Success";
                            final c k = com.beetalk.sdk.plugin.c.k();
                            final g2.f a = this.a;
                            k.o(f, a.a, a.b.d());
                        }
                    });
                    k.a("launching vk share dialog", new Object[0]);
                    e.c(this.a.getFragmentManager(), "VK_SHARE_DIALOG");
                }
                return null;
            }
        }, o.m);
    }
}
