package com.beetalk.sdk.plugin.impl.vk.share.api;

import java.util.Collection;
import org.json.JSONException;
import K6.h;
import org.json.JSONObject;
import android.os.Parcelable;
import android.os.Parcel;
import java.util.ArrayList;
import java.util.List;
import H6.q;
import java.util.concurrent.TimeUnit;
import H6.v$a;
import H6.o;
import H6.x$a;
import H6.p;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import android.net.Uri;
import org.jetbrains.annotations.NotNull;
import android.os.Parcelable$Creator;
import kotlin.Metadata;

@Metadata
public final class VKPhotoAttachments extends VKMediaAttachments
{
    @NotNull
    public static final Parcelable$Creator<VKPhotoAttachments> CREATOR;
    private final Uri[] b;
    
    static {
        CREATOR = (Parcelable$Creator)new a();
    }
    
    public VKPhotoAttachments(@NotNull final Uri[] b) {
        Intrinsics.checkNotNullParameter((Object)b, "images");
        super(null);
        this.b = b;
    }
    
    private final g l(final p p) {
        return (g)p.f(new x$a().v("photos.getWallUploadServer").z(p.h().u()).e(), (o)new d());
    }
    
    private final String m(final Uri uri, final g g, final p p3) {
        final e e = (e)p3.e(new v$a().k(g.a()).a("photo", uri, "image.jpg").j(TimeUnit.MINUTES.toMillis(5L)).i(3).b(), (q)null, (o)new b());
        return ((f)p3.f(new x$a().v("photos.saveWallPhoto").b("server", (Object)e.c()).c("photo", e.b()).c("hash", e.a()).z(p3.h().u()).e(), (o)new c())).a();
    }
    
    public int describeContents() {
        return 0;
    }
    
    @Override
    public List i(final p p) {
        Intrinsics.checkNotNullParameter((Object)p, "manager");
        final g l = this.l(p);
        final Uri[] b = this.b;
        final ArrayList list = new ArrayList(b.length);
        for (int length = b.length, i = 0; i < length; ++i) {
            ((Collection)list).add((Object)this.m(b[i], l, p));
        }
        return (List)list;
    }
    
    public void writeToParcel(final Parcel parcel, final int n) {
        Intrinsics.checkNotNullParameter((Object)parcel, "out");
        final Uri[] b = this.b;
        final int length = b.length;
        parcel.writeInt(length);
        for (int i = 0; i != length; ++i) {
            parcel.writeParcelable((Parcelable)b[i], n);
        }
    }
    
    @Metadata
    public static final class a implements Parcelable$Creator<VKPhotoAttachments>
    {
        public final VKPhotoAttachments a(final Parcel parcel) {
            Intrinsics.checkNotNullParameter((Object)parcel, "parcel");
            final int int1 = parcel.readInt();
            final Uri[] array = new Uri[int1];
            for (int i = 0; i != int1; ++i) {
                array[i] = (Uri)parcel.readParcelable(VKPhotoAttachments.class.getClassLoader());
            }
            return new VKPhotoAttachments(array);
        }
        
        public final VKPhotoAttachments[] b(final int n) {
            return new VKPhotoAttachments[n];
        }
    }
    
    @Metadata
    private static final class b implements o
    {
        public b() {
        }
        
        public e b(JSONObject jsonObject) {
            Intrinsics.checkNotNullParameter((Object)jsonObject, "responseJson");
            try {
                final String optString = jsonObject.optString("root_response");
                Intrinsics.c((Object)optString);
                if (((CharSequence)optString).length() > 0) {
                    jsonObject = new JSONObject(optString);
                }
            }
            catch (final JSONException ex) {
                throw new h((Throwable)ex);
            }
            final int int1 = jsonObject.getInt("server");
            final String string = jsonObject.getString("photo");
            Intrinsics.checkNotNullExpressionValue((Object)string, "getString(...)");
            final String string2 = jsonObject.getString("hash");
            Intrinsics.checkNotNullExpressionValue((Object)string2, "getString(...)");
            return new e(int1, string, string2);
        }
    }
    
    @Metadata
    private static final class c implements o
    {
        public c() {
        }
        
        public f b(JSONObject jsonObject) {
            Intrinsics.checkNotNullParameter((Object)jsonObject, "responseJson");
            try {
                jsonObject = jsonObject.getJSONArray("response").getJSONObject(0);
                return new f(jsonObject.getInt("id"), jsonObject.getInt("owner_id"));
            }
            catch (final JSONException ex) {
                throw new h((Throwable)ex);
            }
        }
    }
    
    @Metadata
    private static final class d implements o
    {
        public d() {
        }
        
        public g b(final JSONObject jsonObject) {
            Intrinsics.checkNotNullParameter((Object)jsonObject, "responseJson");
            try {
                final String string = jsonObject.getJSONObject("response").getString("upload_url");
                Intrinsics.checkNotNullExpressionValue((Object)string, "getString(...)");
                return new g(string);
            }
            catch (final JSONException ex) {
                throw new h((Throwable)ex);
            }
        }
    }
    
    @Metadata
    private static final class e
    {
        private final int a;
        private final String b;
        private final String c;
        
        public e(final int a, @NotNull final String b, @NotNull final String c) {
            Intrinsics.checkNotNullParameter((Object)b, "photo");
            Intrinsics.checkNotNullParameter((Object)c, "hash");
            this.a = a;
            this.b = b;
            this.c = c;
        }
        
        public final String a() {
            return this.c;
        }
        
        public final String b() {
            return this.b;
        }
        
        public final int c() {
            return this.a;
        }
    }
    
    @Metadata
    private static final class f
    {
        private final int a;
        private final int b;
        private final String c;
        
        public f(final int a, final int b) {
            this.a = a;
            this.b = b;
            final StringBuilder sb = new StringBuilder();
            sb.append("photo");
            sb.append(b);
            sb.append("_");
            sb.append(a);
            this.c = sb.toString();
        }
        
        public final String a() {
            return this.c;
        }
    }
    
    @Metadata
    private static final class g
    {
        private final String a;
        
        public g(@NotNull final String a) {
            Intrinsics.checkNotNullParameter((Object)a, "uploadUrl");
            this.a = a;
        }
        
        public final String a() {
            return this.a;
        }
    }
}
