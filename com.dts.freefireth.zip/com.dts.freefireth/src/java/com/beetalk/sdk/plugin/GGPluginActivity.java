package com.beetalk.sdk.plugin;

import android.os.Handler;
import android.os.Looper;
import com.beetalk.sdk.X;
import com.beetalk.sdk.s;
import android.os.Bundle;
import com.beetalk.sdk.helper.k;
import android.text.TextUtils;
import android.content.Context;
import android.content.Intent;
import android.app.Activity;

public class GGPluginActivity extends Activity
{
    private String a;
    private a b;
    
    public static void b(final Activity activity, final String s, final int n) {
        final Intent intent = new Intent();
        intent.setClass((Context)activity, (Class)GGPluginActivity.class);
        intent.putExtra("plugin_id", s);
        activity.startActivityForResult(intent, n);
    }
    
    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        if (!TextUtils.isEmpty((CharSequence)this.a) && this.a.startsWith("facebook")) {
            try {
                if (((com.beetalk.sdk.plugin.impl.fb.a)this.b).l(n, n2, intent, this)) {
                    return;
                }
            }
            catch (final Exception ex) {
                k.b(ex);
            }
        }
        if (this.b.e() != null && n == this.b.e() && this.b.f(this, n2, intent)) {
            this.finish();
        }
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        if (s.w() == null) {
            X.U((Activity)this);
        }
        this.a = this.getIntent().getStringExtra("plugin_id");
        this.b = c.k().l(this.a);
        if (bundle == null) {
            new Handler(Looper.getMainLooper()).postDelayed((Runnable)new Runnable(this) {
                final GGPluginActivity a;
                
                public void run() {
                    c.k().p(this.a.b, this.a);
                }
            }, 140L);
        }
    }
}
