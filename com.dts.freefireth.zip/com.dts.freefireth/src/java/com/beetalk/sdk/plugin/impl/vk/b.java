package com.beetalk.sdk.plugin.impl.vk;

import android.content.Intent;
import H6.i;
import com.beetalk.sdk.helper.k;
import com.beetalk.sdk.X$e;
import com.beetalk.sdk.plugin.c;
import com.garena.pay.android.l;
import com.beetalk.sdk.plugin.f;
import android.app.Activity;
import com.beetalk.sdk.plugin.a;

public abstract class b<S, T> extends a<S, T>
{
    private Object a;
    private com.beetalk.sdk.vk.b b;
    
    private com.beetalk.sdk.vk.b m(final Activity activity) {
        final com.beetalk.sdk.vk.b b = new com.beetalk.sdk.vk.b((androidx.appcompat.app.c)activity);
        b.g((X$e)new com.beetalk.sdk.plugin.impl.vk.a(this, activity));
        return b;
    }
    
    private void n(final Activity activity) {
        final Object a = this.a;
        if (a == null) {
            this.g(activity, l.y.b());
            return;
        }
        this.l(activity, a);
    }
    
    @Override
    protected void b(final Activity activity, final Object a) {
        if (a == null) {
            this.g(activity, l.y.b());
            return;
        }
        k.a("checking vk session", new Object[0]);
        this.a = a;
        if (!(activity instanceof androidx.appcompat.app.c)) {
            final f f = new f();
            f.c = this.d();
            f.a = -1;
            f.d = l.e.b();
            c.k().o(f, activity, this.d());
            return;
        }
        final com.beetalk.sdk.vk.b b = this.b;
        if (b == null) {
            final f f2 = new f();
            f2.c = this.d();
            f2.a = -1;
            f2.d = l.b2.b();
            c.k().o(f2, activity, this.d());
            return;
        }
        if (!i.r()) {
            b.d();
            return;
        }
        this.n(activity);
    }
    
    @Override
    public Integer e() {
        return 0;
    }
    
    @Override
    public boolean f(final Activity activity, final int n, final Intent intent) {
        return false;
    }
    
    @Override
    public void j(final androidx.appcompat.app.c c) {
        this.b = this.m((Activity)c);
    }
    
    protected abstract void l(final Activity p0, final Object p1);
}
