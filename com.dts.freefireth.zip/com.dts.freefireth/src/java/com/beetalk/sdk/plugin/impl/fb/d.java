package com.beetalk.sdk.plugin.impl.fb;

import n2.k;
import com.facebook.share.model.GameRequestContent$b;
import j2.a$f;
import R1.j;
import R1.g;
import com.garena.pay.android.l;
import com.beetalk.sdk.plugin.c;
import android.app.Activity;
import com.beetalk.sdk.plugin.f;

public class d extends a<d.d$c, f>
{
    @Override
    public String d() {
        return "facebook.invite";
    }
    
    @Override
    public Integer e() {
        return 2883;
    }
    
    @Override
    public void k(final Exception ex, final Activity activity) {
        c.k().o(new f(this, ex) {
            final Exception e;
            final d f;
            
            {
                super.c = f.d();
                super.a = -1;
                super.d = l.b2.b();
                super.b = ((Throwable)e).getMessage();
            }
        }, activity, this.d());
    }
    
    @Override
    public void m(final Activity activity) {
        final j2.a a = new j2.a(activity);
        ((k)a).j(super.b, (g)new g(this, activity) {
            final Activity a;
            final d b;
            
            public void a() {
                final f f = new f();
                f.c = this.b.d();
                f.a = -1;
                f.d = l.f.b();
                f.b = "Share cancelled";
                c.k().o(f, this.a, this.b.d());
            }
            
            public void b(final j j) {
                final f f = new f();
                f.c = this.b.d();
                f.a = -1;
                f.d = l.b2.b();
                if (j != null) {
                    f.b = ((Throwable)j).getMessage();
                }
                else {
                    f.b = "Share Failed";
                }
                c.k().o(f, this.a, this.b.d());
            }
            
            public void c(final a$f a$f) {
                final f f = new f();
                f.c = this.b.d();
                f.a = 0;
                f.d = l.c.b();
                f.b = "Successfully shared";
                c.k().o(f, this.a, this.b.d());
            }
        });
        ((k)a).l((Object)new GameRequestContent$b().n(((d.d$c)super.a).a).l(((d.d$c)super.a).b).a());
    }
}
