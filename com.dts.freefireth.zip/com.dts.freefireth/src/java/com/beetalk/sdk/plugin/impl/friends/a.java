package com.beetalk.sdk.plugin.impl.friends;

import com.beetalk.sdk.helper.t;
import com.garena.pay.android.l;
import org.json.JSONObject;

public abstract class a<S, T> extends com.beetalk.sdk.plugin.a<S, T>
{
    @Override
    public boolean a() {
        return false;
    }
    
    protected l k(final JSONObject jsonObject) {
        if (jsonObject == null) {
            return l.h1;
        }
        l l;
        if ((l = t.c(jsonObject)) == null) {
            l = com.garena.pay.android.l.c;
        }
        return l;
    }
}
