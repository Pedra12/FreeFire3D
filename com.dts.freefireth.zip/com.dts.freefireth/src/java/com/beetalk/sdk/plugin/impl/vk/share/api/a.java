package com.beetalk.sdk.plugin.impl.vk.share.api;

import org.json.JSONException;
import K6.h;
import org.json.JSONObject;
import H6.o;
import H6.i;
import H6.x$a;
import kotlin.jvm.internal.Intrinsics;
import H6.p;
import kotlin.Metadata;

@Metadata
public final class a extends a
{
    protected w1.a b(final p p) {
        Intrinsics.checkNotNullParameter((Object)p, "manager");
        return (w1.a)p.f(new x$a().v("users.get").b("user_ids", (Object)i.o().getValue()).c("fields", "photo_100,screen_name,first_name,last_name").z(p.h().u()).e(), (o)new a());
    }
    
    @Metadata
    private static final class a implements o
    {
        public a() {
        }
        
        public w1.a b(final JSONObject jsonObject) {
            Intrinsics.checkNotNullParameter((Object)jsonObject, "responseJson");
            try {
                final JSONObject jsonObject2 = jsonObject.getJSONArray("response").getJSONObject(0);
                final String string = jsonObject2.getString("photo_100");
                Intrinsics.checkNotNullExpressionValue((Object)string, "getString(...)");
                final String string2 = jsonObject2.getString("first_name");
                Intrinsics.checkNotNullExpressionValue((Object)string2, "getString(...)");
                final String string3 = jsonObject2.getString("last_name");
                Intrinsics.checkNotNullExpressionValue((Object)string3, "getString(...)");
                final String string4 = jsonObject2.getString("screen_name");
                Intrinsics.checkNotNullExpressionValue((Object)string4, "getString(...)");
                return new w1.a(string, string2, string3, string4);
            }
            catch (final JSONException ex) {
                throw new h((Throwable)ex);
            }
        }
    }
}
