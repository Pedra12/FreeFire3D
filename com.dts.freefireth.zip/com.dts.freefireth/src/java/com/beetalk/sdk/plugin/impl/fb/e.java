package com.beetalk.sdk.plugin.impl.fb;

import com.facebook.share.model.ShareContent$a;
import n2.k;
import com.facebook.share.model.ShareLinkContent;
import android.net.Uri;
import com.facebook.share.model.ShareLinkContent$a;
import R1.j;
import R1.g;
import android.text.TextUtils;
import com.garena.pay.android.l;
import com.beetalk.sdk.plugin.c;
import android.app.Activity;
import com.beetalk.sdk.plugin.f;

public class e extends a<t1.a, f>
{
    @Override
    public String d() {
        return "facebook.message";
    }
    
    @Override
    public Integer e() {
        return 2884;
    }
    
    @Override
    public void k(final Exception ex, final Activity activity) {
        c.k().o(new f(this, ex) {
            final Exception e;
            final e f;
            
            {
                super.c = f.d();
                super.a = -1;
                super.d = l.b2.b();
                super.b = ((Throwable)e).getMessage();
            }
        }, activity, this.d());
    }
    
    @Override
    public void m(final Activity activity) {
        final Object a = super.a;
        if (a == null || TextUtils.isEmpty((CharSequence)((t1.a)a).d)) {
            final f f = new f();
            f.c = this.d();
            f.d = l.y.b();
            f.a = -1;
            f.b = "The content url is empty";
            c.k().o(f, activity, this.d());
            return;
        }
        final A2.a a2 = new A2.a(activity);
        ((k)a2).j(super.b, (g)new g(this, activity) {
            final Activity a;
            final e b;
            
            public void a() {
                final f f = new f();
                f.c = this.b.d();
                f.d = l.f.b();
                f.a = -1;
                f.b = "Send msg cancelled";
                c.k().o(f, this.a, this.b.d());
            }
            
            public void b(final j j) {
                final f f = new f();
                f.c = this.b.d();
                f.d = l.b2.b();
                f.a = -1;
                f.b = ((Throwable)j).getMessage();
                c.k().o(f, this.a, this.b.d());
            }
            
            public void c(final y2.a a) {
                final f f = new f();
                f.c = this.b.d();
                f.a = 0;
                f.d = l.c.b();
                f.b = "Successfully send msg";
                c.k().o(f, this.a, this.b.d());
            }
        });
        final ShareLinkContent$a shareLinkContent$a = (ShareLinkContent$a)((ShareContent$a)new ShareLinkContent$a()).h(Uri.parse(((t1.a)super.a).d));
        if (A2.a.p((Class)ShareLinkContent.class)) {
            ((k)a2).l((Object)shareLinkContent$a.n());
            return;
        }
        c.k().o(this.c(l.e.b(), "Cannot show Messenger dialog"), activity, this.d());
    }
}
