package com.beetalk.sdk.plugin.impl.tiktok;

import android.text.TextUtils;
import android.content.Intent;
import android.content.Context;
import com.beetalk.sdk.exts.e;
import android.content.IntentFilter;
import android.app.Activity;
import com.beetalk.sdk.plugin.c;
import android.content.BroadcastReceiver;

public class b extends BroadcastReceiver
{
    private f a() {
        return (f)c.k().l("tiktok.share");
    }
    
    public static b b(final Activity activity) {
        final b b = new b();
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.aweme.opensdk.action.stay.in.dy");
        e.b((Context)activity, b, intentFilter, true);
        return b;
    }
    
    public void onReceive(final Context context, final Intent intent) {
        final f a = this.a();
        if (intent != null && TextUtils.equals((CharSequence)intent.getAction(), (CharSequence)"com.aweme.opensdk.action.stay.in.dy")) {
            a.t();
            return;
        }
        a.s();
    }
}
