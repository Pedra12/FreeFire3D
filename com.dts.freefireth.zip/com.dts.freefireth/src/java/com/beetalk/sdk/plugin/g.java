package com.beetalk.sdk.plugin;

import k1.b$h;
import org.json.JSONArray;
import org.json.JSONException;
import k1.b$g;
import org.json.JSONObject;
import java.util.Iterator;
import com.beetalk.sdk.helper.k;
import java.math.BigInteger;
import k1.b$d;
import k1.b$a;
import com.beetalk.sdk.networking.model.FriendGroup;
import java.util.Vector;
import java.util.List;

public class g
{
    public static Vector a(final List list) {
        final Vector vector = new Vector();
        try {
            for (final FriendGroup friendGroup : list) {
                final b$a b$a = new b$a();
                b$a.a = friendGroup.b();
                final List a = friendGroup.a();
                final List c = friendGroup.c();
                final int size = a.size();
                final int size2 = c.size();
                b$a.b = new Vector(size);
                b$a.c = new Vector(size);
                for (int i = 0; i < size; ++i) {
                    final b$d b$d = new b$d();
                    b$d.a = (String)a.get(i);
                    if (i < size2) {
                        b$d.b = new BigInteger((String)c.get(i)).toString();
                    }
                    b$a.b.add((Object)b$d.a);
                    b$a.c.add((Object)b$d);
                }
                vector.add((Object)b$a);
            }
            return vector;
        }
        catch (final Exception ex) {
            k.b(ex);
            return null;
        }
    }
    
    public static Vector b(JSONObject jsonObject) {
        final Vector vector = new Vector();
        try {
            final JSONArray jsonArray = jsonObject.getJSONArray("friends");
            for (int i = 0; i < jsonArray.length(); ++i) {
                final b$g b$g = new b$g();
                jsonObject = jsonArray.getJSONObject(i);
                ((b$h)b$g).a = jsonObject.optString("open_id");
                b$g.f = jsonObject.optInt("platform");
                ((b$h)b$g).d = jsonObject.optInt("gender");
                ((b$h)b$g).b = jsonObject.optString("nickname");
                ((b$h)b$g).c = jsonObject.optString("icon");
                vector.add((Object)b$g);
            }
            return vector;
        }
        catch (final JSONException ex) {
            k.b((Exception)ex);
            return null;
        }
    }
}
