package com.beetalk.sdk.plugin.impl.vk.share.api;

import java.util.Collection;
import org.json.JSONException;
import K6.h;
import org.json.JSONObject;
import android.os.Parcelable;
import android.os.Parcel;
import java.util.ArrayList;
import java.util.List;
import H6.q;
import java.util.concurrent.TimeUnit;
import H6.v$a;
import H6.o;
import H6.x$a;
import H6.p;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import android.net.Uri;
import org.jetbrains.annotations.NotNull;
import android.os.Parcelable$Creator;
import kotlin.Metadata;

@Metadata
public final class VKVideoAttachments extends VKMediaAttachments
{
    @NotNull
    public static final Parcelable$Creator<VKVideoAttachments> CREATOR;
    private final Uri[] b;
    
    static {
        CREATOR = (Parcelable$Creator)new a();
    }
    
    public VKVideoAttachments(@NotNull final Uri... b) {
        Intrinsics.checkNotNullParameter((Object)b, "videoUris");
        super(null);
        this.b = b;
    }
    
    private final d l(final p p) {
        return (d)p.f(new x$a().v("video.save").z(p.h().u()).e(), (o)new c());
    }
    
    private final String m(final Uri uri, final d d, final p p3) {
        return ((e)p3.e(new v$a().k(d.a()).a("video_file", uri, "video.mp4").j(TimeUnit.MINUTES.toMillis(5L)).i(3).b(), (q)null, (o)new b())).a();
    }
    
    public int describeContents() {
        return 0;
    }
    
    @Override
    public List i(final p p) {
        Intrinsics.checkNotNullParameter((Object)p, "manager");
        final Uri[] b = this.b;
        final ArrayList list = new ArrayList(b.length);
        for (int length = b.length, i = 0; i < length; ++i) {
            ((Collection)list).add((Object)this.m(b[i], this.l(p), p));
        }
        return (List)list;
    }
    
    public void writeToParcel(final Parcel parcel, final int n) {
        Intrinsics.checkNotNullParameter((Object)parcel, "out");
        final Uri[] b = this.b;
        final int length = b.length;
        parcel.writeInt(length);
        for (int i = 0; i != length; ++i) {
            parcel.writeParcelable((Parcelable)b[i], n);
        }
    }
    
    @Metadata
    public static final class a implements Parcelable$Creator<VKVideoAttachments>
    {
        public final VKVideoAttachments a(final Parcel parcel) {
            Intrinsics.checkNotNullParameter((Object)parcel, "parcel");
            final int int1 = parcel.readInt();
            final Uri[] array = new Uri[int1];
            for (int i = 0; i != int1; ++i) {
                array[i] = (Uri)parcel.readParcelable(VKVideoAttachments.class.getClassLoader());
            }
            return new VKVideoAttachments(array);
        }
        
        public final VKVideoAttachments[] b(final int n) {
            return new VKVideoAttachments[n];
        }
    }
    
    @Metadata
    private static final class b implements o
    {
        public b() {
        }
        
        public e b(final JSONObject jsonObject) {
            Intrinsics.checkNotNullParameter((Object)jsonObject, "responseJson");
            try {
                return new e(jsonObject.getLong("video_id"), jsonObject.getLong("owner_id"));
            }
            catch (final JSONException ex) {
                throw new h((Throwable)ex);
            }
        }
    }
    
    @Metadata
    private static final class c implements o
    {
        public c() {
        }
        
        public d b(final JSONObject jsonObject) {
            Intrinsics.checkNotNullParameter((Object)jsonObject, "responseJson");
            try {
                final String string = jsonObject.getJSONObject("response").getString("upload_url");
                Intrinsics.checkNotNullExpressionValue((Object)string, "getString(...)");
                return new d(string);
            }
            catch (final JSONException ex) {
                throw new h((Throwable)ex);
            }
        }
    }
    
    @Metadata
    private static final class d
    {
        private final String a;
        
        public d(@NotNull final String a) {
            Intrinsics.checkNotNullParameter((Object)a, "uploadUrl");
            this.a = a;
        }
        
        public final String a() {
            return this.a;
        }
    }
    
    @Metadata
    private static final class e
    {
        private final long a;
        private final long b;
        private final String c;
        
        public e(final long a, final long b) {
            this.a = a;
            this.b = b;
            final StringBuilder sb = new StringBuilder();
            sb.append("video");
            sb.append(b);
            sb.append("_");
            sb.append(a);
            this.c = sb.toString();
        }
        
        public final String a() {
            return this.c;
        }
    }
}
