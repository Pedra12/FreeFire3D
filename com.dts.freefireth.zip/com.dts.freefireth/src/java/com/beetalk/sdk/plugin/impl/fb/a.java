package com.beetalk.sdk.plugin.impl.fb;

import com.beetalk.sdk.plugin.GGPluginActivity;
import android.content.Intent;
import R1.e$a;
import java.util.Collection;
import com.beetalk.sdk.A0;
import com.facebook.login.y;
import R1.j;
import R1.g;
import com.facebook.login.w;
import com.facebook.AccessToken;
import android.app.Activity;
import R1.e;

public abstract class a<S, T> extends com.beetalk.sdk.plugin.a<S, T>
{
    protected Object a;
    protected e b;
    
    private boolean n(final Activity activity) {
        final AccessToken m = AccessToken.m();
        if (m != null && !m.C()) {
            this.m(activity);
            return true;
        }
        w.i().s(this.b, (g)new g(this, activity) {
            final Activity a;
            final a b;
            
            public void a() {
                this.b.k((Exception)new m1.a("Login Cancelled"), this.a);
            }
            
            public void b(final j j) {
                if (j == null) {
                    this.b.k((Exception)new m1.a("Login Failed for some reason"), this.a);
                    return;
                }
                this.b.k((Exception)j, this.a);
            }
            
            public void c(final y y) {
                if (y.a() != null) {
                    this.b.m(this.a);
                }
            }
        });
        w.i().m(activity, (Collection)A0.v());
        return true;
    }
    
    @Override
    protected void b(final Activity activity, final Object a) {
        this.a = a;
        this.b = e$a.a();
        this.n(activity);
    }
    
    @Override
    public boolean f(final Activity activity, final int n, final Intent intent) {
        return false;
    }
    
    public abstract void k(final Exception p0, final Activity p1);
    
    public boolean l(final int n, final int n2, final Intent intent, final GGPluginActivity ggPluginActivity) {
        return this.b.a(n, n2, intent);
    }
    
    public abstract void m(final Activity p0);
}
