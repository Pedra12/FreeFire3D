package com.beetalk.sdk.plugin.impl.fb;

import android.os.BaseBundle;
import android.os.Bundle;
import com.facebook.GraphRequest;
import com.facebook.h;
import com.facebook.GraphRequest$d;
import com.facebook.AccessToken;
import com.garena.pay.android.l;
import com.beetalk.sdk.plugin.c;
import org.json.JSONObject;
import android.app.Activity;
import com.beetalk.sdk.plugin.f;

public class j extends a<Void, f>
{
    private void q(final Activity activity, final String s) {
        c.k().o(new f(this, s) {
            final String e;
            final j f;
            
            {
                super.a = -1;
                super.d = l.b2.b();
                super.b = s;
                super.c = f.d();
            }
        }, activity, this.d());
    }
    
    private void r(final Activity activity, final JSONObject jsonObject) {
        c.k().o(new f(this, jsonObject) {
            final JSONObject e;
            final j f;
            
            {
                super.a = 0;
                super.d = l.c.b();
                super.b = e.toString();
                super.c = f.d();
            }
        }, activity, this.d());
    }
    
    @Override
    public String d() {
        return "facebook.request.me";
    }
    
    @Override
    public Integer e() {
        return 2885;
    }
    
    @Override
    public void k(final Exception ex, final Activity activity) {
        this.q(activity, ((Throwable)ex).getMessage());
    }
    
    @Override
    public void m(final Activity activity) {
        final GraphRequest b = GraphRequest.B(AccessToken.m(), (GraphRequest$d)new GraphRequest$d(this, activity) {
            final Activity a;
            final j b;
            
            public void a(final JSONObject jsonObject, final h h) {
                if (jsonObject == null) {
                    this.b.q(this.a, h.toString());
                    return;
                }
                this.b.r(this.a, jsonObject);
            }
        });
        final Bundle bundle = new Bundle();
        ((BaseBundle)bundle).putString("fields", "id,name,email,birthday,first_name,last_name");
        b.H(bundle);
        b.l();
    }
}
