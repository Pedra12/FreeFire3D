package com.beetalk.sdk.plugin.impl.fb;

import R1.e$a;
import com.beetalk.sdk.plugin.c;
import android.text.TextUtils;
import com.beetalk.sdk.helper.s;
import java.io.File;
import android.os.Parcelable;
import android.content.Context;
import com.beetalk.sdk.helper.t;
import com.beetalk.sdk.plugin.GGPluginActivity;
import android.content.Intent;
import com.garena.pay.android.l;
import android.app.Activity;
import android.net.Uri;
import android.util.Pair;

public class f extends a<Pair<String, String>, com.beetalk.sdk.plugin.f>
{
    private String c;
    private Uri d;
    private Uri e;
    
    @Override
    public String d() {
        return "facebook.reels";
    }
    
    @Override
    public Integer e() {
        return 2903;
    }
    
    @Override
    public void k(final Exception ex, final Activity activity) {
        String s;
        if (ex != null) {
            s = ((Throwable)ex).getMessage();
        }
        else {
            s = l.b2.d();
        }
        this.h(activity, l.b2.b(), s);
    }
    
    @Override
    public boolean l(final int n, final int n2, final Intent intent, final GGPluginActivity ggPluginActivity) {
        if (!super.l(n, n2, intent, ggPluginActivity) && n == this.e()) {
            if (n2 == -1) {
                this.h(ggPluginActivity, l.c.b(), "Successfully shared");
            }
            else if (n2 == 0) {
                this.h(ggPluginActivity, l.f.b(), "Share cancelled");
            }
            else {
                this.h(ggPluginActivity, l.b2.b(), "Share Failed");
            }
            return true;
        }
        return false;
    }
    
    @Override
    public void m(final Activity activity) {
        final Intent intent = new Intent("com.facebook.reels.SHARE_TO_REEL");
        intent.putExtra("com.facebook.platform.extra.APPLICATION_ID", t.l((Context)activity));
        intent.setDataAndType(this.d, this.c);
        final Uri e = this.e;
        if (e != null) {
            intent.putExtra("interactive_asset_uri", (Parcelable)e);
            ((Context)activity).grantUriPermission("com.facebook.katana", this.e, 1);
        }
        intent.setFlags(1);
        if (((Context)activity).getPackageManager().resolveActivity(intent, 0) != null) {
            activity.startActivityForResult(intent, (int)this.e());
            return;
        }
        this.h(activity, l.X.b(), "Share Failed");
    }
    
    protected void o(final Activity activity, final Pair pair) {
        if (pair == null) {
            this.g(activity, l.y.b());
            return;
        }
        final File file = new File((String)pair.second);
        if (!file.exists() || (this.d = s.b((Context)activity, file)) == null || (this.c = ((Context)activity).getContentResolver().getType(this.d)) == null) {
            this.g(activity, l.y.b());
            return;
        }
        if (!TextUtils.isEmpty((CharSequence)pair.first)) {
            this.e = s.b((Context)activity, new File((String)pair.first));
        }
        else {
            this.e = null;
        }
        if (!t.u("com.facebook.katana", (Context)activity)) {
            com.beetalk.sdk.plugin.c.k().o(this.c(l.d.b(), "Facebook App is not installed."), activity, this.d());
            return;
        }
        super.b = e$a.a();
        this.m(activity);
    }
}
