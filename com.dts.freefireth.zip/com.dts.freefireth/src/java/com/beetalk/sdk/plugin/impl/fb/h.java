package com.beetalk.sdk.plugin.impl.fb;

import R1.j;
import R1.g;
import android.content.Context;
import com.beetalk.sdk.helper.t;
import android.graphics.Bitmap;
import com.facebook.share.model.SharePhoto$a;
import com.facebook.share.model.SharePhotoContent$a;
import com.beetalk.sdk.helper.k;
import android.graphics.BitmapFactory;
import com.facebook.share.model.SharePhotoContent;
import com.beetalk.sdk.plugin.c;
import com.garena.pay.android.l;
import android.app.Activity;
import com.beetalk.sdk.plugin.f;
import n1.b;

public class h extends a<b, f>
{
    @Override
    public String d() {
        return "facebook.share";
    }
    
    @Override
    public Integer e() {
        return 2880;
    }
    
    @Override
    public void k(final Exception ex, final Activity activity) {
        final f f = new f();
        f.c = this.d();
        f.d = l.b2.b();
        f.a = -1;
        f.b = ((Throwable)ex).getMessage();
        c.k().o(f, activity, this.d());
    }
    
    @Override
    public void m(final Activity activity) {
        if (A2.b.p((Class)SharePhotoContent.class)) {
            final A2.b t = this.t(activity);
            Bitmap decodeByteArray = null;
            Label_0089: {
                try {
                    final Object a = super.a;
                    decodeByteArray = BitmapFactory.decodeByteArray(((b)a).f, 0, ((b)a).f.length);
                    break Label_0089;
                }
                catch (final Exception ex) {}
                catch (final OutOfMemoryError outOfMemoryError) {
                    k.c("Failed to create bitmap: out of memory", new Object[0]);
                    c.k().o(this.c(l.f2.b(), "Failed to create bitmap: out of memory"), activity, this.d());
                    return;
                }
                final Exception ex;
                k.b(ex);
                decodeByteArray = null;
            }
            if (decodeByteArray != null) {
                ((n2.k)t).l((Object)new SharePhotoContent$a().n(new SharePhoto$a().k(decodeByteArray).d()).p());
            }
            else {
                c.k().o(this.c(l.f2.b(), "Failed to create bitmap"), activity, this.d());
            }
            return;
        }
        c.k().o(this.c(l.e.b(), "Facebook App is not installed."), activity, this.d());
    }
    
    protected void s(final Activity activity, final b b) {
        if (b == null) {
            this.g(activity, l.y.b());
            return;
        }
        if (this.u() && !t.u("com.facebook.katana", (Context)activity)) {
            c.k().o(this.c(l.e.b(), "Facebook App is not installed."), activity, this.d());
            return;
        }
        super.b(activity, b);
    }
    
    protected A2.b t(final Activity activity) {
        final A2.b b = new A2.b(activity);
        ((n2.k)b).j(super.b, (g)new g(this, activity) {
            final Activity a;
            final h b;
            
            public void a() {
                c.k().o(this.b.c(l.f.b(), "User cancelled"), this.a, this.b.d());
            }
            
            public void b(final j j) {
                if (j instanceof R1.l) {
                    c.k().o(this.b.c(l.f.b(), "User cancelled"), this.a, this.b.d());
                    return;
                }
                c.k().o(this.b.c(l.b2.b(), ((Throwable)j).getMessage()), this.a, this.b.d());
            }
            
            public void c(final y2.a a) {
                c.k().o(this.b.c(l.c.b(), "Success"), this.a, this.b.d());
            }
        });
        return b;
    }
    
    protected boolean u() {
        return true;
    }
}
