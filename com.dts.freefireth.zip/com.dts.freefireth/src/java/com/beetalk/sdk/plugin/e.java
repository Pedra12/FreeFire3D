package com.beetalk.sdk.plugin;

import java.util.List;
import java.util.ArrayList;

class e implements Runnable
{
    final String a;
    final b b;
    final c c;
    
    e(final c c, final String a, final b b) {
        this.c = c;
        this.a = a;
        this.b = b;
    }
    
    public void run() {
        Object o;
        if ((o = com.beetalk.sdk.plugin.c.a(this.c).get((Object)this.a)) == null) {
            o = new ArrayList();
            com.beetalk.sdk.plugin.c.a(this.c).put((Object)this.a, o);
        }
        ((List)o).add((Object)this.b);
        final Object value = com.beetalk.sdk.plugin.c.d(this.c).get((Object)this.a);
        if (value != null) {
            this.b.onPluginResult(value);
            com.beetalk.sdk.plugin.c.d(this.c).remove((Object)this.a);
        }
    }
}
