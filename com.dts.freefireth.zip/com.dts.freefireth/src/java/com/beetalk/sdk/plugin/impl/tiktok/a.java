package com.beetalk.sdk.plugin.impl.tiktok;

import android.content.Intent;
import android.app.Activity;
import com.beetalk.sdk.plugin.f;

public abstract class a<T> extends com.beetalk.sdk.plugin.a<T, f>
{
    @Override
    public Integer e() {
        return 0;
    }
    
    @Override
    public boolean f(final Activity activity, final int n, final Intent intent) {
        return false;
    }
}
