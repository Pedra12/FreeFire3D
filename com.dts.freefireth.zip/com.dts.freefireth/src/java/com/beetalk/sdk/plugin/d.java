package com.beetalk.sdk.plugin;

import java.util.Iterator;
import java.util.List;

class d implements Runnable
{
    final b a;
    final c b;
    
    d(final c b, final b a) {
        this.b = b;
        this.a = a;
    }
    
    public void run() {
        final Iterator iterator = c.a(this.b).values().iterator();
        while (iterator.hasNext()) {
            ((List)iterator.next()).remove((Object)this.a);
        }
    }
}
