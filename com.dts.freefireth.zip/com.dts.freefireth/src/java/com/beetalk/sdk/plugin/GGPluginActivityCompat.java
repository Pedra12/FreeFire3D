package com.beetalk.sdk.plugin;

import android.os.Handler;
import android.os.Looper;
import com.beetalk.sdk.X;
import com.beetalk.sdk.s;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.app.Activity;
import androidx.appcompat.app.c;

public class GGPluginActivityCompat extends c
{
    private String g1;
    private a h1;
    
    public static void A0(final Activity activity, final String s, final int n) {
        final Intent intent = new Intent();
        intent.setClass((Context)activity, (Class)GGPluginActivityCompat.class);
        intent.putExtra("plugin_id", s);
        activity.startActivityForResult(intent, n);
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        if (s.w() == null) {
            X.U((Activity)this);
        }
        this.g1 = ((Activity)this).getIntent().getStringExtra("plugin_id");
        (this.h1 = com.beetalk.sdk.plugin.c.k().l(this.g1)).j(this);
        if (bundle == null) {
            new Handler(Looper.getMainLooper()).postDelayed((Runnable)new Runnable(this) {
                final GGPluginActivityCompat a;
                
                public void run() {
                    com.beetalk.sdk.plugin.c.k().p(this.a.h1, (Activity)this.a);
                }
            }, 140L);
        }
    }
}
