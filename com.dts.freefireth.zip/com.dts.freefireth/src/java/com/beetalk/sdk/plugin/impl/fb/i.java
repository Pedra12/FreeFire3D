package com.beetalk.sdk.plugin.impl.fb;

import n2.k;
import android.net.Uri;
import com.garena.pay.android.l;
import com.facebook.share.model.ShareVideo$a;
import com.facebook.share.model.ShareVideoContent$a;
import android.content.Context;
import com.beetalk.sdk.helper.s;
import java.io.File;
import n1.b;
import android.app.Activity;

public class i extends h
{
    @Override
    public String d() {
        return "facebook.share.video";
    }
    
    @Override
    public Integer e() {
        return 2904;
    }
    
    @Override
    public void m(final Activity activity) {
        final File file = new File(((b)super.a).g);
        if (file.exists()) {
            final Uri b = s.b((Context)activity, file);
            if (b != null) {
                ((k)this.t(activity)).l((Object)new ShareVideoContent$a().s(new ShareVideo$a().h(b).d()).n());
                return;
            }
        }
        this.g(activity, l.y.b());
    }
    
    @Override
    protected boolean u() {
        return true;
    }
}
