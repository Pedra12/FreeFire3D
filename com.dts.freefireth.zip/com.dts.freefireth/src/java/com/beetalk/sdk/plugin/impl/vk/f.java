package com.beetalk.sdk.plugin.impl.vk;

import android.os.Parcelable;
import W.X;
import android.content.res.ColorStateList;
import Q2.c;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.widget.EditText;
import kotlin.text.StringsKt;
import android.text.SpannableString;
import java.util.ArrayList;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.widget.ImageView;
import com.beetalk.sdk.helper.v;
import com.beetalk.sdk.plugin.b;
import R2.a;
import com.garena.pay.android.l;
import com.beetalk.sdk.helper.k;
import g2.o;
import android.view.View;
import android.view.View$OnClickListener;
import com.beetalk.sdk.vk.VkShareDialogParam;
import android.widget.TextView;

class f
{
    private TextView a;
    private VkShareDialogParam b;
    private e.a c;
    private final d d;
    View$OnClickListener e;
    
    public f(final d d) {
        this.e = (View$OnClickListener)new View$OnClickListener() {
            final f a;
            
            public void onClick(final View view) {
                this.a.j(true);
                this.a.b.o().k((g2.f)new g2.f(this) {
                    e.a a = b.a.c;
                    final f$c b;
                    
                    public Void b(final o o) {
                        if (o.u()) {
                            final Exception q = o.q();
                            if (q != null) {
                                k.c(((Throwable)q).getLocalizedMessage(), new Object[0]);
                            }
                            final e.a a = this.a;
                            if (a != null) {
                                a.b(l.l);
                            }
                        }
                        else {
                            final Integer n = (Integer)o.r();
                            if (n == null) {
                                k.i("post succeeds, but post id is null", new Object[0]);
                                final e.a a2 = this.a;
                                if (a2 != null) {
                                    a2.b(l.b2);
                                }
                                return null;
                            }
                            final e.a c = this.b.a.c;
                            if (c != null) {
                                c.c(n);
                            }
                            this.b.a.d.dismissAllowingStateLoss();
                        }
                        this.b.a.j(false);
                        return null;
                    }
                }, o.m);
            }
        };
        this.d = d;
    }
    
    private void e(final a a) {
        com.beetalk.sdk.plugin.impl.vk.l.g((b)new b<w1.a>(this, a) {
            final a a;
            final f b;
            
            public void a(final w1.a a) {
                v.c(a.a()).d().a(this.a.b);
                final TextView d = this.a.d;
                final StringBuilder sb = new StringBuilder();
                sb.append(a.b());
                sb.append(" ");
                sb.append(a.c());
                d.setText((CharSequence)sb.toString());
                this.a.k.setText((CharSequence)a.d());
            }
        });
    }
    
    private void j(final boolean b) {
        final TextView a = this.a;
        if (a != null) {
            a.setEnabled(b ^ true);
        }
    }
    
    private void l(final a a) {
        final ImageView j = a.j;
        int visibility;
        if (this.b.l() != null) {
            final v.a e = v.b(this.b.l()).e(6.0f);
            visibility = 0;
            e.c(false).a(j);
        }
        else {
            visibility = 8;
        }
        j.setVisibility(visibility);
    }
    
    private void m(final a a) {
        final EditText i = a.i;
        final String n = this.b.n();
        final String m = this.b.m();
        if (TextUtils.isEmpty((CharSequence)n) && TextUtils.isEmpty((CharSequence)m)) {
            ((View)i).setVisibility(8);
            return;
        }
        final SpannableStringBuilder text = new SpannableStringBuilder();
        final ArrayList list = new ArrayList();
        if (!TextUtils.isEmpty((CharSequence)n)) {
            list.add((Object)new SpannableString((CharSequence)n));
        }
        if (!TextUtils.isEmpty((CharSequence)m)) {
            list.add((Object)com.beetalk.sdk.plugin.impl.vk.l.d(m));
        }
        int n2;
        for (int size = list.size(), j = 0; j < size; j = n2) {
            final Object value = list.get(j);
            n2 = j + 1;
            final CharSequence charSequence = (CharSequence)value;
            j = n2;
            if (!TextUtils.isEmpty(charSequence)) {
                text.append(charSequence).append((CharSequence)" ");
            }
        }
        StringsKt.M0((CharSequence)text);
        ((View)i).setEnabled(true);
        ((TextView)i).setText((CharSequence)text);
    }
    
    public void f() {
        final e.a c = this.c;
        if (c != null) {
            c.a();
        }
    }
    
    public View g(final LayoutInflater layoutInflater, final ViewGroup viewGroup, final Bundle bundle) {
        final a c = R2.a.c(layoutInflater);
        ((View)c.c).setOnClickListener((View$OnClickListener)new View$OnClickListener(this) {
            final f a;
            
            public void onClick(final View view) {
                this.a.d.dismissAllowingStateLoss();
                if (this.a.c != null) {
                    this.a.c.a();
                }
            }
        });
        c.f.setImageResource(Q2.c.c);
        X.t0((View)(this.a = c.h), ColorStateList.valueOf(com.beetalk.sdk.plugin.impl.vk.l.c()));
        this.a.setText((CharSequence)"Create");
        ((View)this.a).setOnClickListener(this.e);
        if (bundle != null) {
            this.b = (VkShareDialogParam)bundle.getParcelable("SharingParam");
        }
        this.l(c);
        this.e(c);
        this.m(c);
        return (View)c.b();
    }
    
    public void h(final Bundle bundle) {
        bundle.putParcelable("SharingParam", (Parcelable)this.b);
    }
    
    public void i(final VkShareDialogParam b) {
        this.b = b;
    }
    
    public void k(final e.a c) {
        this.c = c;
    }
    
    public interface d
    {
        void dismissAllowingStateLoss();
    }
}
