package com.beetalk.sdk.plugin.impl.vk;

import kotlin.jvm.functions.Function0;
import com.vk.id.vksdksupport.WithVKIDTokenKt;
import g2.f;
import java.util.concurrent.Callable;
import java.io.InputStream;
import java.io.Closeable;
import android.graphics.BitmapFactory;
import java.net.URL;
import android.webkit.URLUtil;
import s7.p$a;
import com.beetalk.sdk.helper.k;
import s7.q;
import android.provider.MediaStore$Images$Media;
import android.content.ContentResolver;
import android.os.Build$VERSION;
import s7.p;
import com.beetalk.sdk.X;
import android.graphics.Bitmap;
import android.net.Uri;
import android.text.style.ForegroundColorSpan;
import kotlin.jvm.internal.Intrinsics;
import android.text.SpannableString;
import android.graphics.Color;
import kotlin.Unit;
import g2.o;
import com.beetalk.sdk.plugin.b;
import w1.a;
import kotlin.Metadata;

@Metadata
public final class l
{
    public static final int c() {
        return Color.parseColor("#0077FF");
    }
    
    public static final SpannableString d(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "<this>");
        final SpannableString spannableString = new SpannableString((CharSequence)s);
        spannableString.setSpan((Object)new ForegroundColorSpan(Color.parseColor("#0077FF")), 0, s.length(), 17);
        return spannableString;
    }
    
    public static final Bitmap e(final Uri uri) {
        Intrinsics.checkNotNullParameter((Object)uri, "uri");
        Object o = X.M().getContentResolver();
        Object o2 = null;
        Label_0067: {
            Label_0055: {
                Label_0047: {
                    try {
                        final p$a b = p.b;
                        if (Build$VERSION.SDK_INT >= 28) {
                            o = i.a(h.a((ContentResolver)o, uri));
                            break Label_0047;
                        }
                    }
                    finally {
                        break Label_0055;
                    }
                    o = MediaStore$Images$Media.getBitmap((ContentResolver)o, uri);
                }
                o2 = p.b(o);
                break Label_0067;
            }
            final p$a b2 = p.b;
            final Throwable t;
            o2 = p.b(q.a(t));
        }
        if (p.d(o2) != null) {
            final StringBuilder sb = new StringBuilder();
            sb.append("decode uri to bitmap failed, ");
            sb.append((Object)uri);
            k.i(sb.toString(), new Object[0]);
        }
        Object o3 = o2;
        if (p.f(o2)) {
            o3 = null;
        }
        return (Bitmap)o3;
    }
    
    public static final Bitmap f(final Uri uri) {
        Intrinsics.checkNotNullParameter((Object)uri, "uri");
        final String string = uri.toString();
        Intrinsics.checkNotNullExpressionValue((Object)string, "toString(...)");
        if (URLUtil.isNetworkUrl(string)) {
            final Bitmap bitmap = null;
            Object o = null;
            Label_0091: {
                Label_0079: {
                    try {
                        final p$a b = p.b;
                        final InputStream openStream;
                        o = (openStream = new URL(string).openStream());
                        final Bitmap bitmap2 = BitmapFactory.decodeStream(openStream);
                        final Object o2 = o;
                        final Throwable t = null;
                        C7.b.a((Closeable)o2, t);
                        final Bitmap bitmap3 = bitmap2;
                        o = p.b((Object)bitmap3);
                        break Label_0091;
                    }
                    finally {
                        final Object o3;
                        o = o3;
                        break Label_0079;
                    }
                    try {
                        final InputStream openStream = (InputStream)o;
                        final Bitmap bitmap2 = BitmapFactory.decodeStream(openStream);
                        final Object o2 = o;
                        final Throwable t = null;
                        C7.b.a((Closeable)o2, t);
                        final Bitmap bitmap3 = bitmap2;
                        o = p.b((Object)bitmap3);
                        break Label_0091;
                    }
                    finally {
                        try {}
                        finally {
                            final Throwable t2;
                            C7.b.a((Closeable)o, t2);
                        }
                    }
                }
                final p$a b2 = p.b;
                o = p.b(q.a((Throwable)o));
            }
            if (p.d(o) != null) {
                final StringBuilder sb = new StringBuilder();
                sb.append("failed to load ");
                sb.append((Object)uri);
                k.i(sb.toString(), new Object[0]);
            }
            Object o4;
            if (p.f(o)) {
                o4 = bitmap;
            }
            else {
                o4 = o;
            }
            return (Bitmap)o4;
        }
        return e(uri);
    }
    
    public static final void g(final b b) {
        Intrinsics.checkNotNullParameter((Object)b, "onSuccess");
        o.j.j((Callable)new j()).k((f)new com.beetalk.sdk.plugin.impl.vk.k(b), o.m);
    }
    
    private static final a h() {
        return (a)H6.i.j(WithVKIDTokenKt.withVKIDToken$default((M6.a)new com.beetalk.sdk.plugin.impl.vk.share.api.a(), (Function0)null, 1, (Object)null));
    }
    
    private static final Unit i(final b b, final o o) {
        Intrinsics.checkNotNullParameter((Object)b, "$onSuccess");
        Intrinsics.checkNotNullParameter((Object)o, "it");
        if (!o.u()) {
            final a a = (a)o.r();
            if (a != null) {
                b.onPluginResult((Object)a);
            }
        }
        return Unit.a;
    }
}
