package com.beetalk.sdk.plugin;

public interface b<T>
{
    void onPluginResult(final Object p0);
}
