package com.beetalk.sdk.plugin.impl.fb;

import android.graphics.Bitmap;
import R1.j;
import com.facebook.share.model.SharePhoto$a;
import com.facebook.share.model.SharePhotoContent$a;
import com.beetalk.sdk.helper.k;
import android.graphics.BitmapFactory;
import com.facebook.share.model.SharePhotoContent;
import com.garena.pay.android.l;
import com.beetalk.sdk.plugin.c;
import android.app.Activity;
import com.beetalk.sdk.plugin.f;

public class g extends a<byte[], f>
{
    @Override
    public String d() {
        return "facebook.messenger.send.image";
    }
    
    @Override
    public Integer e() {
        return 2902;
    }
    
    @Override
    public void k(final Exception ex, final Activity activity) {
        c.k().o(new f(this, ex) {
            final Exception e;
            final g f;
            
            {
                super.c = f.d();
                super.a = -1;
                super.d = l.b2.b();
                super.b = ((Throwable)e).getMessage();
            }
        }, activity, this.d());
    }
    
    @Override
    public void m(final Activity activity) {
        if (super.a == null) {
            final f f = new f();
            f.c = this.d();
            f.d = l.y.b();
            f.a = -1;
            f.b = "The content url is empty";
            c.k().o(f, activity, this.d());
            return;
        }
        if (A2.a.p((Class)SharePhotoContent.class)) {
            Bitmap decodeByteArray = null;
            Label_0137: {
                try {
                    final Object a = super.a;
                    decodeByteArray = BitmapFactory.decodeByteArray((byte[])a, 0, ((byte[])a).length);
                    break Label_0137;
                }
                catch (final Exception ex) {}
                catch (final OutOfMemoryError outOfMemoryError) {
                    k.c("Failed to create bitmap: out of memory", new Object[0]);
                    c.k().o(this.c(l.f2.b(), "Failed to create bitmap: out of memory"), activity, this.d());
                    return;
                }
                final Exception ex;
                k.b(ex);
                decodeByteArray = null;
            }
            if (decodeByteArray != null) {
                final SharePhotoContent$a n = new SharePhotoContent$a().n(new SharePhoto$a().k(decodeByteArray).d());
                final A2.a a2 = new A2.a(activity);
                ((n2.k)a2).j(super.b, (R1.g)new R1.g(this, activity) {
                    final Activity a;
                    final g b;
                    
                    public void a() {
                        final f f = new f();
                        f.c = this.b.d();
                        f.d = l.f.b();
                        f.a = -1;
                        f.b = "Send msg cancelled";
                        c.k().o(f, this.a, this.b.d());
                    }
                    
                    public void b(final j j) {
                        final f f = new f();
                        f.c = this.b.d();
                        f.d = l.b2.b();
                        f.a = -1;
                        f.b = ((Throwable)j).getMessage();
                        c.k().o(f, this.a, this.b.d());
                    }
                    
                    public void c(final y2.a a) {
                        final f f = new f();
                        f.c = this.b.d();
                        f.a = 0;
                        f.d = l.c.b();
                        f.b = "Successfully send msg";
                        c.k().o(f, this.a, this.b.d());
                    }
                });
                ((n2.k)a2).l((Object)n.p());
            }
            else {
                c.k().o(this.c(l.f2.b(), "Failed to create bitmap"), activity, this.d());
            }
            return;
        }
        c.k().o(this.c(l.e.b(), "Cannot show Messenger dialog"), activity, this.d());
    }
}
