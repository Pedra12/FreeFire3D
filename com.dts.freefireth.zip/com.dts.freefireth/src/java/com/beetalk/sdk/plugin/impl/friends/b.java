package com.beetalk.sdk.plugin.impl.friends;

import c1.i;
import com.beetalk.sdk.networking.model.GetFriendGroupsResponse;
import com.beetalk.sdk.plugin.c;
import com.beetalk.sdk.plugin.g;
import com.garena.pay.android.l;
import com.beetalk.sdk.helper.t;
import com.beetalk.sdk.networking.service.H;
import java.util.concurrent.Callable;
import android.content.Intent;
import android.app.Activity;
import k1.b$b;

public class b extends a<Void, b$b>
{
    @Override
    public String d() {
        return "msdk.load.friendgroups.list";
    }
    
    @Override
    public Integer e() {
        return 2897;
    }
    
    @Override
    public boolean f(final Activity activity, final int n, final Intent intent) {
        return false;
    }
    
    protected void l(final Activity activity, final Void void1) {
        i.f((Callable)new Callable<Void>(this, activity) {
            final Activity a;
            final b b;
            
            public Void a() {
                final GetFriendGroupsResponse b = H.b();
                l l;
                if ((l = t.b(b.a())) == null) {
                    l = com.garena.pay.android.l.c;
                }
                final b$b b$b = new b$b();
                b$b.a = l.b();
                final l c = com.garena.pay.android.l.c;
                if (l == c) {
                    b$b.a = c.b();
                    b$b.b = g.a(b.b());
                }
                com.beetalk.sdk.plugin.c.k().o(b$b, this.a, this.b.d());
                return null;
            }
        });
    }
}
