package com.beetalk.sdk.plugin;

import com.beetalk.sdk.helper.k;
import android.app.Activity;
import com.beetalk.sdk.plugin.impl.fb.i;
import com.beetalk.sdk.plugin.impl.fb.f;
import com.beetalk.sdk.plugin.impl.fb.g;
import com.beetalk.sdk.plugin.impl.fb.j;
import com.beetalk.sdk.plugin.impl.fb.h;
import com.beetalk.sdk.plugin.impl.friends.d;
import com.beetalk.sdk.plugin.impl.friends.e;
import java.util.Iterator;
import java.util.List;
import android.os.Looper;
import java.util.HashMap;
import android.os.Handler;

public class c
{
    private static volatile c g;
    private final Handler a;
    private final HashMap b;
    private final HashMap c;
    private final HashMap d;
    private final HashMap e;
    private final HashMap f;
    
    private c() {
        this.b = new HashMap();
        this.c = new HashMap();
        this.d = new HashMap();
        this.e = new HashMap();
        this.f = new HashMap();
        this.m();
        this.a = new Handler(Looper.getMainLooper());
    }
    
    private boolean i(final String s, final Object o) {
        final List list = (List)this.d.get((Object)s);
        if (list != null && list.size() > 0) {
            final Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ((b)iterator.next()).onPluginResult(o);
            }
            return true;
        }
        return false;
    }
    
    private boolean j(final String s, final Object o) {
        final b b = (b)this.c.remove((Object)s);
        if (b != null) {
            b.onPluginResult(o);
            return true;
        }
        return false;
    }
    
    public static c k() {
        if (c.g == null) {
            final Class<c> clazz;
            monitorenter(clazz = c.class);
            Label_0036: {
                try {
                    if (c.g == null) {
                        c.g = new c();
                    }
                    break Label_0036;
                }
                finally {
                    monitorexit(clazz);
                    monitorexit(clazz);
                }
            }
        }
        return c.g;
    }
    
    private void m() {
        this.h((a)new v1.b());
        this.h(new com.beetalk.sdk.plugin.impl.friends.b());
        this.h(new e());
        this.h(new d());
        this.h((a)new u1.b());
        this.h((a)new u1.a());
        this.h((a)new u1.c());
        this.h(new h());
        this.h(new j());
        this.h(new com.beetalk.sdk.plugin.impl.fb.d());
        this.h(new com.beetalk.sdk.plugin.impl.fb.e());
        this.h(new com.beetalk.sdk.plugin.impl.misc.c());
        this.h(new com.beetalk.sdk.plugin.impl.fb.b());
        this.h(new com.beetalk.sdk.plugin.impl.fb.c());
        this.h(new g());
        this.h(new f());
        this.h(new i());
        this.h(new com.beetalk.sdk.plugin.impl.vk.c());
        this.h(new com.beetalk.sdk.plugin.impl.line.a());
        this.h(new com.beetalk.sdk.plugin.impl.tiktok.f());
    }
    
    private void q(final Runnable runnable) {
        if (Thread.currentThread() == Looper.getMainLooper().getThread()) {
            runnable.run();
            return;
        }
        this.a.post(runnable);
    }
    
    public void h(final a a) {
        if (!this.b.containsKey((Object)a.d())) {
            this.b.put((Object)a.d(), (Object)a);
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Plugin Already exists for Key: ");
        sb.append(a.d());
        throw new ExceptionInInitializerError(sb.toString());
    }
    
    public a l(final String s) {
        return (a)this.b.get((Object)s);
    }
    
    public void n(final Activity activity, final String s, final Object o, final b b) {
        this.q((Runnable)new Runnable(this, s, b, o, activity) {
            final String a;
            final b b;
            final Object c;
            final Activity d;
            final c e;
            
            public void run() {
                k.i("invokePlugin: %s", this.a);
                this.e.c.put((Object)this.a, (Object)this.b);
                this.e.f.put((Object)this.a, this.c);
                final a l = this.e.l(this.a);
                if (!l.a()) {
                    this.e.p(l, this.d);
                    return;
                }
                if ("vk.share".equals((Object)this.a)) {
                    GGPluginActivityCompat.A0(this.d, this.a, l.e());
                    return;
                }
                GGPluginActivity.b(this.d, this.a, l.e());
            }
        });
    }
    
    public void o(final Object o, final Activity activity, final String s) {
        this.q((Runnable)new Runnable(this, s, activity, o) {
            final String a;
            final Activity b;
            final Object c;
            final c d;
            
            public void run() {
                if (((a)this.d.b.get((Object)this.a)).a()) {
                    this.b.finish();
                }
                final boolean g = this.d.j(this.a, this.c);
                final boolean f = this.d.i(this.a, this.c);
                if (!g && !f) {
                    this.d.e.put((Object)this.a, this.c);
                    return;
                }
                this.d.e.remove((Object)this.a);
            }
        });
    }
    
    void p(final a a, final Activity activity) {
        this.q((Runnable)new Runnable(this, a, activity) {
            final a a;
            final Activity b;
            final c c;
            
            public void run() {
                this.a.b(this.b, this.c.f.remove((Object)this.a.d()));
            }
        });
    }
}
