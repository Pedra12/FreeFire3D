package com.beetalk.sdk.plugin.impl.fb;

import com.facebook.share.model.ShareContent$a;
import n2.k;
import com.facebook.share.model.ShareLinkContent$a;
import android.net.Uri;
import android.text.TextUtils;
import com.garena.pay.android.l;
import com.beetalk.sdk.plugin.f;
import com.beetalk.sdk.plugin.c;
import android.app.Activity;

public class b extends h
{
    @Override
    public String d() {
        return "facebook.share.fallback";
    }
    
    @Override
    public Integer e() {
        return 2881;
    }
    
    @Override
    public void k(final Exception ex, final Activity activity) {
        c.k().o(new f(this, ex) {
            final Exception e;
            final b f;
            
            {
                super.a = -1;
                super.d = l.b2.b();
                super.b = ((Throwable)e).getMessage();
                super.c = "facebook.share.fallback";
            }
        }, activity, this.d());
    }
    
    @Override
    public void m(final Activity activity) {
        final n1.b b = (n1.b)super.a;
        try {
            Uri parse;
            if (!TextUtils.isEmpty((CharSequence)b.d)) {
                parse = Uri.parse(b.d);
            }
            else {
                parse = null;
            }
            ((k)this.t(activity)).l((Object)((ShareLinkContent$a)((ShareContent$a)new ShareLinkContent$a()).h(parse)).n());
        }
        catch (final Exception ex) {
            c.k().o(this.c(l.t1.b(), "Error Uri."), activity, this.d());
        }
    }
    
    @Override
    protected boolean u() {
        return false;
    }
}
