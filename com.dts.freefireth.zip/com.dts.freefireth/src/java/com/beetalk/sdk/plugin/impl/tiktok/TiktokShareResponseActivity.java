package com.beetalk.sdk.plugin.impl.tiktok;

import F1.d;
import android.os.Bundle;
import android.content.Intent;
import M1.b;
import com.beetalk.sdk.plugin.c;
import L1.a;
import android.app.Activity;

public class TiktokShareResponseActivity extends Activity implements a
{
    private G1.a a;
    
    private f d() {
        return (f)c.k().l("tiktok.share");
    }
    
    public void a(final b b) {
        this.d().r(b);
        this.finish();
    }
    
    public void b(final M1.a a) {
    }
    
    public void c(final Intent intent) {
        this.d().q(intent);
        this.finish();
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        (this.a = d.a((Activity)this)).a(this.getIntent(), (a)this);
    }
}
