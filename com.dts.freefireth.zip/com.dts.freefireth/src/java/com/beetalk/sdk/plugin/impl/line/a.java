package com.beetalk.sdk.plugin.impl.line;

import android.net.Uri;
import android.content.ActivityNotFoundException;
import com.beetalk.sdk.helper.k;
import android.text.TextUtils;
import android.os.Parcelable;
import android.content.Context;
import com.beetalk.sdk.helper.s;
import java.io.File;
import com.garena.pay.android.l;
import android.content.Intent;
import android.app.Activity;
import com.beetalk.sdk.plugin.f;

public class a extends com.beetalk.sdk.plugin.a<o1.a, f>
{
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public String d() {
        return "line.share";
    }
    
    @Override
    public Integer e() {
        return null;
    }
    
    @Override
    public boolean f(final Activity activity, final int n, final Intent intent) {
        return false;
    }
    
    protected void k(final Activity activity, final o1.a a) {
        if (a == null) {
            this.g(activity, l.y.b());
            return;
        }
        final Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND");
        intent.setPackage("jp.naver.line.android");
        final int n = a$a.a[((Enum)a.a).ordinal()];
        if (n != 1) {
            if (n != 2) {
                if (n == 3) {
                    intent.setType("video/*");
                    final Uri b = s.b((Context)activity, new File(a.e));
                    if (b == null) {
                        this.g(activity, l.y.b());
                        return;
                    }
                    intent.putExtra("android.intent.extra.STREAM", (Parcelable)b);
                }
            }
            else {
                intent.setType("image/*");
                final Uri b2 = s.b((Context)activity, new File(a.d));
                if (b2 == null) {
                    this.g(activity, l.y.b());
                    return;
                }
                intent.putExtra("android.intent.extra.STREAM", (Parcelable)b2);
            }
        }
        else {
            intent.setType("text/plain");
            final boolean empty = TextUtils.isEmpty((CharSequence)a.b);
            String string = "";
            if (!empty) {
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(a.b);
                string = sb.toString();
            }
            String string2 = string;
            if (!TextUtils.isEmpty((CharSequence)a.c)) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(string);
                sb2.append("\n");
                sb2.append(a.c);
                string2 = sb2.toString();
            }
            intent.putExtra("android.intent.extra.TEXT", string2);
        }
        try {
            activity.startActivity(intent);
            this.g(activity, l.c.b());
        }
        catch (final ActivityNotFoundException ex) {
            k.b((Exception)ex);
            k.a("line not installed", new Object[0]);
            this.g(activity, l.d.b());
        }
    }
}
