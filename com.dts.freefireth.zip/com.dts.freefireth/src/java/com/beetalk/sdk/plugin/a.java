package com.beetalk.sdk.plugin;

import android.content.Intent;
import com.garena.pay.android.l;
import android.app.Activity;

public abstract class a<S, T>
{
    public boolean a() {
        return true;
    }
    
    protected abstract void b(final Activity p0, final Object p1);
    
    protected f c(final int n, final String s) {
        return new f(this, n, s) {
            final int e;
            final String f;
            final a g;
            
            {
                super.d = a;
                super.c = g.d();
                super.b = s;
                if (a == l.c.b()) {
                    a = 0;
                }
                else {
                    a = -1;
                }
                super.a = a;
            }
        };
    }
    
    public abstract String d();
    
    public abstract Integer e();
    
    public abstract boolean f(final Activity p0, final int p1, final Intent p2);
    
    protected void g(final Activity activity, final int n) {
        this.h(activity, n, "");
    }
    
    protected void h(final Activity activity, final int n, final String s) {
        c.k().o(this.c(n, s), activity, this.d());
    }
    
    protected void i(final Activity activity, final l l) {
        this.h(activity, l.b(), l.d());
    }
    
    public void j(final androidx.appcompat.app.c c) {
    }
}
