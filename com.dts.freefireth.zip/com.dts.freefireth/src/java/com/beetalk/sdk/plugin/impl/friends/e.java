package com.beetalk.sdk.plugin.impl.friends;

import c1.i;
import com.beetalk.sdk.networking.model.GetFriendGroupsResponse;
import com.beetalk.sdk.plugin.c;
import com.beetalk.sdk.plugin.g;
import com.garena.pay.android.l;
import com.beetalk.sdk.helper.t;
import com.beetalk.sdk.networking.service.H;
import java.util.concurrent.Callable;
import android.content.Intent;
import android.app.Activity;
import k1.b$b;

public class e extends a<Void, b$b>
{
    @Override
    public String d() {
        return "msdk.load.inapp.friendgroups.list";
    }
    
    @Override
    public Integer e() {
        return 2898;
    }
    
    @Override
    public boolean f(final Activity activity, final int n, final Intent intent) {
        return false;
    }
    
    protected void l(final Activity activity, final Void void1) {
        i.f((Callable)new Callable<Void>(this, new b$b(), activity) {
            final b$b a;
            final Activity b;
            final e c;
            
            public Void a() {
                final GetFriendGroupsResponse a = H.a();
                l l;
                if ((l = t.b(a.a())) == null) {
                    l = com.garena.pay.android.l.c;
                }
                this.a.a = l.b();
                final l c = com.garena.pay.android.l.c;
                if (l == c) {
                    this.a.a = c.b();
                    this.a.b = g.a(a.b());
                }
                com.beetalk.sdk.plugin.c.k().o(this.a, this.b, this.c.d());
                return null;
            }
        });
    }
}
