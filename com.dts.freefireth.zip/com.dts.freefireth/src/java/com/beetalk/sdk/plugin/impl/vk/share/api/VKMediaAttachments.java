package com.beetalk.sdk.plugin.impl.vk.share.api;

import java.util.List;
import H6.p;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.Metadata;
import android.os.Parcelable;

@Metadata
public abstract class VKMediaAttachments implements Parcelable
{
    public static final a a;
    
    static {
        a = new a(null);
    }
    
    private VKMediaAttachments() {
    }
    
    public abstract List i(final p p0);
    
    @Metadata
    public static final class a
    {
        private a() {
        }
    }
}
