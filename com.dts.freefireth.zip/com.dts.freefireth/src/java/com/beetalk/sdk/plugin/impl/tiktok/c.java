package com.beetalk.sdk.plugin.impl.tiktok;

import com.beetalk.sdk.helper.k;
import F1.d;
import F1.e;
import android.text.TextUtils;
import com.beetalk.sdk.helper.t;
import android.content.Context;

public class c
{
    private c() {
    }
    
    public static void a(final Context context) {
        final String n = t.n(context);
        if (!TextUtils.isEmpty((CharSequence)n)) {
            d.b(new e(n));
            return;
        }
        k.l("Tiktok Secret Key not found", new Object[0]);
    }
}
