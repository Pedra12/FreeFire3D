package com.beetalk.sdk.plugin;

import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;

public class f
{
    public int a;
    public String b;
    public String c;
    public int d;
    
    @Retention(RetentionPolicy.SOURCE)
    @interface a {
    }
}
