package com.beetalk.sdk.plugin.impl.vk.share.api;

import org.json.JSONException;
import K6.h;
import org.json.JSONObject;
import java.util.List;
import H6.o;
import kotlin.jvm.functions.Function1;
import java.util.Collection;
import kotlin.collections.CollectionsKt;
import G7.C;
import H6.x$a;
import H6.p;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import kotlin.Metadata;
import M6.a;

@Metadata
public final class b extends M6.a
{
    private final String a;
    private final VKMediaAttachments b;
    private final String c;
    private final int d;
    private final boolean e;
    private final boolean f;
    
    public b(@NotNull final String a, final VKMediaAttachments b, final String c, final int d, final boolean e, final boolean f) {
        Intrinsics.checkNotNullParameter((Object)a, "message");
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    protected Integer b(final p p) {
        Intrinsics.checkNotNullParameter((Object)p, "manager");
        final x$a z = new x$a().v("wall.post").c("message", this.a).b("friends_only", (Object)(int)(this.e ? 1 : 0)).b("from_group", (Object)(int)(this.f ? 1 : 0)).z(p.h().u());
        final int d = this.d;
        if (d != 0) {
            z.b("owner_id", (Object)d);
        }
        final C c = new C();
        final VKMediaAttachments b = this.b;
        Object i;
        if (b != null) {
            i = b.i(p);
        }
        else {
            i = null;
        }
        Object k = i;
        if (i == null) {
            k = CollectionsKt.k();
        }
        c.a = k;
        final String c2 = this.c;
        if (c2 != null) {
            final List o0 = CollectionsKt.o0((Collection)k);
            o0.add((Object)c2);
            c.a = o0;
        }
        z.c("attachments", CollectionsKt.V((Iterable)c.a, (CharSequence)",", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null));
        return (Integer)p.f(z.e(), (o)new a());
    }
    
    @Metadata
    private static final class a implements o
    {
        public a() {
        }
        
        public Integer b(final JSONObject jsonObject) {
            Intrinsics.checkNotNullParameter((Object)jsonObject, "responseJson");
            try {
                return jsonObject.getJSONObject("response").getInt("post_id");
            }
            catch (final JSONException ex) {
                throw new h((Throwable)ex);
            }
        }
    }
}
