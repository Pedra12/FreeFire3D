package com.beetalk.sdk;

import android.content.Context;
import M.f;
import o6.m;
import com.linecorp.linesdk.auth.LineAuthenticationParams$c;
import com.linecorp.linesdk.LineCredential;
import com.linecorp.linesdk.auth.LineLoginResult;
import android.text.TextUtils;
import com.linecorp.linesdk.auth.a;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.DialogInterface$OnCancelListener;
import Q2.e;
import android.app.Dialog;
import java.util.concurrent.Callable;
import c1.i;
import o1.c;
import com.garena.pay.android.l;
import com.beetalk.sdk.helper.k;
import com.beetalk.sdk.networking.service.j;

public class r0 extends g
{
    public r0(final d d) {
        super(d);
    }
    
    private i e(final String s) {
        return i.f((Callable)new q0(this, super.a.j(), s));
    }
    
    private void f(final String s) {
        final Dialog dialog = new Dialog(super.a.g(), Q2.g.a);
        dialog.setContentView(e.e);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setOnCancelListener((DialogInterface$OnCancelListener)new DialogInterface$OnCancelListener(this) {
            final r0 a;
            
            public void onCancel(final DialogInterface dialogInterface) {
                this.a.a.l(d.e.a(l.f.b()));
            }
        });
        while (true) {
            try {
                dialog.show();
                this.e(s).l((c1.g)new c1.g(this, dialog) {
                    final Dialog a;
                    final r0 b;
                    
                    public Void b(final i i) {
                        try {
                            this.a.dismiss();
                        }
                        catch (final Exception ex) {}
                        if (i.z()) {
                            k.b(i.u());
                            this.b.a.l(d.e.c("error", ((Throwable)i.u()).getMessage(), l.h.b()));
                        }
                        else {
                            this.b.a.l((d.e)i.v());
                        }
                        return null;
                    }
                }, i.k);
            }
            catch (final Exception ex) {
                continue;
            }
            break;
        }
    }
    
    boolean b(int n, final int n2, final Intent intent, final d.c c) {
        if (n == 33058) {
            final LineLoginResult d = a.d(intent);
            n = r0$c.a[((Enum)d.y()).ordinal()];
            if (n != 1) {
                if (n != 2 && n != 3) {
                    final String string = d.o().toString();
                    k.a("line login failed: %s", string);
                    super.a.l(com.beetalk.sdk.d.e.c("error", string, l.h.b()));
                }
                else {
                    k.a("line login canceled", new Object[0]);
                    super.a.l(com.beetalk.sdk.d.e.a(l.f.b()));
                }
            }
            else {
                final LineCredential q = d.q();
                if (q != null) {
                    final String i = q.i().i();
                    if (!TextUtils.isEmpty((CharSequence)i)) {
                        k.a("line login success, token: %s", i);
                        this.f(i);
                        return true;
                    }
                }
                k.c("line access token is null", new Object[0]);
                super.a.l(com.beetalk.sdk.d.e.a(l.h.b()));
            }
            return true;
        }
        return false;
    }
    
    boolean c(final d.c c) {
        k.a("start Line Auth", new Object[0]);
        if (c == null) {
            return false;
        }
        final int c2 = c.c(super.a.g());
        try {
            super.a.f().startActivityForResult(a.b((Context)super.a.e(), String.valueOf(c2), new LineAuthenticationParams$c().f(f.a((Object)m.c)).e()), 33058);
            return true;
        }
        catch (final Exception ex) {
            k.b(ex);
            return false;
        }
    }
}
