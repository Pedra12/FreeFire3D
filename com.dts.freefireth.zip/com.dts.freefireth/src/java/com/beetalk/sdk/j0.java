package com.beetalk.sdk;

import org.json.JSONObject;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import java.util.concurrent.Callable;
import android.content.Intent;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions$a;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import android.text.TextUtils;
import com.beetalk.sdk.helper.t;
import android.content.Context;
import com.garena.pay.android.l;
import com.beetalk.sdk.helper.k;
import com.beetalk.sdk.networking.service.j;
import com.google.android.gms.common.api.Status;
import w3.a;
import c1.i;
import com.google.android.gms.auth.api.signin.b;

public class j0 extends g
{
    private static String c;
    private b b;
    
    j0(final d d) {
        super(d);
    }
    
    private String f(final w3.a a) {
        final a a2 = new a(null);
        if (a != null) {
            final Status a3 = a.a();
            if (a3 != null) {
                a2.a = true;
                a2.b = a3.K2();
                a2.c = a3.L2();
            }
            a2.d = ((Throwable)a).getMessage();
            a2.e = a.getClass().getName();
            a2.f = this.l((Exception)a);
        }
        return a2.b();
    }
    
    private d.e g(final String s, final d.c c) {
        final d.e n = j.n(s, c.a(), c.b(), s.Y(c), c.e());
        k.a("Google login exchange token, result: ", n);
        if (n.d == l.c2.b()) {
            this.b.y();
        }
        return n;
    }
    
    private static String h(final Context context) {
        final String c = j0.c;
        if (c != null && c.length() > 0) {
            return j0.c;
        }
        try {
            return t.d();
        }
        catch (final Exception ex) {
            k.b(ex);
            return "";
        }
    }
    
    public static b i(final Context context) {
        final String h = h(context);
        if (TextUtils.isEmpty((CharSequence)h)) {
            k.c("Google client ID is not configured.", new Object[0]);
            return null;
        }
        return com.google.android.gms.auth.api.signin.a.a(context, new GoogleSignInOptions$a(GoogleSignInOptions.l).d(h).b().a());
    }
    
    private w3.a j(final Task task) {
        if (task == null) {
            return null;
        }
        try {
            task.getResult((Class)w3.a.class);
            return null;
        }
        catch (final Exception ex) {}
        catch (final w3.a a) {
            return a;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("get Google sign in exception failed: ");
        final Exception ex;
        sb.append(((Throwable)ex).getMessage());
        k.l(sb.toString(), new Object[0]);
        return null;
    }
    
    private Task k(final Intent intent) {
        if (intent == null) {
            return null;
        }
        try {
            return com.google.android.gms.auth.api.signin.a.c(intent);
        }
        catch (final Exception ex) {
            final StringBuilder sb = new StringBuilder();
            sb.append("get Google sign in task failed: ");
            sb.append(((Throwable)ex).getMessage());
            k.l(sb.toString(), new Object[0]);
            return null;
        }
    }
    
    private String l(final Exception ex) {
        final StackTraceElement[] stackTrace = ((Throwable)ex).getStackTrace();
        if (stackTrace != null && stackTrace.length != 0) {
            final StringBuilder sb = new StringBuilder();
            for (int i = 0; i < stackTrace.length; ++i) {
                if (i > 0) {
                    sb.append('\n');
                }
                sb.append(stackTrace[i].toString());
            }
            return sb.toString();
        }
        return "";
    }
    
    private void m(final l l, final String s) {
        super.a.l(d.e.b(l.b(), s));
    }
    
    private void n(final w3.a a) {
        l l = com.garena.pay.android.l.f;
        if (a != null) {
            l = l;
            if (a.b() != 12501) {
                l = com.garena.pay.android.l.t1;
            }
        }
        this.m(l, this.f(a));
    }
    
    private void o(final d.e e) {
        if (e != null && e.b != null) {
            final s z = s.Z(super.a.j().f(), s.w());
            if (z != null) {
                z.t().l(e.b);
            }
        }
        super.a.l(e);
    }
    
    private void p(final String s) {
        k.i("Starting Token Exchange for Google", new Object[0]);
        if (!TextUtils.isEmpty((CharSequence)s)) {
            i.f((Callable)new h0(this, s)).l((c1.g)new i0(this), i.k);
            return;
        }
        super.a.l(d.e.a(l.W0.b()));
    }
    
    public static void q(final String c) {
        j0.c = c;
    }
    
    boolean b(final int n, final int n2, final Intent intent, final d.c c) {
        if (n == 29554) {
            final Task k = this.k(intent);
            if (n2 == -1 && k != null) {
                Label_0094: {
                    try {
                        final GoogleSignInAccount googleSignInAccount = (GoogleSignInAccount)k.getResult((Class)w3.a.class);
                        if (googleSignInAccount != null && !googleSignInAccount.S2()) {
                            com.beetalk.sdk.helper.k.a("Google login success", new Object[0]);
                            this.p(googleSignInAccount.O2());
                            return true;
                        }
                    }
                    catch (final w3.a a) {
                        break Label_0094;
                    }
                    com.beetalk.sdk.helper.k.c("Google login failed", new Object[0]);
                    this.m(l.h, this.f(null));
                    return true;
                }
                final StringBuilder sb = new StringBuilder();
                sb.append("signInResult:failed code=");
                final w3.a a;
                sb.append(a.b());
                com.beetalk.sdk.helper.k.l(sb.toString(), new Object[0]);
                this.n(a);
            }
            else {
                this.n(this.j(k));
            }
            return true;
        }
        return false;
    }
    
    boolean c(final d.c c) {
        k.a("start Google Auth", new Object[0]);
        if (c == null) {
            return false;
        }
        if ((this.b = i(super.a.g())) == null) {
            return false;
        }
        final GoogleSignInAccount b = com.google.android.gms.auth.api.signin.a.b(super.a.g());
        String o2;
        if (b != null && !b.S2()) {
            o2 = b.O2();
            if (o2 != null) {
                k.a("already login", new Object[0]);
                this.p(o2);
            }
            else {
                k.a("got token failed", new Object[0]);
            }
        }
        else {
            o2 = null;
        }
        if (o2 == null) {
            k.a("starting google sign in page", new Object[0]);
            super.a.f().startActivityForResult(this.b.w(), 29554);
        }
        return true;
    }
    
    private static class a
    {
        boolean a;
        int b;
        String c;
        String d;
        String e;
        String f;
        
        private static void a(final JSONObject jsonObject, final String s, final String s2) {
            Object null = s2;
            if (s2 == null) {
                null = JSONObject.NULL;
            }
            jsonObject.put(s, null);
        }
        
        String b() {
            final JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("hasStatusCode", this.a);
                jsonObject.put("statusCode", this.b);
                a(jsonObject, "statusMessage", this.c);
                a(jsonObject, "exceptionMessage", this.d);
                a(jsonObject, "exceptionClass", this.e);
                a(jsonObject, "exceptionStackTrace", this.f);
            }
            catch (final Exception ex) {
                final StringBuilder sb = new StringBuilder();
                sb.append("build Google auth native info failed: ");
                sb.append(((Throwable)ex).getMessage());
                k.l(sb.toString(), new Object[0]);
            }
            return jsonObject.toString();
        }
    }
}
