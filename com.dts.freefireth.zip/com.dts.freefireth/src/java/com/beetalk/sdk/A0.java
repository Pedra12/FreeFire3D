package com.beetalk.sdk;

public class a0
{
    protected int a;
    protected String b;
    protected int c;
    protected byte[] d;
    protected int e;
    protected String f;
    protected String g;
    protected String h;
    protected String i;
    
    public a0() {
        this.a = 0;
        this.b = "";
        this.c = 0;
        this.d = null;
        this.e = 0;
    }
    
    public String a() {
        return this.h;
    }
    
    public int b() {
        return this.c;
    }
    
    public String c() {
        return this.b;
    }
    
    public int d() {
        return this.a;
    }
    
    public int e() {
        return this.e;
    }
    
    public byte[] f() {
        return this.d;
    }
    
    public String g() {
        return this.i;
    }
    
    public String h() {
        return this.f;
    }
    
    public static class a
    {
        private final a0 a;
        
        public a(final int c) {
            final a0 a = new a0();
            this.a = a;
            a.a = 0;
            a.c = c;
            a.g = "";
        }
        
        public a(final byte[] d, final int c) {
            final a0 a = new a0();
            this.a = a;
            a.a = 0;
            a.d = d;
            a.c = c;
            a.e = d.length;
            a.g = "";
        }
        
        public a0 a() {
            return this.a;
        }
        
        public a b(final String g) {
            this.a.g = g;
            return this;
        }
        
        public a c(final String h) {
            this.a.h = h;
            return this;
        }
        
        public a d(final String b) {
            this.a.b = b;
            return this;
        }
        
        public a e(final Integer n) {
            this.a.a = n;
            return this;
        }
        
        public a f(final String i) {
            this.a.i = i;
            return this;
        }
        
        public a g(final String f) {
            this.a.f = f;
            return this;
        }
    }
}
