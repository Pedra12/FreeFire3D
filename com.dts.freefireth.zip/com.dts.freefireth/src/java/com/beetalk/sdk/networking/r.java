package com.beetalk.sdk.networking;

import kotlin.jvm.internal.Intrinsics;
import com.garena.pay.android.l;
import kotlin.Metadata;

@Metadata
public final class r
{
    public static final r a;
    
    static {
        a = new r();
    }
    
    private r() {
    }
    
    public static final l a(final int n) {
        if (n == s.d.b()) {
            return l.c;
        }
        if (n == s.c.b()) {
            return l.h1;
        }
        if (n == s.g.b()) {
            return l.y;
        }
        if (n == s.h.b()) {
            return l.b1;
        }
        if (n == s.i.b()) {
            return l.c1;
        }
        if (n == s.j.b()) {
            return l.n1;
        }
        if (n == s.k.b()) {
            return l.o1;
        }
        return l.b2;
    }
    
    public static final l b(final b b) {
        Intrinsics.checkNotNullParameter((Object)b, "dataResponse");
        final String b2 = b.b();
        final l a1 = l.a1;
        final l d = d(b2, a1);
        if (d == a1) {
            final String b3 = b.b();
            switch (b3.hashCode()) {
                default: {
                    return a1;
                }
                case 497691631: {
                    if (!b3.equals((Object)"error_resource_exhausted")) {
                        return a1;
                    }
                    break;
                }
                case 454295039: {
                    if (!b3.equals((Object)"error_unauthenticated")) {
                        return a1;
                    }
                    return l.s1;
                }
                case 386302298: {
                    b3.equals((Object)"error_server");
                    return a1;
                }
                case 296700829: {
                    if (!b3.equals((Object)"error_params")) {
                        return a1;
                    }
                    return l.y;
                }
                case 290665061: {
                    if (!b3.equals((Object)"error_invalid_cfg")) {
                        return a1;
                    }
                    return l.e;
                }
                case 138092537: {
                    if (!b3.equals((Object)"error_open_id")) {
                        return a1;
                    }
                    return l.y;
                }
                case -367534689: {
                    if (!b3.equals((Object)"error_not_found")) {
                        return a1;
                    }
                    return l.e;
                }
                case -623480664: {
                    if (!b3.equals((Object)"cpf_limit_reached")) {
                        return a1;
                    }
                    break;
                }
                case -736647788: {
                    if (!b3.equals((Object)"error_permission_denied")) {
                        return a1;
                    }
                    return l.e;
                }
                case -817608446: {
                    if (!b3.equals((Object)"error_token")) {
                        return a1;
                    }
                    return l.b1;
                }
                case -821713002: {
                    if (!b3.equals((Object)"error_param")) {
                        return a1;
                    }
                    return l.y;
                }
                case -835880527: {
                    if (!b3.equals((Object)"invalid_token")) {
                        return a1;
                    }
                    return l.b1;
                }
                case -1182679558: {
                    if (!b3.equals((Object)"error_no_policy_region")) {
                        return a1;
                    }
                    return l.p1;
                }
                case -1966938570: {
                    if (!b3.equals((Object)"unauthenticated")) {
                        return a1;
                    }
                    return l.s1;
                }
            }
            return l.v1;
        }
        return d;
    }
    
    public static final l c(final String s) {
        return e(s, null, 2, null);
    }
    
    public static final l d(final String s, final l l) {
        if (s != null) {
            switch (s.hashCode()) {
                case 2019871319: {
                    if (!s.equals((Object)"ssl_failure")) {
                        break;
                    }
                    return l.w;
                }
                case 972718356: {
                    if (!s.equals((Object)"error_unsupported_platform")) {
                        break;
                    }
                    return l.e;
                }
                case 298509446: {
                    if (!s.equals((Object)"error_profile_linked")) {
                        break;
                    }
                    return l.q1;
                }
                case 296700829: {
                    if (!s.equals((Object)"error_params")) {
                        break;
                    }
                    return l.y;
                }
                case 224059890: {
                    if (!s.equals((Object)"error_user_ban")) {
                        break;
                    }
                    return l.d2;
                }
                case -95137703: {
                    if (!s.equals((Object)"error_token_session")) {
                        break;
                    }
                    return l.g1;
                }
                case -435389650: {
                    if (!s.equals((Object)"error_platform_linked")) {
                        break;
                    }
                    return l.r1;
                }
                case -610623917: {
                    if (!s.equals((Object)"error_account_swapped")) {
                        break;
                    }
                    return l.L1;
                }
                case -783947217: {
                    if (!s.equals((Object)"error_no_auth")) {
                        break;
                    }
                    return l.n1;
                }
                case -817608446: {
                    if (!s.equals((Object)"error_token")) {
                        break;
                    }
                    return l.b1;
                }
                case -818885283: {
                    if (!s.equals((Object)"error_scope")) {
                        break;
                    }
                    return l.c1;
                }
                case -847806252: {
                    if (!s.equals((Object)"invalid_grant")) {
                        break;
                    }
                    return l.c2;
                }
                case -1172553854: {
                    if (!s.equals((Object)"error_too_many_requests")) {
                        break;
                    }
                    return l.m1;
                }
                case -1700264455: {
                    if (!s.equals((Object)"error_invalid_signature")) {
                        break;
                    }
                    return l.o1;
                }
                case -1970522959: {
                    if (!s.equals((Object)"auth_error")) {
                        break;
                    }
                    return l.e2;
                }
                case -2054838772: {
                    if (!s.equals((Object)"server_error")) {
                        break;
                    }
                    return l.a1;
                }
            }
        }
        if (l == null) {
            return l.a1;
        }
        return l;
    }
    
    public static /* synthetic */ l e(final String s, l l, final int n, final Object o) {
        if ((n & 0x2) != 0x0) {
            l = null;
        }
        return d(s, l);
    }
}
