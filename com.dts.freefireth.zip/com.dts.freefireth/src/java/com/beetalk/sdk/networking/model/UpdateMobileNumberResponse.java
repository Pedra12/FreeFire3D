package com.beetalk.sdk.networking.model;

import org.json.JSONObject;

public final class UpdateMobileNumberResponse extends BaseResp
{
    private UpdateMobileNumberResponse() {
    }
    
    public static UpdateMobileNumberResponse j(final JSONObject jsonObject) {
        final UpdateMobileNumberResponse updateMobileNumberResponse = new UpdateMobileNumberResponse();
        updateMobileNumberResponse.h(jsonObject);
        return updateMobileNumberResponse;
    }
}
