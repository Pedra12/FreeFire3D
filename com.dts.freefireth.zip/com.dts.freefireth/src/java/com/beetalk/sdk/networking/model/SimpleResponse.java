package com.beetalk.sdk.networking.model;

import com.google.gson.annotations.SerializedName;
import kotlin.Metadata;

@Metadata
public final class SimpleResponse
{
    @SerializedName("result")
    private int result;
    
    public SimpleResponse() {
        this.result = -1;
    }
    
    public final int a() {
        return this.result;
    }
}
