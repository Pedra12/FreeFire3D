package com.beetalk.sdk.networking.model;

import org.json.JSONException;
import com.beetalk.sdk.helper.k;
import com.garena.pay.android.helper.b;
import com.garena.pay.android.data.GGRebateItem;
import org.json.JSONObject;
import com.garena.pay.android.l;
import com.garena.pay.android.data.GGPayment$PaymentChannel;
import java.util.List;

public class ChannelsResp extends BaseResp
{
    private List<GGPayment$PaymentChannel> channels;
    
    public static ChannelsResp k(final String s) {
        final ChannelsResp channelsResp = new ChannelsResp();
        if (s == null) {
            channelsResp.errorCode = l.h1.b();
            return channelsResp;
        }
        if ((channelsResp.errorCode = channelsResp.f(s)) != l.c.b()) {
            return channelsResp;
        }
        channelsResp.channels = (List<GGPayment$PaymentChannel>)Pricing.b(s);
        return channelsResp;
    }
    
    public static ChannelsResp l(final String s, final long n) {
        final ChannelsResp channelsResp = new ChannelsResp();
        if (s == null) {
            channelsResp.errorCode = l.h1.b();
            return channelsResp;
        }
        if ((channelsResp.errorCode = channelsResp.f(s)) != l.c.b()) {
            return channelsResp;
        }
        try {
            final JSONObject jsonObject = new JSONObject(s);
            channelsResp.channels = (List<GGPayment$PaymentChannel>)b.e(GGPayment$PaymentChannel.h(jsonObject.optJSONArray("channels")), GGRebateItem.d(jsonObject.optJSONArray("rebates")), Long.valueOf(n));
            return channelsResp;
        }
        catch (final JSONException ex) {
            k.b((Exception)ex);
            return channelsResp;
        }
    }
    
    public List j() {
        return this.channels;
    }
    
    public void m(final List channels) {
        this.channels = (List<GGPayment$PaymentChannel>)channels;
    }
}
