package com.beetalk.sdk.networking;

import y7.b;
import Z7.C$a;
import java.nio.charset.Charset;
import Z7.s$a;
import kotlin.collections.F;
import com.google.gson.Gson;
import Z7.x;
import s7.n;
import java.util.Arrays;
import java.util.Locale;
import G7.G;
import kotlin.jvm.functions.Function1;
import D2.a;
import com.beetalk.sdk.helper.A;
import android.os.Build$VERSION;
import android.os.Build;
import android.telephony.TelephonyManager;
import com.beetalk.sdk.X;
import Z7.B;
import Z7.C;
import java.util.Iterator;
import Z7.v$a;
import java.util.Set;
import kotlin.jvm.internal.Intrinsics;
import Z7.B$a;
import kotlin.collections.CollectionsKt;
import java.util.Map$Entry;
import java.util.List;
import java.util.Map;
import Z7.v;
import Z7.z;
import kotlin.jvm.functions.Function0;
import s7.j;
import kotlin.jvm.internal.DefaultConstructorMarker;
import s7.i;
import kotlin.Metadata;

@Metadata
public final class t
{
    public static final b a;
    private static final i b;
    
    static {
        a = new b(null);
        b = j.a((Function0)t$a.b);
    }
    
    private t() {
    }
    
    public static final /* synthetic */ i a() {
        return t.b;
    }
    
    public static final t b() {
        return t.a.a();
    }
    
    private final String d(final z z, final v v, final Map map, final List list, final boolean b) {
        final Set entrySet = map.entrySet();
        final v$a k = v.k();
        for (final Map$Entry map$Entry : entrySet) {
            k.b((String)map$Entry.getKey(), (String)map$Entry.getValue());
        }
        final String string = k.c().toString();
        List i;
        if ((i = list) == null) {
            i = CollectionsKt.k();
        }
        final B$a b$a = new B$a();
        for (final com.beetalk.sdk.networking.c c : i) {
            final String a = c.a;
            Intrinsics.checkNotNullExpressionValue((Object)a, "key");
            final String b2 = c.b;
            Intrinsics.checkNotNullExpressionValue((Object)b2, "value");
            b$a.a(a, b2);
        }
        return this.q(z, b$a.l(string).d().b(), b);
    }
    
    public static /* synthetic */ String i(final t t, final String s, final Map map, boolean b, List list, boolean b2, final int n, final Object o) {
        if ((n & 0x4) != 0x0) {
            b = false;
        }
        if ((n & 0x8) != 0x0) {
            list = null;
        }
        if ((n & 0x10) != 0x0) {
            b2 = false;
        }
        return t.h(s, map, b, list, b2);
    }
    
    private final String j(final z z, final String s, final List list, final C c, final boolean b) {
        List k = list;
        if (list == null) {
            k = CollectionsKt.k();
        }
        final B$a b$a = new B$a();
        for (final com.beetalk.sdk.networking.c c2 : k) {
            final String a = c2.a;
            Intrinsics.checkNotNullExpressionValue((Object)a, "key");
            final String b2 = c2.b;
            Intrinsics.checkNotNullExpressionValue((Object)b2, "value");
            b$a.a(a, b2);
        }
        return this.q(z, b$a.l(s).h(c).b(), b);
    }
    
    public static /* synthetic */ String p(final t t, final String s, List list, final Map map, boolean b, String s2, z z, boolean b2, c a, final int n, final Object o) {
        if ((n & 0x2) != 0x0) {
            list = null;
        }
        if ((n & 0x8) != 0x0) {
            b = false;
        }
        if ((n & 0x10) != 0x0) {
            s2 = null;
        }
        if ((n & 0x20) != 0x0) {
            z = null;
        }
        if ((n & 0x40) != 0x0) {
            b2 = false;
        }
        if ((n & 0x80) != 0x0) {
            a = c.a;
        }
        return t.n(s, list, map, b, s2, z, b2, a);
    }
    
    private final String q(final z p0, final B p1, final boolean p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: aload_2        
        //     2: invokevirtual   Z7/z.a:(LZ7/B;)LZ7/e;
        //     5: invokeinterface Z7/e.i:()LZ7/D;
        //    10: astore_2       
        //    11: aload_2        
        //    12: invokevirtual   Z7/D.e:()I
        //    15: istore          4
        //    17: iload           4
        //    19: sipush          429
        //    22: if_icmpeq       93
        //    25: iload           4
        //    27: sipush          503
        //    30: if_icmpeq       93
        //    33: aload_2        
        //    34: invokevirtual   Z7/D.m:()Z
        //    37: ifne            67
        //    40: iload_3        
        //    41: ifeq            47
        //    44: goto            67
        //    47: getstatic       kotlin/Unit.a:Lkotlin/Unit;
        //    50: astore_1       
        //    51: aload_2        
        //    52: aconst_null    
        //    53: invokestatic    C7/b.a:(Ljava/io/Closeable;Ljava/lang/Throwable;)V
        //    56: goto            127
        //    59: astore_1       
        //    60: goto            113
        //    63: astore_1       
        //    64: goto            101
        //    67: aload_2        
        //    68: invokevirtual   Z7/D.a:()LZ7/E;
        //    71: astore_1       
        //    72: aload_1        
        //    73: ifnull          84
        //    76: aload_1        
        //    77: invokevirtual   Z7/E.i:()Ljava/lang/String;
        //    80: astore_1       
        //    81: goto            86
        //    84: aconst_null    
        //    85: astore_1       
        //    86: aload_2        
        //    87: aconst_null    
        //    88: invokestatic    C7/b.a:(Ljava/io/Closeable;Ljava/lang/Throwable;)V
        //    91: aload_1        
        //    92: areturn        
        //    93: aload_2        
        //    94: aconst_null    
        //    95: invokestatic    C7/b.a:(Ljava/io/Closeable;Ljava/lang/Throwable;)V
        //    98: ldc             "{\n    \"error\":\"error_too_many_requests\"\n}"
        //   100: areturn        
        //   101: aload_1        
        //   102: athrow         
        //   103: astore          5
        //   105: aload_2        
        //   106: aload_1        
        //   107: invokestatic    C7/b.a:(Ljava/io/Closeable;Ljava/lang/Throwable;)V
        //   110: aload           5
        //   112: athrow         
        //   113: aload_1        
        //   114: invokestatic    com/beetalk/sdk/helper/k.b:(Ljava/lang/Exception;)V
        //   117: aload_1        
        //   118: instanceof      Ljavax/net/ssl/SSLHandshakeException;
        //   121: ifeq            127
        //   124: ldc             "{\n    \"error\":\"ssl_failure\"\n}"
        //   126: areturn        
        //   127: aconst_null    
        //   128: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  0      11     59     127    Ljava/lang/Exception;
        //  11     17     63     113    Any
        //  33     40     63     113    Any
        //  47     51     63     113    Any
        //  51     56     59     127    Ljava/lang/Exception;
        //  67     72     63     113    Any
        //  76     81     63     113    Any
        //  86     91     59     127    Ljava/lang/Exception;
        //  93     98     59     127    Ljava/lang/Exception;
        //  101    103    103    113    Any
        //  105    113    59     127    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0047:
        //     at q5.p.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:150)
        //     at q5.p.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:470)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:30)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        //     at java.lang.Thread.run(Thread.java:1571)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public final String c() {
        final Object systemService = X.M().getSystemService("phone");
        TelephonyManager telephonyManager;
        if (systemService instanceof TelephonyManager) {
            telephonyManager = (TelephonyManager)systemService;
        }
        else {
            telephonyManager = null;
        }
        String s;
        if (telephonyManager != null && telephonyManager.getPhoneType() == 0) {
            s = "tablet";
        }
        else {
            s = "";
        }
        final String model = Build.MODEL;
        String string = s;
        if (model != null) {
            if (((CharSequence)model).length() == 0) {
                string = s;
            }
            else {
                final StringBuilder sb = new StringBuilder();
                sb.append(model);
                sb.append(" ");
                sb.append(s);
                string = sb.toString();
            }
        }
        final String release = Build$VERSION.RELEASE;
        String string2;
        if (release != null && ((CharSequence)release).length() != 0) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("Android ");
            sb2.append(release);
            string2 = sb2.toString();
        }
        else {
            string2 = "Android";
        }
        final String c = A.c();
        final String a = A.a();
        final String a2 = com.beetalk.sdk.helper.t.A();
        Intrinsics.checkNotNullExpressionValue((Object)a2, "obtainVersionName(...)");
        final String z = com.beetalk.sdk.helper.t.z();
        Intrinsics.checkNotNullExpressionValue((Object)z, "obtainVersionCode(...)");
        final StringBuilder sb3 = new StringBuilder();
        sb3.append("app ");
        sb3.append(a2);
        sb3.append(" ");
        sb3.append(z);
        final String string3 = sb3.toString();
        final String l = kotlin.collections.j.L((Object[])D2.a.a.a(), (CharSequence)";", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null);
        final G a3 = G.a;
        final String format = String.format(Locale.getDefault(), "%s/%s(%s;%s;%s;%s;%s;%s)", Arrays.copyOf(new Object[] { "GarenaMSDK", "4.0.44", string, string2, c, a, string3, l }, 8));
        Intrinsics.checkNotNullExpressionValue((Object)format, "format(...)");
        return format;
    }
    
    public final String e(final String s, final Map map) {
        Intrinsics.checkNotNullParameter((Object)s, "baseUrl");
        Intrinsics.checkNotNullParameter((Object)map, "getData");
        return i(this, s, map, false, null, false, 28, null);
    }
    
    public final String f(final String s, final Map map, final String s2, final boolean b, final boolean b2) {
        Intrinsics.checkNotNullParameter((Object)s, "baseUrl");
        Intrinsics.checkNotNullParameter((Object)map, "getData");
        Intrinsics.checkNotNullParameter((Object)s2, "signatureKey");
        final v f = v.k.f(s);
        if (f == null) {
            return null;
        }
        return this.d(m.a.q(s2, b2), f, map, null, b);
    }
    
    public final String g(final String s, final Map map, final boolean b) {
        Intrinsics.checkNotNullParameter((Object)s, "baseUrl");
        Intrinsics.checkNotNullParameter((Object)map, "getData");
        return i(this, s, map, b, null, false, 24, null);
    }
    
    public final String h(final String s, final Map map, final boolean b, final List list, final boolean b2) {
        Intrinsics.checkNotNullParameter((Object)s, "baseUrl");
        Intrinsics.checkNotNullParameter((Object)map, "getData");
        final v f = v.k.f(s);
        if (f == null) {
            return null;
        }
        return this.d(m.j(m.a, b2, null, null, 6, null), f, map, list, b);
    }
    
    public final String k(final String s, final List list, final Map map) {
        Intrinsics.checkNotNullParameter((Object)s, "url");
        Intrinsics.checkNotNullParameter((Object)map, "postData");
        return p(this, s, list, map, false, null, null, false, null, 248, null);
    }
    
    public final String l(final String s, final List list, final Map map, final boolean b, final String s2, final z z) {
        Intrinsics.checkNotNullParameter((Object)s, "url");
        Intrinsics.checkNotNullParameter((Object)map, "postData");
        return p(this, s, list, map, b, s2, z, false, null, 192, null);
    }
    
    public final String m(final String s, final List list, final Map map, final boolean b, final String s2, final z z, final boolean b2) {
        Intrinsics.checkNotNullParameter((Object)s, "url");
        Intrinsics.checkNotNullParameter((Object)map, "postData");
        return p(this, s, list, map, b, s2, z, b2, null, 128, null);
    }
    
    public final String n(final String s, final List list, final Map map, final boolean b, final String s2, final z z, final boolean b2, final c c) {
        Intrinsics.checkNotNullParameter((Object)s, "url");
        Intrinsics.checkNotNullParameter((Object)map, "postData");
        Intrinsics.checkNotNullParameter((Object)c, "reqBodyFormat");
        z z2 = z;
        if (z == null) {
            z z3;
            if (s2 != null && ((CharSequence)s2).length() != 0) {
                z3 = m.a.n(s2, b2);
            }
            else {
                z3 = m.j(m.a, b2, null, null, 6, null);
            }
            z2 = z3;
        }
        final int n = d.a[c.ordinal()];
        Object o;
        if (n != 1) {
            if (n != 2) {
                throw new n();
            }
            final x b3 = x.e.b("application/json");
            final C$a a = C.a;
            final String json = new Gson().toJson((Object)F.h(map));
            Intrinsics.checkNotNullExpressionValue((Object)json, "toJson(...)");
            o = a.a(b3, json);
        }
        else {
            final Set entrySet = map.entrySet();
            final s$a s$a = new s$a((Charset)null, 1, (DefaultConstructorMarker)null);
            for (final Map$Entry map$Entry : entrySet) {
                s$a.a((String)map$Entry.getKey(), map$Entry.getValue().toString());
            }
            o = s$a.c();
        }
        return this.j(z2, s, list, (C)o, b);
    }
    
    public final String o(final String s, final Map map) {
        Intrinsics.checkNotNullParameter((Object)s, "url");
        Intrinsics.checkNotNullParameter((Object)map, "postData");
        return p(this, s, null, map, false, null, null, false, null, 250, null);
    }
    
    @Metadata
    public static final class b
    {
        private b() {
        }
        
        public final t a() {
            return (t)t.a().getValue();
        }
    }
    
    @Metadata
    public enum c
    {
        a, 
        b;
        
        private static final c[] c;
        private static final y7.a d;
        
        static {
            d = y7.b.a((Enum[])(c = a()));
        }
        
        private static final /* synthetic */ c[] a() {
            return new c[] { t.c.a, t.c.b };
        }
    }
}
