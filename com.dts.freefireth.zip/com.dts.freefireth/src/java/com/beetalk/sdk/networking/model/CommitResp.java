package com.beetalk.sdk.networking.model;

import org.json.JSONException;
import com.beetalk.sdk.helper.k;
import org.json.JSONObject;
import com.beetalk.sdk.networking.s;
import com.garena.pay.android.l;

public class CommitResp extends BaseResp
{
    private int appPointAmount;
    private String currentCommitTxnId;
    private boolean isFreeItem;
    private String itemIconUrl;
    private String itemName;
    private long rebateCardId;
    private int remainingDays;
    
    public CommitResp() {
        this.itemName = "";
        this.itemIconUrl = "";
        this.rebateCardId = 0L;
        this.currentCommitTxnId = "";
        this.remainingDays = 0;
        this.appPointAmount = 0;
        this.isFreeItem = false;
    }
    
    public static CommitResp s(final String s) {
        final CommitResp commitResp = new CommitResp();
        if (s == null) {
            commitResp.errorCode = l.h1.b();
            commitResp.resultCode = s.c.b();
            return commitResp;
        }
        if ((commitResp.errorCode = commitResp.f(s)) != l.c.b()) {
            commitResp.resultCode = s.c.b();
            return commitResp;
        }
        try {
            final JSONObject jsonObject = new JSONObject(s);
            commitResp.resultCode = commitResp.g(jsonObject);
            commitResp.itemName = jsonObject.optString("item_name", "");
            commitResp.itemIconUrl = jsonObject.optString("item_icon", "");
            commitResp.currentCommitTxnId = jsonObject.optString("txn_id", "");
            commitResp.appPointAmount = jsonObject.optInt("app_point_amount", 0);
            commitResp.isFreeItem = jsonObject.optBoolean("is_free_item", false);
            final JSONObject optJSONObject = jsonObject.optJSONObject("rebate_card");
            if (optJSONObject != null) {
                commitResp.rebateCardId = optJSONObject.optLong("rebate_card_id", 0L);
                commitResp.remainingDays = optJSONObject.optInt("remaining_days", 0);
            }
            return commitResp;
        }
        catch (final JSONException ex) {
            k.b((Exception)ex);
            commitResp.resultCode = s.c.b();
            return commitResp;
        }
    }
    
    public int j() {
        return this.appPointAmount;
    }
    
    public String k() {
        return this.currentCommitTxnId;
    }
    
    public String l() {
        return this.itemIconUrl;
    }
    
    public String m() {
        return this.itemName;
    }
    
    public String n() {
        return s.d(super.resultCode);
    }
    
    public long o() {
        return this.rebateCardId;
    }
    
    public int p() {
        return this.remainingDays;
    }
    
    public boolean q() {
        return super.resultCode != s.d.b();
    }
    
    public boolean r() {
        return this.isFreeItem;
    }
}
