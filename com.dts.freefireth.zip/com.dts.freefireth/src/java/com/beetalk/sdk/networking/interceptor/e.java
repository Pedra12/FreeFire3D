package com.beetalk.sdk.networking.interceptor;

import Z7.B;
import kotlin.Metadata;

@Metadata
public interface e
{
    String a(final B p0);
}
