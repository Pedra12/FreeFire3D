package com.beetalk.sdk.networking.model;

import org.json.JSONObject;

public final class GetOTPResponse extends BaseResp
{
    private GetOTPResponse() {
    }
    
    public static GetOTPResponse j(final JSONObject jsonObject) {
        final GetOTPResponse getOTPResponse = new GetOTPResponse();
        getOTPResponse.h(jsonObject);
        return getOTPResponse;
    }
}
