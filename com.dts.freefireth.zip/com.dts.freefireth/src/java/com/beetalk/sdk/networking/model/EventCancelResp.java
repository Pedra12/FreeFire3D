package com.beetalk.sdk.networking.model;

import org.json.JSONException;
import com.beetalk.sdk.helper.k;
import org.json.JSONObject;
import com.garena.pay.android.l;

public class EventCancelResp extends BaseResp
{
    public static EventCancelResp j(final String s) {
        final EventCancelResp eventCancelResp = new EventCancelResp();
        if (s == null) {
            eventCancelResp.errorCode = l.h1.b();
            return eventCancelResp;
        }
        eventCancelResp.errorCode = eventCancelResp.f(s);
        try {
            eventCancelResp.resultCode = eventCancelResp.g(new JSONObject(s));
            return eventCancelResp;
        }
        catch (final JSONException ex) {
            k.b((Exception)ex);
            return eventCancelResp;
        }
    }
}
