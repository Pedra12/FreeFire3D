package com.beetalk.sdk.networking.model;

import com.google.gson.annotations.SerializedName;
import com.beetalk.sdk.networking.ResultCodeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.beetalk.sdk.networking.s;

public class SaveTokenResponse extends BaseResponse
{
    @JsonAdapter(ResultCodeAdapter.class)
    @SerializedName("result")
    private s result;
    
    public s c() {
        return this.result;
    }
    
    public boolean d() {
        return this.result != s.d;
    }
}
