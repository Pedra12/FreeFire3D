package com.beetalk.sdk.networking.model;

import com.beetalk.sdk.helper.k;
import com.beetalk.sdk.helper.A;
import com.beetalk.sdk.X;
import java.util.HashMap;
import java.util.Map;
import com.garena.pay.android.p;
import android.content.Context;

public class EventPriceReq extends BaseReq
{
    public static Map a(final Context context, final p p3, final String s) {
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"access_token", (Object)p3.c().q());
        hashMap.put((Object)"open_id", (Object)p3.c().g());
        hashMap.put((Object)"app_id", (Object)p3.c().d());
        hashMap.put((Object)"client_type", (Object)String.valueOf(2));
        hashMap.put((Object)"app_server_id", (Object)String.valueOf(p3.c().f()));
        hashMap.put((Object)"app_role_id", (Object)String.valueOf(p3.c().p()));
        hashMap.put((Object)"platform", (Object)String.valueOf(p3.c().l()));
        hashMap.put((Object)"source", (Object)X.N().toString());
        if (p3.c().k() != null) {
            hashMap.put((Object)"locale", (Object)A.f(p3.c().k()));
        }
        else {
            hashMap.put((Object)"locale", (Object)A.f(A.e(context)));
        }
        hashMap.put((Object)"for_channel_id", (Object)String.valueOf(201069));
        hashMap.put((Object)"user_region", (Object)s);
        k.a("EventPrice Get Request Data %s", hashMap.toString());
        return (Map)hashMap;
    }
}
