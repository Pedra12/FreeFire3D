package com.beetalk.sdk.networking.model;

import java.util.List;
import com.beetalk.sdk.helper.k;
import D2.a;
import android.text.TextUtils;
import com.beetalk.sdk.X;
import com.beetalk.sdk.helper.A;
import java.util.HashMap;
import java.util.Map;
import com.garena.pay.android.p;
import android.content.Context;

public class ChannelsReq extends BaseReq
{
    public static Map a(final Context context, final p p2) {
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"access_token", (Object)p2.c().q());
        if (p2.c().k() != null) {
            hashMap.put((Object)"locale", (Object)A.f(p2.c().k()));
        }
        else {
            hashMap.put((Object)"locale", (Object)A.f(A.e(context)));
        }
        hashMap.put((Object)"app_id", (Object)p2.c().d());
        hashMap.put((Object)"open_id", (Object)p2.c().g());
        hashMap.put((Object)"source", (Object)X.N().toString());
        hashMap.put((Object)"platform", (Object)String.valueOf(p2.c().l()));
        hashMap.put((Object)"client_type", (Object)String.valueOf(2));
        hashMap.put((Object)"app_server_id", (Object)String.valueOf(p2.c().f()));
        hashMap.put((Object)"app_role_id", (Object)String.valueOf(p2.c().p()));
        final List j = p2.c().j();
        if (j != null && !j.isEmpty()) {
            hashMap.put((Object)"for_item_ids", (Object)TextUtils.join((CharSequence)",", (Iterable)j));
        }
        final List n = p2.c().n();
        if (n != null && !n.isEmpty()) {
            hashMap.put((Object)"for_rebate_ids", (Object)TextUtils.join((CharSequence)",", (Iterable)n));
        }
        final List e = p2.c().e();
        if (e != null && !e.isEmpty()) {
            hashMap.put((Object)"for_app_item_ids", (Object)TextUtils.join((CharSequence)",", (Iterable)e));
        }
        if (a.a.d()) {
            hashMap.put((Object)"for_channel_id", (Object)String.valueOf(999999));
        }
        k.a("Channel Get Request Data %s", hashMap.toString());
        return (Map)hashMap;
    }
}
