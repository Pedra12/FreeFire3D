package com.beetalk.sdk.networking.model;

import com.beetalk.sdk.networking.ULongJsonAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;

public class RecallToken
{
    @SerializedName("access_token")
    private String accessToken;
    @SerializedName("create_time")
    private long createTime;
    @SerializedName("expiry_time")
    private long expiryTime;
    @SerializedName("login_platform")
    private int loginPlatform;
    @SerializedName("open_id")
    private String openId;
    @SerializedName("platform")
    private int platform;
    @SerializedName("main_active_platform")
    private int primaryPlatform;
    @SerializedName("scope")
    private long scopes;
    @JsonAdapter(ULongJsonAdapter.class)
    @SerializedName("uid")
    private String uid;
    
    public RecallToken() {
        this.platform = 0;
        this.accessToken = "";
        this.createTime = 0L;
        this.expiryTime = 0L;
        this.uid = "";
        this.openId = "";
        this.scopes = -1L;
        this.primaryPlatform = 0;
        this.loginPlatform = 0;
    }
    
    public String a() {
        return this.accessToken;
    }
    
    public long b() {
        return this.expiryTime;
    }
    
    public int c() {
        return this.loginPlatform;
    }
    
    public String d() {
        return this.openId;
    }
    
    public int e() {
        return this.platform;
    }
    
    public int f() {
        return this.primaryPlatform;
    }
    
    public void g(final int loginPlatform) {
        this.loginPlatform = loginPlatform;
    }
}
