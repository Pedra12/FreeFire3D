package com.beetalk.sdk.networking;

import java.util.Collection;
import java.util.ListIterator;
import co.datadome.sdk.DataDomeInterceptor;
import n8.a$a;
import n8.a$b;
import kotlin.jvm.internal.DefaultConstructorMarker;
import co.datadome.sdk.DataDomeSDKListener;
import com.beetalk.sdk.helper.F;
import com.beetalk.sdk.networking.interceptor.a;
import com.beetalk.sdk.networking.interceptor.e;
import com.beetalk.sdk.helper.k;
import Z7.z;
import com.beetalk.sdk.networking.interceptor.c;
import com.beetalk.sdk.networking.interceptor.d;
import Z7.w;
import com.beetalk.sdk.networking.interceptor.f;
import java.util.concurrent.TimeUnit;
import s7.p$a;
import Z7.q;
import s7.p;
import kotlin.collections.CollectionsKt;
import com.beetalk.sdk.A0;
import kotlin.jvm.internal.Intrinsics;
import Z7.v;
import Z7.n;
import Z7.z$a;
import Z7.B;
import java.util.ArrayList;
import kotlin.jvm.functions.Function0;
import s7.j;
import java.util.List;
import com.beetalk.sdk.networking.interceptor.b;
import s7.i;
import kotlin.Metadata;

@Metadata
public final class m
{
    public static final m a;
    private static final i b;
    private static final b c;
    private static final List d;
    
    static {
        a = new m();
        b = j.a((Function0)m$b.b);
        c = new b();
        d = (List)new ArrayList();
    }
    
    private m() {
    }
    
    private final n f() {
        return (n)new n() {
            public void a(final v v, final List list) {
                Intrinsics.checkNotNullParameter((Object)v, "url");
                Intrinsics.checkNotNullParameter((Object)list, "cookies");
            }
            
            public List b(final v v) {
                Intrinsics.checkNotNullParameter((Object)v, "url");
                if (A0.f.contains((Object)v.toString())) {
                    final String d = new com.beetalk.sdk.cache.i().d();
                    Intrinsics.c((Object)d);
                    if (((CharSequence)d).length() > 0) {
                        final Z7.m c = Z7.m.j.c(v, d);
                        List e;
                        if (c != null) {
                            e = CollectionsKt.e((Object)c);
                        }
                        else {
                            e = null;
                        }
                        List k = e;
                        if (e == null) {
                            k = CollectionsKt.k();
                        }
                        return k;
                    }
                }
                return CollectionsKt.k();
            }
        };
    }
    
    private final Object g(final String s) {
        final String s2;
        Label_0075: {
            try {
                final p$a b = p.b;
                if (!((Collection)q.b.a(s)).isEmpty()) {
                    return p.b((Object)Boolean.TRUE);
                }
            }
            finally {
                break Label_0075;
            }
            final StringBuilder sb = new StringBuilder();
            sb.append("Cannot access this domain: ");
            sb.append(s2);
            return p.b(s7.q.a((Throwable)new IllegalStateException(sb.toString())));
        }
        final p$a b2 = p.b;
        return p.b(s7.q.a((Throwable)s2));
    }
    
    private final z$a h(final z$a z$a) {
        final TimeUnit seconds = TimeUnit.SECONDS;
        z$a.P(60L, seconds);
        z$a.g(60L, seconds);
        z$a.a((w)new f(t.a.a().c()));
        z$a.a((w)new d());
        z$a.a((w)new c(m.c));
        z$a.h(m.a.f());
        return z$a;
    }
    
    public static /* synthetic */ z j(final m m, final boolean b, String s, Function0 b2, final int n, final Object o) {
        if ((n & 0x2) != 0x0) {
            s = "";
        }
        if ((n & 0x4) != 0x0) {
            b2 = (Function0)m$c.b;
        }
        return m.i(b, s, b2);
    }
    
    private static final void k(String d) {
        Intrinsics.checkNotNullParameter((Object)d, "message");
        d = com.beetalk.sdk.helper.t.D(d);
        final StringBuilder sb = new StringBuilder();
        sb.append("OkHttp:");
        sb.append(d);
        k.a(sb.toString(), new Object[0]);
    }
    
    private final z$a l() {
        return this.h(this.m().H());
    }
    
    private final z m() {
        return (z)m.b.getValue();
    }
    
    private final z o(final boolean b, final e e) {
        return j(this, b, null, (Function0)new Function0<z$a>(e) {
            final e b;
            
            public final z$a c() {
                return m.a.l().a((w)new a(this.b));
            }
        }, 2, null);
    }
    
    private static final String p(String a, final B b) {
        Intrinsics.checkNotNullParameter((Object)a, "$signatureKey");
        Intrinsics.checkNotNullParameter((Object)b, "it");
        a = F.a(a, o.f(b));
        Intrinsics.checkNotNullExpressionValue((Object)a, "HMAC256Digest(...)");
        return a;
    }
    
    private static final String r(String a, final B b) {
        Intrinsics.checkNotNullParameter((Object)a, "$signatureKey");
        Intrinsics.checkNotNullParameter((Object)b, "it");
        a = F.a(a, o.e(b, false, 1, null));
        Intrinsics.checkNotNullExpressionValue((Object)a, "HMAC256Digest(...)");
        return a;
    }
    
    public final Object e(String s) {
        Intrinsics.checkNotNullParameter((Object)s, "url");
        Label_0119: {
            Object o;
            try {
                o = p.b;
                o = v.k.f(s);
                if (o == null) {
                    return p.b(s7.q.a((Throwable)new IllegalStateException("Parse url failed")));
                }
            }
            finally {
                break Label_0119;
            }
            final String i = ((v)o).i();
            if (!p.g(m.a.g(i))) {
                s = m.c.a(i);
                if (s == null) {
                    return p.b(s7.q.a((Throwable)new IllegalStateException("Backup host not found")));
                }
                s = ((v)o).k().g(s).c().toString();
            }
            return p.b((Object)s);
        }
        final p$a b = p.b;
        return p.b(s7.q.a((Throwable)s));
    }
    
    public final z i(final boolean b, final String s, final Function0 function0) {
        Intrinsics.checkNotNullParameter((Object)s, "dataDomeUserAgent");
        Intrinsics.checkNotNullParameter((Object)function0, "clientBuilderProvider");
        final z$a z$a = (z$a)function0.invoke();
        if (b) {
            final DataDomeInterceptor a = new com.beetalk.sdk.networking.a(false, null, null, 7, null).a();
            final n dataDomeCookieJar = a.getDataDomeCookieJar(m.a.f());
            Intrinsics.checkNotNullExpressionValue((Object)dataDomeCookieJar, "getDataDomeCookieJar(...)");
            z$a.h(dataDomeCookieJar);
            z$a.a((w)a);
            if (((CharSequence)s).length() > 0) {
                z$a.a((w)new f(s));
            }
        }
        final n8.a a2 = new n8.a((a$b)new com.beetalk.sdk.networking.j());
        a$a a$a;
        if (!A0.c) {
            a$a = n8.a$a.d;
        }
        else {
            a$a = n8.a$a.a;
        }
        a2.b(a$a);
        z$a.a((w)a2);
        final ListIterator listIterator = m.d.listIterator();
        while (listIterator.hasNext()) {
            z$a.a((w)listIterator.next());
        }
        return z$a.c();
    }
    
    public final z n(final String s, final boolean b) {
        Intrinsics.checkNotNullParameter((Object)s, "signatureKey");
        return this.o(b, new com.beetalk.sdk.networking.k(s));
    }
    
    public final z q(final String s, final boolean b) {
        Intrinsics.checkNotNullParameter((Object)s, "signatureKey");
        return this.o(b, new l(s));
    }
}
