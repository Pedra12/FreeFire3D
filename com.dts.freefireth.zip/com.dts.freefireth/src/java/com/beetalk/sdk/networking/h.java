package com.beetalk.sdk.networking;

import c1.g;
import java.util.concurrent.Callable;
import org.json.JSONObject;
import com.beetalk.sdk.helper.k;
import c1.i;
import Z7.z;
import java.util.List;
import android.text.TextUtils;
import com.google.gson.ToNumberStrategy;
import com.google.gson.ToNumberPolicy;
import com.google.gson.GsonBuilder;
import java.util.Map;
import com.google.gson.Gson;

public class h
{
    public static final Gson f;
    private final d a;
    private final Map b;
    private String c;
    private boolean d;
    private boolean e;
    
    static {
        final GsonBuilder gsonBuilder = new GsonBuilder();
        final ToNumberPolicy long_OR_DOUBLE = ToNumberPolicy.LONG_OR_DOUBLE;
        f = gsonBuilder.setObjectToNumberStrategy((ToNumberStrategy)long_OR_DOUBLE).setNumberToNumberStrategy((ToNumberStrategy)long_OR_DOUBLE).create();
    }
    
    public h(final d a, final Map<String, String> b) {
        this.d = false;
        this.e = false;
        this.a = a;
        this.b = b;
    }
    
    private void e(String s, final h$b h$b) {
        if (h$b instanceof e) {
            final e e = (e)h$b;
            if (s == null) {
                s = "";
            }
            e.a(s);
            return;
        }
        if (h$b instanceof h.h$c) {
            final h.h$c h$c = (h.h$c)h$b;
            JSONObject jsonObject;
            if (!TextUtils.isEmpty((CharSequence)s)) {
                jsonObject = new JSONObject(s);
            }
            else {
                jsonObject = null;
            }
            h$c.onCompleted(jsonObject);
        }
    }
    
    public static String h(final d d, final String s, final Map map, final boolean b, final boolean b2) {
        final h h = new h(d, (Map<String, String>)map);
        h.i(b);
        h.j(b2);
        return h.g(s);
    }
    
    public void f(final String s, final h$b h$b) {
        i.f((Callable)new com.beetalk.sdk.networking.d(this, s)).l((g)new com.beetalk.sdk.networking.e(this, h$b), i.k).k((g)new f(this, h$b));
    }
    
    public String g(final String s) {
        final i f = i.f((Callable)new com.beetalk.sdk.networking.g(this, s));
        Label_0055: {
            try {
                f.K();
                if (!f.z()) {
                    if (!f.x()) {
                        return (String)f.v();
                    }
                }
            }
            catch (final InterruptedException ex) {
                break Label_0055;
            }
            k.b(f.u());
            return null;
        }
        final InterruptedException ex;
        k.b((Exception)ex);
        return null;
    }
    
    public h i(final boolean d) {
        this.d = d;
        return this;
    }
    
    public void j(final boolean e) {
        this.e = e;
    }
    
    public h k(final String c) {
        this.c = c;
        return this;
    }
    
    public enum d
    {
        a, 
        b;
        
        private static final d[] c;
        
        static {
            c = a();
        }
        
        private static /* synthetic */ d[] a() {
            return new d[] { d.a, d.b };
        }
    }
    
    public interface e extends h$b
    {
        void a(final String p0);
    }
}
