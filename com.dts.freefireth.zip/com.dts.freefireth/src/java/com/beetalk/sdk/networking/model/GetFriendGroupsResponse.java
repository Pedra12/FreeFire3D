package com.beetalk.sdk.networking.model;

import kotlin.collections.CollectionsKt;
import org.jetbrains.annotations.NotNull;
import java.util.List;
import com.google.gson.annotations.SerializedName;
import kotlin.Metadata;

@Metadata
public final class GetFriendGroupsResponse
{
    @SerializedName("error")
    private String error;
    @SerializedName("friends_groups")
    @NotNull
    private List<FriendGroup> groups;
    
    public GetFriendGroupsResponse() {
        this.groups = (List<FriendGroup>)CollectionsKt.k();
    }
    
    public final String a() {
        return this.error;
    }
    
    public final List b() {
        return this.groups;
    }
}
