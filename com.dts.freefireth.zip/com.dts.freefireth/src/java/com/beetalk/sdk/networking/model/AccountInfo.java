package com.beetalk.sdk.networking.model;

import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import com.google.gson.annotations.SerializedName;
import kotlin.Metadata;

@Metadata
public final class AccountInfo
{
    @SerializedName("email")
    @NotNull
    private final String email;
    @SerializedName("gender")
    private final int gender;
    @SerializedName("icon")
    @NotNull
    private final String icon;
    @SerializedName("nickname")
    @NotNull
    private final String nickName;
    
    public AccountInfo(final int gender, @NotNull final String nickName, @NotNull final String email, @NotNull final String icon) {
        Intrinsics.checkNotNullParameter((Object)nickName, "nickName");
        Intrinsics.checkNotNullParameter((Object)email, "email");
        Intrinsics.checkNotNullParameter((Object)icon, "icon");
        this.gender = gender;
        this.nickName = nickName;
        this.email = email;
        this.icon = icon;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof AccountInfo)) {
            return false;
        }
        final AccountInfo accountInfo = (AccountInfo)o;
        return this.gender == accountInfo.gender && Intrinsics.a((Object)this.nickName, (Object)accountInfo.nickName) && Intrinsics.a((Object)this.email, (Object)accountInfo.email) && Intrinsics.a((Object)this.icon, (Object)accountInfo.icon);
    }
    
    @Override
    public int hashCode() {
        return ((this.gender * 31 + this.nickName.hashCode()) * 31 + this.email.hashCode()) * 31 + this.icon.hashCode();
    }
    
    @Override
    public String toString() {
        final int gender = this.gender;
        final String nickName = this.nickName;
        final String email = this.email;
        final String icon = this.icon;
        final StringBuilder sb = new StringBuilder();
        sb.append("AccountInfo(gender=");
        sb.append(gender);
        sb.append(", nickName=");
        sb.append(nickName);
        sb.append(", email=");
        sb.append(email);
        sb.append(", icon=");
        sb.append(icon);
        sb.append(")");
        return sb.toString();
    }
}
