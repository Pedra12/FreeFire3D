package com.beetalk.sdk.networking.interceptor;

import Z7.B;
import kotlin.text.StringsKt;
import Z7.D;
import Z7.w$a;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.Metadata;
import Z7.w;

@Metadata
public final class f implements w
{
    public static final a b;
    private final String a;
    
    static {
        b = new a(null);
    }
    
    public f(@NotNull final String a) {
        Intrinsics.checkNotNullParameter((Object)a, "userAgent");
        this.a = a;
    }
    
    public D intercept(final w$a w$a) {
        Intrinsics.checkNotNullParameter((Object)w$a, "chain");
        final B request = w$a.request();
        String d;
        if ((d = request.d("User-Agent")) == null) {
            d = "";
        }
        final String a = this.a;
        final StringBuilder sb = new StringBuilder();
        sb.append(d);
        sb.append(" ");
        sb.append(a);
        return w$a.b(request.i().e("User-Agent", StringsKt.M0((CharSequence)sb.toString()).toString()).b());
    }
    
    @Metadata
    public static final class a
    {
        private a() {
        }
    }
}
