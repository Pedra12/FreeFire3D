package com.beetalk.sdk.networking.model;

import org.jetbrains.annotations.NotNull;
import com.beetalk.sdk.networking.ULongJsonAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import kotlin.Metadata;

@Metadata
public final class BoundedAccount
{
    @SerializedName("user_info")
    private AccountInfo accountInfo;
    @SerializedName("create_time")
    private long createTime;
    @SerializedName("platform")
    private int platformType;
    @JsonAdapter(ULongJsonAdapter.class)
    @SerializedName("uid")
    @NotNull
    private String uid;
    
    public BoundedAccount() {
        this.uid = "";
    }
}
