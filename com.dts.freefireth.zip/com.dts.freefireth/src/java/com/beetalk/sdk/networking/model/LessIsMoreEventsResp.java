package com.beetalk.sdk.networking.model;

import org.json.JSONException;
import com.beetalk.sdk.helper.k;
import org.json.JSONObject;
import com.garena.pay.android.l;
import java.util.List;

public class LessIsMoreEventsResp extends BaseResp
{
    public List<LessIsMoreEvent> events;
    public String response;
    public String version;
    
    public LessIsMoreEventsResp() {
        this.response = "";
        this.version = "";
    }
    
    public static LessIsMoreEventsResp j(final String response) {
        final LessIsMoreEventsResp lessIsMoreEventsResp = new LessIsMoreEventsResp();
        if (response == null) {
            lessIsMoreEventsResp.errorCode = l.h1.b();
            return lessIsMoreEventsResp;
        }
        lessIsMoreEventsResp.errorCode = lessIsMoreEventsResp.f(response);
        try {
            final JSONObject jsonObject = new JSONObject(response);
            lessIsMoreEventsResp.resultCode = lessIsMoreEventsResp.g(jsonObject);
            lessIsMoreEventsResp.events = (List<LessIsMoreEvent>)LessIsMoreEvent.a(jsonObject.optJSONArray("events"));
            lessIsMoreEventsResp.version = jsonObject.optString("version");
            lessIsMoreEventsResp.response = response;
            return lessIsMoreEventsResp;
        }
        catch (final JSONException ex) {
            k.b((Exception)ex);
            return lessIsMoreEventsResp;
        }
    }
}
