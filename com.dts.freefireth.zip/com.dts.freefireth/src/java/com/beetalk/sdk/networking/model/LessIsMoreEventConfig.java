package com.beetalk.sdk.networking.model;

import org.json.JSONObject;
import com.beetalk.sdk.helper.k;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;

public class LessIsMoreEventConfig
{
    public String extra_info;
    public long item_id;
    public double price;
    public long rebate_id;
    
    public LessIsMoreEventConfig() {
        this.rebate_id = 0L;
        this.item_id = 0L;
        this.price = 0.0;
        this.extra_info = "";
    }
    
    public static List a(final JSONArray jsonArray) {
        if (jsonArray == null) {
            return null;
        }
        final ArrayList list = new ArrayList();
        int n = 0;
        while (true) {
            Label_0118: {
                LessIsMoreEventConfig lessIsMoreEventConfig;
                try {
                    if (n >= jsonArray.length()) {
                        return (List)list;
                    }
                    final JSONObject jsonObject = jsonArray.getJSONObject(n);
                    lessIsMoreEventConfig = new LessIsMoreEventConfig();
                    lessIsMoreEventConfig.rebate_id = jsonObject.optLong("rebate_id");
                    lessIsMoreEventConfig.item_id = jsonObject.optLong("item_id");
                    lessIsMoreEventConfig.price = jsonObject.optDouble("price");
                    final JSONObject optJSONObject = jsonObject.optJSONObject("extra_info");
                    if (optJSONObject != null) {
                        lessIsMoreEventConfig.extra_info = optJSONObject.toString();
                    }
                }
                catch (final JSONException ex) {
                    break Label_0118;
                }
                ((List)list).add((Object)lessIsMoreEventConfig);
                ++n;
                continue;
            }
            final JSONException ex;
            k.b((Exception)ex);
            return null;
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("rebate_id = ");
        sb.append(this.rebate_id);
        sb.append(", item_id = ");
        sb.append(this.item_id);
        sb.append(", price = ");
        sb.append(this.price);
        sb.append("\nextra_info = ");
        sb.append(this.extra_info);
        return sb.toString();
    }
}
