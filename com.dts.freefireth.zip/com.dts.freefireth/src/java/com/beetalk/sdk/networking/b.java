package com.beetalk.sdk.networking;

import F2.a$a;
import com.google.gson.JsonElement;
import kotlin.Unit;
import s7.p$a;
import com.garena.pay.android.l;
import s7.q;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import s7.p;
import kotlin.jvm.internal.Intrinsics;
import F2.a;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;
import com.google.gson.annotations.SerializedName;
import kotlin.Metadata;

@Metadata
public class b<T>
{
    public static final a a;
    @SerializedName("code")
    private int code;
    @SerializedName("data")
    private T data;
    @SerializedName("error")
    @NotNull
    private String error;
    @SerializedName("error_detail")
    @NotNull
    private String errorDetail;
    
    static {
        a = new a(null);
    }
    
    public b() {
        this.code = -1;
        this.error = "";
        this.errorDetail = "";
    }
    
    public final Object a() {
        return this.data;
    }
    
    public final String b() {
        return this.error;
    }
    
    public String c() {
        return this.errorDetail;
    }
    
    @Metadata
    public static final class a
    {
        private a() {
        }
        
        public final F2.a a(final String s, final Class clazz) {
            Intrinsics.checkNotNullParameter((Object)s, "response");
            Intrinsics.checkNotNullParameter((Object)clazz, "clazz");
            Object b3 = null;
            try {
                final p$a b = p.b;
                p.b((Object)h.f.fromJson(s, TypeToken.getParameterized((Type)b.class, new Type[] { (Type)clazz }).getType()));
            }
            finally {
                final p$a b2 = p.b;
                final Throwable t;
                b3 = p.b(q.a(t));
            }
            final Throwable d = p.d(b3);
            Object o = null;
            Label_0172: {
                if (d == null) {
                    final b b4 = (b)b3;
                    if (((CharSequence)b4.b()).length() > 0) {
                        Intrinsics.c((Object)b4);
                        o = F2.a.c(r.b(b4), b4.b(), b4.c());
                    }
                    else {
                        final Object a = b4.a();
                        if (a != null) {
                            o = F2.a.i(a);
                            if (o != null) {
                                break Label_0172;
                            }
                        }
                        Intrinsics.c((Object)b4);
                        o = F2.a.c(r.b(b4), b4.b(), b4.c());
                    }
                }
                else {
                    o = F2.a.a(l.a1, new Exception(d));
                }
            }
            Intrinsics.checkNotNullExpressionValue(o, "fold(...)");
            return (F2.a)o;
        }
        
        public final F2.a b(final String s) {
            Intrinsics.checkNotNullParameter((Object)s, "response");
            Object b3 = null;
            try {
                final p$a b = p.b;
                p.b((Object)h.f.fromJson(s, (Class)b.class));
            }
            finally {
                final p$a b2 = p.b;
                final Throwable t;
                b3 = p.b(q.a(t));
            }
            final Throwable d = p.d(b3);
            Object o;
            if (d == null) {
                final b b4 = (b)b3;
                if (((CharSequence)b4.b()).length() == 0) {
                    o = F2.a.i((Object)Unit.a);
                }
                else {
                    Intrinsics.c((Object)b4);
                    o = F2.a.c(r.b(b4), b4.b(), b4.c());
                }
            }
            else {
                o = F2.a.a(l.a1, new Exception(d));
            }
            Intrinsics.checkNotNullExpressionValue(o, "fold(...)");
            return (F2.a)o;
        }
        
        public final F2.a c(final String s, final Class clazz) {
            Intrinsics.checkNotNullParameter((Object)s, "response");
            Intrinsics.checkNotNullParameter((Object)clazz, "clazz");
            final F2.a a = this.a(s, JsonElement.class);
            if (a.g()) {
                return (F2.a)new a$a(a.d(), a.e(), a.f());
            }
            final Object b3;
            Label_0129: {
                Label_0117: {
                    try {
                        final p$a b = p.b;
                        final JsonElement jsonElement = (JsonElement)a.j();
                        final Object fromJson = h.f.fromJson(jsonElement, clazz);
                        if (fromJson != null) {
                            final String string = jsonElement.toString();
                            Intrinsics.checkNotNullExpressionValue((Object)string, "toString(...)");
                            p.b((Object)new com.beetalk.sdk.networking.p(fromJson, string));
                            break Label_0129;
                        }
                    }
                    finally {
                        break Label_0117;
                    }
                    throw new IllegalArgumentException("Response data is missing");
                }
                final p$a b2 = p.b;
                b3 = p.b(q.a((Throwable)b3));
            }
            final Throwable d = p.d(b3);
            Object o;
            if (d == null) {
                o = F2.a.i((Object)b3);
            }
            else {
                o = F2.a.a(l.a1, new Exception(d));
            }
            Intrinsics.checkNotNullExpressionValue(o, "fold(...)");
            return (F2.a)o;
        }
    }
}
