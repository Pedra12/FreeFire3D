package com.beetalk.sdk.networking.interceptor;

import com.beetalk.sdk.helper.k;
import org.json.JSONObject;
import com.beetalk.sdk.networking.o;
import kotlin.jvm.internal.Intrinsics;
import Z7.w$a;
import java.util.List;
import com.beetalk.sdk.cache.i;
import kotlin.jvm.functions.Function1;
import kotlin.collections.CollectionsKt;
import Z7.D;
import kotlin.Metadata;
import Z7.w;

@Metadata
public final class d implements w
{
    private final void a(final D d, final int n) {
        final List l = d.l("Set-Cookie");
        if (!l.isEmpty()) {
            final String v = CollectionsKt.V((Iterable)l, (CharSequence)";", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null);
            if (((CharSequence)v).length() > 0) {
                final i i = new i();
                if (n == 4) {
                    final String d2 = i.d();
                    if (d2 != null) {
                        if (((CharSequence)d2).length() == 0) {
                            return;
                        }
                        i.i(v);
                    }
                }
            }
        }
    }
    
    public D intercept(w$a b) {
        Intrinsics.checkNotNullParameter((Object)b, "chain");
        b = (w$a)b.b(b.request());
        try {
            this.a((D)b, new JSONObject(o.b((D)b)).optInt("platform", 0));
            return (D)b;
        }
        catch (final Exception ex) {
            k.b(ex);
            return (D)b;
        }
    }
}
