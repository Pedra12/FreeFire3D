package com.beetalk.sdk.networking;

import co.datadome.sdk.DataDomeInterceptor;
import android.content.Context;
import co.datadome.sdk.DataDomeSDK$BackBehaviour;
import co.datadome.sdk.DataDomeSDK;
import com.beetalk.sdk.A0;
import android.app.Application;
import com.beetalk.sdk.X;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import kotlin.jvm.internal.DefaultConstructorMarker;
import co.datadome.sdk.DataDomeSDKListener;
import co.datadome.sdk.DataDomeSDK$Builder;
import kotlin.Metadata;

@Metadata
public final class a
{
    private final DataDomeSDK$Builder a;
    
    public a() {
        this(false, null, null, 7, null);
    }
    
    public a(final boolean b, final DataDomeSDKListener dataDomeSDKListener, @NotNull final String cookie) {
        Intrinsics.checkNotNullParameter((Object)cookie, "cookie");
        final Context m = X.M();
        Intrinsics.d((Object)m, "null cannot be cast to non-null type android.app.Application");
        final DataDomeSDK$Builder backBehaviour = DataDomeSDK.with((Application)m, A0.q(), "4.0.44").listener(dataDomeSDKListener).bypassAcceptHeader(Boolean.valueOf(b)).activateDatadomeLogger(Boolean.valueOf(A0.p())).backBehaviour(DataDomeSDK$BackBehaviour.GO_BACK);
        if (((CharSequence)cookie).length() > 0) {
            backBehaviour.setCookie(cookie);
        }
        Intrinsics.checkNotNullExpressionValue((Object)backBehaviour, "apply(...)");
        this.a = backBehaviour;
    }
    
    public final DataDomeInterceptor a() {
        final Context m = X.M();
        Intrinsics.d((Object)m, "null cannot be cast to non-null type android.app.Application");
        return new DataDomeInterceptor((Application)m, this.a);
    }
}
