package com.beetalk.sdk.networking.model;

import com.garena.pay.android.data.GGPaymentAppItem;
import java.util.List;

public class AppItemsResp extends BaseResp
{
    private List<GGPaymentAppItem> appItems;
    
    public List j() {
        return this.appItems;
    }
}
