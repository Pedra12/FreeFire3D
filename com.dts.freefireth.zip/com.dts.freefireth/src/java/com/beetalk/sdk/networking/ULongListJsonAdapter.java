package com.beetalk.sdk.networking;

import java.util.Collection;
import java.util.Iterator;
import kotlin.text.StringsKt;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonArray;
import java.util.ArrayList;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import com.google.gson.JsonDeserializationContext;
import java.lang.reflect.Type;
import com.google.gson.JsonElement;
import kotlin.Metadata;
import com.google.gson.JsonSerializer;
import java.util.List;
import com.google.gson.JsonDeserializer;

@Metadata
public final class ULongListJsonAdapter implements JsonDeserializer<List<? extends String>>, JsonSerializer<List<? extends String>>
{
    public List a(JsonElement jsonElement, Type type, JsonDeserializationContext iterator) {
        Intrinsics.checkNotNullParameter((Object)jsonElement, "json");
        Intrinsics.checkNotNullParameter((Object)type, "typeOfT");
        Intrinsics.checkNotNullParameter((Object)iterator, "context");
        final JsonArray asJsonArray = jsonElement.getAsJsonArray();
        Intrinsics.checkNotNullExpressionValue((Object)asJsonArray, "getAsJsonArray(...)");
        type = (Type)new ArrayList(CollectionsKt.v((Iterable)asJsonArray, 10));
        iterator = (JsonDeserializationContext)((Iterable)asJsonArray).iterator();
        while (((Iterator)iterator).hasNext()) {
            jsonElement = (JsonElement)((Iterator)iterator).next();
            String string;
            try {
                string = jsonElement.getAsBigInteger().toString();
            }
            catch (final Exception ex) {
                string = "";
            }
            ((Collection)type).add((Object)string);
        }
        return (List)type;
    }
    
    public JsonElement b(final List list, final Type type, final JsonSerializationContext jsonSerializationContext) {
        Intrinsics.checkNotNullParameter((Object)list, "src");
        Intrinsics.checkNotNullParameter((Object)type, "typeOfSrc");
        Intrinsics.checkNotNullParameter((Object)jsonSerializationContext, "context");
        final JsonArray jsonArray = new JsonArray();
        final Iterator iterator = ((Iterable)list).iterator();
        while (iterator.hasNext()) {
            Object o;
            if ((o = StringsKt.m((String)iterator.next())) == null) {
                o = 0;
            }
            jsonArray.add((Number)o);
        }
        return (JsonElement)jsonArray;
    }
}
