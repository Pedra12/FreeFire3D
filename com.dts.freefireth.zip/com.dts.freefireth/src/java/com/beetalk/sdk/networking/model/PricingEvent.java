package com.beetalk.sdk.networking.model;

public class PricingEvent
{
    public int available_times;
    public long end_time;
    public int id;
    public int[] items;
    public long start_time;
    public int status;
    public int total_times;
    public String type;
    
    public PricingEvent() {
        this.id = 0;
        this.type = "";
        this.start_time = 0L;
        this.end_time = 0L;
        this.available_times = 0;
        this.total_times = 0;
        this.status = 0;
    }
}
