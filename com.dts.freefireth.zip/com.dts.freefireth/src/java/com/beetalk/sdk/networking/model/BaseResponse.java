package com.beetalk.sdk.networking.model;

import android.text.TextUtils;
import com.google.gson.annotations.SerializedName;

public class BaseResponse
{
    @SerializedName("error")
    public String error;
    
    public BaseResponse() {
        this.error = "";
    }
    
    public String a() {
        return this.error;
    }
    
    public boolean b() {
        return TextUtils.isEmpty((CharSequence)this.error) ^ true;
    }
}
