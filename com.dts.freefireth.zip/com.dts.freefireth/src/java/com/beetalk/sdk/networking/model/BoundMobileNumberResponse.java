package com.beetalk.sdk.networking.model;

import org.json.JSONObject;

public final class BoundMobileNumberResponse extends BaseResp
{
    public final long lastUpdateTime;
    public final String phoneNumber;
    
    public BoundMobileNumberResponse(final JSONObject jsonObject) {
        this.phoneNumber = jsonObject.optString("mobile_no", "");
        this.lastUpdateTime = jsonObject.optLong("mobile_update_time", 0L);
        this.h(jsonObject);
    }
}
