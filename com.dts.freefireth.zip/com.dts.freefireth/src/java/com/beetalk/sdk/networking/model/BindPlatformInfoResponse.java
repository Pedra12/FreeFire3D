package com.beetalk.sdk.networking.model;

import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import com.google.gson.annotations.SerializedName;
import java.util.List;
import kotlin.Metadata;

@Metadata
public final class BindPlatformInfoResponse
{
    @SerializedName("available_platforms")
    @NotNull
    private final List<Integer> availablePlatforms;
    @SerializedName("bounded_accounts")
    @NotNull
    private final List<BoundedAccount> boundedAccounts;
    @SerializedName("error")
    private final String error;
    
    public BindPlatformInfoResponse(@NotNull final List<BoundedAccount> boundedAccounts, @NotNull final List<Integer> availablePlatforms, final String error) {
        Intrinsics.checkNotNullParameter((Object)boundedAccounts, "boundedAccounts");
        Intrinsics.checkNotNullParameter((Object)availablePlatforms, "availablePlatforms");
        this.boundedAccounts = boundedAccounts;
        this.availablePlatforms = availablePlatforms;
        this.error = error;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BindPlatformInfoResponse)) {
            return false;
        }
        final BindPlatformInfoResponse bindPlatformInfoResponse = (BindPlatformInfoResponse)o;
        return Intrinsics.a((Object)this.boundedAccounts, (Object)bindPlatformInfoResponse.boundedAccounts) && Intrinsics.a((Object)this.availablePlatforms, (Object)bindPlatformInfoResponse.availablePlatforms) && Intrinsics.a((Object)this.error, (Object)bindPlatformInfoResponse.error);
    }
    
    @Override
    public int hashCode() {
        final int hashCode = this.boundedAccounts.hashCode();
        final int hashCode2 = this.availablePlatforms.hashCode();
        final String error = this.error;
        int hashCode3;
        if (error == null) {
            hashCode3 = 0;
        }
        else {
            hashCode3 = error.hashCode();
        }
        return (hashCode * 31 + hashCode2) * 31 + hashCode3;
    }
    
    @Override
    public String toString() {
        final List<BoundedAccount> boundedAccounts = this.boundedAccounts;
        final List<Integer> availablePlatforms = this.availablePlatforms;
        final String error = this.error;
        final StringBuilder sb = new StringBuilder();
        sb.append("BindPlatformInfoResponse(boundedAccounts=");
        sb.append((Object)boundedAccounts);
        sb.append(", availablePlatforms=");
        sb.append((Object)availablePlatforms);
        sb.append(", error=");
        sb.append(error);
        sb.append(")");
        return sb.toString();
    }
}
