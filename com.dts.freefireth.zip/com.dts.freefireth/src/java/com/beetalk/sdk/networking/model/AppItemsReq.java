package com.beetalk.sdk.networking.model;

public class AppItemsReq extends BaseReq
{
}
