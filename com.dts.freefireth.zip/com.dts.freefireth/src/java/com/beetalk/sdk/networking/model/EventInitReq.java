package com.beetalk.sdk.networking.model;

import com.beetalk.sdk.helper.k;
import com.beetalk.sdk.X;
import java.util.HashMap;
import java.util.Map;
import com.garena.pay.android.p;

public class EventInitReq extends BaseReq
{
    public static Map a(final p p4, final String s, final String s2, final String s3) {
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"access_token", (Object)p4.c().q());
        hashMap.put((Object)"app_id", (Object)p4.c().d());
        hashMap.put((Object)"client_type", (Object)String.valueOf(2));
        hashMap.put((Object)"app_server_id", (Object)String.valueOf(p4.c().f()));
        hashMap.put((Object)"app_role_id", (Object)String.valueOf(p4.c().p()));
        hashMap.put((Object)"source", (Object)X.N().toString());
        hashMap.put((Object)"open_id", (Object)p4.c().g());
        hashMap.put((Object)"item_id", (Object)s);
        hashMap.put((Object)"event_id", (Object)s2);
        hashMap.put((Object)"for_channel_id", (Object)String.valueOf(201069));
        hashMap.put((Object)"user_region", (Object)s3);
        k.a("EventInit Post Request Data %s", hashMap.toString());
        return (Map)hashMap;
    }
}
