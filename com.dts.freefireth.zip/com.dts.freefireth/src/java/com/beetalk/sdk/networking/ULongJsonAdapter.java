package com.beetalk.sdk.networking;

import com.google.gson.JsonPrimitive;
import kotlin.text.StringsKt;
import com.google.gson.JsonSerializationContext;
import kotlin.jvm.internal.Intrinsics;
import com.google.gson.JsonDeserializationContext;
import java.lang.reflect.Type;
import com.google.gson.JsonElement;
import kotlin.Metadata;
import com.google.gson.JsonSerializer;
import com.google.gson.JsonDeserializer;

@Metadata
public final class ULongJsonAdapter implements JsonDeserializer<String>, JsonSerializer<String>
{
    public String a(final JsonElement jsonElement, final Type type, final JsonDeserializationContext jsonDeserializationContext) {
        Intrinsics.checkNotNullParameter((Object)jsonElement, "json");
        Intrinsics.checkNotNullParameter((Object)type, "typeOfT");
        Intrinsics.checkNotNullParameter((Object)jsonDeserializationContext, "context");
        try {
            final String string = jsonElement.getAsBigInteger().toString();
            Intrinsics.c((Object)string);
            return string;
        }
        catch (final Exception ex) {
            return "";
        }
    }
    
    public JsonElement b(final String s, final Type type, final JsonSerializationContext jsonSerializationContext) {
        Intrinsics.checkNotNullParameter((Object)s, "src");
        Intrinsics.checkNotNullParameter((Object)type, "typeOfSrc");
        Intrinsics.checkNotNullParameter((Object)jsonSerializationContext, "context");
        Object o;
        if ((o = StringsKt.m(s)) == null) {
            o = 0;
        }
        return (JsonElement)new JsonPrimitive((Number)o);
    }
}
