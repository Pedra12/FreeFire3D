package com.beetalk.sdk.networking;

import c1.g;
import java.util.concurrent.Callable;
import kotlin.jvm.internal.Intrinsics;
import s7.p;
import c1.i;
import kotlin.jvm.functions.Function1;
import android.webkit.WebView;
import kotlin.Metadata;

@Metadata
public final class w
{
    public static final void c(final WebView webView, final String s, final Function1 function1) {
        Intrinsics.checkNotNullParameter((Object)webView, "<this>");
        Intrinsics.checkNotNullParameter((Object)s, "url");
        Intrinsics.checkNotNullParameter((Object)function1, "callback");
        i.f((Callable)new u(s)).l((g)new v(webView, function1), i.k);
    }
    
    private static final p d(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "$url");
        return p.a(m.a.e(s));
    }
    
    private static final Void e(final WebView webView, final Function1 function1, final i i) {
        Intrinsics.checkNotNullParameter((Object)webView, "$this_loadUrlWithAutoSwitch");
        Intrinsics.checkNotNullParameter((Object)function1, "$callback");
        final Object v = i.v();
        Intrinsics.checkNotNullExpressionValue(v, "getResult(...)");
        final Object j = ((p)v).i();
        if (p.d(j) == null) {
            webView.loadUrl((String)j);
            return (Void)function1.invoke((Object)Boolean.TRUE);
        }
        return (Void)function1.invoke((Object)Boolean.FALSE);
    }
}
