package com.beetalk.sdk.networking.interceptor;

import Z7.B$a;
import Z7.B;
import Z7.D;
import Z7.w$a;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import kotlin.Metadata;
import Z7.w;

@Metadata
public final class a implements w
{
    private final e a;
    
    public a(@NotNull final e a) {
        Intrinsics.checkNotNullParameter((Object)a, "signatureProvider");
        this.a = a;
    }
    
    public D intercept(final w$a w$a) {
        Intrinsics.checkNotNullParameter((Object)w$a, "chain");
        final B request = w$a.request();
        final String a = this.a.a(request);
        final B$a i = request.i();
        final StringBuilder sb = new StringBuilder();
        sb.append("Signature ");
        sb.append(a);
        return w$a.b(i.e("Authorization", sb.toString()).b());
    }
}
