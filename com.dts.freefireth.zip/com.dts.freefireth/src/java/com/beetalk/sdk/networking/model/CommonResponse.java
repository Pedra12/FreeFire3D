package com.beetalk.sdk.networking.model;

import kotlin.jvm.internal.Intrinsics;
import com.garena.pay.android.l;
import org.jetbrains.annotations.NotNull;
import com.google.gson.annotations.SerializedName;
import kotlin.Metadata;

@Metadata
public class CommonResponse
{
    @SerializedName("result")
    private final int code;
    @SerializedName("error")
    @NotNull
    private String error;
    
    public CommonResponse() {
        this.error = "";
        final Integer b = l.t1.b();
        Intrinsics.checkNotNullExpressionValue((Object)b, "getCode(...)");
        this.code = ((Number)b).intValue();
    }
    
    public final int a() {
        return this.code;
    }
    
    public final String b() {
        return this.error;
    }
    
    public final boolean c() {
        final int code = this.code;
        final Integer b = l.c.b();
        if (b != null) {
            if (code == b) {
                return true;
            }
        }
        return false;
    }
}
