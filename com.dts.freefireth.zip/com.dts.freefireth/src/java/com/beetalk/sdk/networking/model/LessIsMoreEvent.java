package com.beetalk.sdk.networking.model;

import org.json.JSONObject;
import com.beetalk.sdk.helper.k;
import org.json.JSONException;
import java.util.ArrayList;
import org.json.JSONArray;
import java.util.List;

public class LessIsMoreEvent
{
    public List<LessIsMoreEventConfig> configs;
    public long end_time;
    public long id;
    public String region;
    public long start_time;
    public String type;
    
    public LessIsMoreEvent() {
        this.id = 0L;
        this.start_time = 0L;
        this.end_time = 0L;
        this.region = "";
        this.type = "";
    }
    
    public static List a(final JSONArray jsonArray) {
        if (jsonArray == null) {
            return null;
        }
        final ArrayList list = new ArrayList();
        int i = 0;
        Label_0128: {
            try {
                while (i < jsonArray.length()) {
                    final JSONObject jsonObject = jsonArray.getJSONObject(i);
                    final LessIsMoreEvent lessIsMoreEvent = new LessIsMoreEvent();
                    lessIsMoreEvent.type = jsonObject.optString("type");
                    lessIsMoreEvent.start_time = jsonObject.optLong("start_time");
                    lessIsMoreEvent.id = jsonObject.optLong("id");
                    lessIsMoreEvent.end_time = jsonObject.optLong("end_time");
                    lessIsMoreEvent.region = jsonObject.optString("region");
                    lessIsMoreEvent.configs = (List<LessIsMoreEventConfig>)LessIsMoreEventConfig.a(jsonObject.optJSONArray("configs"));
                    ((List)list).add((Object)lessIsMoreEvent);
                    ++i;
                }
            }
            catch (final JSONException ex) {
                break Label_0128;
            }
            return (List)list;
        }
        final JSONException ex;
        k.b((Exception)ex);
        return null;
    }
}
