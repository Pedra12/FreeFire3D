package com.beetalk.sdk.networking.model;

import org.json.JSONObject;

public final class VerifyOTPResponse extends BaseResp
{
    private VerifyOTPResponse() {
    }
    
    public static VerifyOTPResponse j(final JSONObject jsonObject) {
        final VerifyOTPResponse verifyOTPResponse = new VerifyOTPResponse();
        verifyOTPResponse.h(jsonObject);
        return verifyOTPResponse;
    }
}
