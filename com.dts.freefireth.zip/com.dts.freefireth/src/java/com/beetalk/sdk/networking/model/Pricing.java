package com.beetalk.sdk.networking.model;

import java.util.HashSet;
import java.util.HashMap;
import java.util.Set;
import java.util.Map;
import org.json.JSONArray;
import java.util.Iterator;
import com.garena.pay.android.data.GGPayment$Denomination$Subscription;
import com.garena.pay.android.data.GGPayment$Denomination;
import com.garena.pay.android.data.GGPayment$PaymentChannel;
import java.util.ArrayList;
import y.f;
import org.json.JSONException;
import com.beetalk.sdk.helper.k;
import android.text.TextUtils;
import org.json.JSONObject;
import com.garena.pay.android.ndk.RebateOptionItem;
import com.garena.pay.android.data.GGPaymentAppItem;
import java.util.List;
import java.io.Serializable;

public class Pricing implements Serializable
{
    private App app;
    private List<GGPaymentAppItem> appItems;
    private List<Channel> channels;
    private List<Promo> promoList;
    private List<RebateOptionItem> rebates;
    private Subscription subscription;
    
    public static Pricing a(final JSONObject jsonObject) {
        final Pricing pricing = new Pricing();
        if (jsonObject == null) {
            return pricing;
        }
        final App c = d(jsonObject.optJSONObject("app"));
        final List e = h(jsonObject.optJSONArray("promos"));
        final Subscription b = d(jsonObject.optJSONObject("subscriptions"));
        final List d = f(jsonObject.optJSONArray("channels"));
        final List b2 = RebateOptionItem.b(jsonObject.optJSONArray("rebates"));
        final List b3 = GGPaymentAppItem.b(jsonObject.optJSONArray("app_items"));
        pricing.app = c;
        pricing.promoList = (List<Promo>)e;
        pricing.subscription = b;
        pricing.channels = (List<Channel>)d;
        pricing.rebates = (List<RebateOptionItem>)b2;
        pricing.appItems = (List<GGPaymentAppItem>)b3;
        return pricing;
    }
    
    static List b(final String s) {
        if (TextUtils.isEmpty((CharSequence)s)) {
            return null;
        }
        try {
            return c(new JSONObject(s));
        }
        catch (final JSONException ex) {
            k.b((Exception)ex);
            return null;
        }
    }
    
    private static List c(final JSONObject jsonObject) {
        if (jsonObject == null) {
            return null;
        }
        final Pricing a = a(jsonObject);
        final App app = a.app;
        final List<Promo> promoList = a.promoList;
        final Subscription subscription = a.subscription;
        final List<Channel> channels = a.channels;
        final f f = new f();
        final List<RebateOptionItem> rebates = a.rebates;
        if (rebates != null) {
            for (final RebateOptionItem rebateOptionItem : rebates) {
                f.a(rebateOptionItem.rebateId, (Object)rebateOptionItem);
            }
        }
        final ArrayList list = new ArrayList();
        for (final Channel channel : channels) {
            final GGPayment$PaymentChannel ggPayment$PaymentChannel = new GGPayment$PaymentChannel();
            ggPayment$PaymentChannel.i(channel.id);
            ggPayment$PaymentChannel.n(channel.info.name);
            ggPayment$PaymentChannel.l(channel.info.icon);
            ggPayment$PaymentChannel.j(channel.info.description);
            ggPayment$PaymentChannel.k(channel.info.flag);
            final ArrayList list2 = new ArrayList();
        Label_0626_Outer:
            for (final Sku sku : channel.items) {
                final String d = sku.name;
                final String a2 = app.pointIcon;
                final String c = sku.id;
                final int b = sku.appPointAmount;
                final String e = sku.price;
                final long f2 = sku.rebateCardId;
                final long a3 = sku.appItemId;
                final Iterator iterator4 = promoList.iterator();
                boolean b2 = false;
                int n = 0;
                int n2 = 0;
                while (iterator4.hasNext()) {
                    final Promo promo = (Promo)iterator4.next();
                    if (!promo.f(channel.id, sku.id) && !promo.isOnAllItems) {
                        continue Label_0626_Outer;
                    }
                    final int n3 = (int)Math.ceil((double)(sku.appPointAmount * promo.appPointBonus / 100.0f));
                    n += n3;
                    int n4 = n2;
                    if (promo.isOneTimePromo) {
                        n4 = n2 + n3;
                    }
                    n2 = n4;
                }
                if (n > 0) {
                    b2 = true;
                }
                final GGPayment$Denomination ggPayment$Denomination = new GGPayment$Denomination(d, c, b, a2, e, b2, n, n2);
                ggPayment$Denomination.s(f2);
                ggPayment$Denomination.l(a3);
                ggPayment$Denomination.o(app.pointName);
                if (sku.subscription != null) {
                    int d2 = 0;
                    long b3 = 0L;
                    long a5 = 0L;
                    long c2 = 0L;
                    Label_0550: {
                        if (subscription != null) {
                            final Item.Info a4 = subscription.c(channel.id, sku.id);
                            if (a4 != null) {
                                d2 = a4.status;
                                b3 = a4.lastPaymentTime;
                                a5 = a4.gracePeriodExpire;
                                c2 = a4.onHoldSince;
                                break Label_0550;
                            }
                        }
                        b3 = 0L;
                        a5 = (c2 = 0L);
                        d2 = -1;
                    }
                    ggPayment$Denomination.t(new GGPayment$Denomination$Subscription(sku.subscription.period, d2, b3, a5, sku.subscription.introPrice, sku.subscription.introCycle, sku.subscription.introCurrencyAmount, c2));
                }
                final RebateOptionItem rebateOptionItem2 = (RebateOptionItem)f.d(f2);
                while (true) {
                    Label_0639: {
                        if (rebateOptionItem2 == null) {
                            break Label_0639;
                        }
                        if (!rebateOptionItem2.validToPurchase) {
                            continue Label_0626_Outer;
                        }
                        ggPayment$Denomination.n(rebateOptionItem2.name);
                        break Label_0639;
                        continue Label_0626_Outer;
                    }
                    ((List)list2).add((Object)ggPayment$Denomination);
                    continue;
                }
            }
            ggPayment$PaymentChannel.m((List)list2);
            ((List)list).add((Object)ggPayment$PaymentChannel);
        }
        return (List)list;
    }
    
    private static class App implements Serializable
    {
        private String pointIcon;
        private String pointName;
        
        private static App d(final JSONObject jsonObject) {
            final App app = new App();
            if (jsonObject == null) {
                return app;
            }
            app.pointIcon = jsonObject.optString("point_icon", "");
            app.pointName = jsonObject.optString("point_name", "");
            return app;
        }
    }
    
    private static class Channel implements Serializable
    {
        private String id;
        private Info info;
        private List<Sku> items;
        
        private static Channel e(final JSONObject jsonObject) {
            final Channel channel = new Channel();
            if (jsonObject == null) {
                return channel;
            }
            channel.id = jsonObject.optString("id");
            channel.info = f(jsonObject.optJSONObject("info"));
            channel.items = (List<Sku>)j(jsonObject.optJSONArray("items"));
            return channel;
        }
        
        private static List f(final JSONArray jsonArray) {
            final ArrayList list = new ArrayList();
            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.length(); ++i) {
                    ((List)list).add((Object)e(jsonArray.optJSONObject(i)));
                }
            }
            return (List)list;
        }
        
        private static class Info implements Serializable
        {
            private long channelId;
            private String description;
            private int flag;
            private String icon;
            private String name;
            private int priority;
            
            private static Info f(final JSONObject jsonObject) {
                final Info info = new Info();
                if (jsonObject == null) {
                    return info;
                }
                info.channelId = jsonObject.optLong("channel_id", 0L);
                info.name = jsonObject.optString("name");
                info.description = jsonObject.optString("description");
                info.priority = jsonObject.optInt("priority");
                info.icon = jsonObject.optString("icon");
                info.flag = jsonObject.optInt("flag");
                return info;
            }
        }
        
        private static class Sku implements Serializable
        {
            private long appItemId;
            private int appPointAmount;
            private String currency;
            private float currencyAmount;
            private String id;
            private String name;
            private String price;
            private long rebateCardId;
            private Sub subscription;
            
            private static Sku i(final JSONObject jsonObject) {
                if (jsonObject == null) {
                    return null;
                }
                final Sku sku = new Sku();
                sku.id = jsonObject.optString("id");
                sku.name = jsonObject.optString("name");
                sku.appPointAmount = jsonObject.optInt("app_point_amount");
                sku.price = jsonObject.optString("price");
                sku.currencyAmount = (float)jsonObject.optDouble("currency_amount");
                sku.currency = jsonObject.optString("currency");
                sku.rebateCardId = jsonObject.optLong("rebate_card_id", 0L);
                sku.appItemId = jsonObject.optLong("app_item_id", 0L);
                sku.subscription = f(jsonObject.optJSONObject("subscription"));
                return sku;
            }
            
            private static List j(final JSONArray jsonArray) {
                final ArrayList list = new ArrayList();
                if (jsonArray != null) {
                    for (int i = 0; i < jsonArray.length(); ++i) {
                        final Sku j = i(jsonArray.optJSONObject(i));
                        if (j != null) {
                            ((List)list).add((Object)j);
                        }
                    }
                }
                return (List)list;
            }
            
            private static class Sub implements Serializable
            {
                private double introCurrencyAmount;
                private int introCycle;
                private String introPrice;
                private int period;
                
                private static Sub f(final JSONObject jsonObject) {
                    if (jsonObject == null) {
                        return null;
                    }
                    final Sub sub = new Sub();
                    sub.period = jsonObject.optInt("period", 0);
                    sub.introPrice = jsonObject.optString("intro_price", "");
                    sub.introCurrencyAmount = jsonObject.optDouble("intro_currency_amount", 0.0);
                    sub.introCycle = jsonObject.optInt("intro_cycle", 0);
                    return sub;
                }
            }
        }
    }
    
    private static class Promo implements Serializable
    {
        private float appPointBonus;
        private long id;
        private boolean isOnAllItems;
        private boolean isOneTimePromo;
        private Map<String, Set<String>> targetItems;
        
        private Promo() {
            this.targetItems = (Map<String, Set<String>>)new HashMap();
        }
        
        private boolean f(final String s, final String s2) {
            if (!this.targetItems.containsKey((Object)s)) {
                return false;
            }
            final Set set = (Set)this.targetItems.get((Object)s);
            return set != null && set.contains((Object)s2);
        }
        
        private static Promo g(JSONObject optJSONObject) {
            if (optJSONObject == null) {
                return null;
            }
            final Promo promo = new Promo();
            promo.id = optJSONObject.optLong("id");
            promo.appPointBonus = (float)optJSONObject.optDouble("app_point_bonus");
            promo.isOnAllItems = optJSONObject.optBoolean("is_on_all_items");
            promo.isOneTimePromo = optJSONObject.optBoolean("is_one_time_promo");
            optJSONObject = optJSONObject.optJSONObject("target_items");
            final Iterator keys = optJSONObject.keys();
            while (keys.hasNext()) {
                final String s = (String)keys.next();
                final Object opt = optJSONObject.opt(s);
                if (opt instanceof JSONArray) {
                    final HashSet set = new HashSet();
                    promo.targetItems.put((Object)s, (Object)set);
                    final JSONArray jsonArray = (JSONArray)opt;
                    for (int i = 0; i < jsonArray.length(); ++i) {
                        ((Set)set).add((Object)jsonArray.optString(i));
                    }
                }
            }
            return promo;
        }
        
        private static List h(final JSONArray jsonArray) {
            final ArrayList list = new ArrayList();
            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.length(); ++i) {
                    final Promo g = g(jsonArray.optJSONObject(i));
                    if (g != null) {
                        ((List)list).add((Object)g);
                    }
                }
            }
            return (List)list;
        }
    }
    
    private static class Subscription implements Serializable
    {
        private Map<String, Item> channels;
        
        private Info c(final String s, final String s2) {
            final Map<String, Item> channels = this.channels;
            if (channels != null && channels.containsKey((Object)s)) {
                final Item item = (Item)this.channels.get((Object)s);
                if (item != null && item.info != null && item.info.containsKey((Object)s2)) {
                    return (Info)item.info.get((Object)s2);
                }
            }
            return null;
        }
        
        private static Subscription d(final JSONObject jsonObject) {
            if (jsonObject == null) {
                return null;
            }
            final Subscription subscription = new Subscription();
            subscription.channels = (Map<String, Item>)new HashMap();
            final Iterator keys = jsonObject.keys();
            while (keys.hasNext()) {
                final String s = (String)keys.next();
                final Object opt = jsonObject.opt(s);
                if (opt instanceof JSONObject) {
                    final Item b = c((JSONObject)opt);
                    if (b == null) {
                        continue;
                    }
                    subscription.channels.put((Object)s, (Object)b);
                }
            }
            return subscription;
        }
        
        private static class Item implements Serializable
        {
            private Map<String, Info> info;
            
            private static Item c(final JSONObject jsonObject) {
                if (jsonObject == null) {
                    return null;
                }
                final Item item = new Item();
                item.info = (Map<String, Info>)new HashMap();
                final Iterator keys = jsonObject.keys();
                while (keys.hasNext()) {
                    final String s = (String)keys.next();
                    final Object opt = jsonObject.opt(s);
                    if (opt instanceof JSONObject) {
                        final Info e = f((JSONObject)opt);
                        if (e == null) {
                            continue;
                        }
                        item.info.put((Object)s, (Object)e);
                    }
                }
                return item;
            }
            
            private static class Info implements Serializable
            {
                private long gracePeriodExpire;
                private long lastPaymentTime;
                private long onHoldSince;
                private int status;
                
                private static Info f(final JSONObject jsonObject) {
                    if (jsonObject == null) {
                        return null;
                    }
                    final Info info = new Info();
                    info.status = jsonObject.optInt("status", -1);
                    info.lastPaymentTime = jsonObject.optLong("last_payment_time", 0L);
                    info.gracePeriodExpire = jsonObject.optLong("grace_period_expire", 0L);
                    info.onHoldSince = jsonObject.optLong("on_hold_since", 0L);
                    return info;
                }
            }
        }
    }
}
