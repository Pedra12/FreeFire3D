package com.beetalk.sdk.networking.model;

import com.garena.pay.android.data.UserTransactionInfo;
import java.util.ArrayList;
import com.beetalk.sdk.cache.d;
import com.beetalk.sdk.s;
import java.util.HashMap;
import java.util.Map;
import com.android.billingclient.api.Purchase;

public class CommitReq extends BaseReq
{
    public static Map a(final Purchase purchase, final int n, final int n2, final String s) {
        final HashMap hashMap = new HashMap();
        final s w = s.w();
        if (w != null) {
            if (w.H() != null) {
                ((Map)hashMap).put((Object)"access_token", (Object)w.H().c());
            }
            ((Map)hashMap).put((Object)"open_id", (Object)w.C());
        }
        ((Map)hashMap).put((Object)"client_type", (Object)String.valueOf(2));
        ((Map)hashMap).put((Object)"app_server_id", (Object)String.valueOf(n));
        ((Map)hashMap).put((Object)"app_role_id", (Object)String.valueOf(n2));
        ((Map)hashMap).put((Object)"purchase_data", (Object)purchase.c());
        ((Map)hashMap).put((Object)"quantity", (Object)String.valueOf(purchase.h()));
        ((Map)hashMap).put((Object)"data_signature", (Object)purchase.i());
        ((Map)hashMap).put((Object)"flag", (Object)"1");
        final ArrayList j = purchase.j();
        if (!j.isEmpty()) {
            final UserTransactionInfo f = d.f(s, (String)j.get(0));
            ((Map)hashMap).put((Object)"user_region", (Object)f.region);
            final String ipCountry = f.ipCountry;
            if (ipCountry != null && !ipCountry.isEmpty()) {
                ((Map)hashMap).put((Object)"ip_country", (Object)f.ipCountry);
            }
            ((Map)hashMap).put((Object)"display_local_currency", (Object)f.currency);
            final long priceAmount = f.priceAmount;
            if (priceAmount >= 0L) {
                ((Map)hashMap).put((Object)"display_local_currency_amount", (Object)String.valueOf(priceAmount));
            }
        }
        return (Map)hashMap;
    }
}
