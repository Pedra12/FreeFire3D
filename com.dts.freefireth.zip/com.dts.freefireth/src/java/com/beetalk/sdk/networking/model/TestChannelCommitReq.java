package com.beetalk.sdk.networking.model;

import com.beetalk.sdk.helper.t;
import com.beetalk.sdk.X;
import java.util.HashMap;
import java.util.Map;
import k1.a;
import com.beetalk.sdk.s;

public class TestChannelCommitReq extends BaseReq
{
    public static Map a(final int n, final int n2, final String s, final s s2, final a a) {
        final HashMap hashMap = new HashMap();
        ((Map)hashMap).put((Object)"access_token", (Object)a.c());
        ((Map)hashMap).put((Object)"open_id", (Object)s2.C());
        ((Map)hashMap).put((Object)"platform", (Object)String.valueOf((Object)s2.D()));
        ((Map)hashMap).put((Object)"app_id", (Object)String.valueOf(t.f(X.M())));
        ((Map)hashMap).put((Object)"app_role_id", (Object)String.valueOf(n2));
        ((Map)hashMap).put((Object)"client_type", (Object)String.valueOf(2));
        ((Map)hashMap).put((Object)"app_server_id", (Object)String.valueOf(n));
        ((Map)hashMap).put((Object)"item_id", (Object)String.valueOf((Object)s));
        ((Map)hashMap).put((Object)"bundle_id", (Object)X.M().getPackageName());
        ((Map)hashMap).put((Object)"receipt", (Object)"dummyChannel");
        ((Map)hashMap).put((Object)"transaction_id", (Object)"999999");
        return (Map)hashMap;
    }
}
