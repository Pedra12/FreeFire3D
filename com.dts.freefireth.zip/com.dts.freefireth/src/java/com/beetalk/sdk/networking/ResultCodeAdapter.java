package com.beetalk.sdk.networking;

import com.google.gson.stream.JsonWriter;
import com.google.gson.internal.bind.TypeAdapters;
import com.google.gson.stream.JsonReader;
import com.google.gson.TypeAdapter;

public class ResultCodeAdapter extends TypeAdapter<s>
{
    public s a(final JsonReader jsonReader) {
        return s.e(((Number)TypeAdapters.INTEGER.read(jsonReader)).intValue());
    }
    
    public void b(final JsonWriter jsonWriter, final s s) {
        TypeAdapters.INTEGER.write(jsonWriter, (Object)s.b());
    }
}
