package com.beetalk.sdk.networking.service;

import android.text.TextUtils;
import org.json.JSONException;
import com.beetalk.sdk.d;
import W2.b;
import com.garena.pay.android.l;
import com.beetalk.sdk.networking.r;
import com.beetalk.sdk.networking.model.RecallTokenResponse;
import com.beetalk.sdk.X$e;
import com.beetalk.sdk.networking.model.BindPlatformInfoResponse;
import com.beetalk.sdk.networking.model.SaveTokenResponse;
import com.beetalk.sdk.deviceId.g;
import com.beetalk.sdk.s;
import java.math.BigInteger;
import z1.a;
import org.json.JSONObject;
import com.beetalk.sdk.networking.h$c;
import Z7.z;
import java.util.Map;
import java.util.List;
import com.beetalk.sdk.A0;
import com.beetalk.sdk.helper.t;
import com.beetalk.sdk.X;
import java.util.HashMap;
import com.beetalk.sdk.networking.h;
import k1.c;
import java.util.concurrent.Callable;
import c1.i;

public class j
{
    public static i A(final String s, final String s2) {
        return i.f((Callable)new e(s, s2));
    }
    
    public static void i(final String s, final String s2, final h$c h$c) {
        i.f((Callable)new com.beetalk.sdk.networking.service.b(s, s2)).l((c1.g)new com.beetalk.sdk.networking.service.c(h$c), i.k);
    }
    
    private static d.e j(final String s, final HashMap hashMap, final int n) {
        return w(n, com.beetalk.sdk.networking.t.b().o(s, (Map)hashMap));
    }
    
    public static d.e k(final String s, final String s2, final String s3, final String s4, final boolean b, final String s5) {
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"facebook_access_token", (Object)s);
        hashMap.put((Object)"redirect_uri", (Object)s2);
        hashMap.put((Object)"source", (Object)X.N().toString());
        hashMap.put((Object)"client_id", (Object)s3);
        hashMap.put((Object)"client_secret", (Object)s4);
        if (b) {
            hashMap.put((Object)"create_grant", (Object)"false");
        }
        hashMap.put((Object)"login_scenario", (Object)s5);
        hashMap.put((Object)"device_id", (Object)g.f());
        return j(A0.c(), hashMap, 3);
    }
    
    public static d.e l(final String s, final String s2, final String s3, final String s4, final String s5) {
        return m(s, s2, s3, s4, s5, 1);
    }
    
    public static d.e m(final String s, final String s2, final String s3, final String s4, final String s5, final int n) {
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"grant_type", (Object)"authorization_code");
        hashMap.put((Object)"code", (Object)s);
        hashMap.put((Object)"redirect_uri", (Object)s2);
        hashMap.put((Object)"source", (Object)X.N().toString());
        hashMap.put((Object)"client_id", (Object)s3);
        hashMap.put((Object)"client_secret", (Object)s4);
        hashMap.put((Object)"login_scenario", (Object)s5);
        hashMap.put((Object)"device_id", (Object)g.f());
        return j(A0.g(), hashMap, n);
    }
    
    public static d.e n(final String s, final String s2, final String s3, final boolean b, final String s4) {
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"google_access_token", (Object)s);
        hashMap.put((Object)"source", (Object)X.N().toString());
        hashMap.put((Object)"client_id", (Object)s2);
        hashMap.put((Object)"client_secret", (Object)s3);
        if (b) {
            hashMap.put((Object)"create_grant", (Object)"false");
        }
        hashMap.put((Object)"login_scenario", (Object)s4);
        hashMap.put((Object)"device_id", (Object)g.f());
        return j(A0.d(), hashMap, 8);
    }
    
    public static d.e o(final String s, final String s2, final boolean b, final String s3) {
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"line_access_token", (Object)s);
        hashMap.put((Object)"client_id", (Object)s2);
        if (b) {
            hashMap.put((Object)"create_grant", (Object)"false");
        }
        hashMap.put((Object)"version", (Object)"v2.1");
        hashMap.put((Object)"login_scenario", (Object)s3);
        hashMap.put((Object)"device_id", (Object)g.f());
        return j(A0.e(), hashMap, 6);
    }
    
    public static d.e p(final String s, final String s2, final boolean b, final String s3) {
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"google_auth_code", (Object)s);
        hashMap.put((Object)"client_id", (Object)s2);
        if (b) {
            hashMap.put((Object)"create_grant", (Object)"false");
        }
        hashMap.put((Object)"login_scenario", (Object)s3);
        hashMap.put((Object)"device_id", (Object)g.f());
        return j(A0.f(), hashMap, 14);
    }
    
    public static d.e q(final String s, final String s2, final String s3, final boolean b, final String s4) {
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"twitter_access_token", (Object)s);
        hashMap.put((Object)"token_secret", (Object)s2);
        hashMap.put((Object)"client_id", (Object)s3);
        if (b) {
            hashMap.put((Object)"create_grant", (Object)"false");
        }
        hashMap.put((Object)"login_scenario", (Object)s4);
        hashMap.put((Object)"device_id", (Object)g.f());
        return j(A0.h(), hashMap, 11);
    }
    
    public static d.e r(final String s, final String s2, final boolean b, final String s3) {
        return k.a(5, com.beetalk.sdk.networking.t.b().n(A0.i(), null, j1.c.a(s, s3), true, X.L(), null, false, com.beetalk.sdk.networking.t.c.b));
    }
    
    public static void s(final String s, final X$e x$e) {
        i.f((Callable)new f(s)).l((c1.g)new com.beetalk.sdk.networking.service.g(x$e), i.k);
    }
    
    public static void t(final String s, final String s2, final a a, final String s3, final h$c h$c) {
        i.f((Callable)new com.beetalk.sdk.networking.service.i(s, s2, a, s3, h$c));
    }
    
    public static JSONObject u(final String s) {
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"token", (Object)s);
        hashMap.put((Object)"app_id", (Object)X.J());
        return new JSONObject(com.beetalk.sdk.networking.t.b().e(A0.T(), (Map)hashMap));
    }
    
    public static void v(final String s, final String s2) {
        final HashMap hashMap = new HashMap();
        ((Map)hashMap).put((Object)"access_token", (Object)s);
        ((Map)hashMap).put((Object)"refresh_token", (Object)s2);
        ((Map)hashMap).put((Object)"app_id", (Object)X.J());
        com.beetalk.sdk.networking.t.b().e(A0.G(), (Map)hashMap);
    }
    
    private static d.e w(final int n, final String s) {
        JSONObject jsonObject;
        try {
            jsonObject = new JSONObject(s);
        }
        catch (final JSONException ex) {
            jsonObject = null;
        }
        if (jsonObject == null) {
            return d.e.a(l.h1.b());
        }
        final String optString = jsonObject.optString("error", "");
        if (!TextUtils.isEmpty((CharSequence)optString)) {
            return d.e.a(r.c(optString).b());
        }
        if (jsonObject.has("open_id")) {
            try {
                return d.e.d(k1.a.o(n, jsonObject));
            }
            catch (final JSONException ex2) {
                return d.e.a(l.h1.b());
            }
        }
        return d.e.a(l.h1.b());
    }
    
    public static i x(final String s) {
        return i.f((Callable)new com.beetalk.sdk.networking.service.h(s));
    }
    
    public static JSONObject y(final String s) {
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"refresh_token", (Object)s);
        hashMap.put((Object)"grant_type", (Object)"refresh_token");
        return new JSONObject(com.beetalk.sdk.networking.t.b().o(A0.U(), (Map)hashMap));
    }
    
    public static void z(final c c, final h.e e) {
        i.f((Callable)new com.beetalk.sdk.networking.service.d(c, e));
    }
}
