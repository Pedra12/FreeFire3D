package com.beetalk.sdk.networking;

import kotlin.Pair;
import s7.u;
import java.util.Map$Entry;
import kotlin.collections.CollectionsKt;
import java.util.List;
import java.util.Iterator;
import java.util.Set;
import android.net.Uri;
import java.util.LinkedHashMap;
import kotlin.collections.F;
import java.util.Map;
import java.nio.charset.Charset;
import Z7.x;
import o8.g;
import Z7.E;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import o8.Z;
import kotlin.text.StringsKt;
import Z7.D;
import Z7.C;
import java.io.IOException;
import java.io.Closeable;
import C7.b;
import o8.e;
import f8.f;
import Z7.B;
import kotlin.Metadata;

@Metadata
public final class o
{
    public static final String a(B b) {
        if (b == null) {
            return "";
        }
        if (!f.b(b.h())) {
            return "";
        }
        final C a = b.a();
        if (a == null) {
            return "";
        }
        try {
            b = (B)new e();
            try {
                a.i((o8.f)b);
                final String l1 = ((e)b).L1();
                b.a((Closeable)b, (Throwable)null);
                return l1;
            }
            finally {
                try {}
                finally {
                    final Throwable t;
                    b.a((Closeable)b, t);
                }
            }
        }
        catch (final IOException ex) {
            return "";
        }
    }
    
    public static final String b(D b) {
        if (b != null) {
            if (f8.e.b(b)) {
                final E a = b.a();
                if (a == null) {
                    return "";
                }
                final g h = a.h();
                h.s1(Long.MAX_VALUE);
                final Object p;
                final e e = (e)(p = h.p());
                if (StringsKt.y("gzip", b.k().b("Content-Encoding"), true)) {
                    b = (D)new o8.o((Z)e.b());
                    try {
                        new e().j2((Z)b);
                        b.a((Closeable)b, (Throwable)null);
                    }
                    finally {
                        try {}
                        finally {
                            b.a((Closeable)b, (Throwable)p);
                        }
                    }
                }
                final x f = a.f();
                Charset charset;
                if (f == null || (charset = f.c(Charsets.UTF_8)) == null) {
                    charset = Charsets.UTF_8;
                }
                b = (D)p;
                if (Intrinsics.a(p, (Object)h.p())) {
                    b = (D)((e)p).b();
                }
                try {
                    final String y0 = ((e)b).Y0(charset);
                    b.a((Closeable)b, (Throwable)null);
                    return y0;
                }
                finally {
                    try {}
                    finally {
                        final Throwable t;
                        b.a((Closeable)b, t);
                    }
                }
            }
        }
        return "";
    }
    
    public static final Map c(final B b, final boolean b2) {
        if (b == null) {
            return F.i();
        }
        if (!f.b(b.h())) {
            final Set r = b.k().r();
            final LinkedHashMap linkedHashMap = new LinkedHashMap();
            for (final String s : r) {
                String p2;
                if ((p2 = b.k().p(s)) == null) {
                    p2 = "";
                }
                ((Map)linkedHashMap).put((Object)s, (Object)p2);
            }
            return (Map)linkedHashMap;
        }
        final String a = a(b);
        if (((CharSequence)a).length() == 0) {
            return F.i();
        }
        final List split$default = StringsKt.split$default((CharSequence)a, new String[] { "&" }, false, 0, 6, (Object)null);
        final LinkedHashMap linkedHashMap2 = new LinkedHashMap();
        final Iterator iterator2 = ((Iterable)split$default).iterator();
        while (iterator2.hasNext()) {
            final List split$default2 = StringsKt.split$default((CharSequence)iterator2.next(), new String[] { "=" }, false, 0, 6, (Object)null);
            if (split$default2.size() > 1) {
                final Object value = split$default2.get(0);
                String decode;
                final String s2 = decode = (String)split$default2.get(1);
                if (b2) {
                    decode = Uri.decode(s2);
                }
                Intrinsics.c((Object)decode);
                ((Map)linkedHashMap2).put(value, (Object)decode);
            }
        }
        return (Map)linkedHashMap2;
    }
    
    public static final String d(final B b, final boolean b2) {
        final Set entrySet = F.h(c(b, b2)).entrySet();
        Intrinsics.checkNotNullExpressionValue((Object)entrySet, "<get-entries>(...)");
        final StringBuilder sb = new StringBuilder();
        final Iterator iterator = ((Iterable)entrySet).iterator();
        int n = 0;
        while (iterator.hasNext()) {
            final Object next = iterator.next();
            if (n < 0) {
                CollectionsKt.u();
            }
            final Map$Entry map$Entry = (Map$Entry)next;
            final Pair a = u.a(map$Entry.getKey(), map$Entry.getValue());
            if (n > 0) {
                sb.append('&');
            }
            sb.append((String)a.c());
            sb.append('=');
            String s;
            if ((s = (String)a.d()) == null) {
                s = "";
            }
            sb.append(s);
            ++n;
        }
        final String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue((Object)string, "toString(...)");
        return string;
    }
    
    public static final String f(final B b) {
        if (b == null) {
            return "";
        }
        if (f.b(b.h())) {
            return a(b);
        }
        final Set r = b.k().r();
        final StringBuilder sb = new StringBuilder();
        final Iterator iterator = ((Iterable)r).iterator();
        int n = 0;
        while (iterator.hasNext()) {
            final Object next = iterator.next();
            if (n < 0) {
                CollectionsKt.u();
            }
            final String s = (String)next;
            final Pair a = u.a((Object)s, (Object)b.k().p(s));
            if (n > 0) {
                sb.append('&');
            }
            sb.append((String)a.c());
            sb.append('=');
            String s2;
            if ((s2 = (String)a.d()) == null) {
                s2 = "";
            }
            sb.append(s2);
            ++n;
        }
        final String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue((Object)string, "toString(...)");
        return string;
    }
}
