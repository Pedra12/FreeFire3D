package com.beetalk.sdk.networking.interceptor;

import Z7.B;
import java.net.UnknownHostException;
import java.net.SocketTimeoutException;
import Z7.D;
import Z7.w$a;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import kotlin.Metadata;
import Z7.w;

@Metadata
public final class c implements w
{
    private final b a;
    
    public c(@NotNull final b a) {
        Intrinsics.checkNotNullParameter((Object)a, "finder");
        this.a = a;
    }
    
    public D intercept(final w$a w$a) {
        Intrinsics.checkNotNullParameter((Object)w$a, "chain");
        final B request = w$a.request();
        try {
            return w$a.b(request);
        }
        catch (final Exception ex) {
            if (!(ex instanceof SocketTimeoutException) && !(ex instanceof UnknownHostException)) {
                throw ex;
            }
            final String a = this.a.a(request.k().i());
            if (a != null) {
                return w$a.b(request.i().k(request.k().k().g(a).c()).b());
            }
            throw ex;
        }
    }
}
