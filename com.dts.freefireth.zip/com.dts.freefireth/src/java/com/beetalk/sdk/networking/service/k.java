package com.beetalk.sdk.networking.service;

import j1.a;
import com.beetalk.sdk.networking.b;
import kotlin.jvm.internal.Intrinsics;
import com.garena.pay.android.l;
import com.beetalk.sdk.d;
import kotlin.Metadata;

@Metadata
public final class k
{
    public static final k a;
    
    static {
        a = new k();
    }
    
    private k() {
    }
    
    public static final d.e a(final int n, final String s) {
        if (s == null || ((CharSequence)s).length() == 0) {
            final Integer b = l.l.b();
            Intrinsics.checkNotNullExpressionValue((Object)b, "getCode(...)");
            final d.e a = d.e.a(((Number)b).intValue());
            Intrinsics.checkNotNullExpressionValue((Object)a, "createErrorResult(...)");
            return a;
        }
        final F2.a a2 = b.a.a(s, a.class);
        if (a2.g()) {
            final Integer b2 = a2.d().b();
            Intrinsics.checkNotNullExpressionValue((Object)b2, "getCode(...)");
            final d.e a3 = d.e.a(((Number)b2).intValue());
            Intrinsics.checkNotNullExpressionValue((Object)a3, "createErrorResult(...)");
            return a3;
        }
        final d.e d = com.beetalk.sdk.d.e.d(((a)a2.j()).f(n));
        Intrinsics.checkNotNullExpressionValue((Object)d, "createTokenResult(...)");
        return d;
    }
}
