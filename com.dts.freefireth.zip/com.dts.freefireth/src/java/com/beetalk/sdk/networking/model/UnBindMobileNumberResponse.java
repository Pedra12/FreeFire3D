package com.beetalk.sdk.networking.model;

import org.json.JSONObject;

public final class UnBindMobileNumberResponse extends BaseResp
{
    private UnBindMobileNumberResponse() {
    }
    
    public static UnBindMobileNumberResponse j(final JSONObject jsonObject) {
        final UnBindMobileNumberResponse unBindMobileNumberResponse = new UnBindMobileNumberResponse();
        unBindMobileNumberResponse.h(jsonObject);
        return unBindMobileNumberResponse;
    }
}
