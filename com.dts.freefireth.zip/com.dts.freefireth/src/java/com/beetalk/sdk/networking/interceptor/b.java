package com.beetalk.sdk.networking.interceptor;

import com.beetalk.sdk.X;
import org.jetbrains.annotations.NotNull;
import java.util.Iterator;
import kotlin.text.StringsKt;
import java.util.Map$Entry;
import kotlin.jvm.internal.Intrinsics;
import kotlin.collections.F;
import s7.u;
import kotlin.Pair;
import java.util.Map;
import kotlin.Metadata;

@Metadata
public final class b
{
    private final Map a;
    
    public b() {
        this.a = F.l(new Pair[] { u.a((Object)"connect.garena.com", (Object)new b("connect.gopapi.io")), u.a((Object)"msdk.garena.com", (Object)new b("msdk.gopapi.io")), u.a((Object)"shop.garena.com", (Object)new c("shop.gopapi.io")) });
    }
    
    public final String a(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "host");
        final Iterator iterator = ((Iterable)this.a.entrySet()).iterator();
        String build;
        do {
            final boolean hasNext = iterator.hasNext();
            build = null;
            final String s2 = null;
            if (!hasNext) {
                break;
            }
            final Map$Entry map$Entry = (Map$Entry)iterator.next();
            build = s2;
            if (!StringsKt.P((CharSequence)s, (CharSequence)map$Entry.getKey(), false, 2, (Object)null)) {
                continue;
            }
            build = ((a)map$Entry.getValue()).build();
        } while (build == null);
        return build;
    }
    
    @Metadata
    private interface a
    {
        String build();
    }
    
    @Metadata
    private static final class b implements a
    {
        private final String a;
        
        public b(@NotNull final String a) {
            Intrinsics.checkNotNullParameter((Object)a, "backupHost");
            this.a = a;
        }
        
        @Override
        public String build() {
            final String j = X.J();
            Intrinsics.c((Object)j);
            if (((CharSequence)j).length() == 0) {
                return this.a;
            }
            final String a = this.a;
            final StringBuilder sb = new StringBuilder();
            sb.append(j);
            sb.append(".");
            sb.append(a);
            return sb.toString();
        }
    }
    
    @Metadata
    private static final class c implements a
    {
        private final String a;
        
        public c(@NotNull final String a) {
            Intrinsics.checkNotNullParameter((Object)a, "backupHost");
            this.a = a;
        }
        
        @Override
        public String build() {
            return this.a;
        }
    }
}
