package com.beetalk.sdk.networking.model;

import org.json.JSONArray;
import java.util.ArrayList;
import org.json.JSONException;
import com.beetalk.sdk.helper.k;
import org.json.JSONObject;
import com.garena.pay.android.l;
import com.garena.pay.android.data.GGPayment$PaymentChannel;
import java.util.List;

public class EventPricingResp extends BaseResp
{
    private List<GGPayment$PaymentChannel> channels;
    private List<PricingEvent> events;
    
    public static EventPricingResp l(final String s) {
        final EventPricingResp eventPricingResp = new EventPricingResp();
        if (s == null) {
            eventPricingResp.errorCode = l.h1.b();
            return eventPricingResp;
        }
        eventPricingResp.errorCode = eventPricingResp.f(s);
        try {
            eventPricingResp.resultCode = eventPricingResp.g(new JSONObject(s));
        }
        catch (final JSONException ex) {
            k.b((Exception)ex);
        }
        if (eventPricingResp.errorCode != l.c.b()) {
            return eventPricingResp;
        }
        eventPricingResp.channels = (List<GGPayment$PaymentChannel>)Pricing.b(s);
        eventPricingResp.events = (List<PricingEvent>)m(s);
        return eventPricingResp;
    }
    
    private static List m(final String s) {
        while (true) {
        Label_0228:
            while (true) {
                ArrayList list = null;
                int n = 0;
                PricingEvent pricingEvent = null;
                Label_0210: {
                    JSONArray optJSONArray2;
                    try {
                        final JSONArray optJSONArray = new JSONObject(s).optJSONArray("events");
                        if (optJSONArray == null) {
                            return null;
                        }
                        list = new ArrayList();
                        n = 0;
                        if (n >= optJSONArray.length()) {
                            return (List)list;
                        }
                        final JSONObject jsonObject = optJSONArray.getJSONObject(n);
                        pricingEvent = new PricingEvent();
                        pricingEvent.id = jsonObject.optInt("id");
                        pricingEvent.type = jsonObject.optString("type");
                        pricingEvent.start_time = jsonObject.optLong("start_time");
                        pricingEvent.end_time = jsonObject.optLong("end_time");
                        pricingEvent.available_times = jsonObject.optInt("available_times");
                        pricingEvent.total_times = jsonObject.optInt("total_times");
                        pricingEvent.status = jsonObject.optInt("status");
                        optJSONArray2 = jsonObject.optJSONArray("items");
                        if (optJSONArray2 == null || optJSONArray2.length() <= 0) {
                            break Label_0210;
                        }
                        if (pricingEvent.items == null) {
                            pricingEvent.items = new int[optJSONArray2.length()];
                        }
                    }
                    catch (final JSONException ex) {
                        break Label_0228;
                    }
                    for (int i = 0; i < optJSONArray2.length(); ++i) {
                        pricingEvent.items[i] = optJSONArray2.optInt(i);
                    }
                }
                ((List)list).add((Object)pricingEvent);
                ++n;
                continue;
            }
            final JSONException ex;
            k.b((Exception)ex);
            return null;
        }
    }
    
    public List j() {
        return this.channels;
    }
    
    public List k() {
        return this.events;
    }
}
