package com.beetalk.sdk.networking.model;

import java.io.Serializable;

class BaseReq implements Serializable
{
}
