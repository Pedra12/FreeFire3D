package com.beetalk.sdk.networking.model;

import com.garena.pay.android.l;
import com.garena.pay.android.ndk.RebateOptionItem;
import java.util.List;

public class RebatesResp extends BaseResp
{
    private List<RebateOptionItem> rebates;
    
    public static RebatesResp k(final String s) {
        final RebatesResp rebatesResp = new RebatesResp();
        if (s == null) {
            rebatesResp.errorCode = l.h1.b();
            return rebatesResp;
        }
        if ((rebatesResp.errorCode = rebatesResp.f(s)) != l.c.b()) {
            return rebatesResp;
        }
        rebatesResp.rebates = (List<RebateOptionItem>)RebateOptionItem.a(s);
        return rebatesResp;
    }
    
    public List j() {
        return this.rebates;
    }
}
