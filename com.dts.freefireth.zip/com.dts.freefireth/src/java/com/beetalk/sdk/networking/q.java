package com.beetalk.sdk.networking;

import kotlin.Metadata;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD, ElementType.PARAMETER, ElementType.LOCAL_VARIABLE })
@Metadata
public @interface q {
    @Metadata
    public static final class a
    {
        static final a a;
        
        static {
            a = new a();
        }
        
        private a() {
        }
    }
}
