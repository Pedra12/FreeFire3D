package com.beetalk.sdk.networking.model;

import com.beetalk.sdk.networking.ULongJsonAdapter;
import com.google.gson.annotations.JsonAdapter;
import org.jetbrains.annotations.NotNull;
import com.google.gson.annotations.SerializedName;
import kotlin.Metadata;

@Metadata
public final class RegisterGuestResponse
{
    @SerializedName("data")
    @NotNull
    private Data data;
    @SerializedName("error")
    private String error;
    
    public RegisterGuestResponse() {
        this.data = new Data();
    }
    
    public final String a() {
        return this.error;
    }
    
    public final String b() {
        return this.data.a();
    }
    
    @Metadata
    public static final class Data
    {
        @JsonAdapter(ULongJsonAdapter.class)
        @SerializedName("uid")
        @NotNull
        private String uid;
        
        public Data() {
            this.uid = "";
        }
        
        public final String a() {
            return this.uid;
        }
    }
}
