package com.beetalk.sdk.networking;

import android.text.TextUtils;

public class c
{
    public final String a;
    public final String b;
    
    public c(String a, String b) {
        if (TextUtils.isEmpty((CharSequence)a)) {
            a = "";
        }
        this.a = a;
        if (TextUtils.isEmpty((CharSequence)b)) {
            b = "";
        }
        this.b = b;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("[");
        sb.append(this.a);
        sb.append(" -> ");
        sb.append(this.b);
        sb.append("]");
        return sb.toString();
    }
}
