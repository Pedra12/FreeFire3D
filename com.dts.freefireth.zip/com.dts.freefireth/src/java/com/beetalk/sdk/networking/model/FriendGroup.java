package com.beetalk.sdk.networking.model;

import kotlin.collections.CollectionsKt;
import com.beetalk.sdk.networking.ULongListJsonAdapter;
import com.google.gson.annotations.JsonAdapter;
import org.jetbrains.annotations.NotNull;
import com.google.gson.annotations.SerializedName;
import java.util.List;
import kotlin.Metadata;

@Metadata
public final class FriendGroup
{
    @SerializedName("friends")
    @NotNull
    private List<String> friends;
    @SerializedName("platform")
    private int platform;
    @JsonAdapter(ULongListJsonAdapter.class)
    @SerializedName("uids")
    @NotNull
    private List<String> uids;
    
    public FriendGroup() {
        this.friends = (List<String>)CollectionsKt.k();
        this.uids = (List<String>)CollectionsKt.k();
    }
    
    public final List a() {
        return this.friends;
    }
    
    public final int b() {
        return this.platform;
    }
    
    public final List c() {
        return this.uids;
    }
}
