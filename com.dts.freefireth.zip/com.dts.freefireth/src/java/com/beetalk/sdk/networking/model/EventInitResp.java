package com.beetalk.sdk.networking.model;

import org.json.JSONException;
import com.beetalk.sdk.helper.k;
import org.json.JSONObject;
import com.garena.pay.android.l;

public class EventInitResp extends BaseResp
{
    public String event_txn_id;
    
    public EventInitResp() {
        this.event_txn_id = "";
    }
    
    public static EventInitResp j(final String s) {
        final EventInitResp eventInitResp = new EventInitResp();
        if (s == null) {
            eventInitResp.errorCode = l.h1.b();
            return eventInitResp;
        }
        eventInitResp.errorCode = eventInitResp.f(s);
        try {
            final JSONObject jsonObject = new JSONObject(s);
            eventInitResp.resultCode = eventInitResp.g(jsonObject);
            eventInitResp.event_txn_id = jsonObject.optString("event_txn_id");
            return eventInitResp;
        }
        catch (final JSONException ex) {
            k.b((Exception)ex);
            return eventInitResp;
        }
    }
}
