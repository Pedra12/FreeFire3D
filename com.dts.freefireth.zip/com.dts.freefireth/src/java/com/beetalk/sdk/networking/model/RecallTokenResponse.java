package com.beetalk.sdk.networking.model;

import java.util.Collections;
import com.google.gson.annotations.SerializedName;
import java.util.List;

public class RecallTokenResponse extends BaseResponse
{
    @SerializedName("tokens")
    private List<RecallToken> tokens;
    
    public RecallTokenResponse() {
        this.tokens = (List<RecallToken>)Collections.EMPTY_LIST;
    }
    
    public List c() {
        return this.tokens;
    }
}
