package com.beetalk.sdk.networking;

import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import kotlin.Metadata;

@Metadata
public final class p<T>
{
    private final Object a;
    private final String b;
    
    public p(final T a, @NotNull final String b) {
        Intrinsics.checkNotNullParameter((Object)b, "dataJson");
        this.a = a;
        this.b = b;
    }
    
    public final String a() {
        return this.b;
    }
    
    public final Object b() {
        return this.a;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof p)) {
            return false;
        }
        final p p = (p)o;
        return Intrinsics.a(this.a, p.a) && Intrinsics.a((Object)this.b, (Object)p.b);
    }
    
    @Override
    public int hashCode() {
        final Object a = this.a;
        int hashCode;
        if (a == null) {
            hashCode = 0;
        }
        else {
            hashCode = a.hashCode();
        }
        return hashCode * 31 + this.b.hashCode();
    }
    
    @Override
    public String toString() {
        final Object a = this.a;
        final String b = this.b;
        final StringBuilder sb = new StringBuilder();
        sb.append("ParsedResponse(value=");
        sb.append(a);
        sb.append(", dataJson=");
        sb.append(b);
        sb.append(")");
        return sb.toString();
    }
}
