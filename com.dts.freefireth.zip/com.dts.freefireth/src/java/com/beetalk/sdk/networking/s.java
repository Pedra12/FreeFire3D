package com.beetalk.sdk.networking;

import android.util.SparseArray;

public enum s
{
    private static final s[] X;
    
    c(-1, "Failed to parse response"), 
    d(0, "Success"), 
    e(1, "Unknown error"), 
    f(3, "Pending transaction"), 
    g(1001, "Error params"), 
    h(1002, "Error token"), 
    i(1003, "Error scope"), 
    j(1004, "Not Authorize"), 
    k(1005, "Invalid Signature"), 
    l(1101, "Error user platform"), 
    v(2000, "Error display result (task error)"), 
    w(3001, "Error subscription binding"), 
    x(3002, "Error subscription get details failed");
    
    private static final SparseArray y;
    private final int a;
    private final String b;
    
    static {
        int n = 0;
        X = a();
        y = new SparseArray();
        for (s[] values = values(); n < values.length; ++n) {
            final s s = values[n];
            com.beetalk.sdk.networking.s.y.put(s.b(), (Object)s);
        }
    }
    
    private s(final int a, final String b) {
        this.a = a;
        this.b = b;
    }
    
    private static /* synthetic */ s[] a() {
        return new s[] { s.c, s.d, s.e, s.f, s.g, s.h, s.i, s.j, s.k, s.l, s.v, s.w, s.x };
    }
    
    public static String d(final int n) {
        return ((s)s.y.get(n, (Object)s.c)).c();
    }
    
    public static s e(final int n) {
        s c;
        if ((c = (s)s.y.get(n)) == null) {
            c = s.c;
        }
        return c;
    }
    
    public int b() {
        return this.a;
    }
    
    public String c() {
        return this.b;
    }
}
