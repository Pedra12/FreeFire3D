package com.beetalk.sdk.networking.model;

import kotlin.text.StringsKt;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import kotlin.Metadata;

@Metadata
public final class LocaleRegion
{
    @NotNull
    public static final String BR = "br";
    @NotNull
    public static final String CN = "cn";
    @NotNull
    public static final LocaleRegion INSTANCE;
    @NotNull
    public static final String KR = "kr";
    @NotNull
    public static final String TR = "tr";
    @NotNull
    public static final String US = "us";
    @NotNull
    public static final String VN = "vn";
    
    static {
        INSTANCE = new LocaleRegion();
    }
    
    private LocaleRegion() {
    }
    
    public final boolean a(final String s, final String... array) {
        Intrinsics.checkNotNullParameter((Object)s, "<this>");
        Intrinsics.checkNotNullParameter((Object)array, "regions");
        for (int length = array.length, i = 0; i < length; ++i) {
            if (StringsKt.y(s, array[i], true)) {
                return true;
            }
        }
        return false;
    }
}
