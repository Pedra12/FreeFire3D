package com.beetalk.sdk.networking;

import java.util.Iterator;
import W2.b;
import com.garena.pay.android.l;
import java.util.Map$Entry;
import java.util.LinkedHashMap;
import kotlin.jvm.internal.Intrinsics;
import java.util.Map;
import kotlin.Metadata;

@Metadata
public final class i
{
    public static final Object a(final h.d d, final String s, final Map map, final Class clazz) {
        Intrinsics.checkNotNullParameter((Object)d, "requestType");
        Intrinsics.checkNotNullParameter((Object)s, "url");
        Intrinsics.checkNotNullParameter((Object)map, "params");
        Intrinsics.checkNotNullParameter((Object)clazz, "clazz");
        return c(d, s, map, clazz, false, false, 48, null);
    }
    
    public static final Object b(final h.d d, String h, final Map map, final Class clazz, final boolean b, final boolean b2) {
        Intrinsics.checkNotNullParameter((Object)d, "requestType");
        Intrinsics.checkNotNullParameter((Object)h, "url");
        Intrinsics.checkNotNullParameter((Object)map, "params");
        Intrinsics.checkNotNullParameter((Object)clazz, "clazz");
        final LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (final Map$Entry map$Entry : map.entrySet()) {
            if (map$Entry.getKey() != null && map$Entry.getValue() != null) {
                ((Map)linkedHashMap).put(map$Entry.getKey(), map$Entry.getValue());
            }
        }
        h = h.h(d, h, (Map)linkedHashMap, b, b2);
        String s;
        if ((s = h) == null) {
            s = "";
        }
        if (((CharSequence)s).length() != 0) {
            return h.f.fromJson(s, clazz);
        }
        throw new b(l.h1);
    }
    
    public static /* synthetic */ Object c(h.d b, final String s, final Map map, final Class clazz, boolean b2, boolean b3, final int n, final Object o) {
        if ((n & 0x1) != 0x0) {
            b = h.d.b;
        }
        if ((n & 0x10) != 0x0) {
            b2 = false;
        }
        if ((n & 0x20) != 0x0) {
            b3 = false;
        }
        return b(b, s, map, clazz, b2, b3);
    }
}
