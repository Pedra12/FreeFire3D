package com.beetalk.sdk.networking.service;

import java.util.AbstractMap;
import java.util.Map;
import java.util.HashMap;
import com.beetalk.sdk.A0;
import com.beetalk.sdk.networking.t;
import org.json.JSONObject;

public class a
{
    public static JSONObject a(final String s, final String s2, final String s3) {
        return new JSONObject(t.b().o(A0.w(), (Map)new HashMap<String, String>(s, s2, s3) {
            final String a;
            final String b;
            final String c;
            
            {
                ((AbstractMap)this).put((Object)"app_id", (Object)a);
                ((AbstractMap)this).put((Object)"open_id", (Object)b);
                ((AbstractMap)this).put((Object)"feedback", (Object)c);
            }
        }));
    }
}
