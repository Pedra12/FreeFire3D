package com.beetalk.sdk.networking.model;

import com.garena.pay.android.E;
import org.json.JSONObject;
import androidx.annotation.NonNull;

public class PaymentEligibility extends BaseResp
{
    public static final String ERROR_REASON_CURRENCY_BAN = "local_currency_ban";
    public static final String ERROR_REASON_TOPUP_EXCEEDED = "topup_limit_exceeded";
    public final boolean eligible;
    public final String localCurrencyCode;
    @NonNull
    public final String reason;
    public final double remainingAmountInLocalCurrency;
    public final double totalLimitInLocalCurrency;
    
    public PaymentEligibility(final JSONObject jsonObject, final E e) {
        this.eligible = jsonObject.optBoolean("eligibility", false);
        this.reason = jsonObject.optString("eligibility_reason", "");
        this.totalLimitInLocalCurrency = jsonObject.optDouble("total_limit_in_local_currency", 0.0);
        this.remainingAmountInLocalCurrency = jsonObject.optDouble("remaining_amount_in_local_currency", 0.0);
        this.localCurrencyCode = e.d();
    }
}
