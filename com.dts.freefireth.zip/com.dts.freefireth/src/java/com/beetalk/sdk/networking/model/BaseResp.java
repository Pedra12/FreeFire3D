package com.beetalk.sdk.networking.model;

import org.json.JSONObject;
import com.beetalk.sdk.s;
import android.text.TextUtils;
import kotlin.jvm.functions.Function1;
import kotlin.collections.CollectionsKt;
import java.util.Arrays;
import com.garena.pay.android.l;
import java.io.Serializable;

public class BaseResp implements Serializable
{
    protected int errorCode;
    protected String errorMessage;
    protected int resultCode;
    
    protected BaseResp() {
    }
    
    public BaseResp(final int resultCode, final int errorCode, final String errorMessage) {
        this.resultCode = resultCode;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }
    
    public static l i(final int n) {
        l b2;
        if ((b2 = (l)CollectionsKt.Q((Iterable)Arrays.asList((Object[])l.values()), (Function1)new a(n))) == null) {
            b2 = l.b2;
        }
        return b2;
    }
    
    public int b() {
        return this.errorCode;
    }
    
    public String c() {
        return this.errorMessage;
    }
    
    public int d() {
        return this.resultCode;
    }
    
    public boolean e() {
        return this.errorCode != l.c.b();
    }
    
    int f(final String s) {
        String errorMessage;
        if (TextUtils.isEmpty((CharSequence)s)) {
            errorMessage = "";
        }
        else {
            errorMessage = s;
        }
        this.errorMessage = errorMessage;
        if (s == null) {
            return l.c.b();
        }
        if (!s.contains((CharSequence)"error")) {
            return l.c.b();
        }
        if (s.contains((CharSequence)"error_params")) {
            return l.y.b();
        }
        if (s.contains((CharSequence)"error_scope")) {
            return l.c1.b();
        }
        if (s.contains((CharSequence)"server_error")) {
            return l.a1.b();
        }
        if (s.contains((CharSequence)"error_token")) {
            s.W();
            return l.b1.b();
        }
        if (s.contains((CharSequence)"ssl_failure")) {
            return l.w.b();
        }
        if (s.contains((CharSequence)"error_no_auth")) {
            return l.n1.b();
        }
        if (s.contains((CharSequence)"error_invalid_signature")) {
            return l.o1.b();
        }
        if (s.contains((CharSequence)"error_too_many_requests")) {
            return l.m1.b();
        }
        return l.b2.b();
    }
    
    int g(final JSONObject jsonObject) {
        return jsonObject.optInt("result", com.beetalk.sdk.networking.s.c.b());
    }
    
    public void h(final JSONObject jsonObject) {
        String optString;
        if ((optString = jsonObject.optString("error")).isEmpty()) {
            optString = null;
        }
        this.errorCode = this.f(optString);
        this.resultCode = this.g(jsonObject);
    }
}
