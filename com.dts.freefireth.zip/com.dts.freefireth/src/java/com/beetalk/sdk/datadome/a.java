package com.beetalk.sdk.datadome;

final class a
{
    private a() {
    }
}
