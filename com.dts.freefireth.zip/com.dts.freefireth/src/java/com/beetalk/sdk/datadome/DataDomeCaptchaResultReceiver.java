package com.beetalk.sdk.datadome;

import w0.a;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public class DataDomeCaptchaResultReceiver extends BroadcastReceiver
{
    public void onReceive(final Context context, final Intent intent) {
        final Intent intent2 = new Intent("co.datadome.sdk.CAPTCHA_RESULT");
        if (intent.getExtras() != null) {
            intent2.putExtras(intent.getExtras());
        }
        a.b(context).d(intent2);
    }
}
