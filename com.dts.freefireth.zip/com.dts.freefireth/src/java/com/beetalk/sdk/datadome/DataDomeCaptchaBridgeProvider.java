package com.beetalk.sdk.datadome;

import android.database.Cursor;
import android.content.IntentFilter;
import w0.a;
import com.beetalk.sdk.h;
import android.os.Build$VERSION;
import android.content.ContentValues;
import android.net.Uri;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.ContentProvider;

public class DataDomeCaptchaBridgeProvider extends ContentProvider
{
    private final BroadcastReceiver a;
    
    public DataDomeCaptchaBridgeProvider() {
        this.a = new BroadcastReceiver() {
            final DataDomeCaptchaBridgeProvider a;
            
            public void onReceive(Context applicationContext, final Intent intent) {
                applicationContext = applicationContext.getApplicationContext();
                final Intent intent2 = new Intent("com.beetalk.sdk.datadome.CAPTCHA_RESULT_PROXY");
                intent2.setClass(applicationContext, (Class)DataDomeCaptchaResultReceiver.class);
                intent2.setPackage(applicationContext.getPackageName());
                if (intent.getExtras() != null) {
                    intent2.putExtras(intent.getExtras());
                }
                applicationContext.sendBroadcast(intent2);
            }
        };
    }
    
    public int delete(final Uri uri, final String s, final String[] array) {
        return 0;
    }
    
    public String getType(final Uri uri) {
        return null;
    }
    
    public Uri insert(final Uri uri, final ContentValues contentValues) {
        return null;
    }
    
    public boolean onCreate() {
        final Context context = this.getContext();
        if (context == null) {
            return false;
        }
        if (Build$VERSION.SDK_INT >= 28) {
            h.a("datadome_captcha");
        }
        w0.a.b(context).c(this.a, new IntentFilter("co.datadome.sdk.CAPTCHA_RESULT"));
        return true;
    }
    
    public Cursor query(final Uri uri, final String[] array, final String s, final String[] array2, final String s2) {
        return null;
    }
    
    public int update(final Uri uri, final ContentValues contentValues, final String s, final String[] array) {
        return 0;
    }
}
