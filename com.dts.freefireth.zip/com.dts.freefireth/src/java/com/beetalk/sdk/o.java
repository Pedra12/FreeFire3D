package com.beetalk.sdk;

import java.util.Collection;
import androidx.appcompat.app.c;
import android.content.Intent;
import java.util.concurrent.Callable;
import com.garena.pay.android.l;
import com.facebook.AccessToken;
import c1.i;
import com.facebook.login.y;
import com.beetalk.sdk.helper.k;
import R1.j;
import m1.a;
import com.facebook.login.w;
import R1.e$a;
import R1.e;

public class o extends g
{
    private final e b;
    
    public o(final d d) {
        super(d);
        final e a = e$a.a();
        this.b = a;
        w.i().s(a, (R1.g)new R1.g(this) {
            final o a;
            
            public void a() {
                this.a.i((Exception)new a("user_cancelled"));
            }
            
            public void b(final j j) {
                if (j == null) {
                    this.a.i((Exception)new a("Login Failed for some reason"));
                }
                else {
                    this.a.i((Exception)j);
                }
                String localizedMessage;
                if (j != null) {
                    localizedMessage = ((Throwable)j).getLocalizedMessage();
                }
                else {
                    localizedMessage = "exception is null";
                }
                k.c("FB login fail CLOSED_LOGIN_FAILED, exception: ", localizedMessage);
            }
            
            public void c(final y y) {
                if (y.a() != null) {
                    this.a.k();
                }
            }
        });
    }
    
    private d.e h(final String s, final d.c c) {
        final boolean y = s.Y(c);
        final StringBuilder sb = new StringBuilder();
        sb.append("gop");
        sb.append(c.a());
        sb.append("://auth/");
        final d.e k = com.beetalk.sdk.networking.service.j.k(s, sb.toString(), c.a(), c.b(), y, c.e());
        com.beetalk.sdk.helper.k.a("FB login exchange token, result: ", k);
        if (k.d == l.c2.b()) {
            AccessToken.D((AccessToken)null);
        }
        return k;
    }
    
    private void i(final Exception ex) {
        k.c("FB login failed, exception: ", ((Throwable)ex).getLocalizedMessage());
        super.a.j();
        d.e e;
        if (ex instanceof a) {
            if ("user_cancelled".equalsIgnoreCase(((Throwable)ex).getMessage())) {
                e = d.e.a(l.f.b());
            }
            else {
                e = d.e.a(l.h.b());
            }
        }
        else {
            e = d.e.a(l.b2.b());
        }
        super.a.l(e);
    }
    
    private void j(final d.e e) {
        if (e != null && e.b != null) {
            final s z = s.Z(super.a.j().f(), s.w());
            if (z != null) {
                z.t().l(e.b);
            }
        }
        super.a.l(e);
    }
    
    private void k() {
        k.i("Starting Token Exchange for Facebook", new Object[0]);
        final AccessToken m = AccessToken.m();
        if (m != null) {
            i.f((Callable)new m(this, m)).l((c1.g)new n(this), i.k);
            return;
        }
        super.a.l(d.e.a(l.W0.b()));
    }
    
    boolean b(final int n, final int n2, final Intent intent, final d.c c) {
        return true;
    }
    
    boolean c(final d.c c) {
        k.a("start FB Auth", new Object[0]);
        if (c == null) {
            return false;
        }
        final AccessToken m = AccessToken.m();
        if (m != null && !m.C()) {
            this.k();
            return true;
        }
        w.i().n((i.d)super.a.f().getContext(), this.b, (Collection)A0.v());
        return true;
    }
}
