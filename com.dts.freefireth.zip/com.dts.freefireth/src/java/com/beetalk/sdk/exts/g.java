package com.beetalk.sdk.exts;

import F2.a;
import kotlin.jvm.internal.Intrinsics;
import F2.a$a;
import com.garena.pay.android.l;
import kotlin.Metadata;

@Metadata
public final class g
{
    public static final a$a a(final l l, final String s) {
        Intrinsics.checkNotNullParameter((Object)l, "<this>");
        Intrinsics.checkNotNullParameter((Object)s, "message");
        final a$a b = a.b(l, s);
        Intrinsics.checkNotNullExpressionValue((Object)b, "failure(...)");
        return b;
    }
}
