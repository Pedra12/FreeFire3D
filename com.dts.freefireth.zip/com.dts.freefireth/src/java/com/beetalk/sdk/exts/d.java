package com.beetalk.sdk.exts;

import com.beetalk.sdk.plugin.b;
import g2.o;
import android.os.Looper;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.functions.Function0;
import com.beetalk.sdk.X$e;
import kotlin.Metadata;

@Metadata
public final class d
{
    public static final void b(final X$e x$e, final Function0 function0) {
        Intrinsics.checkNotNullParameter((Object)x$e, "<this>");
        Intrinsics.checkNotNullParameter((Object)function0, "action");
        if (Intrinsics.a((Object)Thread.currentThread(), (Object)Looper.getMainLooper().getThread())) {
            ((b)x$e).onPluginResult(function0.invoke());
            return;
        }
        o.m.execute((Runnable)new c(x$e, function0));
    }
    
    private static final void c(final X$e x$e, final Function0 function0) {
        Intrinsics.checkNotNullParameter((Object)x$e, "$this_onUiThread");
        Intrinsics.checkNotNullParameter((Object)function0, "$action");
        ((b)x$e).onPluginResult(function0.invoke());
    }
}
