package com.beetalk.sdk.exts;

import kotlin.jvm.internal.Intrinsics;
import com.google.gson.Gson;
import kotlin.Metadata;

@Metadata
public final class h
{
    public static final String a(final Gson gson, final Object o, final String s) {
        Intrinsics.checkNotNullParameter((Object)gson, "<this>");
        Intrinsics.checkNotNullParameter((Object)s, "default");
        if (o == null) {
            return s;
        }
        try {
            final String json = gson.toJson(o);
            Intrinsics.c((Object)json);
            return json;
        }
        catch (final Exception ex) {
            return s;
        }
    }
    
    public static final String b(final Gson gson, final Object o) {
        Intrinsics.checkNotNullParameter((Object)gson, "<this>");
        return a(gson, o, "");
    }
}
