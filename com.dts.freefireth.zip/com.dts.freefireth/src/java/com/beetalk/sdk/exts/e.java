package com.beetalk.sdk.exts;

import s7.p$a;
import s7.q;
import kotlin.Unit;
import s7.p;
import android.app.Activity;
import android.content.Intent;
import com.android.billingclient.api.A0;
import android.os.Build$VERSION;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import com.beetalk.sdk.cache.c;
import kotlin.jvm.internal.Intrinsics;
import android.content.SharedPreferences;
import android.content.Context;
import kotlin.Metadata;

@Metadata
public final class e
{
    public static final SharedPreferences a(final Context context, final String s) {
        Intrinsics.checkNotNullParameter((Object)context, "<this>");
        Intrinsics.checkNotNullParameter((Object)s, "name");
        return c.g.a(context, s);
    }
    
    public static final void b(final Context context, final BroadcastReceiver broadcastReceiver, final IntentFilter intentFilter, final boolean b) {
        Intrinsics.checkNotNullParameter((Object)context, "<this>");
        Intrinsics.checkNotNullParameter((Object)broadcastReceiver, "receiver");
        Intrinsics.checkNotNullParameter((Object)intentFilter, "filter");
        if (Build$VERSION.SDK_INT >= 33) {
            int n;
            if (b) {
                n = 2;
            }
            else {
                n = 4;
            }
            A0.a(context, broadcastReceiver, intentFilter, n);
            return;
        }
        context.registerReceiver(broadcastReceiver, intentFilter);
    }
    
    public static final boolean c(final Context context, final Intent intent) {
        Intrinsics.checkNotNullParameter((Object)context, "<this>");
        Intrinsics.checkNotNullParameter((Object)intent, "intent");
        if (!(context instanceof Activity)) {
            intent.addFlags(268435456);
        }
        Object b3;
        try {
            final p$a b = p.b;
            context.startActivity(intent);
            p.b((Object)Unit.a);
        }
        finally {
            final p$a b2 = p.b;
            final Throwable t;
            b3 = p.b(q.a(t));
        }
        return p.g(b3);
    }
}
