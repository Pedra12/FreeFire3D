package com.beetalk.sdk.exts;

import com.beetalk.sdk.X;
import kotlin.jvm.internal.Intrinsics;
import kotlin.Metadata;

@Metadata
public final class f
{
    public static final int a(final Number n) {
        Intrinsics.checkNotNullParameter((Object)n, "<this>");
        return (int)(n.floatValue() * X.M().getResources().getDisplayMetrics().density + 0.5f);
    }
}
