package com.beetalk.sdk.exts;

import c1.i;
import kotlin.jvm.internal.Intrinsics;
import g2.f;
import g2.o;
import kotlin.Metadata;

@Metadata
public final class b
{
    public static final o a(final o o, final f f) {
        Intrinsics.checkNotNullParameter((Object)o, "<this>");
        Intrinsics.checkNotNullParameter((Object)f, "continuation");
        return o.k(f, o.m);
    }
    
    public static final boolean b(final i i) {
        Intrinsics.checkNotNullParameter((Object)i, "<this>");
        return !i.z() && !i.x();
    }
    
    public static final boolean c(final o o) {
        Intrinsics.checkNotNullParameter((Object)o, "<this>");
        return !o.u() && !o.s();
    }
}
