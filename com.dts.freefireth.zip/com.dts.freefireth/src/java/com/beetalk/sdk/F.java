package com.beetalk.sdk;

import com.beetalk.sdk.helper.k;
import android.content.Intent;
import java.util.UUID;
import android.app.Activity;
import java.io.Serializable;

public class f implements Serializable
{
    private static final long serialVersionUID = 1L;
    private final c a;
    private final String b;
    private int c;
    private s$h d;
    private String e;
    private String f;
    private s g;
    private final String h;
    private final p1.c i;
    
    public f(final Activity activity, final s$h d, final int c, final String e, final String h, final p1.c i) {
        this.b = UUID.randomUUID().toString();
        this.c = c;
        this.d = d;
        this.e = e;
        this.h = h;
        this.i = i;
        this.a = new c(this, activity) {
            final Activity a;
            final f b;
            
            @Override
            public Activity getContext() {
                return this.a;
            }
            
            @Override
            public void startActivityForResult(final Intent intent, final int n) {
                k.a(this.a.getClass().getName(), new Object[0]);
                this.a.startActivityForResult(intent, n);
            }
        };
    }
    
    public c b() {
        return this.a;
    }
    
    public d.c c() {
        final d.c c = new d.c(new c(this) {
            final f a;
            
            @Override
            public Activity getContext() {
                return this.a.a.getContext();
            }
            
            @Override
            public void startActivityForResult(final Intent intent, final int n) {
                this.a.a.startActivityForResult(intent, n);
            }
        }, this.b, this.c, this.e, this.f, this.h, this.i);
        c.i(this.g.H());
        c.j(this.g.F());
        return c;
    }
    
    public String d() {
        return this.h;
    }
    
    public int e() {
        return this.c;
    }
    
    public s f() {
        return this.g;
    }
    
    public void g(final String e) {
        this.e = e;
    }
    
    public void h(final String f) {
        this.f = f;
    }
    
    public void i(final int c) {
        this.c = c;
    }
    
    public void j(final s g) {
        this.g = g;
    }
}
