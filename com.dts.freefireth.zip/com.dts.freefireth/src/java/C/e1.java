package c;

import android.webkit.CookieManager;
import android.content.Intent;
import com.garena.unity.webview.UnityWebViewActivity;

public final class e1 extends U
{
    public final h a;
    
    public e1(final h a) {
        this.a = a;
        final UnityWebViewActivity a2 = a.a;
    }
    
    @Override
    public final Intent a(Intent f) {
        UnityWebViewActivity.s("execute intent", f);
        boolean b;
        try {
            CookieManager.getInstance();
        }
        finally {
            b = false;
        }
        f = this.a.a.f("test_result");
        f.putExtra("return_value", b);
        return f;
    }
}
