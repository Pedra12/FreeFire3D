package c;

import android.widget.FrameLayout;
import android.app.Activity;
import android.webkit.WebView;
import a.e1;
import com.garena.unity.webview.UnityWebViewActivity;

public final class b0 extends D0
{
    public final UnityWebViewActivity k;
    
    public b0(final UnityWebViewActivity k, final int n) {
        this.k = k;
        super(n);
    }
    
    @Override
    public final void b(final e1 e1) {
        final UnityWebViewActivity k = this.k;
        final int a = super.a;
        final boolean w = UnityWebViewActivity.w;
        k.i(a, e1);
    }
    
    @Override
    public final e1 f() {
        return this.k.a(super.a);
    }
    
    @Override
    public final void g(final String s) {
        final UnityWebViewActivity k = this.k;
        final int a = super.a;
        final boolean w = UnityWebViewActivity.w;
        k.o(k.c(a, "OnConsoleMessage_Android", s));
    }
    
    @Override
    public final WebView h() {
        return (WebView)this.k.b.get((Object)super.a);
    }
    
    @Override
    public final Activity i() {
        return (Activity)this.k;
    }
    
    @Override
    public final FrameLayout j() {
        return (FrameLayout)((Activity)this.k).getWindow().getDecorView().getRootView();
    }
}
