package c;

import android.content.Intent;
import com.garena.unity.webview.UnityWebViewActivity;

public final class c1 extends U
{
    public final h a;
    
    public c1(final h a) {
        this.a = a;
        final UnityWebViewActivity a2 = a.a;
    }
    
    @Override
    public final Intent a(final Intent intent) {
        UnityWebViewActivity.s("execute intent", intent);
        this.a.a.j = true;
        return null;
    }
}
