package c;

import android.content.Intent;
import com.garena.unity.webview.UnityWebViewActivity;

public final class n implements Runnable
{
    public final UnityWebViewActivity a;
    
    public n(final UnityWebViewActivity a) {
        this.a = a;
    }
    
    public final void run() {
        this.a.h = true;
        final UnityWebViewActivity a = this.a;
        a.o(a.f("ready"));
        this.a.z((Intent)null);
    }
}
