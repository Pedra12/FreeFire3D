package c;

import com.garena.unity.webview.WebViewManager;
import android.util.Log;
import android.os.Process;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public final class h0 extends BroadcastReceiver
{
    public final E0 a;
    
    public h0(final E0 a) {
        this.a = a;
    }
    
    public final void onReceive(final Context context, final Intent intent) {
        P0.F("recv by UnityPlayerActivity", intent);
        this.a.a.b.overridePendingTransition(0, 0);
        final int intExtra = intent.getIntExtra("activity_pid", 0);
        if (intExtra > 0) {
            try {
                Process.killProcess(intExtra);
            }
            finally {
                final StringBuilder sb = new StringBuilder("kill pid ");
                sb.append(intExtra);
                final Throwable t;
                Log.e("UWVActivityProxy", sb.toString(), t);
            }
        }
        monitorenter(this);
        Label_0164: {
            try {
                if (this.a.a.f == 0 || this.a.a.f != intExtra) {
                    break Label_0164;
                }
                this.a.a.N();
                final P0 a = this.a.a;
                final boolean b = true;
                a.e = 1;
                if (P0.p) {
                    Log.i("UWVActivityProxy", "close_all setting status to ".concat(K0.a(this.a.a.e)));
                }
                break Label_0164;
            }
            finally {
                monitorexit(this);
                final boolean b = false;
            Block_11:
                while (true) {
                    Label_0180: {
                        break Label_0180;
                        this.a.a.f = 0;
                        break Label_0180;
                        this.a.a.H(false);
                        iftrue(Label_0215:)(!intent.getBooleanExtra("force", false));
                        break Block_11;
                        Label_0225: {
                            return;
                        }
                    }
                    monitorexit(this);
                    iftrue(Label_0225:)(!b);
                    continue;
                }
                WebViewManager.a("ForceCloseAll", "");
                Label_0215: {
                    this.a.a.M();
                }
            }
        }
    }
}
