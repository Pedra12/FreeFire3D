package c;

import a.Z0;
import android.os.Parcel;
import android.os.Parcelable$Creator;

public final class f0 implements Parcelable$Creator
{
    public final Object createFromParcel(final Parcel parcel) {
        return new Z0(parcel);
    }
    
    public final Object[] newArray(final int n) {
        return new Z0[n];
    }
}
