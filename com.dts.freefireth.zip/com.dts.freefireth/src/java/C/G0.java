package c;

import android.app.Activity;
import android.util.Log;
import android.webkit.JavascriptInterface;
import com.garena.unity.webview.UnityWebViewActivity;

public final class g0
{
    public final int a;
    public final UnityWebViewActivity b;
    
    public g0(final UnityWebViewActivity b, final int a) {
        this.b = b;
        this.a = a;
    }
    
    @JavascriptInterface
    public void on_HTML5_Video_Ended() {
        ((Activity)this.b).runOnUiThread((Runnable)new e0(this));
    }
    
    @JavascriptInterface
    public void postMessage(final String s) {
        Label_0115: {
            final Throwable t;
            Label_0105: {
                try {
                    final UnityWebViewActivity b = this.b;
                    final boolean w = UnityWebViewActivity.w;
                    final Q a = b.a;
                    if (a != null) {
                        if (!a.e) {
                            if (s != null && s.contains((CharSequence)"RequestPermission")) {
                                final StringBuilder sb = new StringBuilder("postMessage: skip tryHandlePermissionMessage because permission request processing is disabled, webViewId=");
                                sb.append(this.a);
                                Log.i("UWVActivity", sb.toString());
                            }
                            break Label_0115;
                        }
                    }
                }
                finally {
                    break Label_0105;
                }
                if (UnityWebViewActivity.u((UnityWebViewActivity)t, this.a, s)) {
                    return;
                }
                break Label_0115;
            }
            Log.e("UWVActivity", "postMessage: tryHandlePermissionMessage", t);
        }
        final UnityWebViewActivity b2 = this.b;
        final int a2 = this.a;
        final boolean w2 = UnityWebViewActivity.w;
        b2.o(b2.c(a2, "OnJavaScriptPostMessage", s));
    }
}
