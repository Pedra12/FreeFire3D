package c;

import a.X0;
import android.os.Parcel;
import android.os.Parcelable$Creator;

public final class c0 implements Parcelable$Creator
{
    public final Object createFromParcel(final Parcel parcel) {
        return new X0(parcel);
    }
    
    public final Object[] newArray(final int n) {
        return new X0[n];
    }
}
