package c;

import android.view.View;

public final class u0 implements Runnable
{
    public final D0 a;
    
    public u0(final D0 a) {
        this.a = a;
    }
    
    public final void run() {
        ((View)this.a.d).forceLayout();
    }
}
