package c;

import android.media.MediaPlayer;
import android.media.MediaPlayer$OnPreparedListener;
import android.media.MediaPlayer$OnErrorListener;
import android.media.MediaPlayer$OnCompletionListener;

public final class y0 implements MediaPlayer$OnCompletionListener, MediaPlayer$OnErrorListener, MediaPlayer$OnPreparedListener
{
    public final D0 a;
    
    public y0(final D0 a) {
        this.a = a;
    }
    
    public final void onCompletion(final MediaPlayer mediaPlayer) {
        this.a.onHideCustomView();
    }
    
    public final boolean onError(final MediaPlayer mediaPlayer, final int n, final int n2) {
        return false;
    }
    
    public final void onPrepared(final MediaPlayer mediaPlayer) {
    }
}
