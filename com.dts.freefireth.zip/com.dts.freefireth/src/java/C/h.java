package c;

import java.util.AbstractMap;
import com.garena.unity.webview.UnityWebViewActivity;
import java.util.HashMap;

public final class h extends HashMap
{
    public final UnityWebViewActivity a;
    
    public h(final UnityWebViewActivity a) {
        this.a = a;
        ((AbstractMap)this).put((Object)"ping_resp", (Object)new c1(this));
        ((AbstractMap)this).put((Object)"test", (Object)new e1(this));
        ((AbstractMap)this).put((Object)"clear_all", (Object)new g1(this));
        ((AbstractMap)this).put((Object)"close_all", (Object)new i1(this));
        ((AbstractMap)this).put((Object)"open", (Object)new k1(this));
        ((AbstractMap)this).put((Object)"close", (Object)new m1(this));
        ((AbstractMap)this).put((Object)"reload", (Object)new b(this));
        ((AbstractMap)this).put((Object)"redirect_to", (Object)new d(this));
        ((AbstractMap)this).put((Object)"show", (Object)new f(this));
        ((AbstractMap)this).put((Object)"hide", (Object)new F0(this));
        ((AbstractMap)this).put((Object)"run_javascript", (Object)new H0(this));
        ((AbstractMap)this).put((Object)"can_go_backward", (Object)new J0(this));
        ((AbstractMap)this).put((Object)"can_go_forward", (Object)new L0(this));
        ((AbstractMap)this).put((Object)"go_backward", (Object)new N0(this));
        ((AbstractMap)this).put((Object)"go_forward", (Object)new Q0(this));
        ((AbstractMap)this).put((Object)"capture_screenshot", (Object)new U0(this));
        ((AbstractMap)this).put((Object)"get_ua", (Object)new W0(this));
        ((AbstractMap)this).put((Object)"set_ua", (Object)new Y0(this));
        ((AbstractMap)this).put((Object)"fetch_webview_url", (Object)new a1(this));
    }
}
