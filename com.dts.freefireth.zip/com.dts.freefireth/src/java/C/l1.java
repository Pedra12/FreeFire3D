package c;

import android.webkit.WebView;

public final class l1 implements Runnable
{
    public final int a;
    public final String b;
    public final a0 c;
    
    public l1(final a0 c, final int a, final String b) {
        this.c = c;
        this.a = a;
        this.b = b;
    }
    
    public final void run() {
        final a0 c = this.c;
        final int a = this.a;
        synchronized (c) {
            final WebView webView = (WebView)c.d.get((Object)a);
            monitorexit(c);
            if (webView != null) {
                if (webView.getSettings() != null) {
                    webView.getSettings().setUserAgentString(this.b);
                }
            }
        }
    }
}
