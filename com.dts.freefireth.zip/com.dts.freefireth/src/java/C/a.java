package c;

import com.google.gson.Gson;
import a.e;
import android.webkit.ValueCallback;

public final class a implements ValueCallback
{
    public final String a;
    public final int b;
    public final String c;
    public final a0 d;
    
    public a(final a0 d, final String a, final int b, final String c) {
        this.d = d;
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public final void onReceiveValue(final Object o) {
        final String value = (String)o;
        try {
            final String a = this.a;
            if (a != null && a.length() > 0) {
                final a0 d = this.d;
                final int b = this.b;
                final StringBuilder sb = new StringBuilder("@evaluateJavascript.ValueCallback(): ");
                sb.append(value);
                d.M(b, sb.toString());
                final a0 d2 = this.d;
                final int b2 = this.b;
                final String a2 = this.a;
                final String c = this.c;
                d2.getClass();
                final StringBuilder sb2 = new StringBuilder("@sendJavaScriptResultToUnity: ");
                sb2.append(value);
                d2.M(b2, sb2.toString());
                final Gson c2 = d2.c;
                final e e = new e();
                e.value = value;
                e.callback = a2;
                e.id = c;
                d2.f(b2, "OnJavaScriptResult", c2.toJson((Object)e));
            }
        }
        finally {
            final Throwable t;
            this.d.J(this.b, "@evaluateJavascript.ValueCallback()", t);
            this.d.I(this.b, t.getMessage(), this.a, this.c);
        }
    }
}
