package c;

import android.view.ViewGroup$LayoutParams;
import android.view.View;
import android.widget.FrameLayout$LayoutParams;
import android.content.Context;
import android.widget.FrameLayout;

public final class c implements Runnable
{
    public final a0 a;
    
    public c(final a0 a) {
        this.a = a;
    }
    
    public final void run() {
        final a0 a = this.a;
        if (a.b == null) {
            a.b = new FrameLayout((Context)this.a.a);
            final a0 a2 = this.a;
            a2.a.addContentView((View)a2.b, (ViewGroup$LayoutParams)new FrameLayout$LayoutParams(-1, -1));
            ((View)this.a.b).setVisibility(4);
        }
    }
}
