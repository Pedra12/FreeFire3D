package c;

public final class k implements Runnable
{
    public final a0 a;
    
    public k(final a0 a) {
        this.a = a;
    }
    
    public final void run() {
        if (this.a.i()) {
            a0.K(this.a);
        }
        if (this.a.l()) {
            a0.L(this.a);
        }
        a0.N(this.a);
    }
}
