package c;

import com.garena.unity.webview.UnityWebViewActivity;
import android.webkit.WebView;
import android.graphics.Bitmap;
import android.view.PixelCopy$OnPixelCopyFinishedListener;

public final class l implements PixelCopy$OnPixelCopyFinishedListener
{
    public final int a;
    public final String b;
    public final Bitmap c;
    public final WebView d;
    public final UnityWebViewActivity e;
    
    public l(final UnityWebViewActivity e, final int a, final String b, final Bitmap c, final WebView d) {
        this.e = e;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public final void onPixelCopyFinished(int n) {
        Label_0062: {
            if (n != 0) {
                break Label_0062;
            }
            Label_0150: {
                try {
                    final UnityWebViewActivity e = this.e;
                    n = this.a;
                    final String b = this.b;
                    final Bitmap c = this.c;
                    final boolean w = UnityWebViewActivity.w;
                    e.j(n, e.c(n, "OnCaptureScreenshotSuccess", e.g(b, c)));
                    break Label_0150;
                }
                finally {
                    while (true) {
                        Label_0205: {
                            try {
                                final UnityWebViewActivity e2 = this.e;
                                n = this.a;
                                final Throwable t;
                                if (t.getMessage() == null) {
                                    final String s = t.getClass().getSimpleName();
                                    break Label_0212;
                                }
                                break Label_0205;
                            }
                            finally {
                                if (!this.c.isRecycled()) {
                                    this.c.recycle();
                                }
                                Label_0249: {
                                    return;
                                }
                                final boolean w2 = UnityWebViewActivity.w;
                                final UnityWebViewActivity e2;
                                final String s;
                                e2.j(n, e2.c(n, "OnCaptureScreenshotFailure", s));
                                iftrue(Label_0249:)(this.c.isRecycled());
                                Block_8: {
                                    break Block_8;
                                    final Throwable t;
                                    s = t.getMessage();
                                    continue;
                                }
                                this.c.recycle();
                            }
                        }
                        break;
                    }
                    while (true) {
                        this.c.recycle();
                        return;
                        final UnityWebViewActivity e3 = this.e;
                        final int a = this.a;
                        final StringBuilder sb = new StringBuilder("@captureScreenshot(): PixelCopy failed with ");
                        sb.append(n);
                        sb.append(", falling back to View.draw");
                        final String string = sb.toString();
                        final boolean w3 = UnityWebViewActivity.w;
                        e3.k(a, string);
                        final UnityWebViewActivity e4 = this.e;
                        n = this.a;
                        e4.j(n, e4.b(n, this.b, this.d));
                        iftrue(Label_0249:)(this.c.isRecycled());
                        continue;
                    }
                }
            }
        }
    }
}
