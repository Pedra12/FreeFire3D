package c;

import com.garena.unity.webview.WebViewManager;

public final class x implements Runnable
{
    public final a0 a;
    
    public x(final a0 a) {
        this.a = a;
    }
    
    public final void run() {
        WebViewManager.a("OnClearCache", a0.L(this.a));
    }
}
