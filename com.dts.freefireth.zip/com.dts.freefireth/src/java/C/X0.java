package c;

import a.e1;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public final class x0 extends BroadcastReceiver
{
    public final E0 a;
    
    public x0(final E0 a) {
        this.a = a;
    }
    
    public final void onReceive(final Context context, final Intent intent) {
        intent.setExtrasClassLoader(e1.class.getClassLoader());
        P0.F("recv by UnityPlayerActivity", intent);
        this.a.a.e(intent.getIntExtra("web_view_id", -1), (e1)intent.getParcelableExtra("web_view_status"));
    }
}
