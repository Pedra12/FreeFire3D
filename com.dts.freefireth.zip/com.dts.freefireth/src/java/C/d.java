package c;

import a.e1;
import android.webkit.WebView;
import android.content.Intent;
import com.garena.unity.webview.UnityWebViewActivity;

public final class d extends U
{
    public final h a;
    
    public d(final h a) {
        this.a = a;
        final UnityWebViewActivity a2 = a.a;
    }
    
    @Override
    public final Intent a(Intent a) {
        UnityWebViewActivity.s("execute intent", a);
        final int intExtra = a.getIntExtra("web_view_id", -1);
        final String stringExtra = a.getStringExtra("redirect_url");
        if (intExtra >= 0 && stringExtra != null) {
            a = (Intent)this.a.a;
            final WebView webView = (WebView)((UnityWebViewActivity)a).b.get((Object)intExtra);
            if (webView != null) {
                final String s;
                Label_0111: {
                    try {
                        final e1 a2 = ((UnityWebViewActivity)a).a(intExtra);
                        if (a2 != null) {
                            a2.f = true;
                            a2.g = 0.0;
                            a2.h = stringExtra;
                            ((UnityWebViewActivity)a).i(intExtra, a2);
                        }
                    }
                    finally {
                        break Label_0111;
                    }
                    webView.loadUrl(s);
                    return null;
                }
                ((UnityWebViewActivity)a).l(intExtra, "@_redirectTo()", (Throwable)s);
            }
        }
        return null;
    }
}
