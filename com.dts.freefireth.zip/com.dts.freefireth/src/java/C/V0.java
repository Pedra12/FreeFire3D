package c;

import com.garena.unity.webview.IUnityMessenger;
import a.e1;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public final class v0 extends BroadcastReceiver
{
    public final E0 a;
    
    public v0(final E0 a) {
        this.a = a;
    }
    
    public final void onReceive(final Context context, final Intent intent) {
        P0.F("recv by UnityPlayerActivity", intent);
        final int intExtra = intent.getIntExtra("web_view_id", -1);
        final String stringExtra = intent.getStringExtra("unity_method");
        final String stringExtra2 = intent.getStringExtra("unity_method_parameters");
        stringExtra.getClass();
        if (stringExtra.equals((Object)"OnFetchWebViewURLResult")) {
            final e1 l = this.a.a.L(intExtra);
            if (l != null) {
                l.h = stringExtra2;
                this.a.a.d.put((Object)intExtra, (Object)l);
            }
        }
        final P0 a = this.a.a;
        final e1 i = a.L(intExtra);
        if (i != null) {
            final String a2 = i.a;
            if (a2 != null) {
                if (a2.length() > 0) {
                    final IUnityMessenger j = a.l;
                    if (j != null) {
                        j.Send(i.a, stringExtra, stringExtra2);
                    }
                }
            }
        }
    }
}
