package c;

import android.webkit.WebView;
import android.graphics.Bitmap;
import android.view.PixelCopy$OnPixelCopyFinishedListener;

public final class g implements PixelCopy$OnPixelCopyFinishedListener
{
    public final int a;
    public final String b;
    public final Bitmap c;
    public final WebView d;
    public final a0 e;
    
    public g(final a0 e, final int a, final String b, final Bitmap c, final WebView d) {
        this.e = e;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public final void onPixelCopyFinished(int n) {
        Label_0063: {
            if (n != 0) {
                break Label_0063;
            }
            Label_0129: {
                try {
                    final a0 e = this.e;
                    n = this.a;
                    final String a = e.a(this.b, this.c);
                    if (!e.f.remove((Object)n)) {
                        break Label_0129;
                    }
                    e.f(n, "OnCaptureScreenshotSuccess", a);
                    break Label_0129;
                }
                finally {
                    Label_0180: {
                        try {
                            final a0 e2 = this.e;
                            n = this.a;
                            final Throwable t;
                            if (t.getMessage() == null) {
                                final String s = t.getClass().getSimpleName();
                                break Label_0180;
                            }
                            break Label_0180;
                        }
                        finally {
                            if (!this.c.isRecycled()) {
                                this.c.recycle();
                            }
                            while (true) {
                                iftrue(Label_0229:)(this.c.isRecycled());
                                Block_10: {
                                    break Block_10;
                                    Label_0203: {
                                        final a0 e2;
                                        final String s;
                                        e2.f(n, "OnCaptureScreenshotFailure", s);
                                    }
                                    continue;
                                }
                                this.c.recycle();
                                return;
                                final a0 e2;
                                iftrue(Label_0203:)(e2.f.remove((Object)n));
                                continue;
                            }
                            Label_0229: {
                                return;
                            }
                            final Throwable t;
                            final String s = t.getMessage();
                        }
                    }
                    final a0 e3 = this.e;
                    final int a2 = this.a;
                    final StringBuilder sb = new StringBuilder("@captureScreenshot(): PixelCopy failed with ");
                    sb.append(n);
                    sb.append(", falling back to View.draw");
                    e3.M(a2, sb.toString());
                    this.e.e(this.a, this.b, this.d);
                    break Label_0129;
                    while (true) {
                        this.c.recycle();
                        return;
                        iftrue(Label_0229:)(this.c.isRecycled());
                        continue;
                    }
                }
            }
        }
    }
}
