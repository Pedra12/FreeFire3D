package c;

import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public final class p0 extends BroadcastReceiver
{
    public final E0 a;
    
    public p0(final E0 a) {
        this.a = a;
    }
    
    public final void onReceive(final Context context, final Intent intent) {
        this.a.a.m = false;
        P0.F("recv by UnityPlayerActivity", intent);
    }
}
