package c;

import android.widget.FrameLayout$LayoutParams;
import android.graphics.Canvas;
import java.io.OutputStream;
import android.graphics.Bitmap$CompressFormat;
import java.io.FileOutputStream;
import java.io.File;
import a.e;
import a.e1;
import android.webkit.WebStorage;
import com.garena.unity.webview.WebViewManager;
import android.content.Context;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.view.Window;
import android.view.PixelCopy$OnPixelCopyFinishedListener;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Bitmap;
import android.graphics.Bitmap$Config;
import android.graphics.Rect;
import android.os.Build$VERSION;
import java.util.Iterator;
import android.webkit.WebView;
import java.util.Map$Entry;
import com.garena.unity.webview.IUnityMessenger;
import android.view.View;
import java.util.HashSet;
import java.util.HashMap;
import com.google.gson.Gson;
import android.widget.FrameLayout;
import android.app.Activity;

public final class a0 implements k0
{
    public static volatile a0 j;
    public static volatile boolean k;
    public static volatile int l;
    public Activity a;
    public FrameLayout b;
    public final Gson c;
    public volatile HashMap d;
    public volatile HashMap e;
    public final HashSet f;
    public View g;
    public volatile int h;
    public IUnityMessenger i;
    
    public a0() {
        this.c = new Gson();
        this.d = new HashMap();
        this.e = new HashMap();
        this.f = new HashSet();
        this.h = 0;
    }
    
    public static void F(final a0 a0) {
        final Iterator iterator = a0.d.entrySet().iterator();
        boolean b = true;
        int n = 1;
        while (iterator.hasNext()) {
            final Map$Entry map$Entry = (Map$Entry)iterator.next();
            final Object value = map$Entry.getValue();
            final int n2 = 0;
            final boolean b2 = b & value == null;
            int n3 = 0;
            Label_0099: {
                if (map$Entry.getValue() != null) {
                    n3 = n2;
                    if (((View)map$Entry.getValue()).getVisibility() == 0) {
                        break Label_0099;
                    }
                }
                n3 = 1;
            }
            n &= n3;
            b = b2;
        }
        if (b) {
            final FrameLayout b3 = a0.b;
            if (b3 != null) {
                ((View)b3).setVisibility(4);
            }
        }
        if (n != 0) {
            final View g = a0.g;
            if (g != null) {
                g.requestFocus();
            }
        }
    }
    
    public static void G(final a0 a0, final int n, final String s, final WebView webView) {
        a0.getClass();
        if (Build$VERSION.SDK_INT < 26) {
            a0.e(n, s, webView);
            return;
        }
        if (((View)webView).getWidth() <= 0 || ((View)webView).getHeight() <= 0) {
            a0.M(n, "@captureScreenshot(): PixelCopy has an invalid WebView size, falling back to View.draw");
            a0.e(n, s, webView);
            return;
        }
        Object o = null;
        PixelCopy$OnPixelCopyFinishedListener pixelCopy$OnPixelCopyFinishedListener;
        try {
            final int[] array = new int[2];
            ((View)webView).getLocationInWindow(array);
            final int n2 = array[0];
            final Rect rect = new Rect(n2, array[1], ((View)webView).getWidth() + n2, array[1] + ((View)webView).getHeight());
            final Bitmap bitmap = Bitmap.createBitmap(((View)webView).getWidth(), ((View)webView).getHeight(), Bitmap$Config.ARGB_8888);
            try {
                final Window window = a0.a.getWindow();
                try {
                    o = new g(a0, n, s, bitmap, webView);
                    Z.a(window, rect, bitmap, (PixelCopy$OnPixelCopyFinishedListener)o, new Handler(Looper.getMainLooper()));
                    return;
                }
                finally {}
            }
            finally {}
        }
        finally {
            pixelCopy$OnPixelCopyFinishedListener = (PixelCopy$OnPixelCopyFinishedListener)o;
        }
        if (pixelCopy$OnPixelCopyFinishedListener != null && !((Bitmap)pixelCopy$OnPixelCopyFinishedListener).isRecycled()) {
            ((Bitmap)pixelCopy$OnPixelCopyFinishedListener).recycle();
        }
        final Throwable t;
        a0.J(n, "@captureScreenshot(): PixelCopy request failed, falling back to View.draw", t);
        a0.e(n, s, webView);
    }
    
    public static void H(final a0 a0, final int n, final String s, final String s2, final String s3) {
        synchronized (a0) {
            final WebView webView = (WebView)a0.d.get((Object)n);
            monitorexit(a0);
            final StringBuilder sb = new StringBuilder("@runJavaScript(): execute ");
            sb.append(s2);
            sb.append(": ");
            sb.append(s3);
            a0.M(n, sb.toString());
            if (webView == null) {
                final StringBuilder sb2 = new StringBuilder("WebView is null: ");
                sb2.append(n);
                a0.I(n, sb2.toString(), s2, s3);
                return;
            }
            try {
                a0.M(n, "?evaluateJavascript()");
                webView.evaluateJavascript(s, (ValueCallback)new a(a0, s2, n, s3));
                a0.M(n, "!evaluateJavascript()");
            }
            finally {
                final Throwable t;
                a0.J(n, "@evaluateJavascript()", t);
                a0.I(n, t.getMessage(), s2, s3);
            }
        }
    }
    
    public static void K(final a0 a0) {
        a0.getClass();
        final CookieManager instance = CookieManager.getInstance();
        try {
            instance.removeSessionCookies((ValueCallback)null);
            instance.removeAllCookies((ValueCallback)null);
            instance.flush();
        }
        finally {}
    }
    
    public static String L(final a0 a0) {
        a0.getClass();
        try {
            final WebView webView = new WebView((Context)a0.a);
            webView.clearFormData();
            webView.clearHistory();
            webView.clearMatches();
            webView.clearCache(true);
            webView.destroy();
            return "";
        }
        finally {
            final Throwable t;
            WebViewManager.Log("@clearCache()", t);
            return t.getMessage();
        }
    }
    
    public static void N(final a0 a0) {
        a0.getClass();
        try {
            WebStorage.getInstance().deleteAllData();
        }
        finally {}
    }
    
    public static a0 O() {
        final Class<a0> clazz;
        monitorenter(clazz = a0.class);
        Label_0030: {
            try {
                if (a0.j == null) {
                    a0.j = new a0();
                }
                break Label_0030;
            }
            finally {
                monitorexit(clazz);
                final a0 j = a0.j;
                monitorexit(clazz);
                return j;
            }
        }
    }
    
    @Override
    public final void A(final int n) {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new h1(this, n));
    }
    
    @Override
    public final int B(final String h, final float n, final float n2, final float n3, final float n4, final String s) {
        if (this.a == null) {
            return -1;
        }
        synchronized (this) {
            ++this.h;
            final int h2 = this.h;
            monitorexit(this);
            final e1 e1 = new e1();
            e1.h = h;
            e1.b = true;
            this.e.put((Object)h2, (Object)e1);
            this.a.runOnUiThread((Runnable)new H(this, h2, s, n, n2, n3, n4, h));
            return h2;
        }
    }
    
    @Override
    public final void C(final int n, final String[] array, final int[] array2) {
        if (n != 8227) {
            return;
        }
        final HashMap e;
        monitorenter(e = this.e);
        Label_0087: {
            try {
                for (final e1 e2 : this.e.values()) {
                    if (e2 != null) {
                        final D0 x = e2.x;
                        if (x == null) {
                            continue;
                        }
                        x.d(array, array2);
                    }
                }
                break Label_0087;
            }
            finally {
                monitorexit(e);
                monitorexit(e);
            }
        }
    }
    
    @Override
    public final void D(final int n) {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new N(this, n));
    }
    
    public final void E(final int n, final String s, final Throwable t) {
        final StringBuilder sb = new StringBuilder();
        sb.append(s);
        sb.append(": ");
        sb.append(t.getClass().getName());
        sb.append(": ");
        sb.append(t.getMessage());
        this.f(n, "OnWebViewMessage_Android", sb.toString());
    }
    
    public final void I(final int n, final String error, final String callback, final String id) {
        final StringBuilder sb = new StringBuilder("@sendJavaScriptErrorToUnity: ");
        sb.append(error);
        this.M(n, sb.toString());
        final Gson c = this.c;
        final e e = new e();
        e.error = error;
        e.callback = callback;
        e.id = id;
        this.f(n, "OnJavaScriptResult", c.toJson((Object)e));
    }
    
    public final void J(final int n, final String s, final Throwable t) {
        synchronized (this) {
            final e1 e1 = (e1)this.e.get((Object)n);
            monitorexit(this);
            if (e1 != null) {
                if (e1.j) {
                    this.E(n, s, t);
                }
            }
        }
    }
    
    public final void M(final int n, final String s) {
        synchronized (this) {
            final e1 e1 = (e1)this.e.get((Object)n);
            monitorexit(this);
            if (e1 != null) {
                if (e1.j) {
                    this.f(n, "OnWebViewMessage_Android", s);
                }
            }
        }
    }
    
    public final e1 P(final int n) {
        synchronized (this) {
            return (e1)this.e.get((Object)n);
        }
    }
    
    public final WebView Q(final int n) {
        synchronized (this) {
            return (WebView)this.d.get((Object)n);
        }
    }
    
    public final String a(final String s, final Bitmap bitmap) {
        final Activity a = this.a;
        final FileOutputStream fileOutputStream = null;
        final File externalFilesDir = ((Context)a).getExternalFilesDir((String)null);
        if (externalFilesDir == null) {
            throw new IllegalStateException("External files directory is unavailable");
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(s);
        sb.append(".jpg");
        final File file = new File(externalFilesDir, sb.toString());
        FileOutputStream fileOutputStream3 = null;
        try {
            final FileOutputStream fileOutputStream2 = new FileOutputStream(file);
            Label_0118: {
                try {
                    if (bitmap.compress(Bitmap$CompressFormat.JPEG, 100, (OutputStream)fileOutputStream2)) {
                        ((OutputStream)fileOutputStream2).flush();
                        fileOutputStream2.close();
                        return file.getAbsolutePath();
                    }
                }
                finally {
                    break Label_0118;
                }
                throw new IllegalStateException("Failed to encode screenshot JPEG");
            }
        }
        finally {
            fileOutputStream3 = fileOutputStream;
        }
        if (fileOutputStream3 != null) {
            fileOutputStream3.close();
        }
    }
    
    @Override
    public final void a() {
        boolean b;
        try {
            CookieManager.getInstance();
        }
        finally {
            b = false;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(b);
        sb.append("");
        WebViewManager.a("testResult", sb.toString());
    }
    
    @Override
    public final void a(final int n) {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new Z0(this, n));
    }
    
    @Override
    public final void b() {
        if (this.i()) {
            final Activity a = this.a;
            if (a != null) {
                a.runOnUiThread((Runnable)new m(this));
            }
        }
    }
    
    @Override
    public final void c() {
        final Activity a = this.a;
        if (a != null) {
            a.runOnUiThread((Runnable)new B(this));
        }
    }
    
    @Override
    public final boolean c(final int n) {
        synchronized (this) {
            final e1 e1 = (e1)this.e.get((Object)n);
            monitorexit(this);
            return e1 != null && e1.f;
        }
    }
    
    @Override
    public final void d() {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new k(this));
    }
    
    @Override
    public final void d(final int n, final String s) {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new P(this, n, s));
    }
    
    @Override
    public final void e() {
        final Activity a = this.a;
        if (a != null) {
            a.runOnUiThread((Runnable)new D(this));
        }
    }
    
    public final void e(final int n, String a, WebView webView) {
        Object bitmap = null;
        final WebView webView2 = null;
        try {
            final Bitmap bitmap2 = Bitmap.createBitmap(((View)this.b).getWidth(), ((View)this.b).getHeight(), Bitmap$Config.ARGB_8888);
            bitmap = webView2;
            try {
                final FrameLayout b = this.b;
                bitmap = webView2;
                bitmap = webView2;
                final Canvas canvas = new Canvas(bitmap2);
                bitmap = webView2;
                ((View)b).draw(canvas);
                bitmap = webView2;
                final FrameLayout$LayoutParams frameLayout$LayoutParams = (FrameLayout$LayoutParams)((View)webView).getLayoutParams();
                bitmap = webView2;
                final int leftMargin = frameLayout$LayoutParams.leftMargin;
                bitmap = webView2;
                final int height = ((View)this.b).getHeight();
                bitmap = webView2;
                final int height2 = frameLayout$LayoutParams.height;
                bitmap = webView2;
                final Bitmap bitmap3 = (Bitmap)(bitmap = Bitmap.createBitmap(bitmap2, leftMargin, height - height2 - frameLayout$LayoutParams.bottomMargin, frameLayout$LayoutParams.width, height2));
                a = this.a(a, bitmap3);
                bitmap = bitmap3;
                if (this.f.remove((Object)n)) {
                    bitmap = bitmap3;
                    this.f(n, "OnCaptureScreenshotSuccess", a);
                }
                if (!bitmap3.isRecycled()) {
                    bitmap3.recycle();
                }
                if (bitmap2 != null && !bitmap2.isRecycled()) {
                    bitmap2.recycle();
                }
                return;
            }
            finally {}
        }
        finally {
            a = null;
            webView = (WebView)bitmap;
        }
    Block_14_Outer:
        while (true) {
            Label_0260: {
                try {
                    final Throwable t;
                    if (t.getMessage() == null) {
                        final String s = t.getClass().getSimpleName();
                        break Label_0267;
                    }
                    break Label_0260;
                }
                finally {
                    if (a != null && !((Bitmap)a).isRecycled()) {
                        ((Bitmap)a).recycle();
                    }
                    if (webView != null && !((Bitmap)webView).isRecycled()) {
                        ((Bitmap)webView).recycle();
                    }
                    iftrue(Label_0284:)(this.f.remove((Object)n));
                    final Throwable t;
                    String s;
                    Block_16_Outer:Block_18_Outer:
                    while (true) {
                        break Block_14;
                        Label_0324: {
                            return;
                        }
                        while (true) {
                        Label_0309:
                            while (true) {
                                ((Bitmap)a).recycle();
                                break Label_0309;
                                ((Bitmap)webView).recycle();
                                return;
                                iftrue(Label_0309:)(a == null || ((Bitmap)a).isRecycled());
                                continue Block_18_Outer;
                            }
                            iftrue(Label_0324:)(webView == null || ((Bitmap)webView).isRecycled());
                            continue;
                        }
                        s = t.getMessage();
                        continue Block_14_Outer;
                        Label_0284:
                        this.f(n, "OnCaptureScreenshotFailure", s);
                        continue Block_16_Outer;
                    }
                }
            }
            break;
        }
    }
    
    @Override
    public final void f() {
        this.c();
    }
    
    public final void f(final int n, final String s, final String s2) {
        synchronized (this) {
            final e1 e1 = (e1)this.e.get((Object)n);
            monitorexit(this);
            if (e1 != null) {
                final String a = e1.a;
                if (a != null) {
                    if (a.length() > 0) {
                        final IUnityMessenger i = this.i;
                        if (i != null) {
                            i.Send(e1.a, s, s2);
                        }
                    }
                }
            }
        }
    }
    
    @Override
    public final void g() {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new z(this));
    }
    
    @Override
    public final void h(final int n) {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new X0(this, n));
    }
    
    @Override
    public final void i(final int n, final String s) {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new l1(this, n, s));
    }
    
    @Override
    public final boolean i() {
        return this.a != null;
    }
    
    @Override
    public final void j() {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new L(this));
    }
    
    @Override
    public final void k(final int n) {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new j1(this, n));
    }
    
    @Override
    public final void l(final int n) {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new b1(this, n));
    }
    
    @Override
    public final boolean l() {
        return this.a != null;
    }
    
    @Override
    public final void m() {
        if (this.l()) {
            final Activity a = this.a;
            if (a != null) {
                a.runOnUiThread((Runnable)new x(this));
            }
        }
    }
    
    @Override
    public final boolean m(final int n) {
        if (this.a == null) {
            return false;
        }
        synchronized (this) {
            final e1 e1 = (e1)this.e.get((Object)n);
            monitorexit(this);
            return e1 != null && (e1.e ^ true);
        }
    }
    
    @Override
    public final void n(final Activity a) {
        this.a = a;
        if (a != null) {
            a.runOnUiThread((Runnable)new c(this));
        }
    }
    
    @Override
    public final void o(final int n) {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new f1(this, n));
    }
    
    @Override
    public final String p(final int n) {
        synchronized (this) {
            final e1 e1 = (e1)this.e.get((Object)n);
            monitorexit(this);
            if (e1 != null) {
                return e1.h;
            }
            return "";
        }
    }
    
    @Override
    public final void q(final int n) {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new V0(this, n));
    }
    
    @Override
    public final boolean r(final String s, final boolean b) {
        return false;
    }
    
    @Override
    public final double s(final int n) {
        synchronized (this) {
            final e1 e1 = (e1)this.e.get((Object)n);
            monitorexit(this);
            if (e1 != null) {
                return e1.g;
            }
            return -1.0;
        }
    }
    
    @Override
    public final void t() {
        final Activity a = this.a;
        if (a != null) {
            a.runOnUiThread((Runnable)new F(this));
        }
    }
    
    @Override
    public final void u(final IUnityMessenger i) {
        this.i = i;
    }
    
    @Override
    public final void v(final int n) {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new J(this, n));
    }
    
    @Override
    public final void w(final int webViewId, final String code, final String callback, final String id) {
        if (this.a == null) {
            return;
        }
        final StringBuilder sb = new StringBuilder("@runJavaScript(): ");
        sb.append(id);
        sb.append(": ");
        sb.append(callback);
        sb.append("\n");
        sb.append(code);
        this.M(webViewId, sb.toString());
        synchronized (this) {
            final WebView webView = (WebView)this.d.get((Object)webViewId);
            monitorexit(this);
            final e1 p4 = this.P(webViewId);
            if (webView == null) {
                if (p4 != null && p4.b) {
                    final StringBuilder sb2 = new StringBuilder("@runJavaScript(): queued ");
                    sb2.append(callback);
                    sb2.append(": ");
                    sb2.append(id);
                    this.M(webViewId, sb2.toString());
                    final a.c c = new a.c();
                    c.webViewId = webViewId;
                    c.code = code;
                    c.callback = callback;
                    c.id = id;
                    p4.i.addLast((Object)c);
                    return;
                }
                final StringBuilder sb3 = new StringBuilder("WebView is null: ");
                sb3.append(webViewId);
                this.I(webViewId, sb3.toString(), callback, id);
            }
            this.a.runOnUiThread((Runnable)new c.e(this, webViewId, code, callback, id));
        }
    }
    
    @Override
    public final void x(final int n) {
        final Activity a = this.a;
        if (a == null) {
            return;
        }
        a.runOnUiThread((Runnable)new d1(this, n));
    }
    
    @Override
    public final boolean y() {
        return false;
    }
    
    @Override
    public final boolean z(final int n, final String s) {
        if (this.a == null) {
            return false;
        }
        if (this.b == null) {
            return false;
        }
        if (s != null && s.length() > 0) {
            this.a.runOnUiThread((Runnable)new i(this, n, s));
            return true;
        }
        return false;
    }
}
