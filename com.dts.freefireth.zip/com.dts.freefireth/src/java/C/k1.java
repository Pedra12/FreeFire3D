package c;

import a.X0;
import android.content.Intent;
import com.garena.unity.webview.UnityWebViewActivity;

public final class k1 extends U
{
    public final h a;
    
    public k1(final h a) {
        this.a = a;
        final UnityWebViewActivity a2 = a.a;
    }
    
    @Override
    public final Intent a(final Intent intent) {
        intent.setExtrasClassLoader(X0.class.getClassLoader());
        UnityWebViewActivity.s("execute intent", intent);
        final X0 x0 = (X0)intent.getParcelableExtra("web_view_parameters");
        if (x0 == null) {
            return null;
        }
        UnityWebViewActivity.r(this.a.a, x0, intent.getBundleExtra("web_view_flags"));
        return null;
    }
}
