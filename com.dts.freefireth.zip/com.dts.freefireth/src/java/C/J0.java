package c;

import a.b1;
import android.os.Parcel;
import android.os.Parcelable$Creator;

public final class j0 implements Parcelable$Creator
{
    public final Object createFromParcel(final Parcel parcel) {
        return new b1(parcel);
    }
    
    public final Object[] newArray(final int n) {
        return new b1[n];
    }
}
