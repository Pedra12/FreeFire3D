package c;

import com.garena.unity.webview.IUnityMessenger;
import android.app.Activity;

public interface k0
{
    void A(final int p0);
    
    int B(final String p0, final float p1, final float p2, final float p3, final float p4, final String p5);
    
    void C(final int p0, final String[] p1, final int[] p2);
    
    void D(final int p0);
    
    void a();
    
    void a(final int p0);
    
    void b();
    
    void c();
    
    boolean c(final int p0);
    
    void d();
    
    void d(final int p0, final String p1);
    
    void e();
    
    void f();
    
    void g();
    
    void h(final int p0);
    
    void i(final int p0, final String p1);
    
    boolean i();
    
    void j();
    
    void k(final int p0);
    
    void l(final int p0);
    
    boolean l();
    
    void m();
    
    boolean m(final int p0);
    
    void n(final Activity p0);
    
    void o(final int p0);
    
    String p(final int p0);
    
    void q(final int p0);
    
    boolean r(final String p0, final boolean p1);
    
    double s(final int p0);
    
    void t();
    
    void u(final IUnityMessenger p0);
    
    void v(final int p0);
    
    void w(final int p0, final String p1, final String p2, final String p3);
    
    void x(final int p0);
    
    boolean y();
    
    boolean z(final int p0, final String p1);
}
