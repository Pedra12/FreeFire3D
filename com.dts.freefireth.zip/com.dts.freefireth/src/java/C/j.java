package c;

import a.e1;
import com.google.gson.Gson;
import a.e;
import com.garena.unity.webview.UnityWebViewActivity;
import a.c;
import android.webkit.ValueCallback;

public final class j implements ValueCallback
{
    public final c a;
    public final UnityWebViewActivity b;
    
    public j(final UnityWebViewActivity b, final c a) {
        this.b = b;
        this.a = a;
    }
    
    public final void onReceiveValue(final Object o) {
        final String value = (String)o;
        try {
            final String callback = this.a.callback;
            if (callback != null && callback.length() > 0) {
                final UnityWebViewActivity b = this.b;
                final int webViewId = this.a.webViewId;
                final StringBuilder sb = new StringBuilder("@evaluateJavascript.ValueCallback(): ");
                sb.append(value);
                final String string = sb.toString();
                final boolean w = UnityWebViewActivity.w;
                b.k(webViewId, string);
                final UnityWebViewActivity b2 = this.b;
                final c a = this.a;
                final int webViewId2 = a.webViewId;
                final String callback2 = a.callback;
                final String id = a.id;
                final Gson f = b2.f;
                final e e = new e();
                e.value = value;
                e.callback = callback2;
                e.id = id;
                b2.o(b2.c(webViewId2, "OnJavaScriptResult", f.toJson((Object)e)));
            }
        }
        finally {
            final UnityWebViewActivity b3 = this.b;
            final int webViewId3 = this.a.webViewId;
            final boolean w2 = UnityWebViewActivity.w;
            final e1 a2 = b3.a(webViewId3);
            final Throwable t;
            if (a2 != null) {
                if (a2.j) {
                    b3.l(webViewId3, "@evaluateJavascript.ValueCallback()", t);
                }
            }
            final UnityWebViewActivity b4 = this.b;
            final int webViewId4 = this.a.webViewId;
            final String message = t.getMessage();
            final c a3 = this.a;
            final String callback3 = a3.callback;
            final String id2 = a3.id;
            final Gson f2 = b4.f;
            final e e2 = new e();
            e2.error = message;
            e2.callback = callback3;
            e2.id = id2;
            b4.o(b4.c(webViewId4, "OnJavaScriptResult", f2.toJson((Object)e2)));
        }
    }
}
