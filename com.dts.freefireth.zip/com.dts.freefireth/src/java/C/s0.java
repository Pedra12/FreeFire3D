package c;

import android.view.View;
import android.app.Activity;
import android.util.Log;
import android.view.MotionEvent;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public final class s0 extends BroadcastReceiver
{
    public final E0 a;
    
    public s0(final E0 a) {
        this.a = a;
    }
    
    public final void onReceive(final Context context, final Intent intent) {
        Label_0424: {
            Activity b;
            try {
                intent.setExtrasClassLoader(MotionEvent.class.getClassLoader());
                P0.F("recv by UnityPlayerActivity", intent);
                b = this.a.a.b;
                if (b == null) {
                    Log.w("UWVActivityProxy", "on_touch: UnityPlayerActivity is null");
                    return;
                }
            }
            finally {
                break Label_0424;
            }
            final MotionEvent motionEvent = (MotionEvent)intent.getParcelableExtra("motion_event");
            if (motionEvent == null) {
                Log.w("UWVActivityProxy", "on_touch: motionEvent is null");
                return;
            }
            final Q i = this.a.a.i;
            MotionEvent motionEvent2 = motionEvent;
            if (i != null) {
                motionEvent2 = motionEvent;
                if (i.b) {
                    View rootView;
                    if (b.getWindow() != null && b.getWindow().getDecorView() != null) {
                        rootView = b.getWindow().getDecorView().getRootView();
                    }
                    else {
                        rootView = null;
                    }
                    final int intExtra = intent.getIntExtra("uwv_width", 0);
                    final int intExtra2 = intent.getIntExtra("uwv_height", 0);
                    int n;
                    if (rootView == null) {
                        n = 0;
                    }
                    else {
                        n = rootView.getWidth();
                        if (n <= 0) {
                            n = rootView.getMeasuredWidth();
                        }
                    }
                    int n2;
                    if (rootView == null) {
                        n2 = 0;
                    }
                    else {
                        n2 = rootView.getHeight();
                        if (n2 <= 0) {
                            n2 = rootView.getMeasuredHeight();
                        }
                    }
                    if (P0.p) {
                        if (rootView != null) {
                            Log.i("UWVActivityProxy", String.format("on_touch: scaling motion event: uwv w:%d, h:%d; unity w:%d, h:%d", new Object[] { intExtra, intExtra2, n, n2 }));
                        }
                        else {
                            Log.w("UWVActivityProxy", "on_touch: scaling motion event but view is null!!!");
                        }
                    }
                    motionEvent2 = motionEvent;
                    if (intExtra > 0) {
                        motionEvent2 = motionEvent;
                        if (intExtra2 > 0) {
                            motionEvent2 = motionEvent;
                            if (n > 0) {
                                motionEvent2 = motionEvent;
                                if (n2 > 0) {
                                    final float n3 = n / (float)intExtra;
                                    final float n4 = n2 / (float)intExtra2;
                                    motionEvent2 = motionEvent;
                                    if (n3 > 0.0f) {
                                        if (n4 <= 0.0f) {
                                            motionEvent2 = motionEvent;
                                        }
                                        else if (Math.abs(n3 - 1.0f) < 1.0E-4f && Math.abs(n4 - 1.0f) < 1.0E-4f) {
                                            motionEvent2 = motionEvent;
                                        }
                                        else {
                                            try {
                                                P0.a(motionEvent, n3, n4);
                                            }
                                            finally {
                                                final Throwable t;
                                                Log.w("UWVActivityProxy", "scaleMotionEvent", t);
                                                motionEvent2 = motionEvent;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            b.onTouchEvent(motionEvent2);
            return;
        }
        final Throwable t2;
        Log.w("UWVActivityProxy", "on_touch", t2);
    }
}
