package c;

import android.widget.FrameLayout;
import android.app.Activity;
import a.c;
import a.b1;
import a.Z0;
import a.e1;
import com.garena.unity.webview.UnityWebViewActivity;

public final class d0 extends T0
{
    public final UnityWebViewActivity b;
    
    public d0(final UnityWebViewActivity b, final int n) {
        this.b = b;
        super(n);
    }
    
    @Override
    public final e1 a() {
        return this.b.a(super.a);
    }
    
    @Override
    public final void b(final int n, final Z0 z0) {
        final String json = this.b.f.toJson((Object)z0);
        final UnityWebViewActivity b = this.b;
        b.o(b.c(n, "OnReceivedError", json));
    }
    
    @Override
    public final void c(final int n, final b1 b1) {
        final String json = this.b.f.toJson((Object)b1);
        final UnityWebViewActivity b2 = this.b;
        b2.o(b2.c(n, "OnReceivedHttpError", json));
    }
    
    @Override
    public final void d(final c c) {
        final UnityWebViewActivity b = this.b;
        final boolean w = UnityWebViewActivity.w;
        b.d(c);
    }
    
    @Override
    public final void e(final e1 e1) {
        final UnityWebViewActivity b = this.b;
        final int a = super.a;
        final boolean w = UnityWebViewActivity.w;
        b.i(a, e1);
    }
    
    @Override
    public final void f(final String s) {
        final UnityWebViewActivity b = this.b;
        final int a = super.a;
        final boolean w = UnityWebViewActivity.w;
        b.o(b.c(a, "OnWebViewMessage_Android", s));
    }
    
    @Override
    public final void g(final String s, final Throwable t) {
        final UnityWebViewActivity b = this.b;
        final int a = super.a;
        final boolean w = UnityWebViewActivity.w;
        b.l(a, s, t);
    }
    
    @Override
    public final Activity h() {
        return (Activity)this.b;
    }
    
    @Override
    public final void i(final String s) {
        final UnityWebViewActivity b = this.b;
        final int a = super.a;
        final boolean w = UnityWebViewActivity.w;
        b.k(a, s);
    }
    
    @Override
    public final void j(final String s, final Throwable t) {
        final UnityWebViewActivity b = this.b;
        final int a = super.a;
        final boolean w = UnityWebViewActivity.w;
        final e1 a2 = b.a(a);
        if (a2 != null) {
            if (a2.j) {
                b.l(a, s, t);
            }
        }
    }
    
    @Override
    public final FrameLayout k() {
        return (FrameLayout)((Activity)this.b).getWindow().getDecorView().getRootView();
    }
}
