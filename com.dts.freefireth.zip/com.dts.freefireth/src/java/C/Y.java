package c;

import android.app.Activity;
import android.util.Log;
import android.view.WindowInsets;
import android.view.View;
import com.garena.unity.webview.UnityWebViewActivity;
import android.view.View$OnApplyWindowInsetsListener;

public final class y implements View$OnApplyWindowInsetsListener
{
    public final UnityWebViewActivity a;
    
    public y(final UnityWebViewActivity a) {
        this.a = a;
    }
    
    public final WindowInsets onApplyWindowInsets(final View view, final WindowInsets windowInsets) {
        final boolean a = p.a(windowInsets, o.a());
        if (UnityWebViewActivity.y) {
            final StringBuilder sb = new StringBuilder("onApplyWindowInsets: insets.isVisible(ime): ");
            sb.append(a);
            Log.i("UWVActivity", sb.toString());
        }
        if (!a) {
            this.a.g = r.a(windowInsets, q.a());
            if (UnityWebViewActivity.y) {
                Log.i("UWVActivity", String.format("onApplyWindowInsets: _SystemBarsWindowInsets: <: %d, >: %d, ^: %d, _: %d", new Object[] { s.a(this.a.g), t.a(this.a.g), u.a(this.a.g), v.a(this.a.g) }));
            }
            if (((Activity)this.a).hasWindowFocus()) {
                this.a.C();
            }
        }
        return w.a();
    }
}
