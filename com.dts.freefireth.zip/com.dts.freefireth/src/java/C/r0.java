package c;

import a.e;
import android.os.Parcel;
import android.os.Parcelable$Creator;

public final class r0 implements Parcelable$Creator
{
    public final Object createFromParcel(final Parcel parcel) {
        return new e(parcel);
    }
    
    public final Object[] newArray(final int n) {
        return new e[n];
    }
}
