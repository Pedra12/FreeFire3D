package c;

import a.e1;
import android.os.Parcel;
import android.os.Parcelable$Creator;

public final class q0 implements Parcelable$Creator
{
    public final Object createFromParcel(final Parcel parcel) {
        return new e1(parcel);
    }
    
    public final Object[] newArray(final int n) {
        return new e1[n];
    }
}
