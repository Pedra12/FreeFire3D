package c;

public final class e implements Runnable
{
    public final int a;
    public final String b;
    public final String c;
    public final String d;
    public final a0 e;
    
    public e(final a0 e, final int a, final String b, final String c, final String d) {
        this.e = e;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public final void run() {
        a0.H(this.e, this.a, this.b, this.c, this.d);
    }
}
