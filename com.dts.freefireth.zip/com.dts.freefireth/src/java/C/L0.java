package c;

import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public final class l0 extends BroadcastReceiver
{
    public final E0 a;
    
    public l0(final E0 a) {
        this.a = a;
    }
    
    public final void onReceive(final Context context, final Intent intent) {
        P0.F("recv by UnityPlayerActivity", intent);
        P0.E(this.a.a, intent.getIntExtra("activity_pid", 0));
    }
}
