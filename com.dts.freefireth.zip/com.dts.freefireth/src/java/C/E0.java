package c;

import a.e1;

public final class e0 implements Runnable
{
    public final g0 a;
    
    public e0(final g0 a) {
        this.a = a;
    }
    
    public final void run() {
        final g0 a = this.a;
        final e1 a2 = a.b.a(a.a);
        if (a2 != null) {
            final D0 x = a2.x;
            if (x != null) {
                x.onHideCustomView();
            }
        }
    }
}
