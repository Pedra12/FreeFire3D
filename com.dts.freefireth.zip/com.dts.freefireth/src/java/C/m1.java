package c;

import android.view.ViewGroup;
import android.view.View;
import android.widget.FrameLayout;
import android.webkit.WebView;
import a.e1;
import android.content.Intent;
import com.garena.unity.webview.UnityWebViewActivity;

public final class m1 extends U
{
    public final h a;
    
    public m1(final h a) {
        this.a = a;
        final UnityWebViewActivity a2 = a.a;
    }
    
    @Override
    public final Intent a(Intent a) {
        UnityWebViewActivity.s("execute intent", a);
        final int intExtra = a.getIntExtra("web_view_id", -1);
        if (intExtra < 0) {
            return null;
        }
        a = (Intent)this.a.a;
        ((UnityWebViewActivity)a).i(intExtra, (e1)null);
        final WebView webView = (WebView)((UnityWebViewActivity)a).b.get((Object)intExtra);
        if (webView != null) {
            try {
                ((UnityWebViewActivity)a).b.remove((Object)intExtra);
                ((ViewGroup)((View)webView).getParent()).removeView((View)webView);
                webView.destroy();
            }
            finally {
                final Throwable t;
                ((UnityWebViewActivity)a).l(intExtra, "@_close()", t);
            }
        }
        return null;
    }
}
