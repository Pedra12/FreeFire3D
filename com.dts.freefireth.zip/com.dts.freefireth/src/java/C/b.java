package c;

import android.webkit.WebView;
import android.content.Intent;
import com.garena.unity.webview.UnityWebViewActivity;

public final class b extends U
{
    public final h a;
    
    public b(final h a) {
        this.a = a;
        final UnityWebViewActivity a2 = a.a;
    }
    
    @Override
    public final Intent a(Intent a) {
        UnityWebViewActivity.s("execute intent", a);
        final int intExtra = a.getIntExtra("web_view_id", -1);
        if (intExtra < 0) {
            return null;
        }
        a = (Intent)this.a.a;
        final WebView webView = (WebView)((UnityWebViewActivity)a).b.get((Object)intExtra);
        if (webView != null) {
            try {
                webView.reload();
            }
            finally {
                final Throwable t;
                ((UnityWebViewActivity)a).l(intExtra, "@_reload()", t);
            }
        }
        return null;
    }
}
