package c;

import a.c;
import android.os.Parcel;
import android.os.Parcelable$Creator;

public final class m0 implements Parcelable$Creator
{
    public final Object createFromParcel(final Parcel parcel) {
        return new c(parcel);
    }
    
    public final Object[] newArray(final int n) {
        return new c[n];
    }
}
