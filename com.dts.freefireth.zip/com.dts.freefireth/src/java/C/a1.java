package c;

import a.e1;
import android.webkit.WebView;
import android.content.Intent;
import com.garena.unity.webview.UnityWebViewActivity;

public final class a1 extends U
{
    public final h a;
    
    public a1(final h a) {
        this.a = a;
        final UnityWebViewActivity a2 = a.a;
    }
    
    @Override
    public final Intent a(Intent url) {
        UnityWebViewActivity.s("execute intent", url);
        final int intExtra = url.getIntExtra("web_view_id", -1);
        final Intent intent = url = (Intent)"";
        if (intExtra >= 0) {
            final WebView webView = (WebView)this.a.a.b.get((Object)intExtra);
            url = intent;
            if (webView != null) {
                url = intent;
                try {
                    final Object h = url = (Intent)webView.getUrl();
                    final e1 a = this.a.a.a(intExtra);
                    url = (Intent)h;
                    if (a != null) {
                        url = (Intent)h;
                        a.h = (String)h;
                        url = (Intent)h;
                        this.a.a.d.put((Object)intExtra, (Object)a);
                        url = (Intent)h;
                    }
                }
                finally {
                    final Throwable t;
                    this.a.a.l(intExtra, "@fetchWebViewURL()", t);
                }
            }
        }
        return this.a.a.c(intExtra, "OnFetchWebViewURLResult", (String)url);
    }
}
