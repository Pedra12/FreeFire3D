package c;

import com.google.gson.annotations.SerializedName;

public final class o0
{
    @SerializedName("AllowAudioCapture")
    public boolean AllowAudioCapture;
    @SerializedName("AllowReadSystemCalendar")
    public boolean AllowReadSystemCalendar;
    @SerializedName("AllowVideoCapture")
    public boolean AllowVideoCapture;
    @SerializedName("AllowWriteSystemCalendar")
    public boolean AllowWriteSystemCalendar;
    @SerializedName("AutoPlayMedia")
    public boolean AutoPlayMedia;
    @SerializedName("DeferredDisplay")
    public boolean DeferredDisplay;
    @SerializedName("ExtraLog")
    public boolean ExtraLog;
    @SerializedName("HardwareAcceleration")
    public boolean HardwareAcceleration;
    @SerializedName("Scaling")
    public boolean Scaling;
    @SerializedName("UnitySendMessageGameObjectName")
    public String UnitySendMessageGameObjectName;
    @SerializedName("UseCookie")
    public boolean UseCookie;
    
    public o0() {
        this.Scaling = false;
        this.UseCookie = true;
        this.DeferredDisplay = false;
        this.ExtraLog = false;
        this.AutoPlayMedia = true;
        this.HardwareAcceleration = true;
        this.AllowAudioCapture = true;
        this.AllowVideoCapture = true;
        this.AllowReadSystemCalendar = false;
        this.AllowWriteSystemCalendar = false;
    }
}
