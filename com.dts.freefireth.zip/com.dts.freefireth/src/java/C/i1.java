package c;

import android.content.Intent;
import com.garena.unity.webview.UnityWebViewActivity;

public final class i1 extends U
{
    public final h a;
    
    public i1(final h a) {
        this.a = a;
        final UnityWebViewActivity a2 = a.a;
    }
    
    @Override
    public final Intent a(final Intent intent) {
        UnityWebViewActivity.s("execute intent", intent);
        this.a.a.h();
        return null;
    }
}
