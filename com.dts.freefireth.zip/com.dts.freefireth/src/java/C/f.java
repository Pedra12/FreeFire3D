package c;

import android.content.Intent;
import com.garena.unity.webview.UnityWebViewActivity;

public final class f extends U
{
    public final h a;
    
    public f(final h a) {
        this.a = a;
        final UnityWebViewActivity a2 = a.a;
    }
    
    @Override
    public final Intent a(final Intent intent) {
        UnityWebViewActivity.s("execute intent", intent);
        final int intExtra = intent.getIntExtra("web_view_id", -1);
        if (intExtra < 0) {
            return null;
        }
        UnityWebViewActivity.p(this.a.a, intExtra);
        return null;
    }
}
