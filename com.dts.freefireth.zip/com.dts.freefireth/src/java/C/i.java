package c;

import android.os.Build$VERSION;
import android.webkit.WebView;

public final class i implements Runnable
{
    public final int a;
    public final String b;
    public final a0 c;
    
    public i(final a0 c, final int a, final String b) {
        this.c = c;
        this.a = a;
        this.b = b;
    }
    
    public final void run() {
        final a0 c = this.c;
        final int a = this.a;
        synchronized (c) {
            final WebView webView = (WebView)c.d.get((Object)a);
            monitorexit(c);
            if (webView == null) {
                this.c.f(this.a, "OnCaptureScreenshotFailure", "WebView is unavailable");
                return;
            }
            if (!this.c.f.add((Object)this.a)) {
                this.c.f(this.a, "OnCaptureScreenshotFailure", "Screenshot capture is already in progress");
                return;
            }
            if (a0.l != 0 && Build$VERSION.SDK_INT >= 26) {
                a0.G(this.c, this.a, this.b, webView);
                return;
            }
            this.c.e(this.a, this.b, webView);
        }
    }
}
