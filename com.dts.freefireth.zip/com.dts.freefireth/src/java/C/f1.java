package c;

import android.view.View;
import android.webkit.WebView;
import a.e1;

public final class f1 implements Runnable
{
    public final int a;
    public final a0 b;
    
    public f1(final a0 b, final int a) {
        this.b = b;
        this.a = a;
    }
    
    public final void run() {
        final a0 b = this.b;
        final int a = this.a;
        synchronized (b) {
            final e1 e1 = (e1)b.e.get((Object)a);
            monitorexit(b);
            if (e1 != null) {
                e1.e = false;
                if (!e1.d) {
                    final WebView q = this.b.Q(this.a);
                    if (q != null) {
                        try {
                            q.onResume();
                            q.resumeTimers();
                        }
                        finally {
                            final Throwable t;
                            this.b.E(this.a, "@show()", t);
                        }
                        ((View)this.b.b).setVisibility(0);
                        ((View)q).setVisibility(0);
                        ((View)q).requestFocus();
                    }
                }
            }
        }
    }
}
