package c;

import android.content.Intent;
import com.garena.unity.webview.UnityWebViewActivity;

public final class g1 extends U
{
    public final h a;
    
    public g1(final h a) {
        this.a = a;
        final UnityWebViewActivity a2 = a.a;
    }
    
    @Override
    public final Intent a(final Intent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     2: aload_1        
        //     3: invokestatic    com/garena/unity/webview/UnityWebViewActivity.s:(Ljava/lang/String;Landroid/content/Intent;)V
        //     6: invokestatic    android/webkit/CookieManager.getInstance:()Landroid/webkit/CookieManager;
        //     9: astore_1       
        //    10: aload_1        
        //    11: aconst_null    
        //    12: invokevirtual   android/webkit/CookieManager.removeSessionCookies:(Landroid/webkit/ValueCallback;)V
        //    15: aload_1        
        //    16: aconst_null    
        //    17: invokevirtual   android/webkit/CookieManager.removeAllCookies:(Landroid/webkit/ValueCallback;)V
        //    20: aload_1        
        //    21: invokevirtual   android/webkit/CookieManager.flush:()V
        //    24: new             Landroid/webkit/WebView;
        //    27: astore_1       
        //    28: aload_1        
        //    29: aload_0        
        //    30: getfield        c/g1.a:Lc/h;
        //    33: getfield        c/h.a:Lcom/garena/unity/webview/UnityWebViewActivity;
        //    36: invokespecial   android/webkit/WebView.<init>:(Landroid/content/Context;)V
        //    39: aload_1        
        //    40: invokevirtual   android/webkit/WebView.clearFormData:()V
        //    43: aload_1        
        //    44: invokevirtual   android/webkit/WebView.clearHistory:()V
        //    47: aload_1        
        //    48: invokevirtual   android/webkit/WebView.clearMatches:()V
        //    51: aload_1        
        //    52: iconst_1       
        //    53: invokevirtual   android/webkit/WebView.clearCache:(Z)V
        //    56: aload_1        
        //    57: invokevirtual   android/webkit/WebView.destroy:()V
        //    60: invokestatic    android/webkit/WebStorage.getInstance:()Landroid/webkit/WebStorage;
        //    63: invokevirtual   android/webkit/WebStorage.deleteAllData:()V
        //    66: aload_0        
        //    67: getfield        c/g1.a:Lc/h;
        //    70: getfield        c/h.a:Lcom/garena/unity/webview/UnityWebViewActivity;
        //    73: ldc             "clear_all_done"
        //    75: invokevirtual   com/garena/unity/webview/UnityWebViewActivity.f:(Ljava/lang/String;)Landroid/content/Intent;
        //    78: areturn        
        //    79: astore_1       
        //    80: goto            24
        //    83: astore_1       
        //    84: goto            60
        //    87: astore_1       
        //    88: goto            66
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  6      24     79     83     Any
        //  24     60     83     87     Any
        //  60     66     87     91     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 45 out of bounds for length 45
        //     at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:100)
        //     at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:106)
        //     at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:302)
        //     at java.util.Objects.checkIndex(Objects.java:371)
        //     at java.util.ArrayList.get(ArrayList.java:435)
        //     at q5.g.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at q5.g.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:2125)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:21)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        //     at java.lang.Thread.run(Thread.java:1571)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
