package c;

import android.webkit.WebView;

public final class b1 implements Runnable
{
    public final int a;
    public final a0 b;
    
    public b1(final a0 b, final int a) {
        this.b = b;
        this.a = a;
    }
    
    public final void run() {
        final a0 b = this.b;
        final int a = this.a;
        synchronized (b) {
            final WebView webView = (WebView)b.d.get((Object)a);
            monitorexit(b);
            if (webView != null && webView.canGoForward()) {
                try {
                    webView.goForward();
                }
                finally {
                    final Throwable t;
                    this.b.E(this.a, "@_goForward()", t);
                }
            }
        }
    }
}
