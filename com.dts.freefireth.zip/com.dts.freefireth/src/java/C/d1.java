package c;

import a.e1;
import android.webkit.WebView;

public final class d1 implements Runnable
{
    public final int a;
    public final a0 b;
    
    public d1(final a0 b, final int a) {
        this.b = b;
        this.a = a;
    }
    
    public final void run() {
        final a0 b = this.b;
        final int a = this.a;
        synchronized (b) {
            final WebView webView = (WebView)b.d.get((Object)a);
            monitorexit(b);
            if (webView == null) {
                return;
            }
            final String url = webView.getUrl();
            final e1 p = this.b.P(this.a);
            if (p != null) {
                p.h = url;
                this.b.e.put((Object)this.a, (Object)p);
            }
            this.b.f(this.a, "OnFetchWebViewURLResult", webView.getUrl());
        }
    }
}
