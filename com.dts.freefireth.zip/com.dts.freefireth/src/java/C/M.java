package c;

public final class m implements Runnable
{
    public final a0 a;
    
    public m(final a0 a) {
        this.a = a;
    }
    
    public final void run() {
        a0.K(this.a);
    }
}
