package c;

import android.webkit.WebView;

public final class j1 implements Runnable
{
    public final int a;
    public final a0 b;
    
    public j1(final a0 b, final int a) {
        this.b = b;
        this.a = a;
    }
    
    public final void run() {
        String userAgentString = "";
        final a0 b = this.b;
        final int a = this.a;
        synchronized (b) {
            final WebView webView = (WebView)b.d.get((Object)a);
            monitorexit(b);
            if (webView != null) {
                userAgentString = webView.getSettings().getUserAgentString();
            }
            this.b.f(this.a, "OnGetUserAgentString", userAgentString);
        }
    }
}
