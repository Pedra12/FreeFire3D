package c;

import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public final class i0 extends BroadcastReceiver
{
    public final E0 a;
    
    public i0(final E0 a) {
        this.a = a;
    }
    
    public final void onReceive(final Context context, final Intent intent) {
        P0.F("recv by UnityPlayerActivity", intent);
        this.a.a.J(-1, "ping_resp");
    }
}
