package c;

import android.view.KeyEvent;

public final class z0 implements Runnable
{
    public final C0 a;
    
    public z0(final C0 a) {
        this.a = a;
    }
    
    public final void run() {
        this.a.a.a.b.dispatchKeyEvent(new KeyEvent(0, 4));
        this.a.a.a.b.dispatchKeyEvent(new KeyEvent(1, 4));
    }
}
