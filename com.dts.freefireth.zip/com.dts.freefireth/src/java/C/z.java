package c;

public final class z implements Runnable
{
    public final a0 a;
    
    public z(final a0 a) {
        this.a = a;
    }
    
    public final void run() {
        a0.N(this.a);
    }
}
