package c;

import android.app.Activity;
import android.content.res.Configuration;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public final class t0 extends BroadcastReceiver
{
    public final E0 a;
    
    public t0(final E0 a) {
        this.a = a;
    }
    
    public final void onReceive(final Context context, final Intent intent) {
        intent.setExtrasClassLoader(Configuration.class.getClassLoader());
        P0.F("recv by UnityPlayerActivity", intent);
        final Configuration configuration = (Configuration)intent.getParcelableExtra("configuration");
        final Activity b = this.a.a.b;
        if (b != null) {
            b.onConfigurationChanged(configuration);
        }
    }
}
