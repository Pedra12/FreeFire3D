package c;

import com.garena.unity.webview.WebViewManager;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public final class n0 extends BroadcastReceiver
{
    public final E0 a;
    
    public n0(final E0 a) {
        this.a = a;
    }
    
    public final void onReceive(final Context context, final Intent intent) {
        this.a.a.h = false;
        P0.F("recv by UnityPlayerActivity", intent);
        final boolean booleanExtra = intent.getBooleanExtra("return_value", false);
        final StringBuilder sb = new StringBuilder();
        sb.append(booleanExtra);
        sb.append("");
        WebViewManager.a("testResult", sb.toString());
    }
}
