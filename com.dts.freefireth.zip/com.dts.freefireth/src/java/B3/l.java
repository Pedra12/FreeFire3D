package b3;

import f3.a;
import Z2.f;
import Z2.i;

public abstract class l
{
    public static void a(final i i, final f f) {
        if (i instanceof s) {
            u.c().e().l(((s)i).d().f(f), 1);
            return;
        }
        a.g("ForcedSender", "Expected instance of `TransportImpl`, got `%s`.", (Object)i);
    }
}
