package b3;

public interface f
{
    byte[] getExtras();
    
    String getName();
}
