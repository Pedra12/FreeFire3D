package b3;

import d3.d;
import java.util.concurrent.Executor;
import d3.b;

public final class k implements b
{
    public static k a() {
        return a.a;
    }
    
    public static Executor b() {
        return (Executor)d.d((Object)j.a());
    }
    
    public Executor c() {
        return b();
    }
    
    private abstract static final class a
    {
        private static final k a;
        
        static {
            a = new k();
        }
    }
}
