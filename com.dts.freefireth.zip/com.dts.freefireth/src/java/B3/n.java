package b3;

import f3.a;
import java.util.concurrent.Executor;

class n implements Executor
{
    private final Executor a;
    
    n(final Executor a) {
        this.a = a;
    }
    
    public void execute(final Runnable runnable) {
        this.a.execute((Runnable)new a(runnable));
    }
    
    static class a implements Runnable
    {
        private final Runnable a;
        
        a(final Runnable a) {
            this.a = a;
        }
        
        public void run() {
            try {
                this.a.run();
            }
            catch (final Exception ex) {
                f3.a.d("Executor", "Background execution failure.", (Throwable)ex);
            }
        }
    }
}
