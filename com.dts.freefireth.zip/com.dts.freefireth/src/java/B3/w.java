package b3;

import i3.v;
import i3.r;
import h3.e;
import r7.a;
import d3.b;

public final class w implements b
{
    private final a a;
    private final a b;
    private final a c;
    private final a d;
    private final a e;
    
    public w(final a a, final a b, final a c, final a d, final a e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    public static w a(final a a, final a a2, final a a3, final a a4, final a a5) {
        return new w(a, a2, a3, a4, a5);
    }
    
    public static u c(final l3.a a, final l3.a a2, final e e, final r r, final v v) {
        return new u(a, a2, e, r, v);
    }
    
    public u b() {
        return c((l3.a)this.a.get(), (l3.a)this.b.get(), (e)this.c.get(), (r)this.d.get(), (v)this.e.get());
    }
}
