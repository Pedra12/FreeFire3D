package b3;

import android.content.Context;
import j3.d;
import java.io.Closeable;

abstract class v implements Closeable, AutoCloseable
{
    abstract d a();
    
    abstract u b();
    
    public void close() {
        ((Closeable)this.a()).close();
    }
    
    interface a
    {
        a a(final Context p0);
        
        v build();
    }
}
