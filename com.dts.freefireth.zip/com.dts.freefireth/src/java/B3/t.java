package b3;

import Z2.j;

interface t
{
    void a(final o p0, final j p1);
}
