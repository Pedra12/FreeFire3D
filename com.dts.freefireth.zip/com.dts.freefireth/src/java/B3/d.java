package b3;

import java.util.Arrays;
import Z2.f;

final class d extends p
{
    private final String a;
    private final byte[] b;
    private final f c;
    
    private d(final String a, final byte[] b, final f c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    @Override
    public String b() {
        return this.a;
    }
    
    @Override
    public byte[] c() {
        return this.b;
    }
    
    @Override
    public f d() {
        return this.c;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof p) {
            final p p = (p)o;
            if (this.a.equals((Object)p.b())) {
                final byte[] b = this.b;
                byte[] array;
                if (p instanceof d) {
                    array = ((d)p).b;
                }
                else {
                    array = p.c();
                }
                if (Arrays.equals(b, array) && this.c.equals(p.d())) {
                    return true;
                }
            }
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return ((this.a.hashCode() ^ 0xF4243) * 1000003 ^ Arrays.hashCode(this.b)) * 1000003 ^ this.c.hashCode();
    }
    
    static final class b extends a
    {
        private String a;
        private byte[] b;
        private f c;
        
        @Override
        public p a() {
            final String a = this.a;
            String string = "";
            if (a == null) {
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(" backendName");
                string = sb.toString();
            }
            String string2 = string;
            if (this.c == null) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(string);
                sb2.append(" priority");
                string2 = sb2.toString();
            }
            if (string2.isEmpty()) {
                return new d(this.a, this.b, this.c, null);
            }
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("Missing required properties:");
            sb3.append(string2);
            throw new IllegalStateException(sb3.toString());
        }
        
        @Override
        public a b(final String a) {
            if (a != null) {
                this.a = a;
                return this;
            }
            throw new NullPointerException("Null backendName");
        }
        
        @Override
        public a c(final byte[] b) {
            this.b = b;
            return this;
        }
        
        @Override
        public a d(final f c) {
            if (c != null) {
                this.c = c;
                return this;
            }
            throw new NullPointerException("Null priority");
        }
    }
}
