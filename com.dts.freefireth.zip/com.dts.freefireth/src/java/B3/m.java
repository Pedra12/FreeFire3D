package b3;

import J5.h;

public abstract class m
{
    private static final h a;
    
    static {
        a = h.a().d(b3.a.a).c();
    }
    
    public static byte[] a(final Object o) {
        return m.a.c(o);
    }
}
