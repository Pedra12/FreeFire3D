package b3;

import Z2.h;
import Z2.d;

abstract class o
{
    public static a a() {
        return (a)new c.b();
    }
    
    public abstract Z2.c b();
    
    abstract d c();
    
    public byte[] d() {
        return (byte[])this.e().apply(this.c().c());
    }
    
    abstract h e();
    
    public abstract p f();
    
    public abstract String g();
    
    public abstract static class a
    {
        public abstract o a();
        
        abstract a b(final Z2.c p0);
        
        abstract a c(final d p0);
        
        abstract a d(final h p0);
        
        public abstract a e(final p p0);
        
        public abstract a f(final String p0);
    }
}
