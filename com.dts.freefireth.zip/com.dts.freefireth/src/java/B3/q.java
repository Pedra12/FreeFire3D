package b3;

import Z2.i;
import Z2.h;
import Z2.c;
import java.util.Set;
import com.google.android.datatransport.TransportFactory;

final class q implements TransportFactory
{
    private final Set a;
    private final p b;
    private final t c;
    
    q(final Set a, final p b, final t c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public i a(final String s, final Class clazz, final c c, final h h) {
        if (this.a.contains((Object)c)) {
            return (i)new s(this.b, s, c, h, this.c);
        }
        throw new IllegalArgumentException(String.format("%s is not supported byt this factory. Supported encodings are: %s.", new Object[] { c, this.a }));
    }
}
