package b3;

import java.util.Arrays;
import java.util.Map;

final class b extends i
{
    private final String a;
    private final Integer b;
    private final h c;
    private final long d;
    private final long e;
    private final Map f;
    private final Integer g;
    private final String h;
    private final byte[] i;
    private final byte[] j;
    
    private b(final String a, final Integer b, final h c, final long d, final long e, final Map f, final Integer g, final String h, final byte[] i, final byte[] j) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
        this.j = j;
    }
    
    @Override
    protected Map c() {
        return this.f;
    }
    
    @Override
    public Integer d() {
        return this.b;
    }
    
    @Override
    public h e() {
        return this.c;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof i) {
            final i i = (i)o;
            if (this.a.equals((Object)i.n())) {
                final Integer b = this.b;
                if (b == null) {
                    if (i.d() != null) {
                        return false;
                    }
                }
                else if (!b.equals((Object)i.d())) {
                    return false;
                }
                if (this.c.equals(i.e()) && this.d == i.f() && this.e == i.o() && this.f.equals((Object)i.c())) {
                    final Integer g = this.g;
                    if (g == null) {
                        if (i.l() != null) {
                            return false;
                        }
                    }
                    else if (!g.equals((Object)i.l())) {
                        return false;
                    }
                    final String h = this.h;
                    if (h == null) {
                        if (i.m() != null) {
                            return false;
                        }
                    }
                    else if (!h.equals((Object)i.m())) {
                        return false;
                    }
                    final byte[] j = this.i;
                    final boolean b2 = i instanceof b;
                    byte[] array;
                    if (b2) {
                        array = ((b)i).i;
                    }
                    else {
                        array = i.g();
                    }
                    if (Arrays.equals(j, array)) {
                        final byte[] k = this.j;
                        byte[] array2;
                        if (b2) {
                            array2 = ((b)i).j;
                        }
                        else {
                            array2 = i.h();
                        }
                        if (Arrays.equals(k, array2)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    
    @Override
    public long f() {
        return this.d;
    }
    
    @Override
    public byte[] g() {
        return this.i;
    }
    
    @Override
    public byte[] h() {
        return this.j;
    }
    
    @Override
    public int hashCode() {
        final int hashCode = this.a.hashCode();
        final Integer b = this.b;
        int hashCode2 = 0;
        int hashCode3;
        if (b == null) {
            hashCode3 = 0;
        }
        else {
            hashCode3 = b.hashCode();
        }
        final int hashCode4 = this.c.hashCode();
        final long d = this.d;
        final int n = (int)(d ^ d >>> 32);
        final long e = this.e;
        final int n2 = (int)(e ^ e >>> 32);
        final int hashCode5 = this.f.hashCode();
        final Integer g = this.g;
        int hashCode6;
        if (g == null) {
            hashCode6 = 0;
        }
        else {
            hashCode6 = g.hashCode();
        }
        final String h = this.h;
        if (h != null) {
            hashCode2 = h.hashCode();
        }
        return (((((((((hashCode ^ 0xF4243) * 1000003 ^ hashCode3) * 1000003 ^ hashCode4) * 1000003 ^ n) * 1000003 ^ n2) * 1000003 ^ hashCode5) * 1000003 ^ hashCode6) * 1000003 ^ hashCode2) * 1000003 ^ Arrays.hashCode(this.i)) * 1000003 ^ Arrays.hashCode(this.j);
    }
    
    @Override
    public Integer l() {
        return this.g;
    }
    
    @Override
    public String m() {
        return this.h;
    }
    
    @Override
    public String n() {
        return this.a;
    }
    
    @Override
    public long o() {
        return this.e;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("EventInternal{transportName=");
        sb.append(this.a);
        sb.append(", code=");
        sb.append((Object)this.b);
        sb.append(", encodedPayload=");
        sb.append((Object)this.c);
        sb.append(", eventMillis=");
        sb.append(this.d);
        sb.append(", uptimeMillis=");
        sb.append(this.e);
        sb.append(", autoMetadata=");
        sb.append((Object)this.f);
        sb.append(", productId=");
        sb.append((Object)this.g);
        sb.append(", pseudonymousId=");
        sb.append(this.h);
        sb.append(", experimentIdsClear=");
        sb.append(Arrays.toString(this.i));
        sb.append(", experimentIdsEncrypted=");
        sb.append(Arrays.toString(this.j));
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends a
    {
        private String a;
        private Integer b;
        private h c;
        private Long d;
        private Long e;
        private Map f;
        private Integer g;
        private String h;
        private byte[] i;
        private byte[] j;
        
        @Override
        public i d() {
            final String a = this.a;
            String string = "";
            if (a == null) {
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(" transportName");
                string = sb.toString();
            }
            String string2 = string;
            if (this.c == null) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(string);
                sb2.append(" encodedPayload");
                string2 = sb2.toString();
            }
            String string3 = string2;
            if (this.d == null) {
                final StringBuilder sb3 = new StringBuilder();
                sb3.append(string2);
                sb3.append(" eventMillis");
                string3 = sb3.toString();
            }
            String string4 = string3;
            if (this.e == null) {
                final StringBuilder sb4 = new StringBuilder();
                sb4.append(string3);
                sb4.append(" uptimeMillis");
                string4 = sb4.toString();
            }
            String string5 = string4;
            if (this.f == null) {
                final StringBuilder sb5 = new StringBuilder();
                sb5.append(string4);
                sb5.append(" autoMetadata");
                string5 = sb5.toString();
            }
            if (string5.isEmpty()) {
                return new b3.b(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, null);
            }
            final StringBuilder sb6 = new StringBuilder();
            sb6.append("Missing required properties:");
            sb6.append(string5);
            throw new IllegalStateException(sb6.toString());
        }
        
        @Override
        protected Map e() {
            final Map f = this.f;
            if (f != null) {
                return f;
            }
            throw new IllegalStateException("Property \"autoMetadata\" has not been set");
        }
        
        @Override
        protected a f(final Map f) {
            if (f != null) {
                this.f = f;
                return this;
            }
            throw new NullPointerException("Null autoMetadata");
        }
        
        @Override
        public a g(final Integer b) {
            this.b = b;
            return this;
        }
        
        @Override
        public a h(final h c) {
            if (c != null) {
                this.c = c;
                return this;
            }
            throw new NullPointerException("Null encodedPayload");
        }
        
        @Override
        public a i(final long n) {
            this.d = n;
            return this;
        }
        
        @Override
        public a j(final byte[] i) {
            this.i = i;
            return this;
        }
        
        @Override
        public a k(final byte[] j) {
            this.j = j;
            return this;
        }
        
        @Override
        public a l(final Integer g) {
            this.g = g;
            return this;
        }
        
        @Override
        public a m(final String h) {
            this.h = h;
            return this;
        }
        
        @Override
        public a n(final String a) {
            if (a != null) {
                this.a = a;
                return this;
            }
            throw new NullPointerException("Null transportName");
        }
        
        @Override
        public a o(final long n) {
            this.e = n;
            return this;
        }
    }
}
