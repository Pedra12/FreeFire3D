package b3;

import d3.b;
import i3.w;
import i3.s;
import j3.N;
import j3.h;
import j3.X;
import j3.i;
import j3.g;
import c3.l;
import c3.j;
import d3.c;
import r7.a;
import d3.d;
import android.content.Context;

abstract class e
{
    public static v.a a() {
        return new b();
    }
    
    private static final class b implements a
    {
        private Context a;
        
        public b b(final Context context) {
            this.a = (Context)d.b((Object)context);
            return this;
        }
        
        @Override
        public v build() {
            d.a((Object)this.a, (Class)Context.class);
            return new c(this.a);
        }
    }
    
    private static final class c extends v
    {
        private final c a;
        private r7.a b;
        private r7.a c;
        private r7.a d;
        private r7.a e;
        private r7.a f;
        private r7.a g;
        private r7.a h;
        private r7.a i;
        private r7.a j;
        private r7.a k;
        private r7.a l;
        private r7.a v;
        private r7.a w;
        
        private c(final Context context) {
            (this.a = this).c(context);
        }
        
        private void c(final Context context) {
            this.b = d3.a.a((r7.a)b3.k.a());
            final d3.b a = d3.c.a((Object)context);
            this.c = (r7.a)a;
            final j a2 = c3.j.a((r7.a)a, (r7.a)l3.c.a(), (r7.a)l3.d.a());
            this.d = (r7.a)a2;
            this.e = d3.a.a((r7.a)c3.l.a(this.c, (r7.a)a2));
            this.f = (r7.a)X.a(this.c, (r7.a)j3.g.a(), (r7.a)j3.i.a());
            this.g = d3.a.a((r7.a)j3.h.a(this.c));
            this.h = d3.a.a((r7.a)N.a((r7.a)l3.c.a(), (r7.a)l3.d.a(), (r7.a)j3.j.a(), this.f, this.g));
            final h3.g b = h3.g.b((r7.a)l3.c.a());
            this.i = (r7.a)b;
            final h3.i a3 = h3.i.a(this.c, this.h, (r7.a)b, (r7.a)l3.d.a());
            this.j = (r7.a)a3;
            final r7.a b2 = this.b;
            final r7.a e = this.e;
            final r7.a h = this.h;
            this.k = (r7.a)h3.d.a(b2, e, (r7.a)a3, h, h);
            final r7.a c = this.c;
            final r7.a e2 = this.e;
            final r7.a h2 = this.h;
            this.l = (r7.a)s.a(c, e2, h2, this.j, this.b, h2, (r7.a)l3.c.a(), (r7.a)l3.d.a(), this.h);
            final r7.a b3 = this.b;
            final r7.a h3 = this.h;
            this.v = (r7.a)i3.w.a(b3, h3, this.j, h3);
            this.w = d3.a.a((r7.a)b3.w.a((r7.a)l3.c.a(), (r7.a)l3.d.a(), this.k, this.l, this.v));
        }
        
        @Override
        j3.d a() {
            return (j3.d)this.h.get();
        }
        
        @Override
        u b() {
            return (u)this.w.get();
        }
    }
}
