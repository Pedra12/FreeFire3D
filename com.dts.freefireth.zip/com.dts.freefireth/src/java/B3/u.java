package b3;

import com.google.android.datatransport.TransportFactory;
import Z2.j;
import android.content.Context;
import java.util.Collections;
import Z2.c;
import j$.util.DesugarCollections;
import java.util.Set;
import i3.r;
import h3.e;
import l3.a;

public class u implements t
{
    private static volatile v e;
    private final a a;
    private final a b;
    private final e c;
    private final r d;
    
    u(final a a, final a b, final e c, final r d, final i3.v v) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        v.c();
    }
    
    private i b(final o o) {
        final i.a g = i.a().i(this.a.a()).o(this.b.a()).n(o.g()).h(new h(o.b(), o.d())).g(o.c().a());
        if (o.c().e() != null && o.c().e().a() != null) {
            g.l(o.c().e().a());
        }
        o.c().b();
        return g.d();
    }
    
    public static u c() {
        final v e = u.e;
        if (e != null) {
            return e.b();
        }
        throw new IllegalStateException("Not initialized!");
    }
    
    private static Set d(final f f) {
        if (f instanceof g) {
            return DesugarCollections.unmodifiableSet(((g)f).a());
        }
        return Collections.singleton((Object)c.b("proto"));
    }
    
    public static void f(final Context context) {
        if (u.e == null) {
            final Class<u> clazz;
            monitorenter(clazz = u.class);
            Label_0041: {
                try {
                    if (u.e == null) {
                        u.e = b3.e.a().a(context).build();
                    }
                    break Label_0041;
                }
                finally {
                    monitorexit(clazz);
                    monitorexit(clazz);
                }
            }
        }
    }
    
    @Override
    public void a(final o o, final j j) {
        this.c.a(o.f().f(o.c().d()), this.b(o), j);
    }
    
    public r e() {
        return this.d;
    }
    
    public TransportFactory g(final f f) {
        return (TransportFactory)new q(d(f), p.a().b(f.getName()).c(f.getExtras()).a(), this);
    }
}
