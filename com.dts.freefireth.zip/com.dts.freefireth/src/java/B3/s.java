package b3;

import Z2.j;
import Z2.d;
import Z2.h;
import Z2.c;
import Z2.i;

final class s implements i
{
    private final p a;
    private final String b;
    private final c c;
    private final h d;
    private final t e;
    
    s(final p a, final String b, final c c, final h d, final t e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    public void a(final d d) {
        this.b(d, (j)new r());
    }
    
    public void b(final d d, final j j) {
        this.e.a(o.a().e(this.a).c(d).f(this.b).d(this.d).b(this.c).a(), j);
    }
    
    p d() {
        return this.a;
    }
}
