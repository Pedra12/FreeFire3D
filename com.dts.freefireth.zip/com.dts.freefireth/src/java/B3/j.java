package b3;

import java.util.concurrent.Executors;
import java.util.concurrent.Executor;

abstract class j
{
    static Executor a() {
        return (Executor)new n((Executor)Executors.newSingleThreadExecutor());
    }
}
