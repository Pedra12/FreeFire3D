package b3;

import j$.util.DesugarCollections;
import java.util.Map;
import java.util.HashMap;

public abstract class i
{
    public static a a() {
        return new b.b().f((Map)new HashMap());
    }
    
    public final String b(String s) {
        if ((s = (String)this.c().get((Object)s)) == null) {
            s = "";
        }
        return s;
    }
    
    protected abstract Map c();
    
    public abstract Integer d();
    
    public abstract h e();
    
    public abstract long f();
    
    public abstract byte[] g();
    
    public abstract byte[] h();
    
    public final int i(String s) {
        s = (String)this.c().get((Object)s);
        if (s == null) {
            return 0;
        }
        return Integer.valueOf(s);
    }
    
    public final long j(String s) {
        s = (String)this.c().get((Object)s);
        if (s == null) {
            return 0L;
        }
        return Long.valueOf(s);
    }
    
    public final Map k() {
        return DesugarCollections.unmodifiableMap(this.c());
    }
    
    public abstract Integer l();
    
    public abstract String m();
    
    public abstract String n();
    
    public abstract long o();
    
    public a p() {
        return new b.b().n(this.n()).g(this.d()).l(this.l()).m(this.m()).j(this.g()).k(this.h()).h(this.e()).i(this.f()).o(this.o()).f((Map)new HashMap(this.c()));
    }
    
    public abstract static class a
    {
        public final a a(final String s, final int n) {
            this.e().put((Object)s, (Object)String.valueOf(n));
            return this;
        }
        
        public final a b(final String s, final long n) {
            this.e().put((Object)s, (Object)String.valueOf(n));
            return this;
        }
        
        public final a c(final String s, final String s2) {
            this.e().put((Object)s, (Object)s2);
            return this;
        }
        
        public abstract i d();
        
        protected abstract Map e();
        
        protected abstract a f(final Map p0);
        
        public abstract a g(final Integer p0);
        
        public abstract a h(final h p0);
        
        public abstract a i(final long p0);
        
        public abstract a j(final byte[] p0);
        
        public abstract a k(final byte[] p0);
        
        public abstract a l(final Integer p0);
        
        public abstract a m(final String p0);
        
        public abstract a n(final String p0);
        
        public abstract a o(final long p0);
    }
}
