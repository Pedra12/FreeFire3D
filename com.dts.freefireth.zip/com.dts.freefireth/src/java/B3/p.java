package b3;

import android.util.Base64;
import Z2.f;

public abstract class p
{
    public static a a() {
        return new d.b().d(f.a);
    }
    
    public abstract String b();
    
    public abstract byte[] c();
    
    public abstract f d();
    
    public boolean e() {
        return this.c() != null;
    }
    
    public p f(final f f) {
        return a().b(this.b()).d(f).c(this.c()).a();
    }
    
    @Override
    public final String toString() {
        final String b = this.b();
        final f d = this.d();
        String encodeToString;
        if (this.c() == null) {
            encodeToString = "";
        }
        else {
            encodeToString = Base64.encodeToString(this.c(), 2);
        }
        return String.format("TransportContext(%s, %s, %s)", new Object[] { b, d, encodeToString });
    }
    
    public abstract static class a
    {
        public abstract p a();
        
        public abstract a b(final String p0);
        
        public abstract a c(final byte[] p0);
        
        public abstract a d(final f p0);
    }
}
