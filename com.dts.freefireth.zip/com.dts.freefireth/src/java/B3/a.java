package b3;

import java.lang.annotation.Annotation;
import e3.e;
import e3.c;
import e3.f;
import G5.d;
import H5.b;

public final class a implements a
{
    public static final a a;
    
    static {
        a = (a)new a();
    }
    
    private a() {
    }
    
    public void a(final H5.b b) {
        b.a((Class)m.class, (G5.d)e.a);
        b.a((Class)e3.a.class, (G5.d)b3.a.a.a);
        b.a((Class)e3.f.class, (G5.d)g.a);
        b.a((Class)e3.d.class, (G5.d)d.a);
        b.a((Class)e3.c.class, (G5.d)c.a);
        b.a((Class)e3.b.class, (G5.d)b3.a.b.a);
        b.a((Class)e3.e.class, (G5.d)f.a);
    }
    
    private static final class a implements G5.d
    {
        static final a a;
        private static final G5.c b;
        private static final G5.c c;
        private static final G5.c d;
        private static final G5.c e;
        
        static {
            a = new a();
            b = G5.c.a("window").b((Annotation)J5.a.b().c(1).a()).a();
            c = G5.c.a("logSourceMetrics").b((Annotation)J5.a.b().c(2).a()).a();
            d = G5.c.a("globalMetrics").b((Annotation)J5.a.b().c(3).a()).a();
            e = G5.c.a("appNamespace").b((Annotation)J5.a.b().c(4).a()).a();
        }
        
        public void b(final e3.a a, final G5.e e) {
            e.a(a.b, (Object)a.d());
            e.a(a.c, (Object)a.c());
            e.a(a.d, (Object)a.b());
            e.a(a.e, (Object)a.a());
        }
    }
    
    private static final class b implements G5.d
    {
        static final b a;
        private static final G5.c b;
        
        static {
            a = new b();
            b = G5.c.a("storageMetrics").b((Annotation)J5.a.b().c(1).a()).a();
        }
        
        public void b(final e3.b b, final G5.e e) {
            e.a(b3.a.b.b, (Object)b.a());
        }
    }
    
    private static final class c implements G5.d
    {
        static final c a;
        private static final G5.c b;
        private static final G5.c c;
        
        static {
            a = new c();
            b = G5.c.a("eventsDroppedCount").b((Annotation)J5.a.b().c(1).a()).a();
            c = G5.c.a("reason").b((Annotation)J5.a.b().c(3).a()).a();
        }
        
        public void b(final e3.c c, final G5.e e) {
            e.c(b3.a.c.b, c.a());
            e.a(b3.a.c.c, (Object)c.b());
        }
    }
    
    private static final class d implements G5.d
    {
        static final d a;
        private static final G5.c b;
        private static final G5.c c;
        
        static {
            a = new d();
            b = G5.c.a("logSource").b((Annotation)J5.a.b().c(1).a()).a();
            c = G5.c.a("logEventDropped").b((Annotation)J5.a.b().c(2).a()).a();
        }
        
        public void b(final e3.d d, final G5.e e) {
            e.a(b3.a.d.b, (Object)d.b());
            e.a(b3.a.d.c, (Object)d.a());
        }
    }
    
    private static final class e implements G5.d
    {
        static final e a;
        private static final G5.c b;
        
        static {
            a = new e();
            b = G5.c.d("clientMetrics");
        }
        
        public void b(final m m, final G5.e e) {
            throw null;
        }
    }
    
    private static final class f implements G5.d
    {
        static final f a;
        private static final G5.c b;
        private static final G5.c c;
        
        static {
            a = new f();
            b = G5.c.a("currentCacheSizeBytes").b((Annotation)J5.a.b().c(1).a()).a();
            c = G5.c.a("maxCacheSizeBytes").b((Annotation)J5.a.b().c(2).a()).a();
        }
        
        public void b(final e3.e e, final G5.e e2) {
            e2.c(f.b, e.a());
            e2.c(f.c, e.b());
        }
    }
    
    private static final class g implements G5.d
    {
        static final g a;
        private static final G5.c b;
        private static final G5.c c;
        
        static {
            a = new g();
            b = G5.c.a("startMs").b((Annotation)J5.a.b().c(1).a()).a();
            c = G5.c.a("endMs").b((Annotation)J5.a.b().c(2).a()).a();
        }
        
        public void b(final e3.f f, final G5.e e) {
            e.c(g.b, f.b());
            e.c(g.c, f.a());
        }
    }
}
