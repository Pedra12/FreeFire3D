package E0;

import java.util.Collection;
import java.util.TreeMap;
import java.util.Iterator;
import java.util.ArrayList;
import kotlin.collections.L;
import java.util.Set;
import kotlin.collections.CollectionsKt;
import java.util.List;
import android.database.Cursor;
import kotlin.jvm.internal.Intrinsics;
import java.io.Closeable;
import C7.b;
import kotlin.collections.F;
import java.util.Map;
import G0.g;

public abstract class e
{
    private static final Map a(g u0, String string) {
        final StringBuilder sb = new StringBuilder();
        sb.append("PRAGMA table_info(`");
        sb.append(string);
        sb.append("`)");
        u0 = (g)u0.U0(sb.toString());
        Label_0068: {
            try {
                if (((Cursor)u0).getColumnCount() <= 0) {
                    final Map i = F.i();
                    b.a((Closeable)u0, (Throwable)null);
                    return i;
                }
                break Label_0068;
            }
            finally {
                try {}
                finally {
                    b.a((Closeable)u0, (Throwable)string);
                }
                while (true) {
                    final int columnIndex;
                    final String string2 = ((Cursor)u0).getString(columnIndex);
                    final int columnIndex2;
                    string = ((Cursor)u0).getString(columnIndex2);
                    final int columnIndex3;
                    final boolean b = ((Cursor)u0).getInt(columnIndex3) != 0;
                    final int columnIndex4;
                    final int int1 = ((Cursor)u0).getInt(columnIndex4);
                    final int columnIndex5;
                    final String string3 = ((Cursor)u0).getString(columnIndex5);
                    Intrinsics.checkNotNullExpressionValue((Object)string2, "name");
                    Intrinsics.checkNotNullExpressionValue((Object)string, "type");
                    final Map c;
                    c.put((Object)string2, (Object)new d.a(string2, string, b, int1, string3, 2));
                    Label_0121: {
                        break Label_0121;
                        final Map b2;
                        Label_0235: {
                            b2 = F.b(c);
                        }
                        C7.b.a((Closeable)u0, (Throwable)null);
                        return b2;
                        columnIndex = ((Cursor)u0).getColumnIndex("name");
                        columnIndex2 = ((Cursor)u0).getColumnIndex("type");
                        columnIndex3 = ((Cursor)u0).getColumnIndex("notnull");
                        columnIndex4 = ((Cursor)u0).getColumnIndex("pk");
                        columnIndex5 = ((Cursor)u0).getColumnIndex("dflt_value");
                        c = F.c();
                    }
                    iftrue(Label_0235:)(!((Cursor)u0).moveToNext());
                    continue;
                }
            }
        }
    }
    
    private static final List b(final Cursor cursor) {
        final int columnIndex = cursor.getColumnIndex("id");
        final int columnIndex2 = cursor.getColumnIndex("seq");
        final int columnIndex3 = cursor.getColumnIndex("from");
        final int columnIndex4 = cursor.getColumnIndex("to");
        final List c = CollectionsKt.c();
        while (cursor.moveToNext()) {
            final int int1 = cursor.getInt(columnIndex);
            final int int2 = cursor.getInt(columnIndex2);
            final String string = cursor.getString(columnIndex3);
            Intrinsics.checkNotNullExpressionValue((Object)string, "cursor.getString(fromColumnIndex)");
            final String string2 = cursor.getString(columnIndex4);
            Intrinsics.checkNotNullExpressionValue((Object)string2, "cursor.getString(toColumnIndex)");
            c.add((Object)new d.d(int1, int2, string, string2));
        }
        return CollectionsKt.h0((Iterable)CollectionsKt.a(c));
    }
    
    private static final Set c(g u0, final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append("PRAGMA foreign_key_list(`");
        sb.append(s);
        sb.append("`)");
        u0 = (g)u0.U0(sb.toString());
    Label_0238_Outer:
        while (true) {
            Label_0229: {
                try {
                    final int columnIndex = ((Cursor)u0).getColumnIndex("id");
                    final int columnIndex2 = ((Cursor)u0).getColumnIndex("seq");
                    final int columnIndex3 = ((Cursor)u0).getColumnIndex("table");
                    final int columnIndex4 = ((Cursor)u0).getColumnIndex("on_delete");
                    final int columnIndex5 = ((Cursor)u0).getColumnIndex("on_update");
                    final List b = b((Cursor)u0);
                    ((Cursor)u0).moveToPosition(-1);
                    final Set b2 = L.b();
                    Label_0135: {
                        while (((Cursor)u0).moveToNext()) {
                            if (((Cursor)u0).getInt(columnIndex2) != 0) {
                                continue;
                            }
                            break Label_0135;
                        }
                        break Label_0229;
                    }
                    final int int1 = ((Cursor)u0).getInt(columnIndex);
                    final ArrayList list = new ArrayList();
                    final ArrayList list2 = new ArrayList();
                    final ArrayList list3 = new ArrayList();
                    for (final Object next : b) {
                        if (((d.d)next).c() == int1) {
                            ((Collection)list3).add(next);
                        }
                    }
                    break Label_0229;
                }
                finally {
                    try {}
                    finally {
                        b.a((Closeable)u0, (Throwable)s);
                    }
                    final ArrayList list3;
                    final int size = list3.size();
                    int n = 0;
                    final Set b2;
                    while (true) {
                        break Label_0238;
                        final String string;
                        Label_0290: {
                            final int columnIndex3;
                            string = ((Cursor)u0).getString(columnIndex3);
                        }
                        Intrinsics.checkNotNullExpressionValue((Object)string, "cursor.getString(tableColumnIndex)");
                        final int columnIndex4;
                        final String string2 = ((Cursor)u0).getString(columnIndex4);
                        Intrinsics.checkNotNullExpressionValue((Object)string2, "cursor.getString(onDeleteColumnIndex)");
                        final int columnIndex5;
                        final String string3 = ((Cursor)u0).getString(columnIndex5);
                        Intrinsics.checkNotNullExpressionValue((Object)string3, "cursor.getString(onUpdateColumnIndex)");
                        final ArrayList list;
                        final ArrayList list2;
                        b2.add((Object)new d.c(string, string2, string3, (List)list, (List)list2));
                        continue Label_0238_Outer;
                        iftrue(Label_0290:)(n >= size);
                        final Object value = list3.get(n);
                        ++n;
                        final d.d d = (d.d)value;
                        ((List)list).add((Object)d.b());
                        ((List)list2).add((Object)d.d());
                        continue;
                    }
                    final Set a = L.a(b2);
                    b.a((Closeable)u0, (Throwable)null);
                    return a;
                }
            }
            break;
        }
    }
    
    private static final d.e d(final g g, final String s, final boolean b) {
        final StringBuilder sb = new StringBuilder();
        sb.append("PRAGMA index_xinfo(`");
        sb.append(s);
        sb.append("`)");
        final Cursor u0 = g.U0(sb.toString());
    Label_0205_Outer:
        while (true) {
            Label_0244: {
                while (true) {
                    Label_0202: {
                        try {
                            final int columnIndex = u0.getColumnIndex("seqno");
                            final int columnIndex2 = u0.getColumnIndex("cid");
                            final int columnIndex3 = u0.getColumnIndex("name");
                            final int columnIndex4 = u0.getColumnIndex("desc");
                            if (columnIndex == -1 || columnIndex2 == -1 || columnIndex3 == -1 || columnIndex4 == -1) {
                                break Label_0205_Outer;
                            }
                            final TreeMap treeMap = new TreeMap();
                            final TreeMap treeMap2 = new TreeMap();
                            Label_0159: {
                                while (u0.moveToNext()) {
                                    if (u0.getInt(columnIndex2) < 0) {
                                        continue Label_0205_Outer;
                                    }
                                    break Label_0159;
                                }
                                break Label_0244;
                            }
                            final int int1 = u0.getInt(columnIndex);
                            final String string = u0.getString(columnIndex3);
                            if (u0.getInt(columnIndex4) > 0) {
                                final String s2 = "DESC";
                                break Label_0205;
                            }
                            break Label_0202;
                        }
                        finally {
                            try {}
                            finally {
                                b.a((Closeable)u0, (Throwable)s);
                            }
                            final TreeMap treeMap;
                            final Collection values = treeMap.values();
                            Intrinsics.checkNotNullExpressionValue((Object)values, "columnsMap.values");
                            final List m0 = CollectionsKt.m0((Iterable)values);
                            final TreeMap treeMap2;
                            final Collection values2 = treeMap2.values();
                            Intrinsics.checkNotNullExpressionValue((Object)values2, "ordersMap.values");
                            final d.e e = new d.e(s, b, m0, CollectionsKt.m0((Iterable)values2));
                            b.a((Closeable)u0, (Throwable)null);
                            return e;
                            final String string;
                            Intrinsics.checkNotNullExpressionValue((Object)string, "columnName");
                            final int int1;
                            ((Map)treeMap).put((Object)int1, (Object)string);
                            final String s2;
                            ((Map)treeMap2).put((Object)int1, (Object)s2);
                            continue Label_0205_Outer;
                            b.a((Closeable)u0, (Throwable)null);
                            return null;
                            s2 = "ASC";
                            continue;
                        }
                    }
                    break;
                }
            }
            break;
        }
    }
    
    private static final Set e(final g g, String u0) {
        final StringBuilder sb = new StringBuilder();
        sb.append("PRAGMA index_list(`");
        sb.append(u0);
        sb.append("`)");
        u0 = (String)g.U0(sb.toString());
        Label_0218: {
            try {
                final int columnIndex = ((Cursor)u0).getColumnIndex("name");
                final int columnIndex2 = ((Cursor)u0).getColumnIndex("origin");
                final int columnIndex3 = ((Cursor)u0).getColumnIndex("unique");
                if (columnIndex != -1 && columnIndex2 != -1 && columnIndex3 != -1) {
                    final Set b = L.b();
                    Block_9: {
                        while (((Cursor)u0).moveToNext()) {
                            if (!Intrinsics.a((Object)"c", (Object)((Cursor)u0).getString(columnIndex2))) {
                                continue;
                            }
                            final String string = ((Cursor)u0).getString(columnIndex);
                            final int int1 = ((Cursor)u0).getInt(columnIndex3);
                            boolean b2 = true;
                            if (int1 != 1) {
                                b2 = false;
                            }
                            Intrinsics.checkNotNullExpressionValue((Object)string, "name");
                            final d.e d = d(g, string, b2);
                            if (d == null) {
                                break Block_9;
                            }
                            b.add((Object)d);
                        }
                        break Label_0218;
                    }
                    C7.b.a((Closeable)u0, (Throwable)null);
                    return null;
                }
                break Label_0218;
            }
            finally {
                try {}
                finally {
                    final Throwable t;
                    b.a((Closeable)u0, t);
                }
                final Set b;
                final Set a = L.a(b);
                C7.b.a((Closeable)u0, (Throwable)null);
                return a;
                C7.b.a((Closeable)u0, (Throwable)null);
                return null;
            }
        }
    }
    
    public static final d f(final g g, final String s) {
        Intrinsics.checkNotNullParameter((Object)g, "database");
        Intrinsics.checkNotNullParameter((Object)s, "tableName");
        return new d(s, a(g, s), c(g, s), e(g, s));
    }
}
