package E0;

import java.util.Collection;
import C0.k;
import java.util.ArrayList;
import java.util.List;
import kotlin.text.StringsKt;
import java.util.Locale;
import G0.g;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.DefaultConstructorMarker;
import java.util.Set;
import java.util.Map;

public final class d
{
    public static final b e;
    public final String a;
    public final Map b;
    public final Set c;
    public final Set d;
    
    static {
        e = new b(null);
    }
    
    public d(final String a, final Map b, final Set c, final Set d) {
        Intrinsics.checkNotNullParameter((Object)a, "name");
        Intrinsics.checkNotNullParameter((Object)b, "columns");
        Intrinsics.checkNotNullParameter((Object)c, "foreignKeys");
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public static final d a(final g g, final String s) {
        return d.e.a(g, s);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof d)) {
            return false;
        }
        final String a = this.a;
        final d d = (d)o;
        if (!Intrinsics.a((Object)a, (Object)d.a)) {
            return false;
        }
        if (!Intrinsics.a((Object)this.b, (Object)d.b)) {
            return false;
        }
        if (!Intrinsics.a((Object)this.c, (Object)d.c)) {
            return false;
        }
        final Set d2 = this.d;
        if (d2 != null) {
            final Set d3 = d.d;
            if (d3 != null) {
                return Intrinsics.a((Object)d2, (Object)d3);
            }
        }
        return true;
    }
    
    @Override
    public int hashCode() {
        return (this.a.hashCode() * 31 + this.b.hashCode()) * 31 + this.c.hashCode();
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("TableInfo{name='");
        sb.append(this.a);
        sb.append("', columns=");
        sb.append((Object)this.b);
        sb.append(", foreignKeys=");
        sb.append((Object)this.c);
        sb.append(", indices=");
        sb.append((Object)this.d);
        sb.append('}');
        return sb.toString();
    }
    
    public static final class a
    {
        public static final a h;
        public final String a;
        public final String b;
        public final boolean c;
        public final int d;
        public final String e;
        public final int f;
        public final int g;
        
        static {
            h = new a(null);
        }
        
        public a(final String a, final String b, final boolean c, final int d, final String e, final int f) {
            Intrinsics.checkNotNullParameter((Object)a, "name");
            Intrinsics.checkNotNullParameter((Object)b, "type");
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.e = e;
            this.f = f;
            this.g = this.a(b);
        }
        
        private final int a(String upperCase) {
            if (upperCase == null) {
                return 5;
            }
            final Locale us = Locale.US;
            Intrinsics.checkNotNullExpressionValue((Object)us, "US");
            upperCase = upperCase.toUpperCase(us);
            Intrinsics.checkNotNullExpressionValue((Object)upperCase, "this as java.lang.String).toUpperCase(locale)");
            if (StringsKt.P((CharSequence)upperCase, (CharSequence)"INT", false, 2, (Object)null)) {
                return 3;
            }
            if (StringsKt.P((CharSequence)upperCase, (CharSequence)"CHAR", false, 2, (Object)null) || StringsKt.P((CharSequence)upperCase, (CharSequence)"CLOB", false, 2, (Object)null) || StringsKt.P((CharSequence)upperCase, (CharSequence)"TEXT", false, 2, (Object)null)) {
                return 2;
            }
            if (StringsKt.P((CharSequence)upperCase, (CharSequence)"BLOB", false, 2, (Object)null)) {
                return 5;
            }
            if (!StringsKt.P((CharSequence)upperCase, (CharSequence)"REAL", false, 2, (Object)null) && !StringsKt.P((CharSequence)upperCase, (CharSequence)"FLOA", false, 2, (Object)null) && !StringsKt.P((CharSequence)upperCase, (CharSequence)"DOUB", false, 2, (Object)null)) {
                return 1;
            }
            return 4;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof a)) {
                return false;
            }
            if (this.d != ((a)o).d) {
                return false;
            }
            final String a = this.a;
            final a a2 = (a)o;
            if (!Intrinsics.a((Object)a, (Object)a2.a)) {
                return false;
            }
            if (this.c != a2.c) {
                return false;
            }
            if (this.f == 1 && a2.f == 2) {
                final String e = this.e;
                if (e != null && !E0.d.a.h.b(e, a2.e)) {
                    return false;
                }
            }
            if (this.f == 2 && a2.f == 1) {
                final String e2 = a2.e;
                if (e2 != null && !E0.d.a.h.b(e2, this.e)) {
                    return false;
                }
            }
            final int f = this.f;
            if (f != 0 && f == a2.f) {
                final String e3 = this.e;
                if (e3 != null) {
                    if (E0.d.a.h.b(e3, a2.e)) {
                        return this.g == a2.g;
                    }
                }
                else if (a2.e == null) {
                    return this.g == a2.g;
                }
                return false;
            }
            return this.g == a2.g;
        }
        
        @Override
        public int hashCode() {
            final int hashCode = this.a.hashCode();
            final int g = this.g;
            int n;
            if (this.c) {
                n = 1231;
            }
            else {
                n = 1237;
            }
            return ((hashCode * 31 + g) * 31 + n) * 31 + this.d;
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append("Column{name='");
            sb.append(this.a);
            sb.append("', type='");
            sb.append(this.b);
            sb.append("', affinity='");
            sb.append(this.g);
            sb.append("', notNull=");
            sb.append(this.c);
            sb.append(", primaryKeyPosition=");
            sb.append(this.d);
            sb.append(", defaultValue='");
            String e;
            if ((e = this.e) == null) {
                e = "undefined";
            }
            sb.append(e);
            sb.append("'}");
            return sb.toString();
        }
        
        public static final class a
        {
            private a() {
            }
            
            private final boolean a(final String s) {
                if (((CharSequence)s).length() == 0) {
                    return false;
                }
                int i = 0;
                int n = 0;
                int n3;
                for (int n2 = 0; i < ((CharSequence)s).length(); ++i, ++n2, n = n3) {
                    final char char1 = ((CharSequence)s).charAt(i);
                    if (n2 == 0 && char1 != '(') {
                        return false;
                    }
                    if (char1 == '(') {
                        n3 = n + 1;
                    }
                    else {
                        n3 = n;
                        if (char1 == ')') {
                            n3 = --n;
                            if (n == 0) {
                                n3 = n;
                                if (n2 != s.length() - 1) {
                                    return false;
                                }
                            }
                        }
                    }
                }
                return n == 0;
            }
            
            public final boolean b(String substring, final String s) {
                Intrinsics.checkNotNullParameter((Object)substring, "current");
                if (Intrinsics.a((Object)substring, (Object)s)) {
                    return true;
                }
                if (this.a(substring)) {
                    substring = substring.substring(1, substring.length() - 1);
                    Intrinsics.checkNotNullExpressionValue((Object)substring, "this as java.lang.String\u2026ing(startIndex, endIndex)");
                    return Intrinsics.a((Object)StringsKt.M0((CharSequence)substring).toString(), (Object)s);
                }
                return false;
            }
        }
    }
    
    public static final class b
    {
        private b() {
        }
        
        public final d a(final g g, final String s) {
            Intrinsics.checkNotNullParameter((Object)g, "database");
            Intrinsics.checkNotNullParameter((Object)s, "tableName");
            return E0.e.f(g, s);
        }
    }
    
    public static final class c
    {
        public final String a;
        public final String b;
        public final String c;
        public final List d;
        public final List e;
        
        public c(final String a, final String b, final String c, final List d, final List e) {
            Intrinsics.checkNotNullParameter((Object)a, "referenceTable");
            Intrinsics.checkNotNullParameter((Object)b, "onDelete");
            Intrinsics.checkNotNullParameter((Object)c, "onUpdate");
            Intrinsics.checkNotNullParameter((Object)d, "columnNames");
            Intrinsics.checkNotNullParameter((Object)e, "referenceColumnNames");
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.e = e;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof c)) {
                return false;
            }
            final String a = this.a;
            final c c = (c)o;
            return Intrinsics.a((Object)a, (Object)c.a) && Intrinsics.a((Object)this.b, (Object)c.b) && Intrinsics.a((Object)this.c, (Object)c.c) && Intrinsics.a((Object)this.d, (Object)c.d) && Intrinsics.a((Object)this.e, (Object)c.e);
        }
        
        @Override
        public int hashCode() {
            return (((this.a.hashCode() * 31 + this.b.hashCode()) * 31 + this.c.hashCode()) * 31 + this.d.hashCode()) * 31 + this.e.hashCode();
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append("ForeignKey{referenceTable='");
            sb.append(this.a);
            sb.append("', onDelete='");
            sb.append(this.b);
            sb.append(" +', onUpdate='");
            sb.append(this.c);
            sb.append("', columnNames=");
            sb.append((Object)this.d);
            sb.append(", referenceColumnNames=");
            sb.append((Object)this.e);
            sb.append('}');
            return sb.toString();
        }
    }
    
    public static final class d implements Comparable
    {
        private final int a;
        private final int b;
        private final String c;
        private final String d;
        
        public d(final int a, final int b, final String c, final String d) {
            Intrinsics.checkNotNullParameter((Object)c, "from");
            Intrinsics.checkNotNullParameter((Object)d, "to");
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
        }
        
        public int a(final d d) {
            Intrinsics.checkNotNullParameter((Object)d, "other");
            int n;
            if ((n = this.a - d.a) == 0) {
                n = this.b - d.b;
            }
            return n;
        }
        
        public final String b() {
            return this.c;
        }
        
        public final int c() {
            return this.a;
        }
        
        public final String d() {
            return this.d;
        }
    }
    
    public static final class e
    {
        public static final a e;
        public final String a;
        public final boolean b;
        public final List c;
        public List d;
        
        static {
            e = new a(null);
        }
        
        public e(final String a, final boolean b, final List c, final List d) {
            Intrinsics.checkNotNullParameter((Object)a, "name");
            Intrinsics.checkNotNullParameter((Object)c, "columns");
            Intrinsics.checkNotNullParameter((Object)d, "orders");
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            List d2 = d;
            if (((Collection)d).isEmpty()) {
                final int size = c.size();
                final ArrayList list = new ArrayList(size);
                int n = 0;
                while (true) {
                    d2 = (List)list;
                    if (n >= size) {
                        break;
                    }
                    list.add((Object)k.a.name());
                    ++n;
                }
            }
            this.d = d2;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof e)) {
                return false;
            }
            final boolean b = this.b;
            final e e = (e)o;
            if (b != e.b) {
                return false;
            }
            if (!Intrinsics.a((Object)this.c, (Object)e.c)) {
                return false;
            }
            if (!Intrinsics.a((Object)this.d, (Object)e.d)) {
                return false;
            }
            if (StringsKt.J(this.a, "index_", false, 2, (Object)null)) {
                return StringsKt.J(e.a, "index_", false, 2, (Object)null);
            }
            return Intrinsics.a((Object)this.a, (Object)e.a);
        }
        
        @Override
        public int hashCode() {
            int hashCode;
            if (StringsKt.J(this.a, "index_", false, 2, (Object)null)) {
                hashCode = -1184239155;
            }
            else {
                hashCode = this.a.hashCode();
            }
            return ((hashCode * 31 + (this.b ? 1 : 0)) * 31 + this.c.hashCode()) * 31 + this.d.hashCode();
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append("Index{name='");
            sb.append(this.a);
            sb.append("', unique=");
            sb.append(this.b);
            sb.append(", columns=");
            sb.append((Object)this.c);
            sb.append(", orders=");
            sb.append((Object)this.d);
            sb.append("'}");
            return sb.toString();
        }
        
        public static final class a
        {
            private a() {
            }
        }
    }
}
