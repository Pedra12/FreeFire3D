package e0;

import kotlin.jvm.internal.Intrinsics;
import java.io.File;
import android.content.Context;

public abstract class a
{
    public static final File a(final Context context, final String s) {
        Intrinsics.checkNotNullParameter((Object)context, "<this>");
        Intrinsics.checkNotNullParameter((Object)s, "fileName");
        final File filesDir = context.getApplicationContext().getFilesDir();
        final StringBuilder sb = new StringBuilder();
        sb.append("datastore/");
        sb.append(s);
        return new File(filesDir, sb.toString());
    }
}
