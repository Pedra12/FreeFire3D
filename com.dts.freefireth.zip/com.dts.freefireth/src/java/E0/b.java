package E0;

import java.nio.channels.FileChannel;
import android.database.AbstractCursor;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.io.FileInputStream;
import java.io.File;
import android.os.Build$VERSION;
import android.database.AbstractWindowedCursor;
import android.os.CancellationSignal;
import G0.j;
import C0.r;
import java.util.Iterator;
import android.database.Cursor;
import java.util.List;
import kotlin.Unit;
import kotlin.text.StringsKt;
import java.io.Closeable;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import G0.g;

public abstract class b
{
    public static final void a(final g g) {
        Intrinsics.checkNotNullParameter((Object)g, "db");
        final List c = CollectionsKt.c();
        final Cursor u0 = g.U0("SELECT name FROM sqlite_master WHERE type = 'trigger'");
        Label_0049: {
            try {
                while (u0.moveToNext()) {
                    c.add((Object)u0.getString(0));
                }
                break Label_0049;
            }
            finally {
                try {}
                finally {
                    C7.b.a((Closeable)u0, (Throwable)g);
                }
                Label_0139: {
                    return;
                }
                while (true) {
                    String s = null;
                Block_5:
                    while (true) {
                        final Iterator iterator;
                        s = (String)iterator.next();
                        Intrinsics.checkNotNullExpressionValue((Object)s, "triggerName");
                        iftrue(Label_0068:)(!StringsKt.J(s, "room_fts_content_sync_", false, 2, (Object)null));
                        break Block_5;
                        final Unit a = Unit.a;
                        C7.b.a((Closeable)u0, (Throwable)null);
                        iterator = ((Iterable)CollectionsKt.a(c)).iterator();
                        iftrue(Label_0139:)(!iterator.hasNext());
                        continue;
                    }
                    final StringBuilder sb = new StringBuilder();
                    sb.append("DROP TRIGGER IF EXISTS ");
                    sb.append(s);
                    g.J(sb.toString());
                    continue;
                }
            }
        }
    }
    
    public static final Cursor b(final r r, final j j, final boolean b, final CancellationSignal cancellationSignal) {
        Intrinsics.checkNotNullParameter((Object)r, "db");
        Intrinsics.checkNotNullParameter((Object)j, "sqLiteQuery");
        Cursor cursor2;
        final Cursor cursor = cursor2 = r.z(j, cancellationSignal);
        if (b) {
            cursor2 = cursor;
            if (cursor instanceof AbstractWindowedCursor) {
                final AbstractWindowedCursor abstractWindowedCursor = (AbstractWindowedCursor)cursor;
                final int count = ((AbstractCursor)abstractWindowedCursor).getCount();
                int numRows;
                if (abstractWindowedCursor.hasWindow()) {
                    numRows = abstractWindowedCursor.getWindow().getNumRows();
                }
                else {
                    numRows = count;
                }
                if (Build$VERSION.SDK_INT >= 23) {
                    cursor2 = cursor;
                    if (numRows >= count) {
                        return cursor2;
                    }
                }
                cursor2 = a.a(cursor);
            }
        }
        return cursor2;
    }
    
    public static final int c(File channel) {
        Intrinsics.checkNotNullParameter((Object)channel, "databaseFile");
        channel = (File)new FileInputStream(channel).getChannel();
        try {
            final ByteBuffer allocate = ByteBuffer.allocate(4);
            ((FileChannel)channel).tryLock(60L, 4L, true);
            ((FileChannel)channel).position(60L);
            if (((FileChannel)channel).read(allocate) == 4) {
                allocate.rewind();
                final int int1 = allocate.getInt();
                C7.b.a((Closeable)channel, (Throwable)null);
                return int1;
            }
            throw new IOException("Bad database header, unable to read 4 bytes at offset 60");
        }
        finally {
            try {}
            finally {
                final Throwable t;
                C7.b.a((Closeable)channel, t);
            }
            throw new IOException("Bad database header, unable to read 4 bytes at offset 60");
        }
    }
}
