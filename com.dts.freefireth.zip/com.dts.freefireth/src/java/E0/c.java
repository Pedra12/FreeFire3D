package E0;

import java.nio.channels.spi.AbstractInterruptibleChannel;
import java.nio.channels.Channel;
import java.io.OutputStream;
import java.io.InputStream;
import java.nio.channels.WritableByteChannel;
import java.nio.channels.Channels;
import android.os.Build$VERSION;
import kotlin.jvm.internal.Intrinsics;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;

public abstract class c
{
    public static final void a(final ReadableByteChannel readableByteChannel, final FileChannel fileChannel) {
        Intrinsics.checkNotNullParameter((Object)readableByteChannel, "input");
        Intrinsics.checkNotNullParameter((Object)fileChannel, "output");
        try {
            Label_0079: {
                if (Build$VERSION.SDK_INT > 23) {
                    try {
                        fileChannel.transferFrom(readableByteChannel, 0L, Long.MAX_VALUE);
                        break Label_0079;
                    }
                    finally {}
                }
                final InputStream inputStream = Channels.newInputStream(readableByteChannel);
                final OutputStream outputStream = Channels.newOutputStream((WritableByteChannel)fileChannel);
                final byte[] array = new byte[4096];
                while (true) {
                    final int read = inputStream.read(array);
                    if (read <= 0) {
                        break;
                    }
                    outputStream.write(array, 0, read);
                }
            }
            fileChannel.force(false);
            ((Channel)readableByteChannel).close();
            ((AbstractInterruptibleChannel)fileChannel).close();
            return;
        }
        finally {}
        ((Channel)readableByteChannel).close();
        ((AbstractInterruptibleChannel)fileChannel).close();
    }
}
