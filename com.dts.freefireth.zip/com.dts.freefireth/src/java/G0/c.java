package G0;

import android.app.ActivityManager;
import kotlin.jvm.internal.Intrinsics;
import android.net.Uri;
import android.database.Cursor;

public final class c
{
    public static final c a;
    
    static {
        a = new c();
    }
    
    private c() {
    }
    
    public static final Uri a(final Cursor cursor) {
        Intrinsics.checkNotNullParameter((Object)cursor, "cursor");
        final Uri notificationUri = cursor.getNotificationUri();
        Intrinsics.checkNotNullExpressionValue((Object)notificationUri, "cursor.notificationUri");
        return notificationUri;
    }
    
    public static final boolean b(final ActivityManager activityManager) {
        Intrinsics.checkNotNullParameter((Object)activityManager, "activityManager");
        return activityManager.isLowRamDevice();
    }
}
