package G0;

import kotlin.jvm.internal.Intrinsics;
import android.os.Bundle;
import android.database.Cursor;

public final class e
{
    public static final e a;
    
    static {
        a = new e();
    }
    
    private e() {
    }
    
    public static final void a(final Cursor cursor, final Bundle extras) {
        Intrinsics.checkNotNullParameter((Object)cursor, "cursor");
        Intrinsics.checkNotNullParameter((Object)extras, "extras");
        cursor.setExtras(extras);
    }
}
