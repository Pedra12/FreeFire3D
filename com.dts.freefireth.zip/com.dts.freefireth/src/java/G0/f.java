package G0;

import android.content.ContentResolver;
import kotlin.jvm.internal.Intrinsics;
import java.util.List;
import android.database.Cursor;

public final class f
{
    public static final f a;
    
    static {
        a = new f();
    }
    
    private f() {
    }
    
    public static final List a(final Cursor cursor) {
        Intrinsics.checkNotNullParameter((Object)cursor, "cursor");
        final List notificationUris = cursor.getNotificationUris();
        Intrinsics.c((Object)notificationUris);
        return notificationUris;
    }
    
    public static final void b(final Cursor cursor, final ContentResolver contentResolver, final List list) {
        Intrinsics.checkNotNullParameter((Object)cursor, "cursor");
        Intrinsics.checkNotNullParameter((Object)contentResolver, "cr");
        Intrinsics.checkNotNullParameter((Object)list, "uris");
        cursor.setNotificationUris(contentResolver, list);
    }
}
