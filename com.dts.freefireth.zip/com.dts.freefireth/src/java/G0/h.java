package G0;

import android.content.Context;
import java.util.Iterator;
import android.database.sqlite.SQLiteException;
import java.io.IOException;
import android.util.Pair;
import java.io.File;
import android.util.Log;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import java.io.Closeable;

public interface h extends Closeable
{
    g R0();
    
    void close();
    
    String getDatabaseName();
    
    void setWriteAheadLoggingEnabled(final boolean p0);
    
    public abstract static class a
    {
        public static final h.a.a b;
        public final int a;
        
        static {
            b = new h.a.a(null);
        }
        
        public a(final int a) {
            this.a = a;
        }
        
        private final void a(final String s) {
            if (!StringsKt.y(s, ":memory:", true)) {
                int n = ((CharSequence)s).length() - 1;
                int i = 0;
                int n2 = 0;
                while (i <= n) {
                    int n3;
                    if (n2 == 0) {
                        n3 = i;
                    }
                    else {
                        n3 = n;
                    }
                    final boolean b = Intrinsics.f((int)((CharSequence)s).charAt(n3), 32) <= 0;
                    if (n2 == 0) {
                        if (!b) {
                            n2 = 1;
                        }
                        else {
                            ++i;
                        }
                    }
                    else {
                        if (!b) {
                            break;
                        }
                        --n;
                    }
                }
                if (((CharSequence)((CharSequence)s).subSequence(i, n + 1).toString()).length() == 0) {
                    return;
                }
                final StringBuilder sb = new StringBuilder();
                sb.append("deleting the database file: ");
                sb.append(s);
                Log.w("SupportSQLite", sb.toString());
                try {
                    G0.b.a(new File(s));
                }
                catch (final Exception ex) {
                    Log.w("SupportSQLite", "delete failed: ", (Throwable)ex);
                }
            }
        }
        
        public void b(final g g) {
            Intrinsics.checkNotNullParameter((Object)g, "db");
        }
        
        public void c(g g) {
            Intrinsics.checkNotNullParameter((Object)g, "db");
            Object o = new StringBuilder();
            ((StringBuilder)o).append("Corruption reported by sqlite on database: ");
            ((StringBuilder)o).append((Object)g);
            ((StringBuilder)o).append(".path");
            Log.e("SupportSQLite", ((StringBuilder)o).toString());
            if (!g.isOpen()) {
                g = (g)g.getPath();
                if (g != null) {
                    this.a((String)g);
                }
                return;
            }
            final Iterable iterable = null;
            while (true) {
                try {
                    Label_0172: {
                        try {
                            o = g.D();
                            break Label_0092;
                        }
                        finally {
                            Label_0103: {
                                break Label_0103;
                                try {
                                    ((Closeable)g).close();
                                    break Label_0172;
                                    iftrue(Label_0153:)(iterable == null);
                                Label_0169:
                                    while (true) {
                                        Block_12: {
                                            break Block_12;
                                            final Iterator iterator;
                                            iftrue(Label_0169:)(!iterator.hasNext());
                                            Block_13: {
                                                break Block_13;
                                                Label_0153: {
                                                    g = (g)g.getPath();
                                                }
                                                iftrue(Label_0169:)(g == null);
                                                this.a((String)g);
                                                break Label_0169;
                                            }
                                            g = (g)((Pair)iterator.next()).second;
                                            Intrinsics.checkNotNullExpressionValue((Object)g, "p.second");
                                            this.a((String)g);
                                            continue;
                                        }
                                        final Iterator iterator = iterable.iterator();
                                        continue;
                                    }
                                }
                                catch (final IOException ex) {}
                            }
                        }
                    }
                    if (o != null) {
                        g = (g)((Iterable)o).iterator();
                        while (((Iterator)g).hasNext()) {
                            o = ((Pair)((Iterator)g).next()).second;
                            Intrinsics.checkNotNullExpressionValue(o, "p.second");
                            this.a((String)o);
                        }
                    }
                    else {
                        g = (g)g.getPath();
                        if (g != null) {
                            this.a((String)g);
                        }
                    }
                }
                catch (final SQLiteException ex2) {
                    continue;
                }
                break;
            }
        }
        
        public abstract void d(final g p0);
        
        public abstract void e(final g p0, final int p1, final int p2);
        
        public void f(final g g) {
            Intrinsics.checkNotNullParameter((Object)g, "db");
        }
        
        public abstract void g(final g p0, final int p1, final int p2);
        
        public static final class a
        {
            private a() {
            }
        }
    }
    
    public static final class b
    {
        public static final h.b.b f;
        public final Context a;
        public final String b;
        public final h.a c;
        public final boolean d;
        public final boolean e;
        
        static {
            f = new h.b.b(null);
        }
        
        public b(final Context a, final String b, final h.a c, final boolean d, final boolean e) {
            Intrinsics.checkNotNullParameter((Object)a, "context");
            Intrinsics.checkNotNullParameter((Object)c, "callback");
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.e = e;
        }
        
        public static final a a(final Context context) {
            return h.b.f.a(context);
        }
        
        public static class a
        {
            private final Context a;
            private String b;
            private h.a c;
            private boolean d;
            private boolean e;
            
            public a(final Context a) {
                Intrinsics.checkNotNullParameter((Object)a, "context");
                this.a = a;
            }
            
            public a a(final boolean e) {
                this.e = e;
                return this;
            }
            
            public h.b b() {
                final h.a c = this.c;
                if (c != null) {
                    if (this.d) {
                        final String b = this.b;
                        if (b == null || ((CharSequence)b).length() == 0) {
                            throw new IllegalArgumentException("Must set a non-null database name to a configuration that uses the no backup directory.");
                        }
                    }
                    return new h.b(this.a, this.b, c, this.d, this.e);
                }
                throw new IllegalArgumentException("Must set a callback to create the configuration.");
            }
            
            public a c(final h.a c) {
                Intrinsics.checkNotNullParameter((Object)c, "callback");
                this.c = c;
                return this;
            }
            
            public a d(final String b) {
                this.b = b;
                return this;
            }
            
            public a e(final boolean d) {
                this.d = d;
                return this;
            }
        }
        
        public static final class b
        {
            private b() {
            }
            
            public final a a(final Context context) {
                Intrinsics.checkNotNullParameter((Object)context, "context");
                return new a(context);
            }
        }
    }
    
    public interface c
    {
        h a(final h.b p0);
    }
}
