package G0;

public interface k extends i
{
    int R();
    
    long x2();
}
