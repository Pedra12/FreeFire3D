package g0;

import f0.c;
import f0.d;

public final class a implements d
{
    public Object a(final c c, final v7.c c2) {
        throw c;
    }
}
