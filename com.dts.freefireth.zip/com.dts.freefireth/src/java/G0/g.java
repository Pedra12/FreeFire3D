package G0;

import android.os.CancellationSignal;
import android.database.Cursor;
import android.content.ContentValues;
import java.util.List;
import java.io.Closeable;

public interface g extends Closeable
{
    List D();
    
    void F0();
    
    void H0(final String p0, final Object[] p1);
    
    void I0();
    
    boolean I1();
    
    void J(final String p0);
    
    int J0(final String p0, final int p1, final ContentValues p2, final String p3, final Object[] p4);
    
    k T(final String p0);
    
    Cursor U0(final String p0);
    
    boolean a2();
    
    void b1();
    
    Cursor f2(final j p0, final CancellationSignal p1);
    
    String getPath();
    
    boolean isOpen();
    
    Cursor j0(final j p0);
    
    void v();
}
