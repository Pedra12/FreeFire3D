package g0;

import f0.c;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.functions.Function1;
import f0.d;

public final class b implements d
{
    private final Function1 a;
    
    public b(final Function1 a) {
        Intrinsics.checkNotNullParameter((Object)a, "produceNewData");
        this.a = a;
    }
    
    public Object a(final c c, final v7.c c2) {
        return this.a.invoke((Object)c);
    }
}
