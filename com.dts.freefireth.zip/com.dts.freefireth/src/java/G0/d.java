package G0;

import kotlin.jvm.internal.Intrinsics;
import java.io.File;
import android.content.Context;

public final class d
{
    public static final d a;
    
    static {
        a = new d();
    }
    
    private d() {
    }
    
    public static final File a(final Context context) {
        Intrinsics.checkNotNullParameter((Object)context, "context");
        final File noBackupFilesDir = context.getNoBackupFilesDir();
        Intrinsics.checkNotNullExpressionValue((Object)noBackupFilesDir, "context.noBackupFilesDir");
        return noBackupFilesDir;
    }
}
