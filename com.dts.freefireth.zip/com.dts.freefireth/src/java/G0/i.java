package G0;

import java.io.Closeable;

public interface i extends Closeable
{
    void D0(final int p0, final long p1);
    
    void K(final int p0, final String p1);
    
    void K0(final int p0, final byte[] p1);
    
    void g0(final int p0, final double p1);
    
    void y1(final int p0);
}
