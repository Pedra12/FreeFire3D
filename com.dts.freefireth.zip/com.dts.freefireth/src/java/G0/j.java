package G0;

public interface j
{
    String a();
    
    void b(final i p0);
}
