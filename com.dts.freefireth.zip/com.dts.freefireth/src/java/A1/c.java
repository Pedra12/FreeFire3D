package a1;

import java.util.concurrent.Executor;
import O7.E;

public interface c
{
    E a();
    
    Executor b();
    
    a c();
    
    void d(final Runnable p0);
}
