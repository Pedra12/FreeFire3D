package a1;

import O7.j0;
import android.os.Looper;
import java.util.concurrent.Executor;
import android.os.Handler;
import O7.E;
import Z0.C;

public class d implements c
{
    private final C a;
    private final E b;
    final Handler c;
    private final Executor d;
    
    public d(final Executor executor) {
        this.c = new Handler(Looper.getMainLooper());
        this.d = (Executor)new Executor() {
            final d a;
            
            public void execute(final Runnable runnable) {
                this.a.c.post(runnable);
            }
        };
        final C a = new C(executor);
        this.a = a;
        this.b = j0.b((Executor)a);
    }
    
    @Override
    public E a() {
        return this.b;
    }
    
    @Override
    public Executor b() {
        return this.d;
    }
    
    public C e() {
        return this.a;
    }
}
