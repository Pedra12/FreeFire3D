package a0;

import android.widget.Filter$FilterResults;
import android.database.Cursor;
import android.widget.Filter;

class b extends Filter
{
    a a;
    
    b(final a a) {
        this.a = a;
    }
    
    public CharSequence convertResultToString(final Object o) {
        return this.a.c((Cursor)o);
    }
    
    protected Filter$FilterResults performFiltering(final CharSequence charSequence) {
        final Cursor d = this.a.d(charSequence);
        final Filter$FilterResults filter$FilterResults = new Filter$FilterResults();
        if (d != null) {
            filter$FilterResults.count = d.getCount();
            filter$FilterResults.values = d;
            return filter$FilterResults;
        }
        filter$FilterResults.count = 0;
        filter$FilterResults.values = null;
        return filter$FilterResults;
    }
    
    protected void publishResults(final CharSequence charSequence, final Filter$FilterResults filter$FilterResults) {
        final Cursor b = this.a.b();
        final Object values = filter$FilterResults.values;
        if (values != null && values != b) {
            this.a.a((Cursor)values);
        }
    }
    
    interface a
    {
        void a(final Cursor p0);
        
        Cursor b();
        
        CharSequence c(final Cursor p0);
        
        Cursor d(final CharSequence p0);
    }
}
