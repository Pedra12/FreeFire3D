package b;

abstract class c
{
}
