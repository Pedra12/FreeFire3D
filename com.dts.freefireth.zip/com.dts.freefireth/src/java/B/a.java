package b;

public final class a
{
    public final StackTraceElement a() {
        return b.a((Throwable)new Exception(), c.class.getSimpleName());
    }
}
