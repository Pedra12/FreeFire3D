package x3;

import w3.e;
import com.google.android.gms.tasks.OnCompleteListener;
import w3.e$a;
import java.util.Iterator;
import w3.a;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.common.api.internal.BasePendingResult;
import java.util.Map$Entry;
import java.util.HashMap;
import com.google.android.gms.common.api.Status;
import j$.util.DesugarCollections;
import java.util.WeakHashMap;
import java.util.Map;

public final class u
{
    private final Map a;
    private final Map b;
    
    public u() {
        this.a = DesugarCollections.synchronizedMap((java.util.Map<Object, Object>)new WeakHashMap());
        this.b = DesugarCollections.synchronizedMap((java.util.Map<Object, Object>)new WeakHashMap());
    }
    
    private final void h(final boolean b, final Status status) {
        final Map a = this.a;
        synchronized (a) {
            final HashMap hashMap = new HashMap(this.a);
            monitorexit(a);
            final Map b2 = this.b;
            synchronized (b2) {
                final HashMap hashMap2 = new HashMap(this.b);
                monitorexit(b2);
                for (final Map$Entry map$Entry : ((Map)hashMap).entrySet()) {
                    if (b || (boolean)map$Entry.getValue()) {
                        ((BasePendingResult)map$Entry.getKey()).f(status);
                    }
                }
                for (final Map$Entry map$Entry2 : ((Map)hashMap2).entrySet()) {
                    if (b || (boolean)map$Entry2.getValue()) {
                        ((TaskCompletionSource)map$Entry2.getKey()).d((Exception)new a(status));
                    }
                }
            }
        }
    }
    
    final void c(final BasePendingResult basePendingResult, final boolean b) {
        this.a.put((Object)basePendingResult, (Object)b);
        ((e)basePendingResult).c((e$a)new s(this, basePendingResult));
    }
    
    final void d(final TaskCompletionSource taskCompletionSource, final boolean b) {
        this.b.put((Object)taskCompletionSource, (Object)b);
        taskCompletionSource.a().addOnCompleteListener((OnCompleteListener)new t(this, taskCompletionSource));
    }
    
    final void e(final int n, final String s) {
        final StringBuilder sb = new StringBuilder("The connection to Google Play services was lost");
        if (n == 1) {
            sb.append(" due to service disconnection.");
        }
        else if (n == 3) {
            sb.append(" due to dead object exception.");
        }
        if (s != null) {
            sb.append(" Last reason for disconnect: ");
            sb.append(s);
        }
        this.h(true, new Status(20, sb.toString()));
    }
    
    public final void f() {
        this.h(false, f.p);
    }
    
    final boolean g() {
        return !this.a.isEmpty() || !this.b.isEmpty();
    }
}
