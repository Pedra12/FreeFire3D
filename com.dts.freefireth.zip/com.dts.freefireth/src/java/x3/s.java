package x3;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.BasePendingResult;
import w3.e$a;

final class s implements e$a
{
    final BasePendingResult a;
    final u b;
    
    s(final u b, final BasePendingResult a) {
        this.a = a;
        this.b = b;
    }
    
    public final void a(final Status status) {
        u.a(this.b).remove((Object)this.a);
    }
}
