package x3;

import java.lang.ref.Reference;
import android.content.Intent;
import java.io.PrintWriter;
import java.io.FileDescriptor;
import android.app.Activity;
import android.os.Bundle;
import androidx.fragment.app.FragmentManager;
import java.lang.ref.WeakReference;
import androidx.fragment.app.h;
import java.util.WeakHashMap;
import com.google.android.gms.common.api.internal.LifecycleFragment;
import androidx.fragment.app.Fragment;

public final class k0 extends Fragment implements LifecycleFragment
{
    private static final WeakHashMap H1;
    private final j0 G1;
    
    static {
        H1 = new WeakHashMap();
    }
    
    public k0() {
        this.G1 = new j0();
    }
    
    public static k0 J1(final h h) {
        final FragmentManager g0 = h.g0();
        final WeakHashMap h2 = k0.H1;
        final WeakReference weakReference = (WeakReference)h2.get((Object)h);
        if (weakReference != null) {
            final k0 k0 = (k0)((Reference)weakReference).get();
            if (k0 != null) {
                return k0;
            }
        }
        try {
            final k0 k2 = (k0)g0.g0("SLifecycleFragmentImpl");
            k0 k3 = null;
            Label_0083: {
                if (k2 != null) {
                    k3 = k2;
                    if (!k2.g0()) {
                        break Label_0083;
                    }
                }
                k3 = new k0();
                g0.n().d((Fragment)k3, "SLifecycleFragmentImpl").h();
            }
            h2.put((Object)h, (Object)new WeakReference((Object)k3));
            return k3;
        }
        catch (final ClassCastException ex) {
            throw new IllegalStateException("Fragment with tag SLifecycleFragmentImpl is not a SupportLifecycleFragmentImpl", (Throwable)ex);
        }
    }
    
    public final void L0() {
        super.L0();
        this.G1.e();
    }
    
    public final void M0(final Bundle bundle) {
        super.M0(bundle);
        this.G1.g(bundle);
    }
    
    public final void N0() {
        super.N0();
        this.G1.d();
    }
    
    public final void O0() {
        super.O0();
        this.G1.h();
    }
    
    public final x3.h a(final String s, final Class clazz) {
        return this.G1.a(s, clazz);
    }
    
    public final Activity c() {
        return (Activity)this.n();
    }
    
    public final void d(final String s, final x3.h h) {
        this.G1.b(s, h);
    }
    
    public final void i(final String s, final FileDescriptor fileDescriptor, final PrintWriter printWriter, final String[] array) {
        super.i(s, fileDescriptor, printWriter, array);
        this.G1.j(s, fileDescriptor, printWriter, array);
    }
    
    public final void l0(final int n, final int n2, final Intent intent) {
        super.l0(n, n2, intent);
        this.G1.f(n, n2, intent);
    }
    
    public final void q0(final Bundle bundle) {
        super.q0(bundle);
        this.G1.c(bundle);
    }
    
    public final void v0() {
        super.v0();
        this.G1.i();
    }
}
