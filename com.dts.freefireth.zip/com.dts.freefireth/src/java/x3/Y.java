package x3;

final class y implements a
{
    final f a;
    
    y(final f a) {
        this.a = a;
    }
    
    @Override
    public final void a(final boolean b) {
        final f a = this.a;
        f.o(a).sendMessage(f.o(a).obtainMessage(1, (Object)b));
    }
}
