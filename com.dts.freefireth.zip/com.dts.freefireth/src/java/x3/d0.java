package x3;

import android.app.Dialog;
import com.google.android.gms.common.api.internal.zabu;

final class d0 extends zabu
{
    final Dialog a;
    final e0 b;
    
    d0(final e0 b, final Dialog a) {
        this.a = a;
        this.b = b;
    }
    
    public final void a() {
        f0.r(this.b.b);
        if (this.a.isShowing()) {
            this.a.dismiss();
        }
    }
}
