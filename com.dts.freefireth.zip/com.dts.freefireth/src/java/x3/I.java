package x3;

public abstract class i
{
}
