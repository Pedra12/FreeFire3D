package x3;

import java.util.Iterator;
import android.app.Application;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import android.util.Log;
import android.os.Message;
import com.google.android.gms.common.internal.RootTelemetryConfiguration;
import z3.l;
import java.util.Collection;
import com.google.android.gms.common.internal.MethodInvocation;
import com.google.android.gms.common.api.internal.a;
import com.google.android.gms.common.internal.c;
import com.google.android.gms.common.internal.d;
import z3.k;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.OnCompleteListener;
import java.util.concurrent.Executor;
import j$.util.Objects;
import com.google.android.gms.tasks.TaskCompletionSource;
import z3.n;
import com.google.android.gms.common.api.GoogleApi;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.util.i;
import com.google.android.gms.common.GoogleApiAvailabilityLight;
import d4.g;
import y.b;
import j$.util.concurrent.ConcurrentHashMap;
import android.os.Looper;
import android.os.Handler;
import java.util.Set;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import z3.u;
import com.google.android.gms.common.GoogleApiAvailability;
import android.content.Context;
import z3.o;
import com.google.android.gms.common.internal.TelemetryData;
import com.google.android.gms.common.api.Status;
import android.os.Handler$Callback;

public class f implements Handler$Callback
{
    public static final Status p;
    private static final Status q;
    private static final Object r;
    private static f s;
    private static volatile boolean t;
    private long a;
    private boolean b;
    private TelemetryData c;
    private o d;
    private final Context e;
    private final GoogleApiAvailability f;
    private final u g;
    private final AtomicInteger h;
    private final AtomicInteger i;
    private final Map j;
    private v k;
    private final Set l;
    private final Set m;
    private final Handler n;
    private volatile boolean o;
    
    static {
        p = new Status(4, "Sign-out occurred while this API call was in progress.");
        q = new Status(4, "The user must be signed in to make this API call.");
        r = new Object();
        f.t = false;
    }
    
    private f(final Context e, final Looper looper, final GoogleApiAvailability f) {
        this.a = 10000L;
        this.b = false;
        this.h = new AtomicInteger(1);
        this.i = new AtomicInteger(0);
        this.j = (Map)new ConcurrentHashMap(5, 0.75f, 1);
        this.k = null;
        this.l = (Set)new b();
        this.m = (Set)new b();
        this.o = true;
        this.e = e;
        final g n = new g(looper, (Handler$Callback)this);
        this.n = (Handler)n;
        this.f = f;
        this.g = new u((GoogleApiAvailabilityLight)f);
        if (com.google.android.gms.common.util.i.a(e)) {
            this.o = false;
        }
        ((Handler)n).sendMessage(((Handler)n).obtainMessage(6));
    }
    
    public static void a() {
        final Object r;
        monitorenter(r = f.r);
        Label_0047: {
            try {
                final f s = f.s;
                if (s != null) {
                    s.i.incrementAndGet();
                    final Handler n = s.n;
                    n.sendMessageAtFrontOfQueue(n.obtainMessage(10));
                }
                break Label_0047;
            }
            finally {
                monitorexit(r);
                monitorexit(r);
            }
        }
    }
    
    private static Status g(final x3.b b, final ConnectionResult connectionResult) {
        final String b2 = b.b();
        final String value = String.valueOf((Object)connectionResult);
        final StringBuilder sb = new StringBuilder();
        sb.append("API: ");
        sb.append(b2);
        sb.append(" is not available on this device. Connection failed with: ");
        sb.append(value);
        return new Status(connectionResult, sb.toString());
    }
    
    private final D h(final GoogleApi googleApi) {
        final Map j = this.j;
        final x3.b f = googleApi.f();
        D d;
        if ((d = (D)j.get((Object)f)) == null) {
            d = new D(this, googleApi);
            this.j.put((Object)f, (Object)d);
        }
        if (d.a()) {
            this.m.add((Object)f);
        }
        d.F();
        return d;
    }
    
    private final o i() {
        if (this.d == null) {
            this.d = z3.n.a(this.e);
        }
        return this.d;
    }
    
    private final void j() {
        final TelemetryData c = this.c;
        if (c != null) {
            if (c.I2() > 0 || this.e()) {
                this.i().b(c);
            }
            this.c = null;
        }
    }
    
    private final void k(final TaskCompletionSource taskCompletionSource, final int n, final GoogleApi googleApi) {
        if (n != 0) {
            final L a = L.a(this, n, googleApi.f());
            if (a != null) {
                final Task a2 = taskCompletionSource.a();
                final Handler n2 = this.n;
                Objects.requireNonNull(n2);
                a2.addOnCompleteListener((Executor)new x(n2), (OnCompleteListener)a);
            }
        }
    }
    
    public static f u() {
        final Object r = f.r;
        synchronized (r) {
            k.m(f.s, "Must guarantee manager is non-null before using getInstance");
            return f.s;
        }
    }
    
    public static f v(final Context context) {
        final Object r;
        monitorenter(r = f.r);
        Label_0080: {
            try {
                if (f.s != null) {
                    break Label_0080;
                }
                f.s = new f(context.getApplicationContext(), d.b().getLooper(), GoogleApiAvailability.getInstance());
                if (f.t) {
                    final Handler n = f.s.n;
                    Objects.requireNonNull(n);
                    c.n0((Executor)new x(n));
                }
                break Label_0080;
            }
            finally {
                monitorexit(r);
                final f s = f.s;
                monitorexit(r);
                return s;
            }
        }
    }
    
    public final void C(final GoogleApi googleApi, final int n, final a a) {
        this.n.sendMessage(this.n.obtainMessage(4, (Object)new N(new X(n, a), this.i.get(), googleApi)));
    }
    
    public final void D(final GoogleApi googleApi, final int n, final p p5, final TaskCompletionSource taskCompletionSource, final x3.n n2) {
        this.k(taskCompletionSource, p5.d(), googleApi);
        this.n.sendMessage(this.n.obtainMessage(4, (Object)new N(new Y(n, p5, taskCompletionSource, n2), this.i.get(), googleApi)));
    }
    
    final void E(final MethodInvocation methodInvocation, final int n, final long n2, final int n3) {
        this.n.sendMessage(this.n.obtainMessage(18, (Object)new M(methodInvocation, n, n2, n3)));
    }
    
    public final void F(final ConnectionResult connectionResult, final int n) {
        if (!this.f(connectionResult, n)) {
            final Handler n2 = this.n;
            n2.sendMessage(n2.obtainMessage(5, n, 0, (Object)connectionResult));
        }
    }
    
    public final void G() {
        final Handler n = this.n;
        n.sendMessage(n.obtainMessage(3));
    }
    
    public final void H(final GoogleApi googleApi) {
        final Handler n = this.n;
        n.sendMessage(n.obtainMessage(7, (Object)googleApi));
    }
    
    public final void b(final v k) {
        final Object r;
        monitorenter(r = x3.f.r);
        Label_0037: {
            try {
                if (this.k != k) {
                    this.k = k;
                    this.l.clear();
                }
                break Label_0037;
            }
            finally {
                monitorexit(r);
                this.l.addAll((Collection)k.t());
                monitorexit(r);
            }
        }
    }
    
    final void c(final v v) {
        final Object r;
        monitorenter(r = x3.f.r);
        Label_0037: {
            try {
                if (this.k == v) {
                    this.k = null;
                    this.l.clear();
                }
                break Label_0037;
            }
            finally {
                monitorexit(r);
                monitorexit(r);
            }
        }
    }
    
    final boolean e() {
        if (this.b) {
            return false;
        }
        final RootTelemetryConfiguration a = z3.l.b().a();
        if (a != null && !a.K2()) {
            return false;
        }
        final int a2 = this.g.a(this.e, 203400000);
        return a2 == -1 || a2 == 0;
    }
    
    final boolean f(final ConnectionResult connectionResult, final int n) {
        return this.f.zah(this.e, connectionResult, n);
    }
    
    public final boolean handleMessage(final Message message) {
        final int what = message.what;
        long a = 300000L;
        final D d = null;
        switch (what) {
            default: {
                final StringBuilder sb = new StringBuilder();
                sb.append("Unknown message id: ");
                sb.append(what);
                Log.w("GoogleApiManager", sb.toString());
                return false;
            }
            case 19: {
                this.b = false;
                break;
            }
            case 18: {
                final M m = (M)message.obj;
                if (m.c == 0L) {
                    this.i().b(new TelemetryData(m.b, Arrays.asList((Object[])new MethodInvocation[] { m.a })));
                    break;
                }
                final TelemetryData c = this.c;
                if (c != null) {
                    final List j2 = c.J2();
                    if (c.I2() == m.b && (j2 == null || j2.size() < m.d)) {
                        this.c.K2(m.a);
                    }
                    else {
                        this.n.removeMessages(17);
                        this.j();
                    }
                }
                if (this.c == null) {
                    final ArrayList list = new ArrayList();
                    list.add((Object)m.a);
                    this.c = new TelemetryData(m.b, (List)list);
                    final Handler n = this.n;
                    n.sendMessageDelayed(n.obtainMessage(17), m.c);
                    break;
                }
                break;
            }
            case 17: {
                this.j();
                break;
            }
            case 16: {
                final E e = (E)message.obj;
                if (this.j.containsKey((Object)E.b(e))) {
                    D.D((D)this.j.get((Object)E.b(e)), e);
                    break;
                }
                break;
            }
            case 15: {
                final E e2 = (E)message.obj;
                if (this.j.containsKey((Object)E.b(e2))) {
                    D.C((D)this.j.get((Object)E.b(e2)), e2);
                    break;
                }
                break;
            }
            case 14: {
                android.support.v4.media.session.b.a(message.obj);
                throw null;
            }
            case 12: {
                if (this.j.containsKey(message.obj)) {
                    ((D)this.j.get(message.obj)).b();
                    break;
                }
                break;
            }
            case 11: {
                if (this.j.containsKey(message.obj)) {
                    ((D)this.j.get(message.obj)).N();
                    break;
                }
                break;
            }
            case 10: {
                final Iterator iterator = this.m.iterator();
                while (iterator.hasNext()) {
                    final D d2 = (D)this.j.remove((Object)iterator.next());
                    if (d2 != null) {
                        d2.M();
                    }
                }
                this.m.clear();
                break;
            }
            case 9: {
                if (this.j.containsKey(message.obj)) {
                    ((D)this.j.get(message.obj)).L();
                    break;
                }
                break;
            }
            case 7: {
                this.h((GoogleApi)message.obj);
                break;
            }
            case 6: {
                if (!(this.e.getApplicationContext() instanceof Application)) {
                    break;
                }
                x3.c.c((Application)this.e.getApplicationContext());
                x3.c.b().a((x3.c.a)new y(this));
                if (!x3.c.b().e(true)) {
                    this.a = 300000L;
                    break;
                }
                break;
            }
            case 5: {
                final int arg1 = message.arg1;
                final ConnectionResult connectionResult = (ConnectionResult)message.obj;
                final Iterator iterator2 = this.j.values().iterator();
                D d3;
                do {
                    d3 = d;
                    if (!iterator2.hasNext()) {
                        break;
                    }
                    d3 = (D)iterator2.next();
                } while (d3.s() != arg1);
                if (d3 == null) {
                    final StringBuilder sb2 = new StringBuilder();
                    sb2.append("Could not find API instance ");
                    sb2.append(arg1);
                    sb2.append(" while trying to fail enqueued calls.");
                    Log.wtf("GoogleApiManager", sb2.toString(), (Throwable)new Exception());
                    break;
                }
                if (connectionResult.J2() == 13) {
                    final String errorString = this.f.getErrorString(connectionResult.J2());
                    final String k2 = connectionResult.K2();
                    final StringBuilder sb3 = new StringBuilder();
                    sb3.append("Error resolution was canceled by the user, original error message: ");
                    sb3.append(errorString);
                    sb3.append(": ");
                    sb3.append(k2);
                    D.z(d3, new Status(17, sb3.toString()));
                    break;
                }
                D.z(d3, g(D.x(d3), connectionResult));
                break;
            }
            case 4:
            case 8:
            case 13: {
                final N n2 = (N)message.obj;
                D h;
                if ((h = (D)this.j.get((Object)n2.c.f())) == null) {
                    h = this.h(n2.c);
                }
                if (h.a() && this.i.get() != n2.b) {
                    n2.a.a(x3.f.p);
                    h.M();
                    break;
                }
                h.G(n2.a);
                break;
            }
            case 3: {
                for (final D d4 : this.j.values()) {
                    d4.E();
                    d4.F();
                }
                break;
            }
            case 2: {
                final b0 b0 = (b0)message.obj;
                for (final x3.b b2 : b0.b()) {
                    final D d5 = (D)this.j.get((Object)b2);
                    if (d5 == null) {
                        b0.c(b2, new ConnectionResult(13), null);
                        break;
                    }
                    if (d5.P()) {
                        b0.c(b2, ConnectionResult.f, d5.w().e());
                    }
                    else {
                        final ConnectionResult u = d5.u();
                        if (u != null) {
                            b0.c(b2, u, null);
                        }
                        else {
                            d5.K(b0);
                            d5.F();
                        }
                    }
                }
                break;
            }
            case 1: {
                if (message.obj) {
                    a = 10000L;
                }
                this.a = a;
                this.n.removeMessages(12);
                for (final x3.b b3 : this.j.keySet()) {
                    final Handler n3 = this.n;
                    n3.sendMessageDelayed(n3.obtainMessage(12, (Object)b3), this.a);
                }
                break;
            }
        }
        return true;
    }
    
    public final int l() {
        return this.h.getAndIncrement();
    }
    
    final D t(final x3.b b) {
        return (D)this.j.get((Object)b);
    }
    
    public final Task x(final Iterable iterable) {
        final b0 b0 = new b0(iterable);
        this.n.sendMessage(this.n.obtainMessage(2, (Object)b0));
        return b0.a();
    }
}
