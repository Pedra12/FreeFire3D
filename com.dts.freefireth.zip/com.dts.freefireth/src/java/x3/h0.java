package x3;

import java.lang.ref.Reference;
import android.os.Bundle;
import android.content.Intent;
import java.io.PrintWriter;
import java.io.FileDescriptor;
import java.lang.ref.WeakReference;
import android.app.Activity;
import java.util.WeakHashMap;
import com.google.android.gms.common.api.internal.LifecycleFragment;
import android.app.Fragment;

public final class h0 extends Fragment implements LifecycleFragment
{
    private static final WeakHashMap b;
    private final j0 a;
    
    static {
        b = new WeakHashMap();
    }
    
    public h0() {
        this.a = new j0();
    }
    
    public static h0 b(final Activity activity) {
        final WeakHashMap b = h0.b;
        final WeakReference weakReference = (WeakReference)b.get((Object)activity);
        if (weakReference != null) {
            final h0 h0 = (h0)((Reference)weakReference).get();
            if (h0 != null) {
                return h0;
            }
        }
        try {
            final h0 h2 = (h0)activity.getFragmentManager().findFragmentByTag("LifecycleFragmentImpl");
            h0 h3 = null;
            Label_0085: {
                if (h2 != null) {
                    h3 = h2;
                    if (!h2.isRemoving()) {
                        break Label_0085;
                    }
                }
                h3 = new h0();
                activity.getFragmentManager().beginTransaction().add((Fragment)h3, "LifecycleFragmentImpl").commitAllowingStateLoss();
            }
            b.put((Object)activity, (Object)new WeakReference((Object)h3));
            return h3;
        }
        catch (final ClassCastException ex) {
            throw new IllegalStateException("Fragment with tag LifecycleFragmentImpl is not a LifecycleFragmentImpl", (Throwable)ex);
        }
    }
    
    public final h a(final String s, final Class clazz) {
        return this.a.a(s, clazz);
    }
    
    public final Activity c() {
        return this.getActivity();
    }
    
    public final void d(final String s, final h h) {
        this.a.b(s, h);
    }
    
    public final void dump(final String s, final FileDescriptor fileDescriptor, final PrintWriter printWriter, final String[] array) {
        super.dump(s, fileDescriptor, printWriter, array);
        this.a.j(s, fileDescriptor, printWriter, array);
    }
    
    public final void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        this.a.f(n, n2, intent);
    }
    
    public final void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.a.c(bundle);
    }
    
    public final void onDestroy() {
        super.onDestroy();
        this.a.i();
    }
    
    public final void onResume() {
        super.onResume();
        this.a.e();
    }
    
    public final void onSaveInstanceState(final Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.a.g(bundle);
    }
    
    public final void onStart() {
        super.onStart();
        this.a.d();
    }
    
    public final void onStop() {
        super.onStop();
        this.a.h();
    }
}
