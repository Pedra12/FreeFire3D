package x3;

import com.google.android.gms.common.Feature;

public abstract class J extends a0
{
    public J(final int n) {
        super(n);
    }
    
    public abstract boolean f(final D p0);
    
    public abstract Feature[] g(final D p0);
}
