package x3;

import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.common.api.a$b;
import com.google.android.gms.common.Feature;

public abstract class k
{
    public abstract void a();
    
    public abstract Feature[] b();
    
    protected abstract void c(final a$b p0, final TaskCompletionSource p1);
    
    public abstract boolean d();
}
