package x3;

import z3.i;
import com.google.android.gms.common.Feature;

final class E
{
    private final b a = a;
    private final Feature b = b;
    
    @Override
    public final boolean equals(final Object o) {
        if (o != null && o instanceof E) {
            final E e = (E)o;
            if (i.a(this.a, e.a) && i.a(this.b, e.b)) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public final int hashCode() {
        return i.b(this.a, this.b);
    }
    
    @Override
    public final String toString() {
        return i.c(this).a("key", this.a).a("feature", this.b).toString();
    }
}
