package x3;

import com.google.android.gms.common.api.Status;
import android.os.RemoteException;

public abstract class a0
{
    public final int a;
    
    public a0(final int a) {
        this.a = a;
    }
    
    public abstract void a(final Status p0);
    
    public abstract void b(final Exception p0);
    
    public abstract void c(final D p0);
    
    public abstract void d(final u p0, final boolean p1);
}
