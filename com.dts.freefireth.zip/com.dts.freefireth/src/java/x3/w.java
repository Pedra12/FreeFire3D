package x3;

import android.os.DeadObjectException;
import android.os.RemoteException;
import w3.a;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.TaskCompletionSource;

abstract class W extends J
{
    protected final TaskCompletionSource b;
    
    public W(final int n, final TaskCompletionSource b) {
        super(n);
        this.b = b;
    }
    
    @Override
    public final void a(final Status status) {
        this.b.d((Exception)new a(status));
    }
    
    @Override
    public final void b(final Exception ex) {
        this.b.d(ex);
    }
    
    @Override
    public final void c(final D d) {
        try {
            this.h(d);
        }
        catch (final RuntimeException ex) {
            this.b.d((Exception)ex);
        }
        catch (final RemoteException ex2) {
            this.a(a0.e(ex2));
        }
        catch (final DeadObjectException ex3) {
            this.a(a0.e((RemoteException)ex3));
            throw ex3;
        }
    }
    
    protected abstract void h(final D p0);
}
