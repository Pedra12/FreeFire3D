package x3;

import androidx.fragment.app.h;
import z3.k;
import android.app.Activity;

public class g
{
    private final Object a;
    
    public g(final Activity a) {
        k.m(a, "Activity must not be null");
        this.a = a;
    }
    
    public final boolean a() {
        return this.a instanceof h;
    }
    
    public final boolean b() {
        return this.a instanceof Activity;
    }
    
    public final Activity c() {
        return (Activity)this.a;
    }
    
    public final h d() {
        return (h)this.a;
    }
}
