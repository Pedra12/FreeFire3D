package x3;

import w3.i;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.c;
import com.google.android.gms.common.api.internal.BasePendingResult;

public class o extends BasePendingResult
{
    public o(final c c) {
        super(c);
    }
}
