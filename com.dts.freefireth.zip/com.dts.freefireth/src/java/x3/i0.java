package x3;

import android.os.Bundle;
import j$.util.Objects;

final class i0 implements Runnable
{
    final h a;
    final String b;
    final j0 c;
    
    i0(final j0 c, final h a, final String b) {
        this.a = a;
        this.b = b;
        Objects.requireNonNull(c);
        this.c = c;
    }
    
    public final void run() {
        final j0 c = this.c;
        if (c.k() > 0) {
            final h a = this.a;
            Bundle bundle;
            if (c.l() != null) {
                bundle = c.l().getBundle(this.b);
            }
            else {
                bundle = null;
            }
            a.f(bundle);
        }
        if (c.k() >= 2) {
            this.a.j();
        }
        if (c.k() >= 3) {
            this.a.h();
        }
        if (c.k() >= 4) {
            this.a.k();
        }
        if (c.k() >= 5) {
            this.a.g();
        }
    }
}
