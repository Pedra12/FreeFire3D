package x3;

final class z implements Runnable
{
    final D a;
    
    z(final D a) {
        this.a = a;
    }
    
    public final void run() {
        D.A(this.a);
    }
}
