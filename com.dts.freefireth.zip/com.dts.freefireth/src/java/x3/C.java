package x3;

import android.content.res.Configuration;
import android.os.Bundle;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager$RunningAppProcessInfo;
import com.google.android.gms.common.util.q;
import android.content.ComponentCallbacks;
import android.app.Application;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import android.content.ComponentCallbacks2;
import android.app.Application$ActivityLifecycleCallbacks;

public final class c implements Application$ActivityLifecycleCallbacks, ComponentCallbacks2
{
    private static final c e;
    private final AtomicBoolean a;
    private final AtomicBoolean b;
    private final ArrayList c;
    private boolean d;
    
    static {
        e = new c();
    }
    
    private c() {
        this.a = new AtomicBoolean();
        this.b = new AtomicBoolean();
        this.c = new ArrayList();
        this.d = false;
    }
    
    public static c b() {
        return c.e;
    }
    
    public static void c(final Application application) {
        final c e = c.e;
        final c c;
        monitorenter(c = e);
        Label_0037: {
            try {
                if (!e.d) {
                    application.registerActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)e);
                    application.registerComponentCallbacks((ComponentCallbacks)e);
                    e.d = true;
                }
                break Label_0037;
            }
            finally {
                monitorexit(c);
                monitorexit(c);
            }
        }
    }
    
    private final void f(final boolean b) {
        final c e;
        monitorenter(e = x3.c.e);
        Label_0060: {
            try {
                final ArrayList c = this.c;
                final int size = c.size();
                int i = 0;
                while (i < size) {
                    final Object value = c.get(i);
                    ++i;
                    ((a)value).a(b);
                }
                break Label_0060;
            }
            finally {
                monitorexit(e);
                monitorexit(e);
            }
        }
    }
    
    public void a(final a a) {
        final c e = x3.c.e;
        synchronized (e) {
            this.c.add((Object)a);
        }
    }
    
    public boolean d() {
        return this.a.get();
    }
    
    public boolean e(final boolean b) {
        final AtomicBoolean b2 = this.b;
        if (!b2.get()) {
            if (q.b()) {
                return b;
            }
            final ActivityManager$RunningAppProcessInfo activityManager$RunningAppProcessInfo = new ActivityManager$RunningAppProcessInfo();
            ActivityManager.getMyMemoryState(activityManager$RunningAppProcessInfo);
            if (!b2.getAndSet(true) && activityManager$RunningAppProcessInfo.importance > 100) {
                this.a.set(true);
            }
        }
        return this.d();
    }
    
    public final void onActivityCreated(final Activity activity, final Bundle bundle) {
        final AtomicBoolean b = this.b;
        final boolean compareAndSet = this.a.compareAndSet(true, false);
        b.set(true);
        if (compareAndSet) {
            this.f(false);
        }
    }
    
    public final void onActivityDestroyed(final Activity activity) {
    }
    
    public final void onActivityPaused(final Activity activity) {
    }
    
    public final void onActivityResumed(final Activity activity) {
        final AtomicBoolean b = this.b;
        final boolean compareAndSet = this.a.compareAndSet(true, false);
        b.set(true);
        if (compareAndSet) {
            this.f(false);
        }
    }
    
    public final void onActivitySaveInstanceState(final Activity activity, final Bundle bundle) {
    }
    
    public final void onActivityStarted(final Activity activity) {
    }
    
    public final void onActivityStopped(final Activity activity) {
    }
    
    public final void onConfigurationChanged(final Configuration configuration) {
    }
    
    public final void onLowMemory() {
    }
    
    public final void onTrimMemory(final int n) {
        if (n == 20 && this.a.compareAndSet(false, true)) {
            this.b.set(true);
            this.f(true);
        }
    }
    
    public interface a
    {
        void a(final boolean p0);
    }
}
