package x3;

import android.os.Bundle;
import android.os.Looper;
import com.google.android.gms.common.internal.b$e;
import B3.e;
import com.google.android.gms.common.internal.b$c;
import android.app.PendingIntent;
import android.util.Log;
import android.os.Message;
import android.os.DeadObjectException;
import android.os.RemoteException;
import com.google.android.gms.common.api.a$b;
import com.google.android.gms.tasks.TaskCompletionSource;
import java.util.Collection;
import z3.k;
import com.google.android.gms.common.api.Status;
import z3.i;
import y.a;
import java.util.Iterator;
import com.google.android.gms.common.Feature;
import w3.j;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import com.google.android.gms.common.api.GoogleApi;
import com.google.android.gms.common.ConnectionResult;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.google.android.gms.common.api.a$f;
import java.util.Queue;
import com.google.android.gms.common.api.c$b;
import com.google.android.gms.common.api.c$a;

public final class D implements c$a, c$b
{
    private final Queue g;
    private final a$f h;
    private final b i;
    private final u j;
    private final Set k;
    private final Map l;
    private final int m;
    private final T n;
    private boolean o;
    private final List p;
    private ConnectionResult q;
    private int r;
    final f s;
    
    public D(final f s, final GoogleApi googleApi) {
        this.s = s;
        this.g = (Queue)new LinkedList();
        this.k = (Set)new HashSet();
        this.l = (Map)new HashMap();
        this.p = (List)new ArrayList();
        this.q = null;
        this.r = 0;
        final a$f s2 = googleApi.s(f.o(s).getLooper(), this);
        this.h = s2;
        this.i = googleApi.f();
        this.j = new u();
        this.m = googleApi.r();
        if (s2.n()) {
            this.n = googleApi.t(f.n(s), f.o(s));
            return;
        }
        this.n = null;
    }
    
    private final Feature c(final Feature[] array) {
        if (array != null) {
            if (array.length != 0) {
                final Feature[] l = this.h.l();
                final int n = 0;
                Feature[] array2;
                if ((array2 = l) == null) {
                    array2 = new Feature[0];
                }
                final a a = new a(array2.length);
                for (int i = 0; i < array2.length; ++i) {
                    final Feature feature = array2[i];
                    ((Map)a).put(feature.getName(), feature.J2());
                }
                for (int length = array.length, j = n; j < length; ++j) {
                    final Feature feature2 = array[j];
                    final Long n2 = (Long)((Map)a).get(feature2.getName());
                    if (n2 == null || n2 < feature2.J2()) {
                        return feature2;
                    }
                }
            }
        }
        return null;
    }
    
    private final void d(final ConnectionResult connectionResult) {
        for (final b0 b0 : this.k) {
            String e;
            if (z3.i.a(connectionResult, ConnectionResult.f)) {
                e = this.h.e();
            }
            else {
                e = null;
            }
            b0.c(this.i, connectionResult, e);
        }
        this.k.clear();
    }
    
    private final void e(final Status status) {
        z3.k.d(f.o(this.s));
        this.h(status, null, false);
    }
    
    private final void h(final Status status, final Exception ex, final boolean b) {
        z3.k.d(f.o(this.s));
        int n = true ? 1 : 0;
        final boolean b2 = status == null;
        if (ex != null) {
            n = (false ? 1 : 0);
        }
        if ((b2 ? 1 : 0) != n) {
            final Iterator iterator = ((Collection)this.g).iterator();
            while (iterator.hasNext()) {
                final a0 a0 = (a0)iterator.next();
                if (!b || a0.a == 2) {
                    if (status != null) {
                        a0.a(status);
                    }
                    else {
                        a0.b(ex);
                    }
                    iterator.remove();
                }
            }
            return;
        }
        throw new IllegalArgumentException("Status XOR exception should be null");
    }
    
    private final void i() {
        final ArrayList list = new ArrayList((Collection)this.g);
        for (int size = ((List)list).size(), i = 0; i < size; ++i) {
            final a0 a0 = (a0)((List)list).get(i);
            if (!this.h.i()) {
                break;
            }
            if (this.p(a0)) {
                ((Collection)this.g).remove((Object)a0);
            }
        }
    }
    
    private final void j() {
        this.E();
        this.d(ConnectionResult.f);
        this.o();
        final Iterator iterator = this.l.values().iterator();
        while (iterator.hasNext()) {
            Object o = iterator.next();
            if (this.c(((O)o).a.b()) == null) {
                try {
                    final x3.k a = ((O)o).a;
                    final a$f h = this.h;
                    o = new TaskCompletionSource();
                    a.c((a$b)h, (TaskCompletionSource)o);
                    continue;
                }
                catch (final RemoteException o) {
                    goto Label_0106;
                }
                catch (final RuntimeException ex) {}
                catch (final DeadObjectException ex2) {
                    this.f(3);
                    this.h.c("DeadObjectException thrown while calling register listener method.");
                }
                break;
            }
            iterator.remove();
        }
        this.i();
        this.m();
    }
    
    private final void l(final int n) {
        this.E();
        this.o = true;
        this.j.e(n, this.h.m());
        final b i = this.i;
        final f s = this.s;
        f.o(s).sendMessageDelayed(Message.obtain(f.o(s), 9, (Object)i), 5000L);
        final b j = this.i;
        final f s2 = this.s;
        f.o(s2).sendMessageDelayed(Message.obtain(f.o(s2), 11, (Object)j), 120000L);
        f.w(this.s).c();
        final Iterator iterator = this.l.values().iterator();
        while (iterator.hasNext()) {
            ((O)iterator.next()).c.run();
        }
    }
    
    private final void m() {
        f.o(this.s).removeMessages(12, (Object)this.i);
        final b i = this.i;
        final f s = this.s;
        f.o(s).sendMessageDelayed(f.o(s).obtainMessage(12, (Object)i), f.m(this.s));
    }
    
    private final void n(final a0 a0) {
        a0.d(this.j, this.a());
        try {
            a0.c(this);
        }
        catch (final DeadObjectException ex) {
            this.f(1);
            this.h.c("DeadObjectException thrown while running ApiCallRunner.");
        }
    }
    
    private final void o() {
        if (this.o) {
            f.o(this.s).removeMessages(11, (Object)this.i);
            f.o(this.s).removeMessages(9, (Object)this.i);
            this.o = false;
        }
    }
    
    private final boolean p(final a0 a0) {
        if (!(a0 instanceof J)) {
            this.n(a0);
            return true;
        }
        final J j = (J)a0;
        final Feature c = this.c(j.g(this));
        if (c == null) {
            this.n(a0);
            return true;
        }
        final String name = this.h.getClass().getName();
        final String name2 = c.getName();
        final long j2 = c.J2();
        final StringBuilder sb = new StringBuilder();
        sb.append(name);
        sb.append(" could not execute call because it requires feature (");
        sb.append(name2);
        sb.append(", ");
        sb.append(j2);
        sb.append(").");
        Log.w("GoogleApiManager", sb.toString());
        if (f.d(this.s) && j.f(this)) {
            final E e = new E(this.i, c, null);
            final int index = this.p.indexOf((Object)e);
            if (index >= 0) {
                final E e2 = (E)this.p.get(index);
                f.o(this.s).removeMessages(15, (Object)e2);
                final f s = this.s;
                f.o(s).sendMessageDelayed(Message.obtain(f.o(s), 15, (Object)e2), 5000L);
            }
            else {
                this.p.add((Object)e);
                final f s2 = this.s;
                f.o(s2).sendMessageDelayed(Message.obtain(f.o(s2), 15, (Object)e), 5000L);
                final f s3 = this.s;
                f.o(s3).sendMessageDelayed(Message.obtain(f.o(s3), 16, (Object)e), 120000L);
                final ConnectionResult connectionResult = new ConnectionResult(2, (PendingIntent)null);
                if (!this.q(connectionResult)) {
                    this.s.f(connectionResult, this.m);
                }
            }
            return false;
        }
        j.b((Exception)new j(c));
        return true;
    }
    
    private final boolean q(final ConnectionResult connectionResult) {
        final Object y;
        monitorenter(y = f.y());
        Label_0061: {
            try {
                final f s = this.s;
                if (f.s(s) != null && f.A(s).contains((Object)this.i)) {
                    f.s(this.s).s(connectionResult, this.m);
                    monitorexit(y);
                    return true;
                }
                break Label_0061;
            }
            finally {
                monitorexit(y);
                monitorexit(y);
                return false;
            }
        }
    }
    
    private final boolean r(final boolean b) {
        z3.k.d(f.o(this.s));
        if (this.h.i() && this.l.isEmpty()) {
            if (!this.j.g()) {
                this.h.c("Timing out service connection.");
                return true;
            }
            if (b) {
                this.m();
            }
        }
        return false;
    }
    
    public final void E() {
        z3.k.d(f.o(this.s));
        this.q = null;
    }
    
    public final void F() {
        z3.k.d(f.o(this.s));
        if (!this.h.i()) {
            if (!this.h.d()) {
                Label_0226: {
                    try {
                        final f s = this.s;
                        final int b = f.w(s).b(f.n(s), this.h);
                        if (b != 0) {
                            final ConnectionResult connectionResult = new ConnectionResult(b, (PendingIntent)null);
                            final String name = this.h.getClass().getName();
                            final String string = connectionResult.toString();
                            final StringBuilder sb = new StringBuilder();
                            sb.append("The service for ");
                            sb.append(name);
                            sb.append(" is not available: ");
                            sb.append(string);
                            Log.w("GoogleApiManager", sb.toString());
                            this.I(connectionResult, null);
                            return;
                        }
                    }
                    catch (final IllegalStateException ex) {
                        break Label_0226;
                    }
                    final f s2 = this.s;
                    final a$f h = this.h;
                    final G g = new G(s2, h, this.i);
                    if (h.n()) {
                        ((T)z3.k.l(this.n)).P1(g);
                    }
                    try {
                        this.h.f((b$c)g);
                        return;
                    }
                    catch (final SecurityException ex2) {
                        this.I(new ConnectionResult(10), (Exception)ex2);
                        return;
                    }
                }
                final IllegalStateException ex;
                this.I(new ConnectionResult(10), (Exception)ex);
            }
        }
    }
    
    public final void G(final a0 a0) {
        z3.k.d(f.o(this.s));
        if (this.h.i()) {
            if (this.p(a0)) {
                this.m();
                return;
            }
            this.g.add((Object)a0);
        }
        else {
            this.g.add((Object)a0);
            final ConnectionResult q = this.q;
            if (q != null && q.M2()) {
                this.I(this.q, null);
                return;
            }
            this.F();
        }
    }
    
    final void H() {
        ++this.r;
    }
    
    public final void I(final ConnectionResult q, final Exception ex) {
        z3.k.d(f.o(this.s));
        final T n = this.n;
        if (n != null) {
            n.Q1();
        }
        this.E();
        f.w(this.s).c();
        this.d(q);
        if (this.h instanceof e && q.J2() != 24) {
            f.B(this.s, true);
            final f s = this.s;
            f.o(s).sendMessageDelayed(f.o(s).obtainMessage(19), 300000L);
        }
        if (q.J2() == 4) {
            this.e(f.q());
            return;
        }
        if (q.J2() == 25) {
            this.e(f.r(this.i, q));
            return;
        }
        if (((Collection)this.g).isEmpty()) {
            this.q = q;
            return;
        }
        if (ex != null) {
            z3.k.d(f.o(this.s));
            this.h(null, ex, false);
            return;
        }
        if (f.d(this.s)) {
            this.h(f.r(this.i, q), null, true);
            if (!((Collection)this.g).isEmpty()) {
                if (!this.q(q) && !this.s.f(q, this.m)) {
                    if (q.J2() == 18) {
                        this.o = true;
                    }
                    if (this.o) {
                        final f s2 = this.s;
                        f.o(s2).sendMessageDelayed(Message.obtain(f.o(s2), 9, (Object)this.i), 5000L);
                        return;
                    }
                    this.e(f.r(this.i, q));
                }
            }
            return;
        }
        this.e(f.r(this.i, q));
    }
    
    public final void J(final ConnectionResult connectionResult) {
        z3.k.d(f.o(this.s));
        final a$f h = this.h;
        final String name = h.getClass().getName();
        final String value = String.valueOf((Object)connectionResult);
        final StringBuilder sb = new StringBuilder();
        sb.append("onSignInFailed for ");
        sb.append(name);
        sb.append(" with ");
        sb.append(value);
        h.c(sb.toString());
        this.I(connectionResult, null);
    }
    
    public final void K(final b0 b0) {
        z3.k.d(f.o(this.s));
        this.k.add((Object)b0);
    }
    
    public final void L() {
        z3.k.d(f.o(this.s));
        if (this.o) {
            this.F();
        }
    }
    
    public final void M() {
        z3.k.d(f.o(this.s));
        this.e(f.p);
        this.j.f();
        final Set keySet = this.l.keySet();
        int i = 0;
        for (x3.i[] array = (x3.i[])keySet.toArray((Object[])new x3.i[0]); i < array.length; ++i) {
            this.G(new Z(array[i], new TaskCompletionSource()));
        }
        this.d(new ConnectionResult(4));
        if (this.h.i()) {
            this.h.h((b$e)new C(this));
        }
    }
    
    public final void N() {
        z3.k.d(f.o(this.s));
        if (this.o) {
            this.o();
            final f s = this.s;
            Status status;
            if (f.p(s).isGooglePlayServicesAvailable(f.n(s)) == 18) {
                status = new Status(21, "Connection timed out waiting for Google Play services update to complete.");
            }
            else {
                status = new Status(22, "API failed to connect while resuming due to an unknown error.");
            }
            this.e(status);
            this.h.c("Timing out connection while resuming.");
        }
    }
    
    final boolean P() {
        return this.h.i();
    }
    
    public final boolean a() {
        return this.h.n();
    }
    
    public final boolean b() {
        return this.r(true);
    }
    
    public final void f(final int n) {
        if (Looper.myLooper() == f.o(this.s).getLooper()) {
            this.l(n);
            return;
        }
        f.o(this.s).post((Runnable)new A(this, n));
    }
    
    public final void g(final ConnectionResult connectionResult) {
        this.I(connectionResult, null);
    }
    
    public final void k(final Bundle bundle) {
        if (Looper.myLooper() == f.o(this.s).getLooper()) {
            this.j();
            return;
        }
        f.o(this.s).post((Runnable)new z(this));
    }
    
    public final int s() {
        return this.m;
    }
    
    final int t() {
        return this.r;
    }
    
    public final ConnectionResult u() {
        z3.k.d(f.o(this.s));
        return this.q;
    }
    
    public final a$f w() {
        return this.h;
    }
    
    public final Map y() {
        return this.l;
    }
}
