package x3;

import z3.k;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.common.api.a$b;
import com.google.android.gms.common.Feature;

public abstract class p
{
    private final Feature[] a;
    private final boolean b;
    private final int c;
    
    protected p(final Feature[] a, final boolean b, final int c) {
        this.a = a;
        boolean b2 = false;
        if (a != null) {
            b2 = b2;
            if (b) {
                b2 = true;
            }
        }
        this.b = b2;
        this.c = c;
    }
    
    public static a a() {
        return new a(null);
    }
    
    protected abstract void b(final a$b p0, final TaskCompletionSource p1);
    
    public boolean c() {
        return this.b;
    }
    
    public final int d() {
        return this.c;
    }
    
    public final Feature[] e() {
        return this.a;
    }
    
    public static class a
    {
        private l a;
        private boolean b = true;
        private Feature[] c;
        private int d = 0;
        
        public p a() {
            k.b(this.a != null, "execute parameter required");
            return new U(this, this.c, this.b, this.d);
        }
        
        public a b(final l a) {
            this.a = a;
            return this;
        }
        
        public a c(final boolean b) {
            this.b = b;
            return this;
        }
        
        public a d(final Feature... c) {
            this.c = c;
            return this;
        }
        
        public a e(final int d) {
            this.d = d;
            return this;
        }
    }
}
