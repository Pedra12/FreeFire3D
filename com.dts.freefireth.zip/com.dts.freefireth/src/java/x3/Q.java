package x3;

import z3.a;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.common.api.Status;

public abstract class q
{
    public static boolean a(final Status status, final Object o, final TaskCompletionSource taskCompletionSource) {
        if (status.N2()) {
            return taskCompletionSource.e(o);
        }
        return taskCompletionSource.d((Exception)a.a(status));
    }
}
