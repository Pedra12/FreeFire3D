package x3;

import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.common.api.a$b;

public abstract class r
{
    protected abstract void a(final a$b p0, final TaskCompletionSource p1);
}
