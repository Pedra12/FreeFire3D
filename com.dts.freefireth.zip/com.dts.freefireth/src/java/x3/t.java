package x3;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.OnCompleteListener;

final class t implements OnCompleteListener
{
    final TaskCompletionSource a;
    final u b;
    
    t(final u b, final TaskCompletionSource a) {
        this.a = a;
        this.b = b;
    }
    
    public final void onComplete(final Task task) {
        u.b(this.b).remove((Object)this.a);
    }
}
