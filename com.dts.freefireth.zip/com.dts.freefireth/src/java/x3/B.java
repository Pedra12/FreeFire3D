package x3;

import z3.i;
import com.google.android.gms.common.api.a$d;
import com.google.android.gms.common.api.a;

public final class b
{
    private final int a;
    private final a b;
    private final a$d c;
    private final String d;
    
    private b(final a b, final a$d c, final String d) {
        this.b = b;
        this.c = c;
        this.d = d;
        this.a = i.b(b, c, d);
    }
    
    public static b a(final a a, final a$d a$d, final String s) {
        return new b(a, a$d, s);
    }
    
    public final String b() {
        return this.b.c();
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (o == null) {
            return false;
        }
        if (o == this) {
            return true;
        }
        if (!(o instanceof b)) {
            return false;
        }
        final b b = (b)o;
        return i.a(this.b, b.b) && i.a(this.c, b.c) && i.a(this.d, b.d);
    }
    
    @Override
    public final int hashCode() {
        return this.a;
    }
}
