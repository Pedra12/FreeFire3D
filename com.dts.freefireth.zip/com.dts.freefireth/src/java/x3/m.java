package x3;

import com.google.android.gms.common.internal.MethodInvocation;

final class M
{
    final MethodInvocation a;
    final int b;
    final long c;
    final int d;
    
    M(final MethodInvocation a, final int b, final long c, final int d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
}
