package x3;

import com.google.android.gms.common.ConnectionResult;
import z3.k;
import android.app.Activity;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.internal.LifecycleFragment;
import y.b;

public final class v extends f0
{
    private final b f;
    private final f g;
    
    v(final LifecycleFragment lifecycleFragment, final f g, final GoogleApiAvailability googleApiAvailability) {
        super(lifecycleFragment, googleApiAvailability);
        this.f = new b();
        this.g = g;
        super.a.d("ConnectionlessLifecycleHelper", (h)this);
    }
    
    public static void u(final Activity activity, final f f, final x3.b b) {
        final LifecycleFragment c = h.c(activity);
        v v;
        if ((v = (v)c.a("ConnectionlessLifecycleHelper", (Class)v.class)) == null) {
            v = new v(c, f, GoogleApiAvailability.getInstance());
        }
        k.m(b, "ApiKey cannot be null");
        v.f.add(b);
        f.b(v);
    }
    
    private final void v() {
        if (!this.f.isEmpty()) {
            this.g.b(this);
        }
    }
    
    public final void h() {
        super.h();
        this.v();
    }
    
    @Override
    public final void j() {
        super.j();
        this.v();
    }
    
    @Override
    public final void k() {
        super.k();
        this.g.c(this);
    }
    
    @Override
    protected final void m(final ConnectionResult connectionResult, final int n) {
        this.g.F(connectionResult, n);
    }
    
    @Override
    protected final void n() {
        this.g.G();
    }
    
    final b t() {
        return this.f;
    }
}
