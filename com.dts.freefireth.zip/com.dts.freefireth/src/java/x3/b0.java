package x3;

import com.google.android.gms.common.ConnectionResult;
import java.util.Set;
import com.google.android.gms.tasks.Task;
import java.util.Iterator;
import com.google.android.gms.common.api.HasApiKey;
import com.google.android.gms.tasks.TaskCompletionSource;
import y.a;

public final class b0
{
    private final a a;
    private final a b;
    private final TaskCompletionSource c;
    private int d;
    private boolean e;
    
    public b0(final Iterable iterable) {
        this.b = new a();
        this.c = new TaskCompletionSource();
        this.e = false;
        this.a = new a();
        final Iterator iterator = iterable.iterator();
        while (iterator.hasNext()) {
            this.a.put(((HasApiKey)iterator.next()).f(), null);
        }
        this.d = this.a.keySet().size();
    }
    
    public final Task a() {
        return this.c.a();
    }
    
    public final Set b() {
        return this.a.keySet();
    }
    
    public final void c(final b b, final ConnectionResult connectionResult, final String s) {
        this.a.put(b, connectionResult);
        this.b.put(b, s);
        --this.d;
        if (!connectionResult.N2()) {
            this.e = true;
        }
        if (this.d == 0) {
            if (this.e) {
                this.c.b((Exception)new com.google.android.gms.common.api.b(this.a));
                return;
            }
            this.c.c((Object)this.b);
        }
    }
}
