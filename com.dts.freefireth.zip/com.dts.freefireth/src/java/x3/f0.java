package x3;

import android.os.BaseBundle;
import k.b;
import android.content.DialogInterface;
import android.os.Parcelable;
import android.os.Bundle;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import com.google.android.gms.common.ConnectionResult;
import d4.g;
import android.os.Looper;
import com.google.android.gms.common.api.internal.LifecycleFragment;
import com.google.android.gms.common.GoogleApiAvailability;
import android.os.Handler;
import java.util.concurrent.atomic.AtomicReference;
import android.content.DialogInterface$OnCancelListener;

public abstract class f0 extends h implements DialogInterface$OnCancelListener
{
    protected volatile boolean b;
    protected final AtomicReference c;
    private final Handler d;
    protected final GoogleApiAvailability e;
    
    f0(final LifecycleFragment lifecycleFragment, final GoogleApiAvailability e) {
        super(lifecycleFragment);
        this.c = new AtomicReference((Object)null);
        this.d = (Handler)new g(Looper.getMainLooper());
        this.e = e;
    }
    
    private final void l(final ConnectionResult connectionResult, final int n) {
        this.c.set((Object)null);
        this.m(connectionResult, n);
    }
    
    private final void o() {
        this.c.set((Object)null);
        this.n();
    }
    
    private static final int p(final c0 c0) {
        if (c0 == null) {
            return -1;
        }
        return c0.a();
    }
    
    public final void e(int n, final int n2, final Intent intent) {
        final c0 c0 = (c0)this.c.get();
        if (n != 1) {
            if (n == 2) {
                n = this.e.isGooglePlayServicesAvailable((Context)this.b());
                if (n == 0) {
                    this.o();
                    return;
                }
                if (c0 == null) {
                    return;
                }
                if (c0.b().J2() == 18 && n == 18) {
                    return;
                }
            }
        }
        else {
            if (n2 == -1) {
                this.o();
                return;
            }
            if (n2 == 0) {
                if (c0 != null) {
                    n = 13;
                    if (intent != null) {
                        n = intent.getIntExtra("<<ResolutionFailureErrorDetail>>", 13);
                    }
                    this.l(new ConnectionResult(n, (PendingIntent)null, c0.b().toString()), p(c0));
                }
                return;
            }
        }
        if (c0 != null) {
            this.l(c0.b(), c0.a());
        }
    }
    
    public final void f(final Bundle bundle) {
        super.f(bundle);
        if (bundle != null) {
            final AtomicReference c = this.c;
            c0 c2;
            if (bundle.getBoolean("resolving_error", false)) {
                c2 = new c0(new ConnectionResult(((BaseBundle)bundle).getInt("failed_status"), (PendingIntent)bundle.getParcelable("failed_resolution")), ((BaseBundle)bundle).getInt("failed_client_id", -1));
            }
            else {
                c2 = null;
            }
            c.set((Object)c2);
        }
    }
    
    public final void i(final Bundle bundle) {
        super.i(bundle);
        final c0 c0 = (c0)this.c.get();
        if (c0 == null) {
            return;
        }
        bundle.putBoolean("resolving_error", true);
        ((BaseBundle)bundle).putInt("failed_client_id", c0.a());
        ((BaseBundle)bundle).putInt("failed_status", c0.b().J2());
        bundle.putParcelable("failed_resolution", (Parcelable)c0.b().L2());
    }
    
    public void j() {
        super.j();
        this.b = true;
    }
    
    public void k() {
        super.k();
        this.b = false;
    }
    
    protected abstract void m(final ConnectionResult p0, final int p1);
    
    protected abstract void n();
    
    public final void onCancel(final DialogInterface dialogInterface) {
        this.l(new ConnectionResult(13, (PendingIntent)null), p((c0)this.c.get()));
    }
    
    public final void s(final ConnectionResult connectionResult, final int n) {
        final c0 c0 = new c0(connectionResult, n);
        AtomicReference c2;
        do {
            c2 = this.c;
            if (k.b.a(c2, (Object)null, (Object)c0)) {
                this.d.post((Runnable)new e0(this, c0));
            }
        } while (c2.get() == null);
    }
}
