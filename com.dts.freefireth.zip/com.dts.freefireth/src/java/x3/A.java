package x3;

import com.google.android.gms.common.api.Status;

public class a implements n
{
    @Override
    public final Exception a(final Status status) {
        return (Exception)z3.a.a(status);
    }
}
