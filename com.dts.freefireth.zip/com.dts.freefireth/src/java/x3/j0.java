package x3;

import android.os.Handler;
import java.io.PrintWriter;
import java.io.FileDescriptor;
import android.content.Intent;
import java.util.Iterator;
import java.util.Map$Entry;
import f4.p;
import android.os.Looper;
import j$.util.DesugarCollections;
import y.a;
import android.os.Bundle;
import java.util.Map;

final class j0
{
    private final Map a;
    private int b;
    private Bundle c;
    
    j0() {
        this.a = DesugarCollections.synchronizedMap((java.util.Map<Object, Object>)new a());
        this.b = 0;
    }
    
    final h a(final String s, final Class clazz) {
        return clazz.cast(this.a.get((Object)s));
    }
    
    final void b(final String s, final h h) {
        final Map a = this.a;
        if (!a.containsKey((Object)s)) {
            a.put((Object)s, (Object)h);
            if (this.b > 0) {
                ((Handler)new p(Looper.getMainLooper())).post((Runnable)new i0(this, h, s));
            }
            return;
        }
        final StringBuilder sb = new StringBuilder(String.valueOf((Object)s).length() + 59);
        sb.append("LifecycleCallback with tag ");
        sb.append(s);
        sb.append(" already added to this fragment.");
        throw new IllegalArgumentException(sb.toString());
    }
    
    final void c(final Bundle c) {
        this.b = 1;
        this.c = c;
        for (final Map$Entry map$Entry : this.a.entrySet()) {
            final h h = (h)map$Entry.getValue();
            Bundle bundle;
            if (c != null) {
                bundle = c.getBundle((String)map$Entry.getKey());
            }
            else {
                bundle = null;
            }
            h.f(bundle);
        }
    }
    
    final void d() {
        this.b = 2;
        final Iterator iterator = this.a.values().iterator();
        while (iterator.hasNext()) {
            ((h)iterator.next()).j();
        }
    }
    
    final void e() {
        this.b = 3;
        final Iterator iterator = this.a.values().iterator();
        while (iterator.hasNext()) {
            ((h)iterator.next()).h();
        }
    }
    
    final void f(final int n, final int n2, final Intent intent) {
        final Iterator iterator = this.a.values().iterator();
        while (iterator.hasNext()) {
            ((h)iterator.next()).e(n, n2, intent);
        }
    }
    
    final void g(final Bundle bundle) {
        if (bundle != null) {
            for (final Map$Entry map$Entry : this.a.entrySet()) {
                final Bundle bundle2 = new Bundle();
                ((h)map$Entry.getValue()).i(bundle2);
                bundle.putBundle((String)map$Entry.getKey(), bundle2);
            }
        }
    }
    
    final void h() {
        this.b = 4;
        final Iterator iterator = this.a.values().iterator();
        while (iterator.hasNext()) {
            ((h)iterator.next()).k();
        }
    }
    
    final void i() {
        this.b = 5;
        final Iterator iterator = this.a.values().iterator();
        while (iterator.hasNext()) {
            ((h)iterator.next()).g();
        }
    }
    
    final void j(final String s, final FileDescriptor fileDescriptor, final PrintWriter printWriter, final String[] array) {
        final Iterator iterator = this.a.values().iterator();
        while (iterator.hasNext()) {
            ((h)iterator.next()).a(s, fileDescriptor, printWriter, array);
        }
    }
}
