package x3;

import android.app.Dialog;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.internal.zabu;
import android.content.DialogInterface$OnCancelListener;
import android.content.Context;
import com.google.android.gms.common.api.GoogleApiActivity;
import z3.k;
import android.app.PendingIntent;

final class e0 implements Runnable
{
    private final c0 a;
    final f0 b;
    
    e0(final f0 b, final c0 a) {
        this.b = b;
        this.a = a;
    }
    
    public final void run() {
        if (!this.b.b) {
            return;
        }
        final ConnectionResult b = this.a.b();
        if (b.M2()) {
            final f0 b2 = this.b;
            b2.a.startActivityForResult(GoogleApiActivity.a((Context)b2.b(), (PendingIntent)k.l(b.L2()), this.a.a(), false), 1);
            return;
        }
        final f0 b3 = this.b;
        if (b3.e.getErrorResolutionIntent((Context)b3.b(), b.J2(), (String)null) != null) {
            final f0 b4 = this.b;
            b4.e.zag(b4.b(), b4.a, b.J2(), 2, (DialogInterface$OnCancelListener)this.b);
            return;
        }
        if (b.J2() == 18) {
            final f0 b5 = this.b;
            final Dialog zab = b5.e.zab(b5.b(), (DialogInterface$OnCancelListener)b5);
            final f0 b6 = this.b;
            b6.e.zac(((Context)b6.b()).getApplicationContext(), (zabu)new d0(this, zab));
            return;
        }
        f0.q(this.b, b, this.a.a());
    }
}
