package x3;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.MethodInvocation;
import w3.a;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.common.internal.ConnectionTelemetryConfiguration;
import com.google.android.gms.common.internal.RootTelemetryConfiguration;
import android.os.SystemClock;
import z3.l;
import com.google.android.gms.tasks.OnCompleteListener;

final class L implements OnCompleteListener
{
    private final f a;
    private final int b;
    private final b c;
    private final long d;
    private final long e;
    
    L(final f a, final int b, final b c, final long d, final long e, final String s, final String s2) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    static L a(final f f, final int n, final b b) {
        if (f.e()) {
            final RootTelemetryConfiguration a = l.b().a();
            boolean m2;
            if (a != null) {
                if (!a.K2()) {
                    return null;
                }
                final boolean l2 = a.L2();
                final D t = f.t(b);
                m2 = l2;
                if (t != null) {
                    if (!(t.w() instanceof com.google.android.gms.common.internal.b)) {
                        return null;
                    }
                    final com.google.android.gms.common.internal.b b2 = (com.google.android.gms.common.internal.b)t.w();
                    m2 = l2;
                    if (b2.J()) {
                        m2 = l2;
                        if (!b2.d()) {
                            final ConnectionTelemetryConfiguration b3 = b(t, b2, n);
                            if (b3 == null) {
                                return null;
                            }
                            t.H();
                            m2 = b3.M2();
                        }
                    }
                }
            }
            else {
                m2 = true;
            }
            long elapsedRealtime = 0L;
            long currentTimeMillis;
            if (m2) {
                currentTimeMillis = System.currentTimeMillis();
            }
            else {
                currentTimeMillis = 0L;
            }
            if (m2) {
                elapsedRealtime = SystemClock.elapsedRealtime();
            }
            return new L(f, n, b, currentTimeMillis, elapsedRealtime, null, null);
        }
        return null;
    }
    
    private static ConnectionTelemetryConfiguration b(final D d, final com.google.android.gms.common.internal.b b, final int n) {
        final ConnectionTelemetryConfiguration h = b.H();
        if (h != null && h.L2()) {
            final int[] j2 = h.J2();
            if (j2 == null) {
                final int[] k2 = h.K2();
                if (k2 != null) {
                    if (com.google.android.gms.common.util.b.a(k2, n)) {
                        return null;
                    }
                }
            }
            else if (!com.google.android.gms.common.util.b.a(j2, n)) {
                return null;
            }
            if (d.t() < h.I2()) {
                return h;
            }
        }
        return null;
    }
    
    public final void onComplete(final Task task) {
        if (this.a.e()) {
            final RootTelemetryConfiguration a = l.b().a();
            if (a == null || a.K2()) {
                final D t = this.a.t(this.c);
                if (t != null && t.w() instanceof com.google.android.gms.common.internal.b) {
                    final com.google.android.gms.common.internal.b b = (com.google.android.gms.common.internal.b)t.w();
                    final long d = this.d;
                    final int n = 1;
                    int n2;
                    if (d > 0L) {
                        n2 = 1;
                    }
                    else {
                        n2 = 0;
                    }
                    final int z = b.z();
                    int i2;
                    int m2;
                    int n4;
                    int n5;
                    if (a != null) {
                        final boolean b2 = (n2 & (a.L2() ? 1 : 0)) != 0x0;
                        i2 = a.I2();
                        final int j2 = a.J2();
                        m2 = a.M2();
                        int n3 = b2 ? 1 : 0;
                        int i3 = j2;
                        if (b.J()) {
                            n3 = (b2 ? 1 : 0);
                            i3 = j2;
                            if (!b.d()) {
                                final ConnectionTelemetryConfiguration b3 = b(t, b, this.b);
                                if (b3 == null) {
                                    return;
                                }
                                if (b3.M2() && this.d > 0L) {
                                    n3 = n;
                                }
                                else {
                                    n3 = 0;
                                }
                                i3 = b3.I2();
                            }
                        }
                        n4 = i3;
                        n5 = n3;
                    }
                    else {
                        m2 = 0;
                        i2 = 5000;
                        n4 = 100;
                        n5 = n2;
                    }
                    final f a2 = this.a;
                    int k2 = 0;
                    int j3 = 0;
                    Label_0325: {
                        if (task.isSuccessful()) {
                            k2 = 0;
                            j3 = 0;
                        }
                        else {
                            if (task.isCanceled()) {
                                k2 = 100;
                            }
                            else {
                                final Exception exception = task.getException();
                                if (exception instanceof a) {
                                    final Status a3 = ((a)exception).a();
                                    k2 = a3.K2();
                                    final ConnectionResult i4 = a3.I2();
                                    if (i4 != null) {
                                        j3 = i4.J2();
                                        break Label_0325;
                                    }
                                }
                                else {
                                    k2 = 101;
                                }
                            }
                            j3 = -1;
                        }
                    }
                    long d2;
                    long currentTimeMillis;
                    int n6;
                    if (n5 != 0) {
                        d2 = this.d;
                        final long e = this.e;
                        currentTimeMillis = System.currentTimeMillis();
                        n6 = (int)(SystemClock.elapsedRealtime() - e);
                    }
                    else {
                        d2 = 0L;
                        currentTimeMillis = 0L;
                        n6 = -1;
                    }
                    a2.E(new MethodInvocation(this.b, k2, j3, d2, currentTimeMillis, (String)null, (String)null, z, n6), m2, i2, n4);
                }
            }
        }
    }
}
