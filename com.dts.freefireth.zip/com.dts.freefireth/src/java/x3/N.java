package x3;

import com.google.android.gms.common.api.Status;

public interface n
{
    Exception a(final Status p0);
}
