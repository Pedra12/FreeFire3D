package x3;

import z3.k;
import com.google.android.gms.common.ConnectionResult;

final class c0
{
    private final int a;
    private final ConnectionResult b;
    
    c0(final ConnectionResult b, final int a) {
        k.l(b);
        this.b = b;
        this.a = a;
    }
    
    final int a() {
        return this.a;
    }
    
    final ConnectionResult b() {
        return this.b;
    }
}
