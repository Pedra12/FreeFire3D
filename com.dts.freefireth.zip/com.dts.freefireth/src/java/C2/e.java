package c2;

import android.content.ComponentName;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.CountDownLatch;
import y7.b;
import y7.a;
import kotlin.collections.CollectionsKt;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import n2.W;
import x2.a$a;
import android.content.ServiceConnection;
import a2.g;
import kotlin.jvm.internal.Intrinsics;
import java.util.List;
import android.content.pm.PackageManager;
import n2.p;
import android.content.Intent;
import android.content.Context;

public final class e
{
    public static final e a;
    private static final String b;
    private static Boolean c;
    
    static {
        a = new e();
        b = e.class.getSimpleName();
    }
    
    private e() {
    }
    
    private final Intent a(final Context context) {
        final PackageManager packageManager = context.getPackageManager();
        if (packageManager != null) {
            final Intent intent = new Intent("ReceiverService");
            intent.setPackage("com.facebook.katana");
            if (packageManager.resolveService(intent, 0) != null && p.a(context, "com.facebook.katana")) {
                return intent;
            }
            final Intent intent2 = new Intent("ReceiverService");
            intent2.setPackage("com.facebook.wakizashi");
            if (packageManager.resolveService(intent2, 0) != null && p.a(context, "com.facebook.wakizashi")) {
                return intent2;
            }
        }
        return null;
    }
    
    public static final boolean b() {
        if (e.c == null) {
            e.c = (e.a.a(com.facebook.e.l()) != null);
        }
        final Boolean c = e.c;
        return c != null && c;
    }
    
    public static final c c(final String s, final List list) {
        Intrinsics.checkNotNullParameter((Object)s, "applicationId");
        Intrinsics.checkNotNullParameter((Object)list, "appEvents");
        return e.a.d(e.a.c, s, list);
    }
    
    private final c d(final a a, final String s, final List list) {
        Object o = e.c.b;
        g.b();
        final Context l = com.facebook.e.l();
        final Intent a2 = this.a(l);
        if (a2 == null) {
            return (c)o;
        }
        final b b = new b();
        if (!l.bindService(a2, (ServiceConnection)b, 1)) {
            return e.c.c;
        }
        c c = null;
    Label_0171_Outer:
        while (true) {
            Label_0158: {
                try {
                    try {
                        final IBinder a3 = b.a();
                        if (a3 == null) {
                            break Label_0140;
                        }
                        o = a$a.f(a3);
                        final Bundle a4 = d.a(a, s, list);
                        if (a4 != null) {
                            ((x2.a)o).z(a4);
                            final String b2 = e.b;
                            final StringBuilder sb = new StringBuilder();
                            sb.append("Successfully sent events to the remote service: ");
                            sb.append((Object)a4);
                            W.k0(b2, sb.toString());
                        }
                        break Label_0158;
                    }
                    finally {}
                }
                catch (final RemoteException ex) {
                    break Label_0158;
                }
                catch (final InterruptedException ex2) {
                    c = e.c.c;
                    String s2 = e.b;
                    W.j0(s2, (Exception)ex2);
                    while (true) {
                        l.unbindService((ServiceConnection)b);
                        W.k0(s2, "Unbound from the remote service");
                        return c;
                        l.unbindService((ServiceConnection)b);
                        W.k0(e.b, "Unbound from the remote service");
                        return (c)o;
                        c = e.c.c;
                        s2 = e.b;
                        final RemoteException ex;
                        W.j0(s2, (Exception)ex);
                        continue;
                    }
                    o = e.c.a;
                    continue Label_0171_Outer;
                }
            }
            break;
        }
        return c;
        l.unbindService((ServiceConnection)b);
        W.k0(e.b, "Unbound from the remote service");
    }
    
    public static final c e(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "applicationId");
        return e.a.d(e.a.b, s, CollectionsKt.k());
    }
    
    public enum a
    {
        b("MOBILE_APP_INSTALL", 0, "MOBILE_APP_INSTALL"), 
        c("CUSTOM_APP_EVENTS", 1, "CUSTOM_APP_EVENTS");
        
        private static final a[] d;
        private static final y7.a e;
        private final String a;
        
        static {
            e = y7.b.a((Enum[])(d = a()));
        }
        
        private a(final String s, final int n, final String a) {
            this.a = a;
        }
        
        private static final /* synthetic */ a[] a() {
            return new a[] { a.b, a.c };
        }
        
        public String toString() {
            return this.a;
        }
    }
    
    private static final class b implements ServiceConnection
    {
        private final CountDownLatch a;
        private IBinder b;
        
        public b() {
            this.a = new CountDownLatch(1);
        }
        
        public final IBinder a() {
            this.a.await(5L, TimeUnit.SECONDS);
            return this.b;
        }
        
        public void onNullBinding(final ComponentName componentName) {
            Intrinsics.checkNotNullParameter((Object)componentName, "name");
            this.a.countDown();
        }
        
        public void onServiceConnected(final ComponentName componentName, final IBinder b) {
            Intrinsics.checkNotNullParameter((Object)componentName, "name");
            Intrinsics.checkNotNullParameter((Object)b, "serviceBinder");
            this.b = b;
            this.a.countDown();
        }
        
        public void onServiceDisconnected(final ComponentName componentName) {
            Intrinsics.checkNotNullParameter((Object)componentName, "name");
        }
    }
    
    public enum c
    {
        a("OPERATION_SUCCESS", 0), 
        b("SERVICE_NOT_AVAILABLE", 1), 
        c("SERVICE_ERROR", 2);
        
        private static final c[] d;
        private static final y7.a e;
        
        static {
            e = y7.b.a((Enum[])(d = a()));
        }
        
        private c(final String s, final int n) {
        }
        
        private static final /* synthetic */ c[] a() {
            return new c[] { c.a, c.b, c.c };
        }
    }
}
