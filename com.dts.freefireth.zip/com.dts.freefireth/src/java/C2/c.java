package c2;

import android.content.SharedPreferences$Editor;
import android.content.SharedPreferences;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import n2.W;
import S1.e;
import android.content.Context;
import kotlin.collections.L;
import java.util.Set;

public final class c
{
    public static final c a;
    private static final Set b;
    
    static {
        a = new c();
        b = L.i((Object[])new String[] { "fb_mobile_purchase", "StartTrial", "Subscribe" });
    }
    
    private c() {
    }
    
    private final boolean c(final e e) {
        final boolean b = e.h() && c.b.contains((Object)e.f());
        return !e.h() || b;
    }
    
    public static final boolean d() {
        return !com.facebook.e.z(com.facebook.e.l()) && !W.a0() && c2.e.b();
    }
    
    public static final void e(final String s, final e e) {
        Intrinsics.checkNotNullParameter((Object)s, "applicationId");
        Intrinsics.checkNotNullParameter((Object)e, "event");
        if (c.a.c(e)) {
            com.facebook.e.t().execute((Runnable)new a(s, e));
        }
    }
    
    private static final void f(final String s, final e e) {
        Intrinsics.checkNotNullParameter((Object)s, "$applicationId");
        Intrinsics.checkNotNullParameter((Object)e, "$event");
        e.c(s, CollectionsKt.e((Object)e));
    }
    
    public static final void g(final String s, final String s2) {
        final Context l = com.facebook.e.l();
        if (l != null && s != null && s2 != null) {
            com.facebook.e.t().execute((Runnable)new b(l, s2, s));
        }
    }
    
    private static final void h(final Context context, String string, final String s) {
        Intrinsics.checkNotNullParameter((Object)context, "$context");
        final SharedPreferences sharedPreferences = context.getSharedPreferences(string, 0);
        final StringBuilder sb = new StringBuilder();
        sb.append(s);
        sb.append("pingForOnDevice");
        string = sb.toString();
        if (sharedPreferences.getLong(string, 0L) == 0L) {
            c2.e.e(s);
            final SharedPreferences$Editor edit = sharedPreferences.edit();
            edit.putLong(string, System.currentTimeMillis());
            edit.apply();
        }
    }
}
