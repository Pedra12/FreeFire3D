package c2;

import android.os.BaseBundle;
import n2.w;
import n2.A;
import java.util.Iterator;
import n2.W;
import X1.a;
import java.util.Collection;
import kotlin.collections.CollectionsKt;
import org.json.JSONArray;
import kotlin.jvm.internal.Intrinsics;
import android.os.Bundle;
import java.util.List;

public final class d
{
    public static final d a;
    private static final String b;
    
    static {
        a = new d();
        b = e.class.getSimpleName();
    }
    
    private d() {
    }
    
    public static final Bundle a(final e.a a, final String s, final List list) {
        Intrinsics.checkNotNullParameter((Object)a, "eventType");
        Intrinsics.checkNotNullParameter((Object)s, "applicationId");
        Intrinsics.checkNotNullParameter((Object)list, "appEvents");
        final Bundle bundle = new Bundle();
        ((BaseBundle)bundle).putString("event", a.toString());
        ((BaseBundle)bundle).putString("app_id", s);
        if (e.a.c == a) {
            final JSONArray b = d.a.b(list, s);
            if (b.length() == 0) {
                return null;
            }
            ((BaseBundle)bundle).putString("custom_events", b.toString());
        }
        return bundle;
    }
    
    private final JSONArray b(List o0, final String s) {
        final JSONArray jsonArray = new JSONArray();
        o0 = CollectionsKt.o0((Collection)o0);
        X1.a.d(o0);
        final boolean c = this.c(s);
        for (final S1.e e : o0) {
            if (e.g()) {
                if (e.h() && (!e.h() || !c)) {
                    continue;
                }
                jsonArray.put((Object)e.e());
            }
            else {
                final String b = d.b;
                final StringBuilder sb = new StringBuilder();
                sb.append("Event with invalid checksum: ");
                sb.append((Object)e);
                W.k0(b, sb.toString());
            }
        }
        return jsonArray;
    }
    
    private final boolean c(final String s) {
        final w o = A.o(s, false);
        return o != null && o.o();
    }
}
