package e1;

import g1.e;
import g1.d;
import com.beetalk.sdk.helper.A;
import java.util.Locale;
import g1.b;
import java.util.Map;
import com.beetalk.sdk.networking.i;
import com.beetalk.sdk.A0;
import com.beetalk.sdk.networking.h$d;
import kotlin.collections.F;
import s7.u;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import com.beetalk.sdk.networking.model.CommonResponse;
import h1.a$c;
import h1.a$b;
import h1.a;
import h1.c$c;
import h1.c$d;
import h1.c$b;
import h1.c;
import kotlin.Metadata;

@Metadata
public final class s
{
    public static final s a;
    
    static {
        a = new s();
    }
    
    private s() {
    }
    
    private final String h(final c c) {
        Object o;
        if (c instanceof c$b) {
            o = c;
        }
        else {
            o = null;
        }
        if (o != null) {
            return ((c)o).b();
        }
        return null;
    }
    
    private final String i(final c c) {
        if (c instanceof c$d) {
            return "whatsapp";
        }
        return null;
    }
    
    private final String j(final c c) {
        if (c instanceof c$c || c instanceof c$d) {
            return c.b();
        }
        return null;
    }
    
    private final String k(final a a) {
        Object o;
        if (a instanceof a$b) {
            o = a;
        }
        else {
            o = null;
        }
        if (o != null) {
            return ((a)o).a();
        }
        return null;
    }
    
    private final String l(final a a) {
        Object o;
        if (a instanceof a$c) {
            o = a;
        }
        else {
            o = null;
        }
        if (o != null) {
            return ((a)o).a();
        }
        return null;
    }
    
    public final CommonResponse a(final String s, String r) {
        Intrinsics.checkNotNullParameter((Object)s, "appId");
        Intrinsics.checkNotNullParameter((Object)r, "accessToken");
        final Map l = F.l(new Pair[] { u.a((Object)"app_id", (Object)s), u.a((Object)"access_token", (Object)r) });
        final h$d b = h$d.b;
        r = A0.R();
        final StringBuilder sb = new StringBuilder();
        sb.append(r);
        sb.append("/game/account_security/bind:cancel_request");
        return (CommonResponse)i.b(b, sb.toString(), l, (Class)CommonResponse.class, false, true);
    }
    
    public final CommonResponse b(final String s, final String s2, final c c, String r, final String s3) {
        Intrinsics.checkNotNullParameter((Object)s, "appId");
        Intrinsics.checkNotNullParameter((Object)s2, "accessToken");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)r, "verifierToken");
        Intrinsics.checkNotNullParameter((Object)s3, "secondaryPassword");
        final Map l = F.l(new Pair[] { u.a((Object)"app_id", (Object)s), u.a((Object)"access_token", (Object)s2), u.a((Object)"verifier_token", (Object)r), u.a((Object)"secondary_password", (Object)s3), u.a((Object)"mobile_no", (Object)this.j(c)), u.a((Object)"email", (Object)this.h(c)) });
        final h$d b = h$d.b;
        r = A0.R();
        final StringBuilder sb = new StringBuilder();
        sb.append(r);
        sb.append("/game/account_security/bind:create_bind_request");
        return (CommonResponse)i.b(b, sb.toString(), l, (Class)CommonResponse.class, false, true);
    }
    
    public final CommonResponse c(final String s, final String s2, String r, final String s3, final c c) {
        Intrinsics.checkNotNullParameter((Object)s, "appId");
        Intrinsics.checkNotNullParameter((Object)s2, "accessToken");
        Intrinsics.checkNotNullParameter((Object)r, "identityToken");
        Intrinsics.checkNotNullParameter((Object)s3, "verifierToken");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        final Map l = F.l(new Pair[] { u.a((Object)"app_id", (Object)s), u.a((Object)"access_token", (Object)s2), u.a((Object)"identity_token", (Object)r), u.a((Object)"verifier_token", (Object)s3), u.a((Object)"mobile_no", (Object)this.j(c)), u.a((Object)"email", (Object)this.h(c)) });
        final h$d b = h$d.b;
        r = A0.R();
        final StringBuilder sb = new StringBuilder();
        sb.append(r);
        sb.append("/game/account_security/bind:create_rebind_request");
        return (CommonResponse)i.b(b, sb.toString(), l, (Class)CommonResponse.class, false, true);
    }
    
    public final CommonResponse d(final String s, final String s2, String r) {
        Intrinsics.checkNotNullParameter((Object)s, "appId");
        Intrinsics.checkNotNullParameter((Object)s2, "accessToken");
        Intrinsics.checkNotNullParameter((Object)r, "identityToken");
        final Map l = F.l(new Pair[] { u.a((Object)"app_id", (Object)s), u.a((Object)"access_token", (Object)s2), u.a((Object)"identity_token", (Object)r) });
        final h$d b = h$d.b;
        r = A0.R();
        final StringBuilder sb = new StringBuilder();
        sb.append(r);
        sb.append("/game/account_security/bind:create_unbind_request");
        return (CommonResponse)i.b(b, sb.toString(), l, (Class)CommonResponse.class, false, true);
    }
    
    public final g1.a e(final String s, String r, final String s2) {
        Intrinsics.checkNotNullParameter((Object)s, "openId");
        Intrinsics.checkNotNullParameter((Object)r, "accessToken");
        Intrinsics.checkNotNullParameter((Object)s2, "appId");
        final Map l = F.l(new Pair[] { u.a((Object)"app_id", (Object)s2), u.a((Object)"open_id", (Object)s), u.a((Object)"access_token", (Object)r) });
        final h$d b = h$d.b;
        r = A0.R();
        final StringBuilder sb = new StringBuilder();
        sb.append(r);
        sb.append("/game/account_security/swap:exchange_session");
        return (g1.a)i.b(b, sb.toString(), l, (Class)g1.a.class, false, true);
    }
    
    public final b f(final String s, String r) {
        Intrinsics.checkNotNullParameter((Object)s, "appId");
        Intrinsics.checkNotNullParameter((Object)r, "accessToken");
        final Map l = F.l(new Pair[] { u.a((Object)"app_id", (Object)s), u.a((Object)"access_token", (Object)r) });
        final h$d a = h$d.a;
        r = A0.R();
        final StringBuilder sb = new StringBuilder();
        sb.append(r);
        sb.append("/game/account_security/bind:get_bind_info");
        return (b)i.b(a, sb.toString(), l, (Class)b.class, false, true);
    }
    
    public final CommonResponse g(String upperCase, final String s, String r, final Locale locale, final c c, final h1.b b) {
        Intrinsics.checkNotNullParameter((Object)upperCase, "appId");
        Intrinsics.checkNotNullParameter((Object)r, "accessToken");
        Intrinsics.checkNotNullParameter((Object)locale, "locale");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)b, "otpFlow");
        final Pair a = u.a((Object)"app_id", (Object)upperCase);
        final Pair a2 = u.a((Object)"access_token", (Object)r);
        final Pair a3 = u.a((Object)"mobile_no", (Object)this.j(c));
        final Pair a4 = u.a((Object)"email", (Object)this.h(c));
        if (s != null) {
            final Locale default1 = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)default1, "getDefault(...)");
            upperCase = s.toUpperCase(default1);
            Intrinsics.checkNotNullExpressionValue((Object)upperCase, "toUpperCase(...)");
        }
        else {
            upperCase = null;
        }
        final Map l = F.l(new Pair[] { a, a2, a3, a4, u.a((Object)"region", (Object)upperCase), u.a((Object)"gateway", (Object)this.i(c)), u.a((Object)"locale", (Object)A.f(locale)), u.a((Object)"flow", (Object)b.b()) });
        final h$d b2 = h$d.b;
        r = A0.R();
        final StringBuilder sb = new StringBuilder();
        sb.append(r);
        sb.append("/game/account_security/bind:send_otp");
        return (CommonResponse)i.b(b2, sb.toString(), l, (Class)CommonResponse.class, true, true);
    }
    
    public final CommonResponse m(String upperCase, final String s, final Locale locale, final c c) {
        Intrinsics.checkNotNullParameter((Object)upperCase, "appId");
        Intrinsics.checkNotNullParameter((Object)locale, "locale");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        final Pair a = u.a((Object)"app_id", (Object)upperCase);
        if (s != null) {
            final Locale default1 = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)default1, "getDefault(...)");
            upperCase = s.toUpperCase(default1);
            Intrinsics.checkNotNullExpressionValue((Object)upperCase, "toUpperCase(...)");
        }
        else {
            upperCase = null;
        }
        final Map l = F.l(new Pair[] { a, u.a((Object)"region", (Object)upperCase), u.a((Object)"mobile_no", (Object)this.j(c)), u.a((Object)"email", (Object)this.h(c)), u.a((Object)"locale", (Object)A.f(locale)), u.a((Object)"gateway", (Object)this.i(c)) });
        final h$d b = h$d.b;
        final String r = A0.R();
        final StringBuilder sb = new StringBuilder();
        sb.append(r);
        sb.append("/game/account_security/swap:send_otp");
        return (CommonResponse)i.b(b, sb.toString(), l, (Class)CommonResponse.class, true, true);
    }
    
    public final d n(String r, final String s, final String s2, final c c) {
        Intrinsics.checkNotNullParameter((Object)r, "appId");
        Intrinsics.checkNotNullParameter((Object)s, "accessToken");
        Intrinsics.checkNotNullParameter((Object)s2, "otp");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        final Map l = F.l(new Pair[] { u.a((Object)"app_id", (Object)r), u.a((Object)"access_token", (Object)s), u.a((Object)"otp", (Object)s2), u.a((Object)"mobile_no", (Object)this.j(c)), u.a((Object)"email", (Object)this.h(c)), u.a((Object)"gateway", (Object)this.i(c)) });
        final h$d b = h$d.b;
        r = A0.R();
        final StringBuilder sb = new StringBuilder();
        sb.append(r);
        sb.append("/game/account_security/bind:verify_otp");
        return (d)i.b(b, sb.toString(), l, (Class)d.class, false, true);
    }
    
    public final g1.c o(String s, final String s2, final a a, final c c) {
        Intrinsics.checkNotNullParameter((Object)s, "appId");
        Intrinsics.checkNotNullParameter((Object)s2, "accessToken");
        Intrinsics.checkNotNullParameter((Object)a, "credential");
        final Pair a2 = u.a((Object)"app_id", (Object)s);
        final Pair a3 = u.a((Object)"access_token", (Object)s2);
        final Pair a4 = u.a((Object)"otp", (Object)this.k(a));
        final Pair a5 = u.a((Object)"secondary_password", (Object)this.l(a));
        final String s3 = null;
        if (c != null) {
            s = this.j(c);
        }
        else {
            s = null;
        }
        final Pair a6 = u.a((Object)"mobile_no", (Object)s);
        if (c != null) {
            s = this.h(c);
        }
        else {
            s = null;
        }
        final Pair a7 = u.a((Object)"email", (Object)s);
        s = s3;
        if (c != null) {
            s = this.i(c);
        }
        final Map l = F.l(new Pair[] { a2, a3, a4, a5, a6, a7, u.a((Object)"gateway", (Object)s) });
        final h$d b = h$d.b;
        final String r = A0.R();
        final StringBuilder sb = new StringBuilder();
        sb.append(r);
        sb.append("/game/account_security/bind:verify_identity");
        return (g1.c)i.b(b, sb.toString(), l, (Class)g1.c.class, false, true);
    }
    
    public final e p(final String s, final String s2, final c c) {
        Intrinsics.checkNotNullParameter((Object)s, "appId");
        Intrinsics.checkNotNullParameter((Object)s2, "otp");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        final Map l = F.l(new Pair[] { u.a((Object)"otp", (Object)s2), u.a((Object)"mobile_no", (Object)this.j(c)), u.a((Object)"email", (Object)this.h(c)), u.a((Object)"gateway", (Object)this.i(c)), u.a((Object)"app_id", (Object)s) });
        final h$d b = h$d.b;
        final String r = A0.R();
        final StringBuilder sb = new StringBuilder();
        sb.append(r);
        sb.append("/game/account_security/swap:verify_otp");
        return (e)i.b(b, sb.toString(), l, (Class)e.class, false, true);
    }
}
