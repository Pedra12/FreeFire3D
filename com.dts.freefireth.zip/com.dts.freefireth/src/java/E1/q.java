package e1;

import com.beetalk.sdk.helper.M;
import com.beetalk.sdk.X$e;
import java.util.concurrent.Callable;
import com.beetalk.sdk.cache.k;
import com.beetalk.sdk.B0;
import com.beetalk.sdk.s$f;
import kotlin.Unit;
import g2.o;
import android.app.Activity;
import com.beetalk.sdk.s$h;
import g1.e;
import com.beetalk.sdk.account.security.model.SwapTokenInfo;
import h1.a$c;
import h1.a$b;
import g1.d;
import com.garena.pay.android.l;
import com.beetalk.sdk.networking.model.CommonResponse;
import com.beetalk.sdk.account.security.model.SecurityVerifierBindInfo;
import com.beetalk.sdk.helper.A;
import h1.c$b;
import com.beetalk.sdk.helper.t;
import com.beetalk.sdk.X;
import kotlin.jvm.internal.Intrinsics;
import h1.b;
import java.util.Locale;
import h1.c;
import kotlin.Metadata;

@Metadata
public final class q
{
    public static final q a;
    
    static {
        a = new q();
    }
    
    private q() {
    }
    
    private static final String A(final c c, final String s, final Locale locale, final b b) {
        Intrinsics.checkNotNullParameter((Object)c, "$recipient");
        Intrinsics.checkNotNullParameter((Object)s, "$region");
        Intrinsics.checkNotNullParameter((Object)locale, "$locale");
        Intrinsics.checkNotNullParameter((Object)b, "$otpFlow");
        final String h = t.h(X.M());
        final e1.b a = b.a;
        a.b(h);
        a.e(c);
        final s a2 = s.a;
        Intrinsics.c((Object)h);
        String a3;
        if (c instanceof c$b) {
            a3 = null;
        }
        else {
            a3 = s;
            if (((CharSequence)s).length() == 0) {
                a3 = A.a();
            }
        }
        return r.a(a2.g(h, a3, q.a.F(), locale, c, b));
    }
    
    private static final SecurityVerifierBindInfo C() {
        final String h = t.h(X.M());
        e1.b.a.b(h);
        final s a = s.a;
        Intrinsics.c((Object)h);
        final g1.b f = a.f(h, q.a.F());
        if (((CommonResponse)f).c()) {
            return new SecurityVerifierBindInfo(f);
        }
        throw e1.a.a.a((CommonResponse)f);
    }
    
    private static final String E(final c c, final String s, final Locale locale) {
        Intrinsics.checkNotNullParameter((Object)c, "$recipient");
        Intrinsics.checkNotNullParameter((Object)s, "$region");
        Intrinsics.checkNotNullParameter((Object)locale, "$locale");
        final String h = t.h(X.M());
        final e1.b a = e1.b.a;
        a.b(h);
        a.e(c);
        final s a2 = s.a;
        Intrinsics.c((Object)h);
        String a3;
        if (c instanceof c$b) {
            a3 = null;
        }
        else {
            a3 = s;
            if (((CharSequence)s).length() == 0) {
                a3 = A.a();
            }
        }
        return r.a(a2.m(h, a3, locale, c));
    }
    
    private final String F() {
        final com.beetalk.sdk.s w = com.beetalk.sdk.s.w();
        if (com.beetalk.sdk.s.j(w)) {
            final k1.a h = w.H();
            Intrinsics.c((Object)h);
            final String c = h.c();
            Intrinsics.checkNotNullExpressionValue((Object)c, "getAuthToken(...)");
            return c;
        }
        throw new W2.b(l.b1);
    }
    
    private static final String H(final String s, final c c) {
        Intrinsics.checkNotNullParameter((Object)s, "$otp");
        Intrinsics.checkNotNullParameter((Object)c, "$recipient");
        final String h = t.h(X.M());
        final e1.b a = e1.b.a;
        a.b(h);
        a.h(s);
        a.e(c);
        final s a2 = s.a;
        Intrinsics.c((Object)h);
        final d n = a2.n(h, q.a.F(), s, c);
        if (((CommonResponse)n).c() && ((CharSequence)n.d()).length() == 0) {
            throw new W2.b(l.t1, "service respond empty security token");
        }
        if (((CharSequence)((CommonResponse)n).b()).length() > 0) {
            throw e1.a.a.a((CommonResponse)n);
        }
        if (((CommonResponse)n).a() == com.beetalk.sdk.networking.s.d.b()) {
            c.a.g(n.d());
            return "Success";
        }
        throw new W2.b(l.a1, ((CommonResponse)n).b());
    }
    
    private static final String J(final a$b a$b, final c c) {
        Intrinsics.checkNotNullParameter((Object)a$b, "$credential");
        Intrinsics.checkNotNullParameter((Object)c, "$recipient");
        final String h = t.h(X.M());
        final e1.b a = e1.b.a;
        a.b(h);
        a.c((h1.a)a$b);
        a.e(c);
        final s a2 = s.a;
        Intrinsics.c((Object)h);
        final g1.c o = a2.o(h, q.a.F(), (h1.a)a$b, c);
        if (((CommonResponse)o).c()) {
            c.a.e(o.d());
        }
        return r.a((CommonResponse)o);
    }
    
    private static final String L(final a$c a$c, final c c) {
        Intrinsics.checkNotNullParameter((Object)a$c, "$credential");
        Intrinsics.checkNotNullParameter((Object)c, "$recipient");
        final String h = t.h(X.M());
        final e1.b a = e1.b.a;
        a.b(h);
        a.c((h1.a)a$c);
        a.e(c);
        final s a2 = s.a;
        Intrinsics.c((Object)h);
        final g1.c o = a2.o(h, q.a.F(), (h1.a)a$c, c);
        if (((CommonResponse)o).c()) {
            c.a.e(o.d());
        }
        return r.a((CommonResponse)o);
    }
    
    private static final SwapTokenInfo N(final String s, final c c) {
        Intrinsics.checkNotNullParameter((Object)s, "$otp");
        Intrinsics.checkNotNullParameter((Object)c, "$recipient");
        final String h = t.h(X.M());
        final e1.b a = e1.b.a;
        a.h(s);
        a.e(c);
        a.b(h);
        final s a2 = s.a;
        Intrinsics.c((Object)h);
        final e p2 = a2.p(h, s, c);
        if (((CommonResponse)p2).c()) {
            final SwapTokenInfo swapTokenInfo = new SwapTokenInfo(p2);
            c.a.f(swapTokenInfo.a());
            return swapTokenInfo;
        }
        throw e1.a.a.a((CommonResponse)p2);
    }
    
    private static final String o() {
        final String h = t.h(X.M());
        e1.b.a.b(h);
        final s a = s.a;
        Intrinsics.c((Object)h);
        return r.a(a.a(h, q.a.F()));
    }
    
    private static final String q(final String s, final c c) {
        Intrinsics.checkNotNullParameter((Object)s, "$secondaryPassword");
        Intrinsics.checkNotNullParameter((Object)c, "$recipient");
        final e1.c a = c.a;
        final String c2 = a.c();
        final String h = t.h(X.M());
        final e1.b a2 = e1.b.a;
        a2.b(h);
        a2.g(c2);
        a2.f(s);
        a2.e(c);
        final s a3 = s.a;
        Intrinsics.c((Object)h);
        final CommonResponse b = a3.b(h, q.a.F(), c, c2, s);
        if (b.c()) {
            a.g("");
        }
        return r.a(b);
    }
    
    private static final String s(final c c) {
        Intrinsics.checkNotNullParameter((Object)c, "$recipient");
        final e1.c a = c.a;
        final String c2 = a.c();
        final String a2 = a.a();
        final String h = t.h(X.M());
        final e1.b a3 = e1.b.a;
        a3.b(h);
        a3.e(c);
        a3.g(c2);
        a3.d(a2);
        final s a4 = s.a;
        Intrinsics.c((Object)h);
        final CommonResponse c3 = a4.c(h, q.a.F(), a2, c2, c);
        if (c3.c()) {
            a.d();
        }
        return r.a(c3);
    }
    
    private static final String u() {
        final e1.c a = e1.c.a;
        final String a2 = a.a();
        final String h = t.h(X.M());
        final e1.b a3 = e1.b.a;
        a3.b(h);
        a3.d(a2);
        final s a4 = s.a;
        Intrinsics.c((Object)h);
        final CommonResponse d = a4.d(h, q.a.F(), a2);
        if (d.c()) {
            a.e("");
        }
        return r.a(d);
    }
    
    private static final Unit w(com.beetalk.sdk.s s, final s$h s$h, final Activity activity, final o o) {
        Intrinsics.checkNotNullParameter((Object)s$h, "$callback");
        Intrinsics.checkNotNullParameter((Object)activity, "$activity");
        Intrinsics.checkNotNullParameter((Object)o, "it");
        final boolean u = o.u();
        final String s2 = "";
        final String s3 = null;
        if (!u && !o.s()) {
            final Object r = o.r();
            Intrinsics.c(r);
            final g1.a a = (g1.a)r;
            if (((CharSequence)((CommonResponse)a).b()).length() > 0) {
                final W2.b a2 = e1.a.a.a((CommonResponse)a);
                if (a2.a() == l.g1) {
                    com.beetalk.sdk.s.f0((com.beetalk.sdk.s)null);
                    s.J();
                }
                s = new s$f().a();
                final B0 f = B0.f;
                final Integer b = a2.a().b();
                Intrinsics.checkNotNullExpressionValue((Object)b, "getCode(...)");
                s$h.onSessionProcessed(s.g0(f, ((Number)b).intValue()), (Exception)a2);
                return Unit.a;
            }
            Intrinsics.c((Object)s);
            ((com.beetalk.sdk.cache.l)k.q()).l(a.d(s));
            s.J();
            e1.c.a.f("");
            if (X.U(activity)) {
                X.e0(activity, s$h);
            }
            else {
                s = new s$f().a();
                final B0 f2 = B0.f;
                final Integer b2 = l.h.b();
                Intrinsics.checkNotNullExpressionValue((Object)b2, "getCode(...)");
                s$h.onSessionProcessed(s.g0(f2, ((Number)b2).intValue()), (Exception)null);
            }
        }
        else {
            final Exception q = o.q();
            W2.b b3;
            if (q instanceof W2.b) {
                b3 = (W2.b)q;
            }
            else {
                b3 = null;
            }
            W2.b b4 = b3;
            if (b3 == null) {
                final l l = com.garena.pay.android.l.l;
                String message = s3;
                if (q != null) {
                    message = ((Throwable)q).getMessage();
                }
                if (message == null) {
                    message = s2;
                }
                b4 = new W2.b(l, message);
            }
            com.beetalk.sdk.s a3;
            if ((a3 = s) == null) {
                a3 = new s$f().a();
            }
            final B0 f3 = B0.f;
            final Integer b5 = b4.a().b();
            Intrinsics.checkNotNullExpressionValue((Object)b5, "getCode(...)");
            a3.g0(f3, ((Number)b5).intValue());
            s$h.onSessionProcessed(a3, q);
        }
        return Unit.a;
    }
    
    private final o x(final com.beetalk.sdk.s s) {
        if (s == null) {
            return o.j.r((Exception)new W2.b(l.g1, "swap session doesn't exist"));
        }
        final k1.a h = s.H();
        String c;
        if (h != null) {
            c = h.c();
        }
        else {
            c = null;
        }
        final String b = e1.c.a.b();
        final String h2 = t.h(X.M());
        if (c == null || ((CharSequence)c).length() == 0) {
            return o.j.r((Exception)new W2.b(l.g1, "invalid access token"));
        }
        if (((CharSequence)b).length() == 0) {
            return o.j.r((Exception)new W2.b(l.y, "invalid swap OpenID"));
        }
        if (h2 != null && ((CharSequence)h2).length() != 0) {
            return o.j.j((Callable)new g(b, c, h2));
        }
        return o.j.r((Exception)new W2.b(l.g1, "invalid AppID"));
    }
    
    private static final g1.a y(final String s, final String s2, final String s3) {
        Intrinsics.checkNotNullParameter((Object)s, "$openId");
        return s.a.e(s, s2, s3);
    }
    
    public final void B(final Activity activity, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        M.e(activity, x$e, (Callable)new n());
    }
    
    public final void D(final Activity activity, final String s, final Locale locale, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)s, "region");
        Intrinsics.checkNotNullParameter((Object)locale, "locale");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        M.e(activity, x$e, (Callable)new e1.o(c, s, locale));
    }
    
    public final void G(final Activity activity, final String s, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)s, "otp");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        M.e(activity, x$e, (Callable)new e1.d(s, c));
    }
    
    public final void I(final Activity activity, final a$b a$b, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)a$b, "credential");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        M.e(activity, x$e, (Callable)new m(a$b, c));
    }
    
    public final void K(final Activity activity, final a$c a$c, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)a$c, "credential");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        M.e(activity, x$e, (Callable)new e1.e(a$c, c));
    }
    
    public final void M(final Activity activity, final String s, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)s, "otp");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        M.e(activity, x$e, (Callable)new j(s, c));
    }
    
    public final void n(final Activity activity, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        M.e(activity, x$e, (Callable)new e1.l());
    }
    
    public final void p(final Activity activity, final c c, final String s, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)s, "secondaryPassword");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        M.e(activity, x$e, (Callable)new i(s, c));
    }
    
    public final void r(final Activity activity, final c c, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        M.e(activity, x$e, (Callable)new p(c));
    }
    
    public final void t(final Activity activity, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        M.e(activity, x$e, (Callable)new h());
    }
    
    public final void v(final Activity activity, final s$h s$h) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)s$h, "callback");
        final com.beetalk.sdk.s n0 = X.n0();
        com.beetalk.sdk.exts.b.a(this.x(n0), (g2.f)new f(n0, s$h, activity));
    }
    
    public final void z(final Activity activity, final String s, final Locale locale, final c c, final b b, final X$e x$e) {
        Intrinsics.checkNotNullParameter((Object)activity, "activity");
        Intrinsics.checkNotNullParameter((Object)s, "region");
        Intrinsics.checkNotNullParameter((Object)locale, "locale");
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        Intrinsics.checkNotNullParameter((Object)b, "otpFlow");
        Intrinsics.checkNotNullParameter((Object)x$e, "callback");
        M.e(activity, x$e, (Callable)new e1.k(c, s, locale, b));
    }
}
