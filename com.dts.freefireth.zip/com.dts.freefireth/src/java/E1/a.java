package e1;

import com.garena.pay.android.l;
import kotlin.jvm.internal.Intrinsics;
import W2.b;
import com.beetalk.sdk.networking.model.CommonResponse;
import kotlin.Metadata;

@Metadata
public final class a
{
    public static final a a;
    
    static {
        a = new a();
    }
    
    private a() {
    }
    
    public final b a(final CommonResponse commonResponse) {
        Intrinsics.checkNotNullParameter((Object)commonResponse, "response");
        final String b = commonResponse.b();
        switch (b.hashCode()) {
            case 2145448895: {
                if (!b.equals((Object)"error_invalid_mobile_no")) {
                    break;
                }
                final l l = com.garena.pay.android.l.x1;
                return new b(l);
            }
            case 2085495885: {
                if (!b.equals((Object)"error_unmatched_mobile")) {
                    break;
                }
                final l l = com.garena.pay.android.l.F1;
                return new b(l);
            }
            case 1916924156: {
                if (!b.equals((Object)"error_verify_otp")) {
                    break;
                }
                final l l = com.garena.pay.android.l.z1;
                return new b(l);
            }
            case 1850543265: {
                if (!b.equals((Object)"error_no_binding_found")) {
                    break;
                }
                final l l = com.garena.pay.android.l.u1;
                return new b(l);
            }
            case 1738003019: {
                if (!b.equals((Object)"error_send_otp")) {
                    break;
                }
                final l l = com.garena.pay.android.l.y1;
                return new b(l);
            }
            case 1598180756: {
                if (!b.equals((Object)"error_ongoing_request")) {
                    break;
                }
                final l l = com.garena.pay.android.l.H1;
                return new b(l);
            }
            case 1444926031: {
                if (!b.equals((Object)"error_identity_token")) {
                    break;
                }
                final l l = com.garena.pay.android.l.C1;
                return new b(l);
            }
            case 1408405095: {
                if (!b.equals((Object)"error_verifier_token")) {
                    break;
                }
                final l l = com.garena.pay.android.l.B1;
                return new b(l);
            }
            case 1203358051: {
                if (!b.equals((Object)"error_create_request")) {
                    break;
                }
                final l l = com.garena.pay.android.l.I1;
                return new b(l);
            }
            case 1168802739: {
                if (!b.equals((Object)"error_no_first_bind")) {
                    break;
                }
                final l l = com.garena.pay.android.l.u1;
                return new b(l);
            }
            case 977381715: {
                if (!b.equals((Object)"error_invalid_region")) {
                    break;
                }
                final l l = com.garena.pay.android.l.w1;
                return new b(l);
            }
            case 972718356: {
                if (!b.equals((Object)"error_unsupported_platform")) {
                    break;
                }
                final l l = com.garena.pay.android.l.e;
                return new b(l);
            }
            case 386302298: {
                if (!b.equals((Object)"error_server")) {
                    break;
                }
                final l l = com.garena.pay.android.l.a1;
                return new b(l);
            }
            case 301404038: {
                if (!b.equals((Object)"error_unmatched_password")) {
                    break;
                }
                final l l = com.garena.pay.android.l.E1;
                return new b(l);
            }
            case 296700829: {
                if (!b.equals((Object)"error_params")) {
                    break;
                }
                final l l = com.garena.pay.android.l.y;
                return new b(l);
            }
            case -26629865: {
                if (!b.equals((Object)"error_email_used")) {
                    break;
                }
                final l l = com.garena.pay.android.l.D1;
                return new b(l);
            }
            case -70218365: {
                if (!b.equals((Object)"error_mobile_used")) {
                    break;
                }
                final l l = com.garena.pay.android.l.D1;
                return new b(l);
            }
            case -96835661: {
                if (!b.equals((Object)"error_binded")) {
                    break;
                }
                final l l = com.garena.pay.android.l.A1;
                return new b(l);
            }
            case -191302841: {
                if (!b.equals((Object)"error_login_fail_limit")) {
                    break;
                }
                final l l = com.garena.pay.android.l.M1;
                return new b(l);
            }
            case -610623917: {
                if (!b.equals((Object)"error_account_swapped")) {
                    break;
                }
                final l l = com.garena.pay.android.l.L1;
                return new b(l);
            }
            case -817608446: {
                if (!b.equals((Object)"error_token")) {
                    break;
                }
                final l l = com.garena.pay.android.l.g1;
                return new b(l);
            }
            case -1172553854: {
                if (!b.equals((Object)"error_too_many_requests")) {
                    break;
                }
                final l l = com.garena.pay.android.l.v1;
                return new b(l);
            }
            case -1602742639: {
                if (!b.equals((Object)"error_unmatched_email")) {
                    break;
                }
                final l l = com.garena.pay.android.l.F1;
                return new b(l);
            }
            case -1772187886: {
                if (!b.equals((Object)"error_delete_request")) {
                    break;
                }
                final l l = com.garena.pay.android.l.J1;
                return new b(l);
            }
            case -2088847001: {
                if (!b.equals((Object)"error_account_not_swapped")) {
                    break;
                }
                final l l = com.garena.pay.android.l.K1;
                return new b(l);
            }
            case -2117277537: {
                if (!b.equals((Object)"error_app_not_configured")) {
                    break;
                }
                final l l = com.garena.pay.android.l.G1;
                return new b(l);
            }
        }
        final l l = com.garena.pay.android.l.t1;
        return new b(l);
    }
}
