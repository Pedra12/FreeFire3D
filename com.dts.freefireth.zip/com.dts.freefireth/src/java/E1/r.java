package e1;

import com.beetalk.sdk.networking.model.CommonResponse;
import kotlin.Metadata;

@Metadata
public final class r
{
    private static final String b(final CommonResponse commonResponse) {
        if (commonResponse.c()) {
            return "Success";
        }
        throw a.a.a(commonResponse);
    }
}
