package e1;

import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import com.beetalk.sdk.X;
import G7.o;
import G7.D;
import G7.p;
import com.beetalk.sdk.helper.J;
import com.beetalk.sdk.cache.h;
import L7.i;
import kotlin.Metadata;

@Metadata
public final class c
{
    public static final c a;
    static final i[] b;
    private static final h c;
    private static final J d;
    private static final J e;
    
    static {
        b = new i[] { (i)D.d((o)new p((Class)c.class, "verifierToken", "getVerifierToken()Ljava/lang/String;", 0)), (i)D.d((o)new p((Class)c.class, "identityToken", "getIdentityToken()Ljava/lang/String;", 0)) };
        final c c2 = a = new c();
        c = h.a(X.M());
        d = new J((Object)c2, (Object)"");
        e = new J((Object)c2, (Object)"");
    }
    
    private c() {
    }
    
    public final String a() {
        return (String)e1.c.e.a((Object)this, e1.c.b[1]);
    }
    
    public final String b() {
        final String b = e1.c.c.b("account_security_open_id", "");
        Intrinsics.checkNotNullExpressionValue((Object)b, "getString(...)");
        return b;
    }
    
    public final String c() {
        return (String)e1.c.d.a((Object)this, e1.c.b[0]);
    }
    
    public final void d() {
        synchronized (this) {
            final c a = e1.c.a;
            a.g("");
            a.e("");
            final Unit a2 = Unit.a;
        }
    }
    
    public final void e(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "<set-?>");
        e1.c.e.b((Object)this, e1.c.b[1], (Object)s);
    }
    
    public final void f(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "value");
        e1.c.c.c("account_security_open_id", s);
    }
    
    public final void g(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "<set-?>");
        e1.c.d.b((Object)this, e1.c.b[0], (Object)s);
    }
}
