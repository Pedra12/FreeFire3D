package e1;

import h1.c;
import kotlin.jvm.internal.Intrinsics;
import h1.a;
import com.garena.pay.android.l;
import kotlin.text.StringsKt;
import kotlin.Metadata;

@Metadata
public final class b
{
    public static final b a;
    
    static {
        a = new b();
    }
    
    private b() {
    }
    
    private final void a(final String s, final String s2) {
        if (s != null && !StringsKt.b0((CharSequence)s)) {
            return;
        }
        throw new W2.b(l.y, s2);
    }
    
    public final void b(final String s) {
        this.a(s, "Invalid appId");
    }
    
    public final void c(final a a) {
        Intrinsics.checkNotNullParameter((Object)a, "credential");
        this.a(a.a(), "Credential data cannot be empty");
    }
    
    public final void d(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "content");
        this.a(s, "Identity data not found. Please verify current account by OTP");
    }
    
    public final void e(final c c) {
        Intrinsics.checkNotNullParameter((Object)c, "recipient");
        this.a(c.b(), "OTPRecipient data cannot be empty");
    }
    
    public final void f(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "content");
        this.a(s, "Secondary password cannot be empty");
    }
    
    public final void g(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "content");
        this.a(s, "Verification data not found. Please verify current account by OTP");
    }
    
    public final void h(final String s) {
        Intrinsics.checkNotNullParameter((Object)s, "otp");
        this.a(s, "OTP cannot be empty");
    }
}
