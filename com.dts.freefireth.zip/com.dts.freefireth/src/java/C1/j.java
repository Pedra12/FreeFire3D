package c1;

public class j
{
    private final i a;
    
    public j() {
        this.a = new i();
    }
    
    public i a() {
        return this.a;
    }
    
    public void b() {
        if (this.e()) {
            return;
        }
        throw new IllegalStateException("Cannot cancel a completed task.");
    }
    
    public void c(final Exception ex) {
        if (this.f(ex)) {
            return;
        }
        throw new IllegalStateException("Cannot set the error on a completed task.");
    }
    
    public void d(final Object o) {
        if (this.g(o)) {
            return;
        }
        throw new IllegalStateException("Cannot set the result of a completed task.");
    }
    
    public boolean e() {
        return this.a.H();
    }
    
    public boolean f(final Exception ex) {
        return this.a.I(ex);
    }
    
    public boolean g(final Object o) {
        return this.a.J(o);
    }
}
