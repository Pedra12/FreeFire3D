package c1;

import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ExecutorService;

final class c
{
    private static final c d;
    private final ExecutorService a;
    private final ScheduledExecutorService b;
    private final Executor c;
    
    static {
        d = new c();
    }
    
    private c() {
        ExecutorService a;
        if (!c()) {
            a = Executors.newCachedThreadPool();
        }
        else {
            a = c1.b.b();
        }
        this.a = a;
        this.b = Executors.newSingleThreadScheduledExecutor();
        this.c = (Executor)new b();
    }
    
    public static ExecutorService a() {
        return c.d.a;
    }
    
    static Executor b() {
        return c.d.c;
    }
    
    private static boolean c() {
        final String property = System.getProperty("java.runtime.name");
        return property != null && property.toLowerCase(Locale.US).contains((CharSequence)"android");
    }
    
    static ScheduledExecutorService d() {
        return c.d.b;
    }
    
    private static class b implements Executor
    {
        private ThreadLocal a;
        
        private b() {
            this.a = new ThreadLocal();
        }
        
        private int a() {
            Integer value;
            if ((value = (Integer)this.a.get()) == null) {
                value = 0;
            }
            final int n = value - 1;
            if (n == 0) {
                this.a.remove();
                return n;
            }
            this.a.set((Object)n);
            return n;
        }
        
        private int b() {
            Integer value;
            if ((value = (Integer)this.a.get()) == null) {
                value = 0;
            }
            final int n = value + 1;
            this.a.set((Object)n);
            return n;
        }
        
        public void execute(final Runnable runnable) {
            Label_0031: {
                Label_0022: {
                    if (this.b() <= 15) {
                        Label_0037: {
                            try {
                                runnable.run();
                                break Label_0031;
                            }
                            finally {
                                break Label_0037;
                            }
                            break Label_0022;
                        }
                        this.a();
                    }
                }
                ((Executor)c1.c.a()).execute(runnable);
            }
            this.a();
        }
    }
}
