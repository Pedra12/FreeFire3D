package c1;

import java.io.Closeable;

public class e implements Closeable, AutoCloseable
{
    private final Object a;
    private f b;
    private Runnable c;
    private boolean d;
    
    e(final f b, final Runnable c) {
        this.a = new Object();
        this.b = b;
        this.c = c;
    }
    
    private void b() {
        if (!this.d) {
            return;
        }
        throw new IllegalStateException("Object already closed");
    }
    
    void a() {
        final Object a = this.a;
        synchronized (a) {
            this.b();
            this.c.run();
            this.close();
        }
    }
    
    public void close() {
        final Object a;
        monitorenter(a = this.a);
        Label_0023: {
            try {
                if (this.d) {
                    monitorexit(a);
                    return;
                }
                break Label_0023;
            }
            finally {
                monitorexit(a);
                this.d = true;
                this.b.h(this);
                this.b = null;
                this.c = null;
                monitorexit(a);
            }
        }
    }
}
