package c1;

import java.util.Locale;

public class d
{
    private final f a;
    
    d(final f a) {
        this.a = a;
    }
    
    public boolean a() {
        return this.a.d();
    }
    
    public e b(final Runnable runnable) {
        return this.a.f(runnable);
    }
    
    @Override
    public String toString() {
        return String.format(Locale.US, "%s@%s[cancellationRequested=%s]", new Object[] { this.getClass().getName(), Integer.toHexString(this.hashCode()), Boolean.toString(this.a.d()) });
    }
}
