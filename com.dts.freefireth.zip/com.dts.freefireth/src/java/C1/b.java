package c1;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.Executor;

final class b
{
    private static final b b;
    private static final int c;
    static final int d;
    static final int e;
    private final Executor a;
    
    static {
        b = new b();
        final int n = c = Runtime.getRuntime().availableProcessors();
        d = n + 1;
        e = n * 2 + 1;
    }
    
    private b() {
        this.a = (Executor)new b();
    }
    
    public static void a(final ThreadPoolExecutor threadPoolExecutor, final boolean b) {
        threadPoolExecutor.allowCoreThreadTimeOut(b);
    }
    
    public static ExecutorService b() {
        final ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(c1.b.d, c1.b.e, 1L, TimeUnit.SECONDS, (BlockingQueue)new LinkedBlockingQueue());
        a(threadPoolExecutor, true);
        return (ExecutorService)threadPoolExecutor;
    }
    
    public static Executor c() {
        return c1.b.b.a;
    }
    
    private static class b implements Executor
    {
        public void execute(final Runnable runnable) {
            new Handler(Looper.getMainLooper()).post(runnable);
        }
    }
}
