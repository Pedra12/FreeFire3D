package c1;

abstract class k
{
    public abstract void a();
}
