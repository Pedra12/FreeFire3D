package c1;

import java.io.PrintWriter;
import java.util.Iterator;
import java.io.PrintStream;
import j$.util.DesugarCollections;
import java.util.List;

public class a extends Exception
{
    private static final long serialVersionUID = 1L;
    private List a;
    
    public a(final String s, final List list) {
        Throwable t;
        if (list != null && list.size() > 0) {
            t = (Throwable)list.get(0);
        }
        else {
            t = null;
        }
        super(s, t);
        this.a = DesugarCollections.unmodifiableList(list);
    }
    
    public void printStackTrace(final PrintStream printStream) {
        super.printStackTrace(printStream);
        final Iterator iterator = this.a.iterator();
        int n = -1;
        while (iterator.hasNext()) {
            final Throwable t = (Throwable)iterator.next();
            printStream.append((CharSequence)"\n");
            printStream.append((CharSequence)"  Inner throwable #");
            ++n;
            printStream.append((CharSequence)Integer.toString(n));
            printStream.append((CharSequence)": ");
            t.printStackTrace(printStream);
            printStream.append((CharSequence)"\n");
        }
    }
    
    public void printStackTrace(final PrintWriter printWriter) {
        super.printStackTrace(printWriter);
        final Iterator iterator = this.a.iterator();
        int n = -1;
        while (iterator.hasNext()) {
            final Throwable t = (Throwable)iterator.next();
            printWriter.append((CharSequence)"\n");
            printWriter.append((CharSequence)"  Inner throwable #");
            ++n;
            printWriter.append((CharSequence)Integer.toString(n));
            printWriter.append((CharSequence)": ");
            t.printStackTrace(printWriter);
            printWriter.append((CharSequence)"\n");
        }
    }
}
