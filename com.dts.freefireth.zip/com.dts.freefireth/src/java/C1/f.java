package c1;

import java.util.concurrent.Future;
import java.util.Locale;
import java.util.Collection;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledExecutorService;
import java.util.List;
import java.io.Closeable;

public class f implements Closeable, AutoCloseable
{
    private final Object a;
    private final List b;
    private final ScheduledExecutorService c;
    private ScheduledFuture d;
    private boolean e;
    private boolean f;
    
    public f() {
        this.a = new Object();
        this.b = (List)new ArrayList();
        this.c = c1.c.d();
    }
    
    private void b() {
        final ScheduledFuture d = this.d;
        if (d != null) {
            ((Future)d).cancel(true);
            this.d = null;
        }
    }
    
    private void e(final List list) {
        final Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            ((e)iterator.next()).a();
        }
    }
    
    private void g() {
        if (!this.f) {
            return;
        }
        throw new IllegalStateException("Object already closed");
    }
    
    public void a() {
        final Object a;
        monitorenter(a = this.a);
        Label_0027: {
            try {
                this.g();
                if (this.e) {
                    monitorexit(a);
                    return;
                }
                break Label_0027;
            }
            finally {
                monitorexit(a);
                this.b();
                this.e = true;
                final ArrayList list = new ArrayList((Collection)this.b);
                monitorexit(a);
                this.e((List)list);
            }
        }
    }
    
    public d c() {
        final Object a = this.a;
        synchronized (a) {
            this.g();
            return new d(this);
        }
    }
    
    public void close() {
        final Object a;
        monitorenter(a = this.a);
        Label_0023: {
            try {
                if (this.f) {
                    monitorexit(a);
                    return;
                }
                break Label_0023;
            }
            finally {
                monitorexit(a);
                while (true) {
                    final Iterator iterator;
                    iftrue(Label_0061:)(!iterator.hasNext());
                    Block_5: {
                        break Block_5;
                        this.b();
                        iterator = this.b.iterator();
                        continue;
                        Label_0061: {
                            this.b.clear();
                        }
                        this.f = true;
                        monitorexit(a);
                        return;
                    }
                    ((e)iterator.next()).close();
                    continue;
                }
            }
        }
    }
    
    public boolean d() {
        final Object a = this.a;
        synchronized (a) {
            this.g();
            return this.e;
        }
    }
    
    e f(final Runnable runnable) {
        final Object a;
        monitorenter(a = this.a);
        Label_0042: {
            try {
                this.g();
                final e e = new e(this, runnable);
                if (this.e) {
                    e.a();
                    break Label_0042;
                }
                break Label_0042;
            }
            finally {
                monitorexit(a);
                final e e;
                this.b.add((Object)e);
                monitorexit(a);
                return e;
            }
        }
    }
    
    void h(final e e) {
        final Object a = this.a;
        synchronized (a) {
            this.g();
            this.b.remove((Object)e);
        }
    }
    
    @Override
    public String toString() {
        return String.format(Locale.US, "%s@%s[cancellationRequested=%s]", new Object[] { this.getClass().getName(), Integer.toHexString(this.hashCode()), Boolean.toString(this.d()) });
    }
}
