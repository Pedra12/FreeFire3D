package c1;

public class h extends RuntimeException
{
    public h(final Exception ex) {
        super("An exception was thrown by an Executor", (Throwable)ex);
    }
}
