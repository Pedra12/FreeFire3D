package c1;

public interface g
{
    Object a(final i p0);
}
