package c1;

import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Callable;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Collection;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

public class i
{
    public static final ExecutorService i;
    private static final Executor j;
    public static final Executor k;
    private static i l;
    private static i m;
    private static i n;
    private static i o;
    private final Object a;
    private boolean b;
    private boolean c;
    private Object d;
    private Exception e;
    private boolean f;
    private k g;
    private List h;
    
    static {
        i = c.a();
        j = c.b();
        k = b.c();
        c1.i.l = new i(null);
        c1.i.m = new i(Boolean.TRUE);
        c1.i.n = new i(Boolean.FALSE);
        c1.i.o = new i(true);
    }
    
    i() {
        this.a = new Object();
        this.h = (List)new ArrayList();
    }
    
    private i(final Object o) {
        this.a = new Object();
        this.h = (List)new ArrayList();
        this.J(o);
    }
    
    private i(final boolean b) {
        this.a = new Object();
        this.h = (List)new ArrayList();
        if (b) {
            this.H();
            return;
        }
        this.J(null);
    }
    
    private void G() {
        final Object a;
        monitorenter(a = this.a);
        while (true) {
            g g = null;
            Label_0069: {
                try {
                    for (final g g2 : this.h) {
                        g = g2;
                        final i i = this;
                        g2.a(i);
                    }
                    break Label_0069;
                }
                finally {
                    monitorexit(a);
                    this.h = null;
                    monitorexit(a);
                    return;
                }
            }
            try {
                final g g2 = g;
                final i i = this;
                g2.a(i);
                continue;
            }
            catch (final Exception ex) {}
            catch (final RuntimeException ex2) {}
            break;
        }
    }
    
    public static i L(final Collection collection) {
        if (collection.size() == 0) {
            return t(null);
        }
        final j j = new j();
        final ArrayList list = new ArrayList();
        final Object o = new Object();
        final AtomicInteger atomicInteger = new AtomicInteger(collection.size());
        final AtomicBoolean atomicBoolean = new AtomicBoolean(false);
        final Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            ((i)iterator.next()).k((g)new g(o, list, atomicBoolean, atomicInteger, j) {
                final Object a;
                final ArrayList b;
                final AtomicBoolean c;
                final AtomicInteger d;
                final j e;
                
                public Void b(final i i) {
                    if (i.z()) {
                        final Object a = this.a;
                        synchronized (a) {
                            this.b.add((Object)i.u());
                        }
                    }
                    if (i.x()) {
                        this.c.set(true);
                    }
                    if (this.d.decrementAndGet() == 0) {
                        if (this.b.size() != 0) {
                            if (this.b.size() == 1) {
                                this.e.c((Exception)this.b.get(0));
                            }
                            else {
                                this.e.c(new a(String.format("There were %d exceptions.", new Object[] { this.b.size() }), (List)this.b));
                            }
                        }
                        else if (this.c.get()) {
                            this.e.b();
                        }
                        else {
                            this.e.d(null);
                        }
                    }
                    return null;
                }
            });
        }
        return j.a();
    }
    
    public static i M(final Collection collection) {
        return L(collection).A((g)new g(collection) {
            final Collection a;
            
            public List b(final i i) {
                if (this.a.size() == 0) {
                    return Collections.EMPTY_LIST;
                }
                final ArrayList list = new ArrayList();
                final Iterator iterator = this.a.iterator();
                while (iterator.hasNext()) {
                    ((List)list).add(((i)iterator.next()).v());
                }
                return (List)list;
            }
        });
    }
    
    public static i N(final Collection collection) {
        if (collection.size() == 0) {
            return t(null);
        }
        final j j = new j();
        final AtomicBoolean atomicBoolean = new AtomicBoolean(false);
        final Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            ((i)iterator.next()).k((g)new g(atomicBoolean, j) {
                final AtomicBoolean a;
                final j b;
                
                public Void b(final i i) {
                    if (this.a.compareAndSet(false, true)) {
                        this.b.d(i);
                    }
                    else {
                        i.u();
                    }
                    return null;
                }
            });
        }
        return j.a();
    }
    
    public static i c(final Callable callable, final d d) {
        return e(callable, c1.i.j, d);
    }
    
    public static i d(final Callable callable, final Executor executor) {
        return e(callable, executor, null);
    }
    
    public static i e(final Callable callable, final Executor executor, final d d) {
        final j j = new j();
        try {
            executor.execute((Runnable)new Runnable(d, j, callable) {
                final d a;
                final j b;
                final Callable c;
                
                public void run() {
                    final d a = this.a;
                    if (a != null && a.a()) {
                        this.b.b();
                        return;
                    }
                    try {
                        this.b.d(this.c.call());
                    }
                    catch (final Exception ex) {
                        this.b.c(ex);
                    }
                    catch (final CancellationException ex2) {
                        this.b.b();
                    }
                }
            });
        }
        catch (final Exception ex) {
            j.c((Exception)new h(ex));
        }
        return j.a();
    }
    
    public static i f(final Callable callable) {
        return e(callable, (Executor)c1.i.i, null);
    }
    
    public static i g(final Callable callable, final d d) {
        return e(callable, (Executor)c1.i.i, d);
    }
    
    public static i h() {
        return c1.i.o;
    }
    
    private static void i(final j j, final g g, final i i, final Executor executor, final d d) {
        try {
            executor.execute((Runnable)new Runnable(d, j, g, i) {
                final d a;
                final j b;
                final g c;
                final i d;
                
                public void run() {
                    final d a = this.a;
                    if (a != null && a.a()) {
                        this.b.b();
                        return;
                    }
                    try {
                        if (this.c.a(this.d) == null) {
                            this.b.d(null);
                            return;
                        }
                        goto Label_0058;
                    }
                    catch (final Exception ex) {
                        goto Label_0074;
                    }
                    catch (final CancellationException ex2) {
                        this.b.b();
                    }
                }
            });
        }
        catch (final Exception ex) {
            j.c((Exception)new h(ex));
        }
    }
    
    private static void j(final j j, final g g, final i i, final Executor executor, final d d) {
        try {
            executor.execute((Runnable)new Runnable(d, j, g, i) {
                final d a;
                final j b;
                final g c;
                final i d;
                
                public void run() {
                    final d a = this.a;
                    if (a != null && a.a()) {
                        this.b.b();
                        return;
                    }
                    try {
                        this.b.d(this.c.a(this.d));
                    }
                    catch (final Exception ex) {
                        this.b.c(ex);
                    }
                    catch (final CancellationException ex2) {
                        this.b.b();
                    }
                }
            });
        }
        catch (final Exception ex) {
            j.c((Exception)new h(ex));
        }
    }
    
    public static i q(final long n, final d d) {
        return r(n, c.d(), d);
    }
    
    static i r(final long n, final ScheduledExecutorService scheduledExecutorService, final d d) {
        if (d != null && d.a()) {
            return h();
        }
        if (n <= 0L) {
            return t(null);
        }
        final j j = new j();
        final ScheduledFuture schedule = scheduledExecutorService.schedule((Runnable)new Runnable(j) {
            final j a;
            
            public void run() {
                this.a.g(null);
            }
        }, n, TimeUnit.MILLISECONDS);
        if (d != null) {
            d.b((Runnable)new Runnable(schedule, j) {
                final ScheduledFuture a;
                final j b;
                
                public void run() {
                    ((Future)this.a).cancel(true);
                    this.b.e();
                }
            });
        }
        return j.a();
    }
    
    public static i s(final Exception ex) {
        final j j = new j();
        j.c(ex);
        return j.a();
    }
    
    public static i t(final Object o) {
        if (o == null) {
            return c1.i.l;
        }
        if (!(o instanceof Boolean)) {
            final j j = new j();
            j.d(o);
            return j.a();
        }
        if (o) {
            return c1.i.m;
        }
        return c1.i.n;
    }
    
    public static m w() {
        return null;
    }
    
    public i A(final g g) {
        return this.B(g, c1.i.j, null);
    }
    
    public i B(final g g, final Executor executor, final d d) {
        return this.o((g)new g(this, d, g) {
            final d a;
            final g b;
            final i c;
            
            public i b(final i i) {
                final d a = this.a;
                if (a != null && a.a()) {
                    return i.h();
                }
                if (i.z()) {
                    return i.s(i.u());
                }
                if (i.x()) {
                    return i.h();
                }
                return i.k(this.b);
            }
        }, executor);
    }
    
    public i C(final g g) {
        return this.E(g, c1.i.j);
    }
    
    public i D(final g g, final d d) {
        return this.F(g, c1.i.j, d);
    }
    
    public i E(final g g, final Executor executor) {
        return this.F(g, executor, null);
    }
    
    public i F(final g g, final Executor executor, final d d) {
        return this.o((g)new g(this, d, g) {
            final d a;
            final g b;
            final i c;
            
            public i b(final i i) {
                final d a = this.a;
                if (a != null && a.a()) {
                    return i.h();
                }
                if (i.z()) {
                    return i.s(i.u());
                }
                if (i.x()) {
                    return i.h();
                }
                return i.n(this.b);
            }
        }, executor);
    }
    
    boolean H() {
        final Object a;
        monitorenter(a = this.a);
        Label_0024: {
            try {
                if (this.b) {
                    monitorexit(a);
                    return false;
                }
                break Label_0024;
            }
            finally {
                monitorexit(a);
                this.b = true;
                this.c = true;
                this.a.notifyAll();
                this.G();
                monitorexit(a);
                return true;
            }
        }
    }
    
    boolean I(final Exception e) {
        final Object a;
        monitorenter(a = this.a);
        Label_0024: {
            try {
                if (this.b) {
                    monitorexit(a);
                    return false;
                }
                break Label_0024;
            }
            finally {
                monitorexit(a);
                this.b = true;
                this.e = e;
                this.f = false;
                this.a.notifyAll();
                this.G();
                iftrue(Label_0061:)(this.f);
                w();
                Label_0061: {
                    monitorexit(a);
                }
                return true;
            }
        }
    }
    
    boolean J(final Object d) {
        final Object a;
        monitorenter(a = this.a);
        Label_0024: {
            try {
                if (this.b) {
                    monitorexit(a);
                    return false;
                }
                break Label_0024;
            }
            finally {
                monitorexit(a);
                this.b = true;
                this.d = d;
                this.a.notifyAll();
                this.G();
                monitorexit(a);
                return true;
            }
        }
    }
    
    public void K() {
        final Object a;
        monitorenter(a = this.a);
        Label_0030: {
            try {
                if (!this.y()) {
                    this.a.wait();
                }
                break Label_0030;
            }
            finally {
                monitorexit(a);
                monitorexit(a);
            }
        }
    }
    
    public i k(final g g) {
        return this.m(g, c1.i.j, null);
    }
    
    public i l(final g g, final Executor executor) {
        return this.m(g, executor, null);
    }
    
    public i m(final g g, final Executor executor, final d d) {
        final j j = new j();
        final Object a;
        monitorenter(a = this.a);
        Label_0098: {
            boolean y = false;
            Label_0075: {
                while (true) {
                    try {
                        y = this.y();
                        if (!y) {
                            final List h = this.h;
                            try {
                                h.add((Object)new g(this, j, g, executor, d) {
                                    final j a;
                                    final g b;
                                    final Executor c;
                                    final d d;
                                    final i e;
                                    
                                    public Void b(final i i) {
                                        j(this.a, this.b, i, this.c, this.d);
                                        return null;
                                    }
                                });
                                break Label_0075;
                            }
                            finally {}
                            break Label_0098;
                        }
                    }
                    finally {
                        continue;
                    }
                    break;
                }
            }
            monitorexit(a);
            if (y) {
                final g g2;
                j(j, g2, this, executor, d);
            }
            return j.a();
        }
        monitorexit(a);
    }
    
    public i n(final g g) {
        return this.p(g, c1.i.j, null);
    }
    
    public i o(final g g, final Executor executor) {
        return this.p(g, executor, null);
    }
    
    public i p(final g g, final Executor executor, final d d) {
        final j j = new j();
        final Object a;
        monitorenter(a = this.a);
        Label_0098: {
            boolean y = false;
            Label_0075: {
                while (true) {
                    try {
                        y = this.y();
                        if (!y) {
                            final List h = this.h;
                            try {
                                h.add((Object)new g(this, j, g, executor, d) {
                                    final j a;
                                    final g b;
                                    final Executor c;
                                    final d d;
                                    final i e;
                                    
                                    public Void b(final i i) {
                                        i(this.a, this.b, i, this.c, this.d);
                                        return null;
                                    }
                                });
                                break Label_0075;
                            }
                            finally {}
                            break Label_0098;
                        }
                    }
                    finally {
                        continue;
                    }
                    break;
                }
            }
            monitorexit(a);
            if (y) {
                final g g2;
                i(j, g2, this, executor, d);
            }
            return j.a();
        }
        monitorexit(a);
    }
    
    public Exception u() {
        final Object a;
        monitorenter(a = this.a);
        Label_0028: {
            try {
                if (this.e != null) {
                    this.f = true;
                }
                break Label_0028;
            }
            finally {
                monitorexit(a);
                final Exception e = this.e;
                monitorexit(a);
                return e;
            }
        }
    }
    
    public Object v() {
        final Object a = this.a;
        synchronized (a) {
            return this.d;
        }
    }
    
    public boolean x() {
        final Object a = this.a;
        synchronized (a) {
            return this.c;
        }
    }
    
    public boolean y() {
        final Object a = this.a;
        synchronized (a) {
            return this.b;
        }
    }
    
    public boolean z() {
        final Object a = this.a;
        synchronized (a) {
            return this.u() != null;
        }
    }
    
    public interface m
    {
    }
}
