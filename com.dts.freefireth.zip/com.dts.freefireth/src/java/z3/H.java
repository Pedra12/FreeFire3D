package z3;

import java.io.Closeable;
import com.google.android.gms.common.util.l;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import j$.util.concurrent.ConcurrentHashMap;

public class h
{
    private static final e b;
    private static final h c;
    private final ConcurrentHashMap a;
    
    static {
        b = new e("LibraryVersion", "");
        c = new h();
    }
    
    protected h() {
        this.a = new ConcurrentHashMap();
    }
    
    public static h a() {
        return h.c;
    }
    
    public String b(final String s) {
        k.g(s, "Please provide a valid libraryName");
        final ConcurrentHashMap a = this.a;
        if (a.containsKey(s)) {
            return (String)a.get(s);
        }
        final Properties properties = new Properties();
        Object o = null;
        Object property = null;
        Object o2 = null;
        final InputStream inputStream = null;
        Label_0491: {
            Object resourceAsStream = null;
            final String s2;
            Label_0444: {
                Label_0348: {
                    try {
                        resourceAsStream = h.class.getResourceAsStream(String.format("/%s.properties", new Object[] { s }));
                        Label_0240: {
                            if (resourceAsStream != null) {
                                property = inputStream;
                                Label_0329: {
                                    try {
                                        properties.load((InputStream)resourceAsStream);
                                        property = inputStream;
                                        o = (property = properties.getProperty("version", (String)null));
                                        final e b = h.b;
                                        property = o;
                                        final int length = String.valueOf((Object)s).length();
                                        property = o;
                                        final int length2 = String.valueOf(o).length();
                                        property = o;
                                        property = o;
                                        o2 = new StringBuilder(length + 12 + length2);
                                        property = o;
                                        ((StringBuilder)o2).append(s);
                                        property = o;
                                        ((StringBuilder)o2).append(" version is ");
                                        property = o;
                                        ((StringBuilder)o2).append((String)o);
                                        property = o;
                                        b.f("LibraryVersion", ((StringBuilder)o2).toString());
                                        property = o;
                                        break Label_0444;
                                    }
                                    catch (final IOException o2) {
                                        o = property;
                                        property = resourceAsStream;
                                        resourceAsStream = o;
                                        break Label_0348;
                                    }
                                    finally {
                                        break Label_0329;
                                    }
                                    break Label_0240;
                                }
                                o = resourceAsStream;
                            }
                        }
                        property = inputStream;
                        final e b2 = h.b;
                        property = inputStream;
                        final int length3 = String.valueOf((Object)s).length();
                        property = inputStream;
                        o = new(java.lang.StringBuilder.class)();
                        property = inputStream;
                        new StringBuilder(length3 + 43);
                        property = inputStream;
                        ((StringBuilder)o).append("Failed to get app version for libraryName: ");
                        property = inputStream;
                        ((StringBuilder)o).append(s);
                        property = inputStream;
                        b2.g("LibraryVersion", ((StringBuilder)o).toString());
                        property = o2;
                        break Label_0444;
                    }
                    catch (final IOException o2) {}
                    finally {
                        break Label_0491;
                    }
                    resourceAsStream = null;
                }
                final e b3 = h.b;
                final StringBuilder sb = new StringBuilder(String.valueOf((Object)s2).length() + 43);
                sb.append("Failed to get app version for libraryName: ");
                sb.append(s2);
                b3.e("LibraryVersion", sb.toString(), (Throwable)o2);
                final InputStream inputStream2 = (InputStream)property;
                property = resourceAsStream;
                resourceAsStream = inputStream2;
            }
            if (resourceAsStream != null) {
                l.a((Closeable)resourceAsStream);
            }
            String s3;
            if ((s3 = (String)property) == null) {
                h.b.b("LibraryVersion", ".properties file is dropped during release process. Failure to read app version is expected during Google internal testing where locally-built libraries are used");
                s3 = "UNKNOWN";
            }
            this.a.put(s2, s3);
            return s3;
        }
        if (o != null) {
            l.a((Closeable)o);
        }
    }
}
