package z3;

final class w implements z
{
}
