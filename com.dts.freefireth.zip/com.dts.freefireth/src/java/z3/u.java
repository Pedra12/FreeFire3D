package z3;

import com.google.android.gms.common.api.a$f;
import android.content.Context;
import com.google.android.gms.common.GoogleApiAvailabilityLight;
import android.util.SparseIntArray;

public final class u
{
    private final SparseIntArray a;
    private GoogleApiAvailabilityLight b;
    
    public u(final GoogleApiAvailabilityLight b) {
        this.a = new SparseIntArray();
        k.l(b);
        this.b = b;
    }
    
    public final int a(final Context context, int value) {
        final SparseIntArray a = this.a;
        synchronized (a) {
            value = this.a.get(value, -1);
            return value;
        }
    }
    
    public final int b(final Context context, final a$f a$f) {
        k.l(context);
        k.l(a$f);
        final boolean j = a$f.j();
        final int n = 0;
        if (!j) {
            return 0;
        }
        final int k = a$f.k();
        final int a = this.a(context, k);
        if (a != -1) {
            return a;
        }
        final SparseIntArray a2;
        monitorenter(a2 = this.a);
        int n2 = 0;
    Label_0141_Outer:
        while (true) {
            Label_0113: {
                try {
                    if (n2 >= this.a.size()) {
                        break Label_0113;
                    }
                    final int key = this.a.keyAt(n2);
                    if (key > k && this.a.get(key) == 0) {
                        final int n3 = n;
                        break Label_0113;
                    }
                    break Label_0113;
                }
                finally {
                    monitorexit(a2);
                    final int n3 = -1;
                    break Label_0113;
                    while (true) {
                        int googlePlayServicesAvailable = 0;
                        this.a.put(k, googlePlayServicesAvailable);
                        monitorexit(a2);
                        return googlePlayServicesAvailable;
                        googlePlayServicesAvailable = n3;
                        iftrue(Label_0141:)(n3 != -1);
                        Block_8: {
                            break Block_8;
                            ++n2;
                            continue Label_0141_Outer;
                        }
                        googlePlayServicesAvailable = this.b.isGooglePlayServicesAvailable(context, k);
                        continue;
                    }
                }
            }
            break;
        }
    }
    
    public final void c() {
        final SparseIntArray a = this.a;
        synchronized (a) {
            this.a.clear();
        }
    }
}
