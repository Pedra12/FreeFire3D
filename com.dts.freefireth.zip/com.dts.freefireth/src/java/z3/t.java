package z3;

import android.util.Log;
import com.google.android.gms.common.n;
import android.content.res.Resources;
import u3.b;
import android.content.pm.PackageManager$NameNotFoundException;
import android.text.TextUtils;
import I3.e;
import android.content.Context;
import java.util.Locale;
import y.i;

public abstract class t
{
    private static final i a;
    private static Locale b;
    
    static {
        a = new i();
    }
    
    public static String a(final Context context) {
        final String packageName = context.getPackageName();
        try {
            return e.a(context).d(packageName).toString();
        }
        catch (final PackageManager$NameNotFoundException | NullPointerException ex) {
            final String name = context.getApplicationInfo().name;
            if (TextUtils.isEmpty((CharSequence)name)) {
                return packageName;
            }
            return name;
        }
    }
    
    public static String b(final Context context, final int n) {
        final Resources resources = context.getResources();
        if (n == 1) {
            return resources.getString(u3.b.d);
        }
        if (n == 2) {
            return resources.getString(u3.b.j);
        }
        if (n != 3) {
            return resources.getString(17039370);
        }
        return resources.getString(u3.b.a);
    }
    
    public static String c(final Context context, final int n) {
        final Resources resources = context.getResources();
        final String a = a(context);
        if (n == 1) {
            return resources.getString(u3.b.e, new Object[] { a });
        }
        if (n != 2) {
            if (n == 3) {
                return resources.getString(u3.b.b, new Object[] { a });
            }
            if (n == 5) {
                return g(context, "common_google_play_services_invalid_account_text", a);
            }
            if (n == 7) {
                return g(context, "common_google_play_services_network_error_text", a);
            }
            if (n == 9) {
                return resources.getString(u3.b.i, new Object[] { a });
            }
            if (n == 20) {
                return g(context, "common_google_play_services_restricted_profile_text", a);
            }
            switch (n) {
                default: {
                    return resources.getString(n.a, new Object[] { a });
                }
                case 18: {
                    return resources.getString(u3.b.m, new Object[] { a });
                }
                case 17: {
                    return g(context, "common_google_play_services_sign_in_failed_text", a);
                }
                case 16: {
                    return g(context, "common_google_play_services_api_unavailable_text", a);
                }
            }
        }
        else {
            if (com.google.android.gms.common.util.i.d(context)) {
                return resources.getString(u3.b.n);
            }
            return resources.getString(u3.b.k, new Object[] { a });
        }
    }
    
    public static String d(final Context context, final int n) {
        if (n != 6 && n != 19) {
            return c(context, n);
        }
        return g(context, "common_google_play_services_resolution_required_text", a(context));
    }
    
    public static String e(final Context context, final int n) {
        String s;
        if (n == 6) {
            s = h(context, "common_google_play_services_resolution_required_title");
        }
        else {
            s = f(context, n);
        }
        if (s == null) {
            return context.getResources().getString(u3.b.h);
        }
        return s;
    }
    
    public static String f(final Context context, final int n) {
        final Resources resources = context.getResources();
        switch (n) {
            default: {
                final StringBuilder sb = new StringBuilder();
                sb.append("Unexpected error code ");
                sb.append(n);
                Log.e("GoogleApiAvailability", sb.toString());
                return null;
            }
            case 20: {
                Log.e("GoogleApiAvailability", "The current user profile is restricted and could not use authenticated features.");
                return h(context, "common_google_play_services_restricted_profile_title");
            }
            case 17: {
                Log.e("GoogleApiAvailability", "The specified account could not be signed in.");
                return h(context, "common_google_play_services_sign_in_failed_title");
            }
            case 16: {
                Log.e("GoogleApiAvailability", "One of the API components you attempted to connect to is not available.");
                return null;
            }
            case 11: {
                Log.e("GoogleApiAvailability", "The application is not licensed to the user.");
                return null;
            }
            case 10: {
                Log.e("GoogleApiAvailability", "Developer error occurred. Please see logs for detailed information");
                return null;
            }
            case 9: {
                Log.e("GoogleApiAvailability", "Google Play services is invalid. Cannot recover.");
                return null;
            }
            case 8: {
                Log.e("GoogleApiAvailability", "Internal error occurred. Please see logs for detailed information");
                return null;
            }
            case 7: {
                Log.e("GoogleApiAvailability", "Network error occurred. Please retry request later.");
                return h(context, "common_google_play_services_network_error_title");
            }
            case 5: {
                Log.e("GoogleApiAvailability", "An invalid account was specified when connecting. Please provide a valid account.");
                return h(context, "common_google_play_services_invalid_account_title");
            }
            case 4:
            case 6:
            case 18: {
                return null;
            }
            case 3: {
                return resources.getString(u3.b.c);
            }
            case 2: {
                return resources.getString(u3.b.l);
            }
            case 1: {
                return resources.getString(u3.b.f);
            }
        }
    }
    
    private static String g(final Context context, String s, final String s2) {
        final Resources resources = context.getResources();
        String s3;
        s = (s3 = h(context, s));
        if (s == null) {
            s3 = resources.getString(n.a);
        }
        return String.format(resources.getConfiguration().locale, s3, new Object[] { s2 });
    }
    
    private static String h(final Context context, final String s) {
        final i a = t.a;
        final i i;
        monitorenter(i = a);
        Label_0052: {
            try {
                final Locale d = R.e.a(context.getResources().getConfiguration()).d(0);
                if (!d.equals((Object)t.b)) {
                    a.clear();
                    t.b = d;
                }
                break Label_0052;
            }
            finally {
                monitorexit(i);
                Block_6: {
                    while (true) {
                        final StringBuilder sb = new StringBuilder();
                        sb.append("Got empty resource: ");
                        sb.append(s);
                        Log.w("GoogleApiAvailability", sb.toString());
                        monitorexit(i);
                        return null;
                        final Resources f;
                        Label_0073: {
                            f = com.google.android.gms.common.i.f(context);
                        }
                        iftrue(Label_0087:)(f != null);
                        break Block_6;
                        final int identifier;
                        Label_0137:
                        final String string = f.getString(identifier);
                        iftrue(Label_0186:)(!TextUtils.isEmpty((CharSequence)string));
                        continue;
                    }
                    while (true) {
                        monitorexit(i);
                        return;
                        final String string;
                        Label_0186: {
                            a.put(s, string);
                        }
                        monitorexit(i);
                        return string;
                        final Resources f;
                        Label_0087:
                        final int identifier = f.getIdentifier(s, "string", "com.google.android.gms");
                        iftrue(Label_0137:)(identifier != 0);
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append("Missing resource: ");
                        sb2.append(s);
                        Log.w("GoogleApiAvailability", sb2.toString());
                        monitorexit(i);
                        return null;
                        s2 = (String)a.get(s);
                        iftrue(Label_0073:)(s2 == null);
                        continue;
                    }
                }
                monitorexit(i);
                return null;
            }
        }
    }
}
