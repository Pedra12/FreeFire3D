package z3;

public interface z
{
}
