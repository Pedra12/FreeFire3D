package z3;

import B3.d;
import android.content.Context;

public abstract class n
{
    public static o a(final Context context) {
        return b(context, p.b);
    }
    
    public static o b(final Context context, final p p2) {
        return (o)new d(context, p2);
    }
}
