package z3;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.common.internal.TelemetryData;
import com.google.android.gms.common.api.HasApiKey;

public interface o extends HasApiKey
{
    Task b(final TelemetryData p0);
}
