package z3;

import android.os.BaseBundle;
import android.os.Bundle;
import com.google.android.gms.common.api.a$d;

public class p implements a$d
{
    public static final p b;
    private final String a = a;
    
    static {
        b = a().a();
    }
    
    public static a a() {
        return new a(null);
    }
    
    public final Bundle b() {
        final Bundle bundle = new Bundle();
        final String a = this.a;
        if (a != null) {
            ((BaseBundle)bundle).putString("api", a);
        }
        return bundle;
    }
    
    @Override
    public final boolean equals(final Object o) {
        return o == this || (o instanceof p && i.a(this.a, ((p)o).a));
    }
    
    @Override
    public final int hashCode() {
        return i.b(this.a);
    }
    
    public static class a
    {
        private String a;
        
        public p a() {
            return new p(this.a, null);
        }
        
        public a b(final String a) {
            this.a = a;
            return this;
        }
    }
}
