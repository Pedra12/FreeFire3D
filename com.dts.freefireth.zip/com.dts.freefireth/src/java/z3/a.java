package z3;

import w3.h;
import com.google.android.gms.common.api.Status;

public abstract class a
{
    public static w3.a a(final Status status) {
        if (status.M2()) {
            return new h(status);
        }
        return new w3.a(status);
    }
}
