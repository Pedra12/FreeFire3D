package z3;

import com.google.android.gms.common.internal.RootTelemetryConfiguration;

public final class l
{
    private static l b;
    private static final RootTelemetryConfiguration c;
    private RootTelemetryConfiguration a;
    
    static {
        c = new RootTelemetryConfiguration(0, false, false, 0, 0);
    }
    
    private l() {
    }
    
    public static l b() {
        final Class<l> clazz;
        monitorenter(clazz = l.class);
        Label_0030: {
            try {
                if (l.b == null) {
                    l.b = new l();
                }
                break Label_0030;
            }
            finally {
                monitorexit(clazz);
                final l b = l.b;
                monitorexit(clazz);
                return b;
            }
        }
    }
    
    public RootTelemetryConfiguration a() {
        return this.a;
    }
    
    public final void c(final RootTelemetryConfiguration a) {
        monitorenter(this);
        Label_0024: {
            if (a != null) {
                break Label_0024;
            }
            try {
                this.a = l.c;
                monitorexit(this);
            }
            finally {
                monitorexit(this);
                while (true) {
                    monitorexit(this);
                    return;
                    final RootTelemetryConfiguration a2 = this.a;
                    iftrue(Label_0058:)(a2 == null || a2.M2() < a.M2());
                    continue;
                }
                Label_0058: {
                    this.a = a;
                }
                monitorexit(this);
            }
        }
    }
}
