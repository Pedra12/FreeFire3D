package z3;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public abstract class i
{
    public static boolean a(final Object o, final Object obj) {
        return o == obj || (o != null && o.equals(obj));
    }
    
    public static int b(final Object... array) {
        return Arrays.hashCode(array);
    }
    
    public static a c(final Object o) {
        return new a(o, null);
    }
    
    public static final class a
    {
        private final List a;
        private final Object b;
        
        public a a(String string, final Object o) {
            k.l(string);
            final int length = string.length();
            final String value = String.valueOf(o);
            final StringBuilder sb = new StringBuilder(length + 1 + value.length());
            sb.append(string);
            sb.append("=");
            sb.append(value);
            string = sb.toString();
            this.a.add((Object)string);
            return this;
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder(100);
            sb.append(this.b.getClass().getSimpleName());
            sb.append('{');
            final List a = this.a;
            for (int size = a.size(), i = 0; i < size; ++i) {
                sb.append((String)a.get(i));
                if (i < size - 1) {
                    sb.append(", ");
                }
            }
            sb.append('}');
            return sb.toString();
        }
    }
}
