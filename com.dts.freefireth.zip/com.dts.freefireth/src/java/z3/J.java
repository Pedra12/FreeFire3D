package z3;

import w3.e$a;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.Task;
import w3.e;

public abstract class j
{
    private static final z a;
    
    static {
        a = new w();
    }
    
    public static Task a(final e e, final j.j$a j$a) {
        final z a = j.a;
        final TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
        e.c((e$a)new x(e, taskCompletionSource, j$a, a));
        return taskCompletionSource.a();
    }
    
    public static Task b(final e e) {
        return a(e, (j.j$a)new y());
    }
}
