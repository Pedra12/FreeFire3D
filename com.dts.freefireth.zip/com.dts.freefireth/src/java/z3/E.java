package z3;

import android.util.Log;

public final class e
{
    private final String a;
    private final String b;
    
    public e(final String s) {
        this(s, null);
    }
    
    public e(String s, final String s2) {
        k.m(s, "log tag cannot be null");
        final int length = s.length();
        boolean b = false;
        if (length <= 23) {
            b = true;
        }
        k.c(b, "tag \"%s\" is longer than the %d character maximum", s, 23);
        this.a = s;
        Label_0071: {
            if (s2 != null) {
                s = s2;
                if (s2.length() > 0) {
                    break Label_0071;
                }
            }
            s = null;
        }
        this.b = s;
    }
    
    private final String j(final String s) {
        final String b = this.b;
        if (b == null) {
            return s;
        }
        return b.concat(s);
    }
    
    private final String k(String format, final Object... array) {
        final String b = this.b;
        format = String.format(format, array);
        if (b == null) {
            return format;
        }
        return b.concat(format);
    }
    
    public boolean a(final int n) {
        return Log.isLoggable(this.a, n);
    }
    
    public void b(final String s, final String s2) {
        if (this.a(3)) {
            Log.d(s, this.j(s2));
        }
    }
    
    public void c(final String s, final String s2, final Throwable t) {
        if (this.a(3)) {
            Log.d(s, this.j(s2), t);
        }
    }
    
    public void d(final String s, final String s2) {
        if (this.a(6)) {
            Log.e(s, this.j(s2));
        }
    }
    
    public void e(final String s, final String s2, final Throwable t) {
        if (this.a(6)) {
            Log.e(s, this.j(s2), t);
        }
    }
    
    public void f(final String s, final String s2) {
        if (this.a(2)) {
            Log.v(s, this.j(s2));
        }
    }
    
    public void g(final String s, final String s2) {
        if (this.a(5)) {
            Log.w(s, this.j(s2));
        }
    }
    
    public void h(final String s, final String s2, final Throwable t) {
        if (this.a(5)) {
            Log.w(s, this.j(s2), t);
        }
    }
    
    public void i(final String s, final String s2, final Object... array) {
        if (this.a(5)) {
            Log.w(this.a, this.k(s2, array));
        }
    }
}
