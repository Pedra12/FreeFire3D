package z3;

import com.google.android.gms.common.n;
import android.content.Context;
import android.content.res.Resources;

public class m
{
    private final Resources a;
    private final String b;
    
    public m(final Context context) {
        k.l(context);
        final Resources resources = context.getResources();
        this.a = resources;
        this.b = resources.getResourcePackageName(n.a);
    }
    
    public String a(final String s) {
        final String b = this.b;
        final Resources a = this.a;
        final int identifier = a.getIdentifier(s, "string", b);
        if (identifier == 0) {
            return null;
        }
        return a.getString(identifier);
    }
}
