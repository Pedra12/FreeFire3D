package z3;

import android.util.Log;
import android.os.Looper;

public abstract class b
{
    public static void a(final String s) {
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            return;
        }
        final String value = String.valueOf((Object)Thread.currentThread());
        final String value2 = String.valueOf((Object)Looper.getMainLooper().getThread());
        final StringBuilder sb = new StringBuilder(value.length() + 56 + value2.length() + 1);
        sb.append("checkMainThread: current thread ");
        sb.append(value);
        sb.append(" IS NOT the main thread ");
        sb.append(value2);
        sb.append("!");
        Log.e("Asserts", sb.toString());
        throw new IllegalStateException(s);
    }
    
    public static void b(final String s) {
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            return;
        }
        final String value = String.valueOf((Object)Thread.currentThread());
        final String value2 = String.valueOf((Object)Looper.getMainLooper().getThread());
        final StringBuilder sb = new StringBuilder(value.length() + 55 + value2.length() + 1);
        sb.append("checkNotMainThread: current thread ");
        sb.append(value);
        sb.append(" IS the main thread ");
        sb.append(value2);
        sb.append("!");
        Log.e("Asserts", sb.toString());
        throw new IllegalStateException(s);
    }
    
    public static void c(final Object o) {
        if (o != null) {
            return;
        }
        throw new IllegalArgumentException("null reference");
    }
    
    public static void d(final boolean b) {
        if (b) {
            return;
        }
        throw new IllegalStateException();
    }
    
    public static void e(final boolean b, final Object o) {
        if (b) {
            return;
        }
        throw new IllegalStateException(String.valueOf(o));
    }
}
