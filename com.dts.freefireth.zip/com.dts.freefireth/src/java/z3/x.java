package z3;

import java.util.concurrent.TimeUnit;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.TaskCompletionSource;
import w3.e;
import w3.e$a;

final class x implements e$a
{
    final e a;
    final TaskCompletionSource b;
    final j$a c;
    final z d;
    
    x(final e a, final TaskCompletionSource b, final j$a c, final z d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public final void a(final Status status) {
        if (status.N2()) {
            this.b.c(this.c.a(this.a.d(0L, TimeUnit.MILLISECONDS)));
            return;
        }
        this.b.b((Exception)z3.a.a(status));
    }
}
