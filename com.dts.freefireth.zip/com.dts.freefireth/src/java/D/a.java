package d;

public abstract class a
{
    public static a a(final String s) {
        return null;
    }
}
