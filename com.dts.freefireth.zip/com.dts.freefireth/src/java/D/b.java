package d;

import android.util.Log;

public class b
{
    private b() {
    }
    
    public b(final a a) {
        this();
        Log.d("HapticPlayer", "new player");
    }
    
    public static boolean a() {
        return false;
    }
    
    public void b(final int n) {
        Log.e("HapticPlayer", "not support Haptic player api, start with loop");
    }
    
    public void c(final int n, final int n2, final int n3) {
        Log.e("HapticPlayer", "not support Haptic player api, start with loop & interval & amplitude");
    }
    
    public void d(final int n, final int n2, final int n3, final int n4) {
        Log.e("HapticPlayer", "not support Haptic player api, start with loop & interval & amplitude & freq");
    }
    
    public void e() {
        Log.e("HapticPlayer", "not support Haptic player api, stop");
    }
    
    public void f(final int n) {
        Log.e("HapticPlayer", "not support Haptic player api, updateAmplitude with amplitude");
    }
    
    public void g(final int n) {
        Log.e("HapticPlayer", "not support Haptic player api, updateFrequency with freq");
    }
    
    public void h(final int n) {
        Log.e("HapticPlayer", "not support Haptic player api, updateInterval with interval");
    }
    
    public void i(final int n, final int n2, final int n3) {
        Log.e("HapticPlayer", "not support Haptic player api, updateParameter with interval/amplitude/freq");
    }
}
