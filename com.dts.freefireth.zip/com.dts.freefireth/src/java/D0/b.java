package D0;

import G0.g;

public abstract class b
{
    public final int a;
    public final int b;
    
    public b(final int a, final int b) {
        this.a = a;
        this.b = b;
    }
    
    public abstract void a(final g p0);
}
