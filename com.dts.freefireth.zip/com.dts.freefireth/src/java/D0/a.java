package d0;

public abstract class a
{
    public static int a = 2131296419;
}
